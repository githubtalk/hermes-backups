# D1 Batch SQL — template

## Rules
- **No BEGIN/COMMIT** — D1 file mode rejects transactions
- **One statement per line** — execute all at once
- **Quote strings** — single quotes around string values, backtick-safe names

## Pattern
```sql
UPDATE products SET image_url = 'https://www.shengtuo-tractor.com/uploadfile/FILENAME.jpg' WHERE id = N;
UPDATE products SET name = 'Product Name' WHERE id = N;
UPDATE products SET description = '...' WHERE id = N;
```

## Verify before running
```bash
cd /home/ubuntu/cf_b2b && CLOUDFLARE_API_TOKEN="cfut_..." \
  npx wrangler d1 execute b2b_database --file=/tmp/update.sql --remote 2>&1 | grep rows_written
```

## Common queries
```sql
-- Preview
SELECT id, name, image_url FROM products WHERE id BETWEEN 1 AND 10;

-- Image update (site photos)
UPDATE products SET image_url = 'https://www.shengtuo-tractor.com/uploadfile/FILENAME.jpg' WHERE id = N;

-- Name update
UPDATE products SET name = 'Normalized Name' WHERE id = N;

-- Specs update
UPDATE products SET hp_range = '185-220HP', key_spec = 'Front PTO, New Hood' WHERE id = N;
```

## Image URL source
Base: `https://www.shengtuo-tractor.com/uploadfile/`

Known valid files (2026 products):
- `202522696126099.jpg` — ST2404
- `20252269022442.jpg` — ST504E
- `2025226853232798.jpg` — ST404
- `202522685248314.jpg` — ST504
- `2025226850147150.jpg` — ST804
- `2025226836565037.jpg` — ST704
- `2025226834184905.jpg` — ST804 Garden
- `202522683152783.jpg` — ST1154
- `2025226829479411.jpg` — ST1354
- `202522682641265.jpg` — ST1404
- `2025226823229802.jpg` — ST1604
- `2025226817568743.jpg` — ST1804
- `2025226813427362.jpg` — ST2204 New Hood
- `202522681071030.jpg` — ST2204
- `202522687293417.jpg` — ST604
- `202522684342389.jpg` — ST504 Cabin
- `2025228818317577.jpg` — Front Loader
- `201745155085167.jpg` — Plow Plough
- `2017451450474178.jpg` — Disc Harrow
- `202522886294924.jpg` — Hay Baler
- `2017451616517641.jpg` — Hydraulic Plough
- `20252271141492268.jpg` — Flail Mower
- `2025227115285978.jpg` — Slasher Mower
- `20252271156459132.jpg` — Post Hole Digger
- `202522712167156.jpg` — Pipe Laying Machine
- `2025227145137471.jpg` — 1GQN Rotary Tiller
- `20252271410187669.jpg` — 1GLN Rotary Tiller
- `20252271426345841.jpg` — Disc Plough
- `20252271422525440.jpg` — 7CX Trailer
- `2025227143061710.jpg` — 3Z Cultivator
- `20252271432542418.jpg` — Adjustable Ridge
- `20252271435484436.jpg` — 3S Subsoiler
- `20252271440265379.jpg` — Box Grader
- `20252271449495374.jpg` — Corn Seeder
- `20252271453356703.jpg` — CRD-600 Spreader
- `20252271459346406.jpg` — Potato Harvester