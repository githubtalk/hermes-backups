# Shengtuo SEO Keyword Framework

## Homepage Title (Google-complementary)
```
China Shengtuo Farm Tractor Manufacturer | 25HP-260HP Agricultural Tractors & Farm Equipment
```
Reference: blog.easiwin.com — recommends not just brand词 but brand + product + buyer词 + long-tail.

## Keyword Hierarchy (100+ keywords, organized by intent)

### Tier 1: Brand Keywords (Homepage / About)
| Keyword | Notes |
|---------|-------|
| China Shengtuo Tractor | geo + brand |
| Shengtuo Tractor | primary brand |
| Shengtuo Farm Tractor | product type |
| Shengtuo Agricultural Tractor | alternative product type |
| Shengtuo Heavy Industry | parent company |
| Shandong Shengtuo Tractor | geo + brand |
| Chinese Tractor Manufacturer | country + type |
| China Farm Tractor Factory | factory signal |
| China Tractor Supplier | buyer intent |
| China Agricultural Machinery Manufacturer | broad category |

### Tier 2: Product Keywords (by HP range)
**Small HP (25-50HP):**
- 25HP Tractor, 30HP Tractor, 40HP Tractor, 50HP Tractor
- Compact Tractor, Mini Farm Tractor, Small Farm Tractor, Garden Tractor

**Medium HP (60-100HP):**
- 60HP Tractor, 70HP Tractor, 80HP Tractor, 90HP Tractor, 100HP Tractor
- Utility Tractor

**Large HP (120-260HP):**
- 120HP Tractor, 140HP Tractor, 160HP Tractor, 180HP Tractor
- 220HP Tractor, 240HP Tractor, 260HP Tractor
- Heavy Duty Farm Tractor

### Tier 3: Buyer Intent Keywords (highest conversion)
| Keyword | Intent |
|---------|--------|
| Farm Tractor for Sale | Transaction |
| China Tractor Exporter | Transaction |
| Tractor Manufacturer China | Transaction |
| Wholesale Farm Tractor | Transaction |
| Farm Tractor Supplier | Commercial |
| OEM Tractor Manufacturer | B2B |
| Agricultural Tractor Factory | B2B/manufacturing |
| Farm Tractor Price | Commercial |
| Buy Farm Tractor | Transaction |

### Tier 4: Farm Equipment Keywords (for implements category)
Rotary Tiller, Disc Harrow, Disc Plough, Reversible Plough, Front Loader, Backhoe Loader, Hay Baler, Flail Mower, Post Hole Digger, Farm Implements, Agricultural Machinery, Farm Equipment

### Tier 5: Long-tail SEO (easy rankings, high intent)
- China 50HP Tractor Manufacturer
- 4WD Farm Tractor for Sale
- Best Tractor for Small Farm
- Diesel Farm Tractor China
- Agricultural Tractor Supplier
- Compact Tractor Manufacturer
- 100HP Farm Tractor Price
- Heavy Duty Agricultural Tractor
- Farm Tractor with Front Loader
- CE Farm Tractor Manufacturer
- OEM Agricultural Tractor
- Farm Equipment Manufacturer China

### Tier 6: Model Number Keywords (per-product SEO)
ST504 Tractor, ST704 Tractor, ST804 Tractor, ST904 Tractor, ST1004 Tractor,
ST1154 Tractor, ST1354 Tractor, ST1604 Tractor, ST1804 Tractor,
ST2204 Tractor, ST2404 Tractor

### Tier 7: Country Market Keywords (export targeting)
Australia Tractor Supplier, South Africa Farm Tractor, Brazil Tractor Manufacturer, Romania Agricultural Tractor

## Implementation in layout.js

Default keywords array in `src/pages/layout.js` — 100+ keywords organized by tier.

Product detail pages get dynamic keywords from DB: `hp_range`, `key_spec`, `category` fields.

## Homepage Meta Description
```
Shandong Shengtuo Heavy Industry is a professional China farm tractor manufacturer supplying 25HP–260HP agricultural tractors, compact tractors, garden tractors and farm implements worldwide. OEM & wholesale service available.
```

## Sitemap Strategy
- 4 static pages (Home, Products, About, Contact) — weekly changefreq
- 42 product pages — weekly changefreq
- Product pages prioritized at 0.8, Home at 1.0

## robots.txt
```
User-agent: *
Allow: /
Disallow: /api/
Disallow: /admin/
Sitemap: https://cf-b2b-website.sdtractor.workers.dev/sitemap.xml
Crawl-delay: 1
```

## Content Cluster Expansion Ideas (for 100-300 keywords)
1. **By HP model**: dedicated landing pages for each ST series
2. **By use case**: Orchard Tractor, Small Farm Tractor, Large Farm Tractor, Greenhouse Tractor
3. **By country**: Australia Tractor, South Africa Tractor, Brazil Tractor (localized content)
4. **By feature**: 4WD Tractor, Cab Tractor, Tractor with Front Loader, PTO Tractor
5. **Buying guides**: How to Choose a Tractor, Tractor Maintenance Tips, etc.