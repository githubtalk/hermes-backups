# shengtuo-tractor.com — Product Name Map

## DB Products (42 total)
Category: `SHENGTUO TRACTOR` (18) | `SHENGTUO FARM EQUIPMENT` (24)

| DB Name | DB ID | Site Name | Site img |
|---------|-------|-----------|----------|
| ST1154 Tractor (80-120HP) | 8 | SHENGTUO ST1154 (80-120hp) Tractor | 202522683152783.jpg |
| ST1354 Tractor (100-140HP) | 9 | SHENGTUO ST1354 (100-140hp) Tractor | 2025226829479411.jpg |
| ST1404 Tractor | 10 | ST1404 SHENGTUO Tractor | 202522682641265.jpg |
| ST1604 Tractor (150-160HP) | 11 | ST1604 (150-160hp) SHENGTUO Tractor | 2025226823229802.jpg |
| ST1654 Tractor (145-165HP) | 12 | — | shengtuo.cc.cd |
| ST1854/ST2204 Tractor | 13 | ST1804(180-220hp) shengtuo Tractor | 2025226817568743.jpg |
| ST2204 New Hood Tractor | 6 | SHENGTUO ST2204 NEW HOOD TRACTOR | 2025226813427362.jpg |
| ST2204 Tractor (185-220HP) | 7 | ST2204 (185-220hp) SHENGTUO Tractor | 202522681071030.jpg |
| ST2404 Tractor with Front PTO Suspension | 4 | ST2404 tractor with front PTO suspension | 202522696126099.jpg |
| ST254 Tractor | — | — | shengtuo.cc.cd |
| ST304 Tractor | — | — | shengtuo.cc.cd |
| ST404 Tractor | 1 | SHENGTUO ST404（35-65HP）TRACTOR | 2025226853232798.jpg |
| ST504 Tractor (30-50HP) | 2 | SHENGTUO ST504（30-50hp) Tractor | 202522685248314.jpg |
| ST504 Tractor with Cabin | 57 | ST504 TRACTOR WITH CABIN | 202522684342389.jpg |
| ST504E Tractor | 14 | SHENGTUO ST504E TRACTOR | 20252269022442.jpg |
| ST604 Garden Tractor | 15 | ST604 GARDEN TRACTOR | 202522687293417.jpg |
| ST704 Tractor | 5 | SHENGTUO ST704（40-70hp）Tractor | 2025226836565037.jpg |
| ST804 Garden Tractor (60-80HP) | 16 | SHENGTUO ST804(60-80hp) Garden Tractor | 2025226834184905.jpg |
| ST804 Tractor (55-80HP) | 3 | SHENGTUO ST804 (55-80hp) Tractor | 2025226850147150.jpg |
| 1GQN Heavy Duty Rotary Tiller | 61 | 1GQN Heavy duty Rotary Tiller | 2025227145137471.jpg |
| 25HP-80HP Tractor Engine Parts | 17 | — | shengtuo.cc.cd |
| Hydraulic Reversible Plough | 21 | Hydraulic reversible plough | 2017451616517641.jpg |
| SHENGTUO Plow Plough | 58 | SHENGTUO PLOW PLOUGH | 201745155085167.jpg |
| Shengtuo 1GLN Series Rotary Tiller | 62 | Shengtuo 1GLN series Rotary Tiller | 20252271410187669.jpg |
| Shengtuo 3S Series Subsoiler | 66 | Shengtuo 3S Series Subsoiler | 20252271435484436.jpg |
| Shengtuo 3Z Cultivator | 64 | Shengtuo 3Z Cultivator | 2025227143061710.jpg |
| Shengtuo Adjustable Ridge Machine | 65 | Shengtuo Adjustable Ridge Machine | 20252271432542418.jpg |
| Shengtuo Baler | 26 | Shengtuo tractor Hay Round Baler | 202522886294924.jpg |
| Shengtuo Box Grader | 67 | Shengtuo Box Grader | 20252271440265379.jpg |
| Shengtuo Corn Seeder | 68 | Shengtuo Corn Seeder | 20252271449495374.jpg |
| Shengtuo CRD-600 Spreader | 69 | Shengtuo CRD-600 Spreader | 20252271453356703.jpg |
| Shengtuo Disc Harrow | 25 | Shengtuo Disc Harrow | 2017451450474178.jpg |
| Shengtuo Disc Plough | 63 | Shengtuo Disc Plough | 20252271426345841.jpg |
| Shengtuo Flail Mower | 22 | Shengtuo Flail Mower | 20252271141492268.jpg |
| Shengtuo Front Loader and Backhoe | 20 | SHENGTUO FRONT LOADER AND BACKHOE | 2025228818317577.jpg |
| Shengtuo Pipe Laying Machine | 60 | Shengtuo pipe laying machine | 202522712167156.jpg |
| Shengtuo Potato Harvester | 70 | Shengtuo Potato Harvester | 20252271459346406.jpg |
| Shengtuo Post Hole Digger | 23 | Shengtuo Post Hole Digger | 20252271156459132.jpg |
| Shengtuo Rotary Tiller | 24 | — | shengtuo.cc.cd |
| Shengtuo Seed Drill | 19 | — | shengtuo.cc.cd |
| Shengtuo Slasher Mower | 59 | shengtuo slasher mower | 2025227115285978.jpg |
| Shengtuo Sprayer | 18 | — | shengtuo.cc.cd |
| Shengtuo Trailer | 27 | Shengtuo 7CX Series farm Trailer | 20252271422525440.jpg |

## Key Notes
- Site has 37 products; DB has 42. 5 products (ST254, ST304, ST1654, Engine Parts, Seed Drill, Rotary Tiller, Sprayer) only on DB.
- Site is **Error 1016** but images still serve (HTTP 200).
- Product match key: extract `ST\d+[A-Z]*` regex from site name.