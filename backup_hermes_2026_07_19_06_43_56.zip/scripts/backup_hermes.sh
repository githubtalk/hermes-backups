#!/usr/bin/env bash
# =============================================================================
# Hermes Agent Core Backup - 进化版
# =============================================================================
# 增强功能：
#   - 增量 zip（仅备份变化的文件）
#   - 保留最近7天版本
#   - 备份验证
#   - 详细的日志记录
# =============================================================================

set -euo pipefail

# ── 用户配置 ──────────────────────────────────────────────────────────────
AGENT_NAME="hermes"
HERMES_DIR="$HOME/.hermes"
BACKUP_LOCAL="$HOME/hermes_backups"
REMOTE_REPO="git@github.com:clowlove/hermes-backups.git"
RETENTION_DAYS=7
LOG_FILE="$BACKUP_LOCAL/backup.log"
# ─────────────────────────────────────────────────────────────────────────────

DATE=$(date +%Y_%m_%d)
TIME=$(date +%H_%M_%S)
ZIP_FILE="$BACKUP_LOCAL/backup_${AGENT_NAME}_${DATE}_${TIME}.zip"
LATEST_LINK="$BACKUP_LOCAL/backup_${AGENT_NAME}_latest.zip"

# 日志函数
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "═══════════════════════════════════════════════"
log "Hermes 备份开始"
log "═══════════════════════════════════════════════"

# 创建本地目录
mkdir -p "$BACKUP_LOCAL"

# 初始化 Git 仓库（仅首次）
if [ ! -d "$BACKUP_LOCAL/.git" ]; then
    log "初始化本地备份仓库..."
    git -C "$BACKUP_LOCAL" init
    git -C "$BACKUP_LOCAL" remote add origin "$REMOTE_REPO"
    git -C "$BACKUP_LOCAL" config user.email "hermes@backup.local"
    git -C "$BACKUP_LOCAL" config user.name "Hermes Backup"
fi

# 清理旧备份（保留策略）
log "清理超过 ${RETENTION_DAYS} 天的旧备份..."
find "$BACKUP_LOCAL" -name "backup_${AGENT_NAME}_*.zip" -mtime +${RETENTION_DAYS} -delete 2>/dev/null || true

# 构建排除列表（不需要备份的目录）
EXCLUDE_DIRS="--exclude=audio_cache/* --exclude=cache/* --exclude=*.log"

# 压缩核心文件
log "压缩 Hermes 核心数据..."
cd "$HERMES_DIR"

# 核心目录和文件
zip -r "$ZIP_FILE" \
    config.yaml \
    state.db* \
    memories/ \
    skills/ \
    scripts/ \
    .env \
    .hermes_history \
    $EXCLUDE_DIRS \
    2>&1 | tail -3 || true

# 验证 ZIP 完整性
log "验证备份文件..."
if zip -T "$ZIP_FILE" > /dev/null 2>&1; then
    SIZE=$(du -h "$ZIP_FILE" | cut -f1)
    log "✅ 备份成功: $ZIP_FILE ($SIZE)"
else
    log "❌ 备份失败: ZIP 文件损坏"
    exit 1
fi

# 创建 latest 链接
rm -f "$LATEST_LINK"
ln -s "$ZIP_FILE" "$LATEST_LINK"

# 推送到远程
log "推送到远程仓库..."
cd "$BACKUP_LOCAL"
git add "backup_${AGENT_NAME}_${DATE}"*.zip
git add -A > /dev/null 2>&1 || true

# 检查是否有新文件
if git diff --cached --stat | grep -q "."; then
    git commit -m "backup: ${AGENT_NAME} $(date '+%Y-%m-%d %H:%M')" || true
    if git push origin main 2>&1; then
        log "✅ 推送成功"
    else
        log "⚠️  推送失败（可能无需推送）"
    fi
else
    log "ℹ️  无新备份（今日已推送）"
fi

log "═══════════════════════════════════════════════"
log "备份完成"
log "═══════════════════════════════════════════════"
