User speaks Chinese (Mandarin). Telegram account: Talkcn (ID: 522296847). Cautious about destructive operations — denied git hard reset to upstream/main.
§
用户使用中文交流，偏好简洁直接的回复风格。
§
用户: 亨利 (Henry)，中文交流，偏好简洁直接。喜欢自己操作平台验证（Cloudflare等），技术活交给我处理。授权型——给方向后让我自主执行，不需要每步确认。

服务器: 43.155.135.188 (本机)，nginx + php8.3-fpm 已配置。网站文件在 /var/www/wordpress-new。
§
用户风格：授权型 — "你去做吧"，给方向后让我自主执行，不需要每步确认。喜欢简洁直接的汇报（完成/失败/下一步）。**做错了会直接骂（"笨蛋"、"你真笨"）——必须先诊断再动手，不要盲目尝试。**
§
Henry (亨利)，中文交流，偏好简洁直接。喜欢自己操作平台验证（Cloudflare、GCP Console等），技术活交给我处理。授权型——给方向后让我自主执行，不需要每步确认。
§
服务器: 43.155.135.188 (本机)，nginx + php8.3-fpm 已配置。网站文件在 /var/www/wordpress-new。
§
GCP 新机器：35.212.209.223，root，Debian 13，Hermes 已装。GCP 防火墙默认拦 22 端口，需通过浏览器 SSH 操作。
§
GitHub PAT (githubtalk): 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。backup 脚本里的 remote clowlove/hermes-backups 实际不存在/无权限，需用 githubtalk 账号下仓库。
§
用户偏好直接执行 - "你直接调动就可以" 意味着不需要每次都询问确认。执行后再汇报结果。
§
网站工作重要规则：用户明确要求"不要动原来的产品结构"。做 SEO 优化和视觉美化时，只能改 CSS/JS/meta，绝对不能替换产品列表的 HTML 结构（表格、卡片布局等）。先恢复原版再叠加改进，不要整体重写。
§
Henry site preferences: light-color business style, compact layout, no dark backgrounds, mobile-friendly. CDN bypass via renames. Rule: never move original product structure; only touch CSS/JS/meta for SEO/visual work.