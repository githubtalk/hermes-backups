Hermes .env file is protected from the patch tool — must use terminal/sed to edit it. Always verify line numbers with grep -n first.
§
亨利 (Henry)，中文，偏好简洁直接，授权型（给方向后自主执行，不需每步确认）。做错了会直接骂——必须先诊断再动手，不要盲目尝试。
§
GCP Hermes 实例：35.212.209.223、35.212.168.70，均为 root/661474ef。SSH 需解封 Fail2Ban。已部署 backup_hermes.sh + cron，仓库 githubtalk/hermes-backups。
§
Sing-box：35.212.168.70，/etc/s-box/，版本 1.14.0-alpha.47。busybox httpd 监听 49799 端口提供订阅，UUID bbaa6c8f-acd5-4bb4-8130-0964e71e5d6b，路径 /root/websbox/{uuid}/jhsub.txt。外部访问需 GCP 防火墙开 tcp:49799。
§
GitHub PAT (githubtalk): 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
§
备份系统已部署：hermes-backups 私有仓库，backup_hermes.sh + restore_hermes.sh，cron 每天 01:00
§
Cron 任务：Hermes Curator 每周日 10:00 运行，报告推送到 Telegram
§
调试网站问题需 SSH 到 AWS，连接信息见 devops/references/remote-hermes-ops.md
§
ago.sld.tw 上线：NPM代理到8087 → Nginx+PHP8.1+MySQL → /root/shengtuo-website。账号：shengtuo / ShengTuo2026!。Nginx配置：/etc/nginx/sites-available/shengtuo。
§
ago.sld.tw：154.41.135.101 /root/shengtuo-website；Nginx 8087；MySQL shengtuo_website / shengtuo / ShengTuo2026!；/etc/nginx/sites-available/shengtuo。缺php8.1-mbstring会造成新闻页 mb_substr() 500。
§
主模型：step-3.7-flash (stepfun, Base URL: https://api.stepfun.com/step_plan/v1, Key: 3Dc4DLtm..., OpenAI Chat Completions: /chat/completions, Claude Messages: /messages)
§
Cloudflare API Token 权限：Workers/D1/KV/R2 都需要 Account:Edit，R2+KV 创建可能需要已添加付款方式。GitHub 内容获取失败401时用 curl -sL raw.githubusercontent.com 代替。