const sharp = require('sharp');
const path = require('path');
const fs = require('fs');

const imagesDir = path.join(__dirname, 'images');
const files = fs.readdirSync(imagesDir).filter(f => 
  /\.(jpg|jpeg|png)$/i.test(f) && !f.startsWith('.')
);

let savedBytes = 0;
let skipped = 0;
let errors = 0;

async function processFile(file) {
  const filePath = path.join(imagesDir, file);
  const ext = path.extname(file).toLowerCase();
  const stats = fs.statSync(filePath);
  const originalSize = stats.size;

  try {
    const pipeline = sharp(filePath);
    let newBuffer;

    if (ext === '.jpg' || ext === '.jpeg') {
      newBuffer = await pipeline
        .jpeg({ quality: 75, progressive: true })
        .toBuffer();
    } else if (ext === '.png') {
      newBuffer = await pipeline
        .png({ compressionLevel: 9 })
        .toBuffer();
    }

    if (newBuffer && newBuffer.length < originalSize) {
      const savedBytes2 = originalSize - newBuffer.length;
      savedBytes += savedBytes2;
      fs.writeFileSync(filePath, newBuffer);
      const savedKB = (savedBytes2 / 1024).toFixed(0);
      const origKB = (originalSize / 1024).toFixed(0);
      const newKB = (newBuffer.length / 1024).toFixed(0);
      console.log(`✓ ${file}: ${origKB}KB → ${newKB}KB (-${savedKB}KB)`);
    } else {
      console.log(`○ ${file}: no significant gain, skipped`);
      skipped++;
    }
  } catch (err) {
    console.log(`✗ ${file}: error - ${err.message}`);
    errors++;
  }
}

(async () => {
  for (const file of files) {
    await processFile(file);
  }
  console.log(`\nDone: ${files.length} files, total saved: ${(savedBytes/1024).toFixed(0)}KB`);
  if (skipped) console.log(`Skipped (no gain): ${skipped}`);
  if (errors) console.log(`Errors: ${errors}`);
})();