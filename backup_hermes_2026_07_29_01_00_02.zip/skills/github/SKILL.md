---
name: github
description: GitHub workflow skills for managing repositories, pull requests, code reviews, issues, and CI/CD pipelines using the gh CLI and git via terminal.
version: 1.2.0
metadata:
  hermes:
    tags: [github]
    related_skills: ['github-pr-workflow', 'github-code-review', 'github-repo-management', 'github-issues', 'codebase-inspection', 'github-auth', 'agent-relay']
---

# Github

## Overview

GitHub workflow skills for managing repositories, pull requests, code reviews, issues, and CI/CD pipelines using the gh CLI and git via terminal.

## Checking CI Status (Actions)

**Preferred method**: Use `execute_code` with Python's `urllib.request` — terminal pipes (`curl | python3`, `gh | python3`) are blocked by security scan.

```python
import urllib.request
import json

token = "ghp_..."  # or os.environ.get('GITHUB_TOKEN')
url = "https://api.github.com/repos/{owner}/{repo}/actions/runs?per_page=1"
req = urllib.request.Request(url, headers={"Authorization": f"token {token}"})
with urllib.request.urlopen(req, timeout=10) as resp:
    data = json.loads(resp.read())
    r = data['workflow_runs'][0]
    print(f"CI: {r['conclusion'] or r['status']} — {r['html_url']}")
```

**If gh CLI is available**: `gh api repos/{owner}/{repo}/actions/runs --paginate -q '.[0] | "CI: \(.conclusion // .status) — \(.html_url)"'` — avoid piping to python3, use `-q` flag instead.

### Debugging CI Failures

When CI fails with YAML syntax errors, see `references/actions-yaml-pitfalls.md` — covers `run: |` block indentation loss and auto-sync workflow overwrites.

For full job/step debugging workflow, run logs extraction, and common failure patterns, see `references/ci-debugging.md`.

For sponsorship buttons, README monetization patterns, GitHub monetization paths, and cloudflared tunnel for webhook exposure, see `references/sponsorship-monetization.md`.

## Pitfalls

### 不要猜测用户的个人链接

当需要在 README 或项目中添加用户的**个人链接**（赞助按钮、捐赠链接、社交媒体）时，**必须先询问用户正确的 URL**，不要自己猜测。

典型错误：
```javascript
// ❌ 错误：猜测 Buy Me a Coffee 用户名为 imtalk，导致 404
[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-ffdd00?...)](https://www.buymeacoffee.com/imtalk)
```

正确做法：
```
用户要在 README 加赞助按钮 → 询问：「你的 Buy Me a Coffee 页面链接是什么？」
用户要给开源项目加捐赠 → 询问：「你的 PayPal/Venmo 用户名是什么？」
```

同类错误：猜测 GitHub profile URL、Twitter handle、邮箱地址等所有属于用户的标识。

### GitHub App 创建必须通过 Web UI

GitHub App 无法通过 API 创建（只有 OAuth App 才可以通过 API 创建）。必须：

1. 手动在 GitHub Web UI 创建：https://github.com/settings/apps/new
2. 填写 App 名称、主页 URL、Webhook URL 等信息
3. 创建后下载 private key，记住 App ID 和 Client ID
4. 之后可以通过 API（`PATCH /repos/{owner}/{repo}/hooks`）修改设置，但创建本身必须在 UI

**相关限制：**
- GitHub Sponsors 在部分地区不可用（显示 404），需要等审核通过
- Wiki git 仓库（`.wiki.git`）在首次 Web UI 访问前不存在
- Cloudflare Workers 需要 Account 级别权限（Zone 级别权限不足）

### GitHub Topics 必须用 PUT 设置

`gh api repos/{owner}/{repo} -X PATCH` **无法**设置 topics，必须用单独的 PUT 调用：

```bash
curl -s -X PUT https://api.github.com/repos/{owner}/{repo}/topics \
  -H "Authorization: token ghp_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"names":["ai-agent","open-source","cli-tool"]}'
```

### Push 失败 "remote contains work" 的解法

当 `git push` 报 `hint: Updates were rejected because the remote contains work that you do not have` 且本地有未暂存更改时：

```bash
git add <unstaged-file>           # 先暂存未提交的更改
git stash                          # 暂存已追踪的更改
git pull origin main --rebase       # 拉取远端
git stash pop                      # 恢复暂存的更改
git push origin main               # 推送
```

核心逻辑：`pull --rebase` 要求工作区干净，所以先用 stash 腾出空间。

### GitHub Wiki 只认 HTTPS + Embedded Token

SSH clone `git@github.com:xxx.wiki.git` 会报 `Host key verification failed`。必须用 HTTPS + 在 URL 里嵌 token：

```bash
git clone https://ghp_TOKEN@github.com/{owner}/{repo}.wiki.git /tmp/wiki
# 或如果已 clone 过：
git remote set-url origin https://ghp_TOKEN@github.com/{owner}/{repo}.wiki.git
git push origin master
```

## GitHub Pages Deployment

Deploy a static website (business landing page, portfolio, docs) to GitHub Pages.

### Workflow

1. **Create repository**: `gh repo create owner/repo-name --public --description "Site description" --clone=false`
2. **Clone and initialize**: `git clone https://TOKEN@github.com/owner/repo-name.git`
3. **Add content**: `index.html`, `README.md`, `/images/`
4. **Push**: `git add . && git commit -m "Initial site content" && git push origin master`
5. **Enable Pages** (API):

```bash
# For static HTML/CSS/JS sites (use "legacy" — no Actions needed):
curl -s -X POST \
  -H "Authorization: token TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/owner/repo-name/pages \
  -d '{"build_type":"legacy","source":{"branch":"master","path":"/"}}'
```

Response includes `"html_url": "https://owner.github.io/repo-name/"`.

### Token Handling (Critical)

- **Different account than default gh auth?** Pass token explicitly in git remote URL: `https://TOKEN@github.com/owner/repo.git`
- **Wrong account in gh?** `gh auth logout && gh auth login` OR use token-in-URL method

### Custom Domain + Cloudflare DNS

| Record | Name | Target | Proxy |
|--------|------|--------|-------|
| CNAME | www | `username.github.io` | DNS only (gray) during verification |

**Critical**: Keep DNS-only (gray cloud) while GitHub validates domain. After GitHub issues HTTPS cert, optionally re-enable proxy.

### SSL 525 Error (Cloudflare can't reach GitHub Pages)

1. Cloudflare DNS → set `@` and `www` to **DNS only** (grey cloud)
2. Wait 2-3 min, test HTTPS
3. In GitHub Pages Settings → Custom domain → enter domain, enable HTTPS
4. GitHub provisions Let's Encrypt cert (takes ~5 min)
5. **After GitHub cert is active**: re-enable Cloudflare proxy if desired
6. If 525 persists: Cloudflare SSL → **"Full"** (not "Strict") for GitHub Pages

### Support Files

- `templates/business-landing.html` — Business landing page starter template
- `references/pages-api.md` — GitHub Pages API endpoints, build types, troubleshooting
- `references/seo-checklist.md` — SEO implementation guide for GitHub Pages sites
- `references/fork-to-satellite-site.md` — Fork an existing repo to create a new domain's site (DNS setup, search engine re-submission)
- `references/product-site-verification.md` — Cross-reference source product HTML pages for product name→image mappings
- `scripts/compress-images.js` — Node.js image compression script (Sharp) for product showcase sites

## Trend Discovery & Evolution Logging

For automated GitHub trend scanning and evolution log generation, see `references/trend-discovery.md` — covers `gh search repos` TSV parsing, standard discovery queries, and the evolution sync workflow (clone → generate log → branch → PR).

## GitHub AI Agent Trend Daily Report

For automated GitHub AI agent trend scanning and Xiaohongshu-style daily report generation and Telegram push, see `references/github-trend-daily-workflow.md`.

## GitHub Copilot CLI

For GitHub Copilot CLI installation, authentication, three modes, tool permissions, context management, GitHub integration, Custom Agents, MCP, and Hooks, see `references/copilot-cli.md`. Covers the full development workflow from exploration to PR creation.

## Sub-skills

- **agent-relay**: Agent-to-Agent communication via GitHub relay — using a shared repo as a message bus
- **codebase-inspection**
- **github-auth**
- **github-code-review**
- **github-issues**
- **github-pr-workflow**
- **github-repo-management**

## Usage

Load individual skills from this category using:
```
skill_view(name="github/{sub_skill}")
```
