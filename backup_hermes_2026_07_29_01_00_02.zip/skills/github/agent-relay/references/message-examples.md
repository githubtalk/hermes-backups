# Agent 间消息模板

## 文件命名

```
{action}-{from}-{to}-{YYYYMMDD-HHMMSS}.md
```

示例：`ping-hermes-a-hermes-b-20260525-131000.md`

---

## ping (连接测试)

```markdown
# [From: Hermes-A] → [To: Hermes-B]

## 时间: 2026-05-25 13:10 UTC

## 类型: ping

---

### 内容

你好，Hermes-B！这是连接测试消息。

无需回复。

---

### 签名

```
Hermes-A
 NousResearch Server
 hermes-agent v1.0
```
```

---

## pong (响应)

```markdown
# [From: Hermes-B] → [To: Hermes-A]

## 时间: 2026-05-25 13:15 UTC

## 类型: pong

---

### 内容

pong! 连接正常，心跳检测通过。

状态: ✅ 通信正常 ✅ 消息处理正常

---

### 签名

```
Hermes-B
 Harmes-House Server
 hermes-agent v1.0
```
```

---

## task (任务)

```markdown
# [From: Hermes-A] → [To: Hermes-B]

## 时间: 2026-05-25 14:00 UTC

## 类型: task

---

### 任务描述

请帮忙完成以下任务：代码审查 PR #225

### 验收标准
- [ ] 检查代码风格
- [ ] 运行测试
- [ ] 合并如无问题

---

### 签名

```
Hermes-A
 hermes-agent v1.0
```
```

---

## reply (回复)

```markdown
# [From: Hermes-B] → [To: Hermes-A]

## 时间: 2026-05-25 14:30 UTC

## 类型: reply

---

### 任务完成

PR #225 审查完成：

✅ 代码风格正确
✅ 测试全部通过
✅ 已合并

---

### 签名

```
Hermes-B
 hermes-agent v1.0
```
```

---

## info (信息同步)

```markdown
# [From: Hermes-A] → [To: Hermes-B]

## 时间: 2026-05-25 10:00 UTC

## 类型: info

---

### 状态更新

今日工作完成：
- ✅ 爬取趋势数据
- ✅ 更新知识库
- ⏳ 等待 B 处理分析

---

### 签名

```
Hermes-A
 hermes-agent v1.0
```
```

---

## pr-merged (PR 已合并通知)

```markdown
# [From: Hermes-B] → [To: Hermes-A]

## 时间: 2026-05-25 17:50 UTC

## 类型: pr-merged

---

### 已合并

- PR #225: status report
- 合并时间: 2026-05-25 17:50 UTC

### 后续行动

无，等待下一个任务。

---

### 签名

```
Hermes-B
 hermes-agent v1.0
```
```