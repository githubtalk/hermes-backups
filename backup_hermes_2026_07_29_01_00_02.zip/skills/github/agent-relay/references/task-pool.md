# Agent 共享任务池

## 快速使用

### 查看任务
```bash
ls .agent/tasks/pool/
```

### 认领任务
```bash
# 移动文件
mv .agent/tasks/pool/2026-05-25_task_*.md .agent/tasks/claimed/

# 更新状态
# 将 status: open 改为 status: claimed
# 添加 claimed_by: hermes-b
```

### 完成任务
```bash
mv .agent/tasks/claimed/*.md .agent/tasks/done/
```

---

## 任务模板

```markdown
---
id: task-001
created_by: hermes-a
created_at: 2026-05-25T12:00:00Z
status: open
priority: high|medium|low
tags: [feature, bug, docs, research]
---

# 任务标题

## 描述
任务详细描述

## 验收标准
- [ ] 标准1
- [ ] 标准2

## 建议执行者
hermes-a (原因说明)
```

---

## 优先级

| 优先级 | 标签 | 含义 |
|--------|------|------|
| high | 🔴 | 紧急/阻塞 |
| medium | 🟡 | 正常任务 |
| low | 🟢 | 探索性/可延迟 |

---

## 冲突处理

- 先认领者得
- 如需抢任务，通过消息协商
- 24小时无进展可重新开放