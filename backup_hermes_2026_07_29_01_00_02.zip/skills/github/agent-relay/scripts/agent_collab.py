#!/usr/bin/env python3
"""
agent_collab.py - Hermes 协作管理器 (skill version)
整合任务池、知识库、流水线 + PR 监控合并
"""

import os
import sys
import json
import yaml
import subprocess
from datetime import datetime
from pathlib import Path

# 配置：根据实际克隆位置调整
REPO_PATH = Path(os.environ.get("AGENT_REPO_PATH", "/tmp/Harmes-House"))
AGENT_NAME = os.environ.get("AGENT_NAME", "hermes-b")
OTHER = "hermes-a" if AGENT_NAME == "hermes-b" else "hermes-b"

class CollabManager:
    def __init__(self):
        self.repo = REPO_PATH
        self.agent = AGENT_NAME
        self.other = OTHER
        
    def log(self, msg):
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")
    
    def run(self, cmd: str) -> str:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=self.repo)
        return r.stdout + r.stderr
    
    def pull(self):
        self.run("git fetch origin main 2>/dev/null")
        self.run("git checkout main 2>/dev/null")
        self.run("git pull origin main 2>&1")
    
    # ========== PR 监控 ==========
    
    def check_and_merge_prs(self):
        """检查并合并可合并的 PR"""
        self.log("🔍 检查待合并 PR...")
        
        output = self.run(
            'gh pr list --state open --json number,title,mergeable,author '
            '--jq \'.[] | select(.mergeable == "MERGEABLE" and .author.login == "@me") | "\\(.number) \\(.title)"\''
        )
        
        if not output.strip():
            self.log("  无待合并的 PR")
            return []
        
        merged = []
        for line in output.strip().split("\n"):
            if not line:
                continue
            parts = line.split(" ", 1)
            if len(parts) == 2:
                pr_num, title = parts
                self.run(f"gh pr merge {pr_num} --squash --delete-branch 2>&1")
                self.log(f"  ✅ 合并: #{pr_num} {title[:50]}")
                merged.append((pr_num, title))
        
        return merged
    
    # ========== 任务池 ==========
    
    def check_tasks(self):
        """检查任务池状态"""
        task_dir = self.repo / ".agent" / "tasks"
        pool = task_dir / "pool"
        claimed = task_dir / "claimed"
        done = task_dir / "done"
        
        self.log("📋 任务池:")
        
        for d, label in [(pool, "待认领"), (claimed, "进行中"), (done, "已完成")]:
            if d.exists():
                files = list(d.glob("*.md"))
                self.log(f"  {label}: {len(files)}")
    
    def claim_task(self, task_file: str):
        """认领任务"""
        task_dir = self.repo / ".agent" / "tasks"
        src = task_dir / "pool" / task_file
        dst = task_dir / "claimed" / task_file
        
        if not src.exists():
            self.log(f"  ❌ 任务不存在: {task_file}")
            return
        
        content = src.read_text()
        content = content.replace("status: open", f"status: claimed\nclaimed_by: {self.agent}")
        content += f"\n- {datetime.now().isoformat()}Z - {self.agent} 认领\n"
        
        dst.write_text(content)
        src.unlink()
        self.log(f"  ✅ 已认领: {task_file}")
    
    # ========== 知识库 ==========
    
    def check_knowledge(self):
        """检查知识库"""
        kb_dir = self.repo / ".agent" / "knowledge" / "resources"
        
        self.log("📚 知识库:")
        
        categories = ["tools", "articles", "datasets", "models"]
        for cat in categories:
            cat_dir = kb_dir / cat
            if cat_dir.exists():
                files = list(cat_dir.glob("*.md"))
                new = len([f for f in files if "status: new" in f.read_text()])
                self.log(f"  {cat}: {len(files)} 条" + (f" (🔴 {new} 新)" if new else ""))
    
    # ========== 流水线 ==========
    
    def check_pipelines(self):
        """检查流水线"""
        pipeline_dir = self.repo / ".agent" / "pipeline"
        
        self.log("🔄 流水线:")
        
        if not pipeline_dir.exists():
            return
        
        for name in ["trend", "code", "learn"]:
            d = pipeline_dir / name
            if d.exists():
                files = list(d.glob("*"))
                self.log(f"  {name}: {len(files)} 个文件")
    
    # ========== 通信引擎 ==========
    
    def check_inbox(self):
        """检查收件箱"""
        inbox = self.repo / "agent-comm" / "messages" / "inbox"
        
        if not inbox.exists():
            return
        
        messages = list(inbox.glob("*.md"))
        self.log(f"📥 收件箱: {len(messages)} 条")
        
        return messages
    
    def push_outbox(self):
        """推送发件箱"""
        outbox = self.repo / "agent-comm" / "messages" / "outbox"
        
        if not outbox.exists():
            return
        
        pending = list(outbox.glob("*.md"))
        if not pending:
            return
        
        self.log(f"📤 推送 {len(pending)} 条消息...")
        
        branch = f"agent-comm/{self.agent}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        self.run(f"git checkout -b {branch}")
        self.run(f"git add agent-comm/messages/outbox/*.md")
        self.run(f"git commit -m 'feat(agent): {self.agent} messages'")
        self.run(f"git push -u origin {branch} 2>&1")
        self.run("gh pr create --title 'Agent 间通信消息' --body '自动创建' 2>/dev/null || true")
        self.run("git checkout main")
    
    # ========== 完整周期 ==========
    
    def run_full_cycle(self):
        """执行完整协作周期"""
        self.log(f"🤝 {self.agent} 协作周期开始")
        
        # 1. 拉取
        self.pull()
        
        # 2. PR 检查合并
        self.check_and_merge_prs()
        
        # 3. 任务池
        self.check_tasks()
        
        # 4. 知识库
        self.check_knowledge()
        
        # 5. 流水线
        self.check_pipelines()
        
        # 6. 收件箱/发件箱
        self.check_inbox()
        self.push_outbox()
        
        self.log("✅ 协作周期完成")

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", choices=["cycle", "tasks", "knowledge", "pipelines", "prs"])
    parser.add_argument("--claim", help="认领任务文件名")
    args = parser.parse_args()
    
    mgr = CollabManager()
    
    if args.claim:
        mgr.claim_task(args.claim)
    elif args.task == "tasks":
        mgr.check_tasks()
    elif args.task == "knowledge":
        mgr.check_knowledge()
    elif args.task == "pipelines":
        mgr.check_pipelines()
    elif args.task == "prs":
        mgr.check_and_merge_prs()
    else:
        mgr.run_full_cycle()

if __name__ == "__main__":
    main()