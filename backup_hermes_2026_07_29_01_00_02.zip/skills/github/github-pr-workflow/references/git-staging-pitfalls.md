# Git Staging Pitfalls

Common mistakes when staging files for commit.

## Accidentally Staged node_modules / Dependencies

When running `npm install` or `pip install` in a project directory, dependency folders get created. If you `git add .` without a `.gitignore`, they're staged.

**Fix before commit:**
```bash
# Unstage specific directory
git reset projects/<name>/node_modules

# Then create .gitignore and re-add cleanly
echo "node_modules/" >> projects/<name>/.gitignore
git add projects/<name>/.gitignore
git add <all the actual source files>
```

**Prevention:** Always create `.gitignore` BEFORE running install/build commands:
```bash
# Create project
mkdir -p projects/myproject/src
cd projects/myproject

# Create .gitignore FIRST
echo -e "node_modules/\ndist/\n*.log\n.env" > .gitignore

# NOW run npm install
npm install
```

## Branch Creation from Non-Commit Ref

```bash
# WRONG - 'assets' is not a commit
git checkout -b feature/monetization assets

# error: 'assets' is not a commit and a branch 'feature/monetization' cannot be created from it

# CORRECT - branch from current HEAD or explicit base branch
git checkout -b feature/monetization main

# OR from a specific commit SHA
git checkout -b feature/monetization abc123def
```

**Rule:** When creating a branch with `git checkout -b`, the second argument must be a valid ref (branch name, tag, or commit SHA), not a directory or file path.

## Staging All Files Except One

```bash
# Bad: stages everything including unwanted files
git add -A

# Better: stage specific paths
git add src/ tests/ README.md package.json

# Or stage by pattern, then verify
git add .
git status  # review before commit
git reset   # if you need to start over
```

**Never `git add -A`** on a branch with uncommitted junk files (node_modules/, dist/, *.log, evolution-log.md, key.pem, package-lock.json, etc.). `git add -A` stages everything and `git commit` locks it in.

**Documentation-only PRs — always explicitly list files:**
```bash
# Stage only README files (multilingual repo example)
git add README.md README.zh.md README.ar.md README.de.md
git add README.es.md README.fr.md README.ko.md README.pt.md README.ru.md

# Verify before commit
git status --short | grep -E "^(A|M|D)"  # only staged files
```

**Recovery if you already committed with `git add -A`:**
```bash
# Undo commit but keep all files staged
git reset --soft HEAD~1

# Unstage everything, keep working tree intact
git reset HEAD

# Discard unwanted files you don't want in the commit
git checkout -- projects/*/node_modules/ projects/*/dist/ evolution-log.md key.pem

# Now stage only correct files
git add README.md README.zh.md README.ar.md README.de.md README.es.md README.fr.md README.ko.md README.pt.md README.ru.md
git status --short  # verify clean

# Amend (if already pushed) or recommit
git commit -m "docs: your message"
git push --force origin your-branch
```

## Multilingual README Pattern

For international repos with multiple language versions:

- `README.md` — **always English** (GitHub's default display)
- `README.zh.md` — Chinese (or other language codes: .ru, .ar, .es, .pt, .fr, .de, .ko)
- `README.{lang}.md` — additional languages

Each file's language switcher must list ALL language files:
```html
🌐 Languages:
  <a href="README.md"><b>English</b></a> ·
  <a href="README.zh.md">中文</a> ·
  <a href="README.ru.md">Русский</a> · ...
```

**When changing the language set** — update switchers in ALL files simultaneously, then commit together with the explicit file list.

## Committing to Wrong Branch

Always verify before committing:
```bash
git branch        # shows current branch with *
git status        # shows staged files
git log -1 --oneline  # shows last commit
```