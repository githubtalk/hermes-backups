# Bulk Repository Normalization

Pattern for repo-wide find-replace tasks: link normalization, branding updates, typo fixes, or configuration sweeps.

## When to Use

- Renaming a repo and updating all internal references
- Fixing a misspelled name/URL that appears in dozens of files
- Updating a shared config value across docs, code, and CI
- Converting markdown/HTML assets to a new standard

## Workflow

### 1. Audit Before Changing Anything

```bash
# Count occurrences and list files — do this FIRST
grep -rn "OldName" --include="*.md" --include="*.py" --include="*.json" --include="*.yml" .
grep -rn "OldName" --include="*.md" --include="*.py" --include="*.json" --include="*.yml" . | wc -l

# Spot-check a few files to confirm context before bulk replace
grep -rn "OldName" --include="*.md" . | head -20
```

> **Rule:** Never run a bulk replace on a repo you haven't audited. Blind find-replace on 200+ matches without reading context is how you break generated files, secrets, and upstream references.

### 2. Decide What to Change vs Preserve

Classify matches into:

| Category | Action |
|----------|--------|
| User-facing docs, READMEs, badges | Replace |
| Code/config that references the repo | Replace |
| Upstream/upstream clone URLs | Replace if pointing to wrong repo |
| Generated files (`site/`, `search_index.json`) | Replace for consistency |
| Privacy-sensitive placeholders (`[REDACTED]`, secrets) | **Never replace** |
| Package-lock or vendor lockfiles with external URLs | **Never replace** unless user explicitly asks |

### 3. Make Changes Incrementally

For a large repo, fix in passes:

```bash
# Pass 1: Core config files
sed -i 's/OldRepo/NewRepo/g' mkdocs.yml package.json README.md

# Pass 2: Code references
sed -i 's/OLD_PATH/NEW_PATH/g' scripts/*.py

# Pass 3: Docs and markdown
find . -name "*.md" -exec sed -i 's/OldName/NewName/g' {} +

# After each pass: review the diff
git diff --stat
```

> **Rule:** Commit in logical chunks, not one mega-commit. Easier to review, easier to revert if one chunk goes sideways.

### 4. Verify No残留

```bash
# Final audit — should return zero matches
grep -rn "OldName" --include="*.md" --include="*.py" --include="*.json" --include="*.yml" . | wc -l
grep -rn "OldName" .  # spot-check any remaining matches
```

### 5. PR + Merge

```bash
git checkout -b fix/normalize-repo-references
git add -A
git commit -m "fix: normalize all repo references to new-name"
git push -u origin HEAD

gh pr create --title "fix: normalize repo references" --body "..."
# Wait for approval, then merge
gh pr merge <PR_NUMBER> --squash --delete-branch
```

### 6. Post-Merge Verification

```bash
# Check the live file on GitHub
curl -sL https://raw.githubusercontent.com/owner/new-repo/main/README.md | grep -c "OldName"
# Expected: 0

# Also check mkdocs.yml or other critical files
curl -sL https://raw.githubusercontent.com/owner/new-repo/main/mkdocs.yml | grep "repo_url"
```

> **Rule:** Don't assume the merge worked. GitHub's web UI may cache the old README for minutes. `raw.githubusercontent.com` shows the committed content directly.

## Pitfalls

- **`[REDACTED]` placeholders:** Don't bulk-replace inside redaction markers. They're intentional and often contain the exact patterns you're replacing.
- **Generated artifacts:** Files like `site/search/search_index.json` or lockfiles may contain hardcoded old URLs. Replace them too, or the live site will still show old links.
- **Badge URLs:** Shields.io and star-history.com badges embed the repo slug. They need explicit replacement.
- **Case sensitivity:** `Hermes-House` vs `hermes-house` vs `Harmes-House` are three different strings. Audit all variants.
- **Clone instructions:** README files often contain `git clone https://github.com/owner/old-name.git` — easy to miss because it's in a code block.
- **Local directory name vs remote repo name:** The local folder name (e.g. `~/Harmes-House`) is independent of the remote repo slug. Changing the remote doesn't rename your local directory unless you explicitly do so.
