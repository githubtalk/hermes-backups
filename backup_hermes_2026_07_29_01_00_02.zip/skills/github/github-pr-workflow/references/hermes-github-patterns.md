# Hermès GitHub Workflow Patterns

> Session-learned patterns specific to the Hermès/cldl/workspace GitHub setup.

## Two-Account Architecture

The workspace uses two GitHub accounts with distinct roles:

| Account | Role | Capabilities |
|---------|------|--------------|
| `clowlove` | Owner | Owns `Harmes-House`, manages sponsors, can push to main |
| `clawlove` | Reviewer/Approver | Reviews PRs, approves merges, tests workflows |

**Typical workflow:**
1. Make changes → commit to feature branch → push
2. Create PR via `gh pr create` (as clowlove)
3. `clawlove` approves the PR
4. Merge via `gh pr merge --admin --merge`

## Autonomous Execution

When the user says "you fully own the GitHub space" or similar, they mean:
- **Don't ask for confirmation** — execute the full workflow autonomously
- Push to branch → create PR → merge when approved
- No need to report back mid-way unless something fails

**User signals for autonomous mode:**
- "你完全拥有github hesmes-house空间" (you fully own the GitHub space)
- "去做吧" (go do it)
- "你自己去做吧" (do it yourself)

## PR Creation + Merge Sequence

```bash
# Full autonomous workflow
git checkout -b feature/xxx && git add . && git commit -m "feat: description"
git push -u origin HEAD
gh pr create --title "feat: xxx" --body "..." --reviewer clowlove
gh pr merge --admin --merge   # merge immediately if already approved
```

**For CI-gated repos** (branch protection requires checks pass):
```bash
gh pr merge --auto --squash --delete-branch
```

## hermes-journal.md Updates

When updating the AI growth journal:
- Auto-commit with message format: `📝 Journal: <title>` or `🏆 Milestone: <milestone>`
- The script at `scripts/hermes_journal.py` handles formatting and Git operations
- Run `python scripts/hermes_journal.py --stats` to verify before committing

## GitHub Sponsors

GitHub Sponsors activation requires **manual user action** at `github.com/sponsors/clowlove`.
Infrastructure setup (SPONSORS.md, sponsorship tiers, README integration) can be automated,
but the user must personally activate the feature and connect payment.

## GitHub App (hermes-reviewer)

GitHub Apps are **UI-only** — cannot be created via API. Must use https://github.com/settings/apps/new.

Key steps after creation:
1. Generate **private key (.pem)** from App settings → Keys
2. Note the **App ID** (from About section)
3. Set **webhook URL** (can be placeholder, update later)
4. Set **permissions**: PR read/write, Contents read-only
5. Install the App on your account/org
6. Note the **installation ID** from the URL after installation

Webhook delivery requires a public URL. Options in priority order:
- **Cloudflare Workers** (free, persistent) — needs account-level API token with Workers edit permission
- **Railway/Render** (deploy webhook server) — free tier available
- **localtunnel** (quick dev) — `npx --yes localtunnel --port 3000`, tunnel URL at http://localhost:4040/api/tunnels
- **serveo.net / localhost.run** — require SSH key, not always available

## Quick Commands for This Workspace

```bash
# Push and create PR with auto-merge on approval
git push -u origin HEAD && gh pr create --title "..." --body "..." --reviewer clowlove

# Merge when approved (use this, not --squash --delete-branch)
gh pr merge --admin --merge

# Check PR status
gh pr list --author clowlove --state open

# Sync main and cleanup
git fetch origin main && git checkout main && git pull origin main
```