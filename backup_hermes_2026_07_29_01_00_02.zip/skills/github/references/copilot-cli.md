# GitHub Copilot CLI

> 安装、认证、三种模式、工具权限、上下文管理、GitHub 集成、Custom Agents、MCP、Hooks

## 安装

**推荐（Linux/macOS）：**
```bash
curl -fsSL https://gh.io/copilot-install | bash
```

**Homebrew：**
```bash
brew install copilot-cli
```

**验证：**
```bash
copilot --version
```

> ⚠️ `gh copilot` 扩展已于 2025 年 9 月废弃，所有功能已迁移到独立的 `copilot` CLI。

## 认证

**关键：需要 Fine-Grained PAT（`ghp_` 开头的不行）**

Fine-Grained PAT 创建：https://github.com/settings/tokens
需要勾选 **Copilot** scope。

**三种认证方式：**
```bash
# 方式1：Web 登录（需浏览器）
copilot login

# 方式2：环境变量（推荐自动化）
export COPILOT_GITHUB_TOKEN=$(gh auth token)

# 方式3：直接指定 PAT
export COPILOT_GITHUB_TOKEN=ghp_xxxxxxxxxxxx
copilot
```

## 三种运行模式

用 `Shift+Tab` 循环切换模式。

| 模式 | 说明 |
|------|------|
| 交互模式（默认） | 每条指令需要确认后才执行 |
| Plan 模式 | 不直接写代码，先生成结构化实施计划 |
| Autopilot 模式 | 自动执行，不需要手动确认 |

```bash
# 启动时指定模式
copilot --mode plan
copilot --mode autopilot -p "实现 xxx 功能"
```

## 工具权限控制

| 标志 | 说明 |
|------|------|
| `--allow-tool 'shell(COMMAND)'` | 允许特定 shell 命令 |
| `--allow-tool 'write'` | 允许所有文件修改 |
| `--allow-all-tools` / `--yolo` | 全部允许（谨慎使用） |
| `--deny-tool 'shell(rm)'` | 拒绝特定命令（优先级最高） |

## 模型选择

| 模型 | 备注 |
|------|------|
| Claude Sonnet 4.6 | 默认，代码能力强 |
| Claude Opus 4.6 | 复杂规划任务 |
| GPT-5.3-Codex | Agentic 任务更快 |
| Auto | 自动选择最优模型（比手动选择便宜 10%） |

## GitHub.com 集成（内置 MCP）

Copilot CLI 内置 GitHub MCP server，无需额外配置即可使用：
```bash
copilot
# "List my open PRs"
# "List all open issues assigned to me"
```

### 在 Issue 上工作
```
I've been assigned this issue: https://github.com/<owner>/<repo>/issues/<number>. Start working on this.
```
Copilot 会：读取 Issue → 创建分支 → 实现 → 运行测试 → 汇报。

## Remote Agent Task（`gh agent-task`）

在云端 Codespace 运行，不占用本地资源：
```bash
gh agent-task create --repo <owner>/<repo> --issue <number> --body "Add docstrings"
gh agent-task list --repo <owner>/<repo>
gh agent-task view <task-id> --repo <owner>/<repo>
```

## Custom Agents

在项目 `.github/agents/` 目录下创建 `.md` 文件：
```markdown
---
name: fastapi-expert
description: FastAPI 专家代理
---
## Role
你是 Python 后端工程师，专精 FastAPI 和异步 Python。
```

使用：`@fastapi-expert Add rate limiting middleware`

## MCP Servers

**配置文件：**
- 用户级：`~/.copilot/mcp-config.json`
- 项目级：`.github/mcp.json`

```json
{
  "servers": {
    "postgres": {
      "command": "docker",
      "args": ["run", "-i", "--rm", "-e", "DATABASE_URL", "mcp/postgres"]
    }
  }
}
```

## Hooks

`.github/hooks/post-write.sh` — 写文件后自动执行：
```bash
#!/bin/bash
if [[ "$COPILOT_HOOK_FILE" == *.py ]]; then
  ruff check --fix "$COPILOT_HOOK_FILE"
  ruff format "$COPILOT_HOOK_FILE"
fi
```

## 完整开发流程

```
Stage 1 → 探索（默认模式）
  copilot "Show me all files involved in the /token endpoint"

Stage 2 → 设计（Plan 模式）
  [Shift+Tab] → Plan 模式
  "Add pagination to /token endpoint..."

Stage 3 → 构建测试
  Copilot 实现代码 → 运行 pytest → 自我修正

Stage 4 → 提交 PR
  "Commit with conventional commit and create PR"

Stage 5 → 异步完善（远程 Agent）
  gh agent-task create --repo owner/repo --issue <num> --body "Add docstrings"
```

## 参考资源

- [Copilot CLI 官方文档](https://docs.github.com/en/copilot/concepts/agents/about-copilot-cli)
- [Awesome Copilot](https://github.com/github/awesome-copilot)