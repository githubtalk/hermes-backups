# GitHub AI Agent Trend Daily Report

> 发现 GitHub AI Agent 热点，生成小红书风格日报并推送到 Telegram

## Trigger
用户要求发送 GitHub 热点日报、趋势推送、或类似 "github热点像trendradar一样" 的需求。

## Workflow

### 1. 扫描 GitHub 热点
```bash
gh search repos "AI agent" --limit 5 --sort stars --order desc --visibility public
gh search repos "LLM agent framework" --limit 5 ...
gh search repos "autonomous agent" --limit 5 ...
```

### 2. 中文描述映射
热门项目维护中文描述字典 `ZH_DESC`：
```python
ZH_DESC = {
    "firecrawl": "🔥 AI时代的数据爬取工具，自动搜索/抓取/清洗网页",
    "browser-use": "🌐 让AI能够操控浏览器自动化任务",
}
```

### 3. 小红书格式 (最终版)
```
🤖 *GitHub AI热榜日报*
📅 YYYY年MM月DD日 | 周X

✨ 今日发现 *N* 个热门项目

━━━━━━━━━━━━━━━━━━

*🤖 AI智能体*
  1️⃣ *firecrawl* — 🔥 AI时代的数据爬取工具...
  2️⃣ *awesome-llm-apps* — 📦 100+ AI Agent应用合集...

*🛠️ Agent框架*
  1️⃣ *AutoAgent* — 🎯 零代码LLM Agent框架...

━━━━━━━━━━━━━━━━━━

💡 关注我，每天发现AI新趋势
🔗 github.com/clowlove/Harmes-House
```

**格式要点：**
- 标题用 `*bold*`
- 每个分类下 4-5 个项目
- 每行格式：`编号 emoji *项目名* — 中文描述`
- 分隔线用 `━━━`

### 4. 推送到 Telegram
使用 `send_message` 工具发送到 `telegram:522296847`

## 分类标签
| 标签 | 含义 |
|------|------|
| 🤖 AI智能体 | AI Agent 项目 |
| 🛠️ Agent框架 | Agent 开发框架 |
| 🚀 自主代理 | 自主任务执行 |
| 🌐 浏览器自动化 | Web 自动化工具 |
| 📚 RAG知识库 | 知识检索增强 |

## 输出格式要求
- 描述全部中文
- 描述长度 40-60 字符
- 每类最多 5 个项目
- 总计 15-25 个项目

## Pitfalls
- **GH API 限速**：使用 `--visibility public` 减少过滤
- **重复项目**：用 `seen` 集合去重
- **描述为空**：使用 `[:40]` 截断并备选 "暂无描述"
- **解析错误**：gh search output 是 `owner/repo\tdesc\tpublic\ttimestamp`，用 tab split，不要用 regex 匹配 `github.com/`
- **编码问题**：描述中可能有 emoji，用 `strip()[:40]` 截断而非 split
- **Unicode heredoc 安全扫描**：使用 Python `execute_code` 写入文件，而非 shell heredoc

## Automation
- 主脚本：`~/.hermes/scripts/hermes_evolution_system.py`
- GitHub Profile 自动更新：`~/.hermes/scripts/hermes_profile_update.py`
- Cron: `0 9 * * *` (每天北京时间 09:00)

### GitHub Actions workflow
`.github/workflows/daily-evolution.yml` — 每天 09:00 北京时间自动运行热点发现脚本，更新 GitHub Profile README，生成日志提交到 `docs/evolution/`。

## 相关技能
- `github` — GitHub 基本操作（PR、repo 管理）
- `hermes-agent` — Hermes Agent 配置和定时任务