# SEO Checklist for GitHub Pages Business Sites

## Minimal SEO Stack (non-negotiable)

Every static business site needs these in `<head>`:

- `<title>` — unique per page, ≤60 chars
- `<meta name="description">` — unique per page, 120-155 chars
- `<link rel="canonical">` — same URL across all variants
- `<meta name="robots" content="index, follow">` — explicit, not relying on defaults

## JSON-LD (Structured Data)

### Minimal viable set

```json
{
  "@context": "https://schema.org",
  "@graph": [
    { "@type": "Organization", "name": "...", "url": "...", "logo": "...", "description": "..." },
    { "@type": "WebSite", "url": "...", "name": "...", "publisher": { "@id": ".../#organization" },
      "potentialAction": { "@type": "SearchAction", "target": "...?q={search_term_string}", "query-input": "required name=search_term_string" }
    },
    { "@type": "WebPage", "url": "...", "name": "...", "isPartOf": { "@id": ".../#website" } }
  ]
}
```

The `SearchAction` enables Sitelinks search box in Google results. Use `@graph` (array) so all types share the same `@id` references.

For **product pages**: add a `Product` schema node with `brand`, `manufacturer`, `offers` (price + currency + availability).

### JSON-LD gotchas

- **Never** put JSON-LD in a comment — parsers will still read it but it's invalid per spec
- **Always** use `application/ld+json` as the script type
- **Escape**: if embedding in a template, ensure `"` → `\"` or use single-quoted HTML attributes: `<script type='application/ld+json'>`
- Use `@id` with trailing fragment for inter-object references (e.g. `"publisher": {"@id": "https://.../#organization"}`)

## Open Graph & Twitter Cards

| Tag | Where used |
|-----|-----------|
| `og:title`, `og:description`, `og:url`, `og:type` | Facebook, LinkedIn, WhatsApp, Telegram link previews |
| `og:image` | All of the above + Twitter |
| `og:locale` | All |
| `twitter:card` | Twitter/X only — use `summary_large_image` |
| `twitter:title`, `twitter:description`, `twitter:image` | Twitter/X override (falls back to og:* if omitted) |

**OG image rules:**
- Minimum 1200×630px
- Max 5MB
- Save as JPG or PNG in `/images/` directory
- Use a real product/hero screenshot — not a blank placeholder

## sitemap.xml

Standard format with schema location:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
  http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
  <url>
    <loc>https://domain.com/</loc>
    <lastmod>2025-05-14</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://domain.com/page.html</loc>
    <lastmod>2025-05-14</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
</urlset>
```

**`lastmod`**: Always use ISO date (YYYY-MM-DD). Google ignores stale dates — keep it current or remove the tag. **`priority`**: Only needed if you have multiple pages; homepage should be `1.0`.

## robots.txt

```
User-agent: *
Allow: /

Sitemap: https://domain.com/sitemap.xml
```

**`Disallow: /images/` is wrong** — it blocks Google from crawling and indexing your image files, which hurts Google Images and breaks OG image loading (since the crawler can't see the images to generate previews). Remove it.

## GitHub Pages Specifics

- **Repo Topics** (Settings → General → Topics): set 3-5 comma-separated topics for GitHub search discoverability
- **Custom domain + HTTPS**: enables HSTS preload, improves trust signals
- **GitHub Pages deployment delay**: takes 2-5 min after push; use `?refresh=1` cache-bust for testing
- **`gh-pages` vs `master`**: if using `gh-pages` branch, adjust all URLs in sitemap/canonical accordingly

## Performance Notes

- `loading="lazy"` on all `<img>` below the fold
- `object-fit: contain` for product cards (avoids cropping) or `cover` (full bleed)
- `display: flex` on image containers can interfere with `object-fit` — test both

## Verification

- [Google Rich Results Test](https://search.google.com/test/rich-results) — validates JSON-LD
- [Twitter Card Validator](https://cards-dev.twitter.com/validator) — preview Twitter Card
- [Facebook Sharing Debugger](https://developers.facebook.com/tools/debug/) — clears OG cache
- `browser_console` with `document.querySelector('script[type="application/ld+json"]')?.textContent` to verify JSON-LD is in DOM