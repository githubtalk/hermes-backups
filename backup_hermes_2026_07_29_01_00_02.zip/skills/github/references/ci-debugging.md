# CI Failure Debugging

## Finding Which Job and Step Failed

When CI fails, drill down from run → job → step:

```python
import urllib.request
import json

token = "ghp_..."  # os.environ.get('GITHUB_TOKEN')
owner, repo = "clowlove", "Harmes-House"
run_id = "25771681350"  # from the run URL

# 1. Get run details (conclusion, status, jobs_url)
run_url = f"https://api.github.com/repos/{owner}/{repo}/actions/runs/{run_id}"
req = urllib.request.Request(run_url, headers={"Authorization": f"token {token}"})
run_data = json.loads(urllib.request.urlopen(req).read())

# 2. Get jobs for this run
jobs_url = run_data['jobs_url']
req = urllib.request.Request(jobs_url, headers={"Authorization": f"token {token}"})
jobs_data = json.loads(urllib.request.urlopen(req).read())

for job in jobs_data['jobs']:
    conclusion = job['conclusion'] or job['status']
    print(f"Job: {job['name']} — {conclusion}")
    for step in job.get('steps', []):
        if step.get('conclusion') == 'failure':
            print(f"  ❌ Failed step: {step['name']} (#{step['number']})")
```

## Getting Logs for a Failed Job

```python
# logs_url is available on each job object
logs_url = job['logs_url']
req = urllib.request.Request(logs_url, headers={"Authorization": f"token {token}"})
logs = urllib.request.urlopen(req).read().decode('utf-8', errors='replace')

# Last 50 lines
lines = logs.split('\n')
print('\n'.join(lines[-50:]))
```

## Common Patterns

| Failure Type | Where to Look |
|---|---|
| YAML syntax | Workflow file raw content — validate with `yaml.safe_load()` |
| PR creation fails | Check if there were actual changes to commit (`git diff --staged --quiet`) |
| Skipped job | Usually `if:` condition on job not met — check event that triggered run |
| Action not found | Typo in `uses:` field — verify action exists at that version |

## This Session's Findings

- `validate.yml` workflow (fork-specific): validates all skills under `skills/` directory for:
  1. `SKILL.md` exists and is non-empty
  2. `skill.json` exists, is valid JSON, and has non-empty `name`, `version`, and `description`
- **Critical difference from upstream**: Fork (clowlove/Harmes-House) requires `skill.json` for every skill; upstream (NousResearch/hermes-agent) uses YAML frontmatter in `SKILL.md` alone.
- **Umbrella skill pattern**: Skills that are directories containing sub-skills (e.g., `apple/`, `github/`, `software-development/`) need their own `SKILL.md` and `skill.json` even if they are wrappers — the validate script checks `skills/*/` at the top level.
- **Fix**: For umbrella skills, create a minimal SKILL.md with YAML frontmatter and a skill.json with name/description/version/author/license/platforms/tags fields.
- Skills validation and journal workflow are independent — validate failures ≠ journal failures.
- Dependency Review failure: "not supported on this repository" → GitHub Dependency Graph not enabled in repo settings. Manual fix required at https://github.com/{owner}/{repo}/settings/security_analysis