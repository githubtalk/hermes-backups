# GitHub Actions YAML Pitfalls

## `run: |` Block Scalar Indentation (Critical)

When a workflow step uses `run: |` (YAML literal block scalar), **all content inside must maintain indentation** relative to the `run:` key. If indentation is lost, YAML parser treats those lines as top-level keys, causing cryptic errors like:

```
Invalid workflow file: .github/workflows/xxx.yml#L53
You have an error in your yaml syntax on line 53
```

### Example failure pattern

Lines 52-59 inside a multi-line bash string lose indentation:

```yaml
      - name: Create or update digest issue
        run: |
          BODY="## Title

### Hacker News AI 热榜     ← LOST indentation — YAML error here
$(echo "$HN_TOP")           ← YAML error here
"
```

### Fix

Restore 10-space indentation to all content lines:

```yaml
      - name: Create or update digest issue
        run: |
          BODY="## Title

          ### Hacker News AI 热榜    ← Correct indentation
          $(echo "$HN_TOP")           ← Correct indentation
          "
```

### Verification

```python
import yaml
import urllib.request

url = "https://raw.githubusercontent.com/{owner}/{repo}/refs/heads/main/.github/workflows/ai-daily-digest.yml"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
content = urllib.request.urlopen(req).read().decode()

try:
    yaml.safe_load(content)
    print("YAML is valid")
except yaml.YAMLError as e:
    print(f"YAML error: {e}")
```

## Auto-Sync Workflow Overwriting Fixes

Some repos have workflows that auto-sync/commit changes (e.g., `Sync insights` commits). These can **overwrite manual fixes** on subsequent runs.

If your fix gets overwritten:
1. Re-apply the fix
2. Merge via PR immediately — do not leave unmerged fixes in branches
3. Consider disabling or bypassing the sync workflow if it's the source of corruption

## GitHub Actions YAML Schema

- `on: [push, pull_request]` — triggers
- `permissions:` — required token scopes
- `jobs.<job_id>.runs-on` — runner
- `steps[].run: |` — multi-line script (must maintain indentation)
- `steps[].uses: actions/checkout@v4` — reuse action

### Common Line Count Mismatch

GitHub's error line numbers may differ from local file if:
- File has CRLF vs LF line endings
- File was modified after CI triggered
- GitHub's parsed view differs from raw content

Always verify the **actual raw content on main branch** using `https://raw.githubusercontent.com/{owner}/{repo}/refs/heads/main/.github/workflows/xxx.yml`.