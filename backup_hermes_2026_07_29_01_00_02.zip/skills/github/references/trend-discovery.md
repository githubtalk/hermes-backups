# GitHub Trend Discovery & Evolution Logging

Automated workflow for discovering trending projects and documenting evolution in GitHub repos.

## Core Technique: Parsing `gh search repos` Output

`gh search repos` returns tab-separated values (TSV):

```
owner/repo    description    public    timestamp
```

### Bash Parsing

```bash
gh search repos "AI agent" --limit 5 --sort stars --order desc | while IFS=$'\t' read -r repo desc rest; do
  echo "REPO: $repo | DESC: $desc"
done
```

### Python Parsing

```python
output, code = run_cmd('gh search repos "AI agent" --limit 5 --sort stars --order desc')
for line in output.strip().split('\n'):
    parts = line.split('\t')
    if len(parts) >= 2:
        repo_path = parts[0].strip()
        desc = parts[1].strip()[:120]
```

## Standard Discovery Queries

```python
QUERIES = [
    "AI agent",
    "LLM agent framework", 
    "autonomous agent",
    "copilot CLI",
    "claude code",
    "browser agent",
    "RAG knowledge base",
]
```

## Evolution Sync Workflow

1. **Clone target repo** (shallow, for stats)
   ```bash
   cd /tmp && rm -rf Harmes-House && git clone --depth 1 https://github.com/clowlove/Harmes-House.git
   ```

2. **Generate evolution log** with frontmatter:
   ```markdown
   # {date} - Daily Evolution
   
   ## 🔥 GitHub Discoveries
   
   - **[owner/repo](url)** — description
   ```

3. **Commit to new branch**:
   ```bash
   cd Harmes-House
   git add -A
   git checkout -b evolution/{date}
   git commit -m "evolution: {date} GitHub discoveries"
   git push -u origin evolution/{date}
   ```

4. **Create PR**:
   ```bash
   gh pr create --title "evolution: {date} GitHub discoveries" --body "Automated daily evolution sync"
   ```

## Integration with Hermès Scripts

Script location: `~/.hermes/scripts/hermes_evolution_sync.py`

Key functions:
- `get_github_trending()` — Scans queries, returns list of `{owner, repo, query, desc, url}`
- `get_hermes_house_stats()` — Returns `{skills, commits}` counts
- `generate_evolution_log()` — Returns markdown string

## Related

- `scripts/github_knowledge.py` — GitHub knowledge backup script
- `scripts/skills_sync.py` — Skills synchronization