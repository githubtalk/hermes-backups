# GitHub Pages API Reference

## Enable Pages

```bash
POST https://api.github.com/repos/{owner}/{repo}/pages
Authorization: token {PAT}
Accept: application/vnd.github+json

{
  "build_type": "workflow",  # or "legacy"
  "source": {
    "branch": "master",       # or "main"
    "path": "/"               # root only for static sites
  }
}
```

**Response:**
```json
{
  "html_url": "https://owner.github.io/repo/",
  "build_type": "workflow",
  "source": { "branch": "master", "path": "/" }
}
```

## Get Pages Status

```bash
GET https://api.github.com/repos/{owner}/{repo}/pages
Authorization: token {PAT}
```

## Disable Pages

```bash
DELETE https://api.github.com/repos/{owner}/{repo}/pages
Authorization: token {PAT}
```

## Required Token Scopes

- Public repo: `public_repo`
- Private repo: `repo`

## Build Types

| Type | Description |
|------|-------------|
| `workflow` | Uses GitHub Actions (recommended) |
| `legacy` | Uses branch source (master/docs folder) |

## Troubleshooting Pages Deployment

1. **No `index.html` at root** — Pages won't deploy until root has an `index.html`
2. **Workflow not triggering** — Check repo Settings → Actions → Actions permissions (must allow workflows)
3. **Custom domain not working** — DNS must propagate; allow 24-48 hours for initial SSL cert
4. **404 after custom domain** — Remove custom domain, redeploy with GitHub-provided URL first, then re-add