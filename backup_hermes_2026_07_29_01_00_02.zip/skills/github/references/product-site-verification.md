# GitHub Pages Product Site — Source Verification Guide

## The Core Problem

When building a product showcase site from an existing e-commerce server (e.g., an ASP/PHP catalog), **product image filenames are meaningless** — `20252271426345841.jpg` tells you nothing about which product it belongs to. You MUST cross-reference source HTML pages to get correct name→image mappings.

**Never assume a file named after a product ID actually corresponds to that product.**

## Verified Workflow

### Step 1: Extract all product pages and their names

```bash
# List all product HTML files
ls /path/to/wwwroot/products/

# Extract product names from each page
for f in /path/to/wwwroot/products/*.html; do
  echo "$(basename $f): $(grep -oP '(?<=<h1>)[^<]+' "$f")"
done
```

### Step 2: Extract the actual product image from each page

Each product page uses a `picautozoom` class on its main image. The reliable extraction:

```bash
# Get the LAST /uploadfile/*.jpg from each product page (main product image)
# Note: grep -oP with variable-length lookbehinds fails — use grep -o with tail -1
for id in 58 61 62 64 65 66 68 137 171 172 175 183 224 225 226 227 228 229 230 231 232 233 234 235 236 237 238 239 240 241 242 243 244 245 246 247 248; do
  echo "$id: $(grep -o '/uploadfile/[^"]*\.jpg' /path/to/wwwroot/products/$id.html | tail -1)"
done
```

### Step 3: Verify images exist locally before assigning them

```bash
for f in 20252271426345841.jpg 20252271432542418.jpg; do
  if [ -f "images/$f" ]; then
    echo "EXISTS: $f"
  else
    echo "MISSING: $f — copy from server"
    cp /path/to/wwwroot/uploadfile/$f images/
  fi
done
```

### Step 4: Cross-reference before building product cards

Build a mapping table like this before writing any HTML:

| Product ID | Product Name (from h1) | Image File | Notes |
|------------|------------------------|------------|-------|
| 58 | ST404 Tractor | 2025226853232798.jpg | |
| 61 | ST1154 Tractor | 202522683152783.jpg | |
| 62 | ST1354 Tractor | 2025226829479411.jpg | |
| 64 | ST1404 Tractor | 202522682641265.jpg | |
| 65 | ST1604 Tractor | 2025226823229802.jpg | |
| 66 | ST1804 Tractor | 2025226817568743.jpg | |
| 68 | ST2204 Tractor | 202522681071030.jpg | |
| 137 | ST804 Garden Tractor | 2025226834184905.jpg | |
| 171 | ST504E Tractor | 20252269022442.jpg | |
| 172 | ST504 Tractor | 202522685248314.jpg | |
| 175 | ST704 Tractor | 2025226836565037.jpg | |
| 183 | ST804 Tractor | 2025226850147150.jpg | |
| 225 | PLOW PLOUGH | 201745155085167.jpg | Mouldboard plough |
| 226 | Disc Harrow | 2017451450474178.jpg | NOT 20252271410187669.jpg |
| 227 | Front Loader & Backhoe | 2025228818317577.jpg | |
| 228 | Round Baler | 202522886294924.jpg | |
| 229 | Hydraulic Reversible Plough | 2017451616517641.jpg | |
| 230 | ST2404 Tractor | 202522696126099.jpg | |
| 231 | ST604 Garden Tractor | 202522687293417.jpg | |
| 232 | ST2204 New Hood | 2025226813427362.jpg | |
| 233 | ST504 with Cabin | 202522684342389.jpg | |
| 234 | Flail Mower | 20252271141492268.jpg | |
| 235 | Slasher Mower | 2025227115285978.jpg | |
| 236 | Post Hole Digger | 20252271156459132.jpg | |
| 237 | Pipe Laying Machine | 202522712167156.jpg | Previously mislabeled as Rice Transplanter |
| 238 | 1GQN Rotary Tiller | 2025227145137471.jpg | |
| 239 | 1GLN Disc Harrow | 20252271410187669.jpg | Used for Spring Tooth Cultivator in site |
| 240 | FarmTrailer 7CX | 20252271422525440.jpg | Previously mislabeled as "Disc Ridger" |
| 241 | Disc Plough | 20252271426345841.jpg | |
| 242 | 3Z Cultivator | 2025227143061710.jpg | |
| 243 | Adjustable Ridge Machine | 20252271432542418.jpg | |
| 244 | 3S Subsoiler | 20252271435484436.jpg | |
| 245 | Box Grader | 20252271440265379.jpg | |
| 246 | Corn Seeder | 20252271449495374.jpg | |
| 247 | CRD-600 Spreader | 20252271453356703.jpg | NOT Potato Harvester |
| 248 | Potato Harvester | 20252271459346406.jpg | |

**Common mistakes when you skip this:**
- `20252271426345841.jpg` (Disc Plough) was being used for: Spring Tooth Cultivator, Disc Ridger, FarmTrailer, and Cultivator cards
- `20252271432542418.jpg` (Adjustable Ridge Machine) was being used for "Grain Auger"
- `202522712167156.jpg` (Pipe Laying Machine) was assigned to Rice Transplanter
- `20252271410187669.jpg` was assigned to Disc Harrow card — actual product for this ID is 1GLN Disc Harrow (239), Spring Tooth Cultivator (242) was misrouted to it
- `20252271453356703.jpg` (CRD-600 Spreader) was described as "CRD-600 Series" on Potato Harvester card

### Step 5: After site deploys, verify all images load

```bash
# Check specific images on live GitHub Pages
for img in 2025226813427362.jpg 202522687293417.jpg 2025227143061710.jpg; do
  status=$(curl -s -o /dev/null -w "%{http_code}" "https://owner.github.io/repo/images/$img")
  echo "$img: $status"
done
```

## Server Source Pattern for shengtuo-tractor.com

- Product pages: `/home/ubuntu/wwwroot/products/{id}.html`
- Images: `/home/ubuntu/wwwroot/uploadfile/{filename}.jpg`
- Image-to-product mapping changes per product page — no filename convention exists

## Key Lesson

> **Product image filenames carry NO semantic information.** Always extract the actual image reference from the source product HTML `<img class="picautozoom">` tag, then verify that image's `<h1>` product name before building the site. Assume nothing.