# Fork-to-Satellite-Site Workflow

Use this when you need to create a **new independent website** for a different domain, starting from an existing GitHub Pages site as a template.

## When to Use

- Launching a new domain (`www.sadin-tractor.com`) based on an existing site (`www.farm-implement.com`)
- Creating a demo/mini site for a sub-brand or product line
- Preserving the original while customizing for a different market

## Workflow

### Step 1: Fork the Repository
```
GitHub → source repo → Fork → create under your account
Example: githubtalk/shengtuo-tractor → mitalkcoin/sd-tractor
```

### Step 2: Configure Fork for New Domain
1. Forked repo → **Settings → Pages → Custom domain** → `www.new-domain.com`
2. Wait for GitHub to issue Let's Encrypt certificate
3. Cloudflare DNS → add CNAME record: `www` → `new-account.github.io`
4. Set Cloudflare SSL to **Flexible** (for GitHub Pages origin)
5. GitHub auto-creates CNAME file in repo root

### Step 3: Update Site Content
```bash
# Clone the fork
git clone https://github.com/new-account/sd-tractor.git
cd sd-tractor

# Update meta tags, branding, contact info, product data
# Then push
git add . && git commit -m "Update for sadin-tractor.com" && git push
```

### Step 4: Verify New Domain
- Check: `curl -sI https://www.new-domain.com/ | grep "HTTP/2 200"`
- Verify SSL: `echo | openssl s_client -connect www.new-domain.com:443 2>/dev/null | openssl x509 -noout -dates`

### Step 5: Submit to Search Engines
Each domain is a separate SEO property:
```
Google:  search.google.com/search-console → add www.new-domain.com
Bing:    bing.com/webmasters → add www.new-domain.com  
Yandex:  webmaster.yandex.com → add www.new-domain.com
Baidu:   zhanzhang.baidu.com → add www.new-domain.com
```

## Key Differences from Clone

| Aspect | Fork (GitHub) | Clone (local copy) |
|--------|--------------|-------------------|
| Sync updates from original | ✅ Pull requests | Manual merge |
| Independent GitHub Pages | ✅ Yes | No (same repo) |
| Separate search console property | ✅ Yes | Single property |
| Preserves commit history | ✅ Yes | Optional |

## Pitfalls

- **CNAME collision**: The fork has its own GitHub Pages URL (`new-account.github.io/repo`). The custom domain IS the new site. Ensure DNS points to the fork's GitHub Pages URL, not the original.
- **Stale sitemap**: If the fork's sitemap.xml still has the original domain URLs, update before submitting to search engines.
- **Verification tags**: Each domain needs its own search engine verification tag added to `<head>`.