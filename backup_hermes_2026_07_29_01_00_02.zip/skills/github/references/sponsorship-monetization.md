# GitHub Sponsorship & Monetization

## 在 README 中添加赞助按钮

### 标准徽章格式

```markdown
[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-ffdd00?style=for-the-badge&logo=buy-me-a-coffee)](https://www.buymeacoffee.com/YOUR_USERNAME)

[![GitHub Sponsor](https://img.shields.io/badge/GitHub%20Sponsors-fafbfc?style=for-the-badge&logo=github-sponsors)](https://github.com/sponsors/YOUR_USERNAME)
```

**⚠️ 关键：必须先询问用户正确的链接，不要猜测用户名。上游徽章服务可能会缓存错误链接。**

### 推荐的赞助板块位置

在 README 顶部（项目标题和徽章之后）添加 "Support This Project" 板块，或在底部添加 "Sponsorship" 板块。

### 常见赞助平台

| 平台 | URL 格式 | 备注 |
|------|---------|------|
| Buy Me a Coffee | `https://www.buymeacoffee.com/USERNAME` | 最流行，需询问确切用户名 |
| GitHub Sponsors | `https://github.com/sponsors/USERNAME` | GitHub 原生，需签署 Sponsors 协议 |
| Ko-fi | `https://ko-fi.com/USERNAME` | 类似 BMC |
| PayPal.Me | `https://paypal.me/USERNAME` | 直接转账 |
| Patreon | `https://www.patreon.com/USERNAME` | 订阅制 |

## GitHub 变现路径（6 种）

1. **GitHub Sponsors** — 开源项目接受赞助，需要申请审核
2. **GitHub Marketplace** — 付费 GitHub App，按安装数收费
3. **GitHub Actions** — 打包可复用的 Action 卖钱
4. **开源捐赠** — 通过 Buy Me a Coffee 等外部渠道
5. **私有仓库** — 付费私有仓库（个人/组织付费计划）
6. **生态合作** — 为商业项目做集成、咨询

### GitHub App + Marketplace 付费应用路线

```
步骤：
1. 开发 GitHub App（Node.js + Express 处理 webhook）
2. Web UI 创建 GitHub App（API 无法创建，必须网页端）
3. 暴露 webhook URL 到公网（cloudflared quick tunnel 或 ngrok）
4. 在 GitHub App 设置填入公网 webhook URL
5. 提交 Marketplace listing，设置定价（免费/付费）
6. GitHub 人工审核（1-3 工作日）
```

**webhook 暴露方案对比：**

| 方案 | 优点 | 缺点 |
|------|------|------|
| cloudflared quick tunnel | 免费、持久运行、无需账号 | 断连后 URL 变化 |
| ngrok | 稳定可用 | 需要账号，免费版有连接数限制 |
| Cloudflare Workers | 稳定、可自定义域名 | 需要 Account 级别 API token |
| 固定公网 IP | 最稳定 | 需要服务器 |

**cloudflared quick tunnel 使用方法：**
```bash
# 下载 binary
wget -O /tmp/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64
chmod +x /tmp/cloudflared

# 启动 tunnel（需要 webhook server 已在本机运行）
/tmp/cloudflared tunnel --url http://localhost:3000 2>&1 | grep trycloudflare
# 输出示例：https://xxxxxxxx.trycloudflare.com
```

## hermes-trendradar 发布记录（参考案例）

- **npm 包名**: hermes-trendradar
- **版本**: 1.1.0（Freemium 模型）
- **认证**: .npmrc 文件 + Granular Access Token
- **发布命令**: `npm publish --access public --registry=https://registry.npmjs.org/`
- **验证**: `npm view hermes-trendradar`

### Freemium 授权系统架构

```
hermes-trendradar v1.1.0
├── Free tier:    trending 限10条，3平台（zhihu,weibo,twitter）
├── Pro ($10/月): 无限结果、sentiment、aggregate、全平台
├── License key 存储: ~/.trendradar/config.json
├── License server: license-server.js（端口3334），生成/验证 license key
│   ├── POST /validate        — 验证 key 有效性
│   ├── POST /generate        — 生成 key（内部使用）
│   └── GET  /keys            — 列出所有 key（管理用）
├── 激活命令: trendradar license --activate <key>
├── 升级引导: trendradar upgrade
└── 注意: License server 必须持久运行（或用户自己部署）
```

**生成 Pro license key（开发/测试）：**
```bash
curl -X POST 'http://localhost:3334/generate?tier=pro&months=1'
# 返回: {"key":"tr-xxxxxx-XXXXXX","expiresAt":"2026-06-13T..."}
```

**生产环境考虑：** License server 需要公网可访问（或通过内网穿透），用户付费后手动生成 key 发给他们激活。未来可迁移到 Stripe webhook 自动发放。

---

## GitHub Wiki 管理

### Wiki Git 仓库初始化

Wiki 的 `.wiki.git` 仓库**在用户首次访问 Wiki 页面后才创建**。如果 clone 报 404，说明还没初始化。需要：

1. 用户在 Web UI 访问 `https://github.com/{owner}/{repo}/wiki` 任意页面（创建或编辑）
2. 然后才能 `git clone https://github.com/{owner}/{repo}.wiki.git`

### Wiki Git Push（无 SSH key）

Wiki 仓库不支持 SSH key 认证，必须用 HTTPS + embedded PAT：

```bash
git clone https://github.com/{owner}/{repo}.wiki.git /tmp/{repo}.wiki
cd /tmp/{repo}.wiki
git remote set-url origin https://ghp_TOKEN@github.com/{owner}/{repo}.wiki.git
# 编辑 .md 文件后
git add *.md && git commit -m "..." && git push origin master
```

### Wiki 内容结构

- `Home.md` → Wiki 主页（侧边栏 Pages 导航会自动生成）
- 其他 `.md` 文件 → Wiki 页面，文件名即页面名
- Wiki 页面间可以用 `[Page Name](Page-Name)` 语法互链

---

## README 多语言方案

### 正确做法：独立文件（推荐）

GitHub **只渲染一个 README**，不自动切换语言。正确方案：

| 文件 | 语言 | 说明 |
|------|------|------|
| `README.md` | 默认语言（通常是英文） | GitHub 默认展示 |
| `README.zh.md` | 中文 | 需从 README.md 顶部导航跳转 |
| `README.ru.md` | 俄语 | 同上 |

每个 README 顶部放语言切换导航：
```html
<p align="center">
  🌐 Languages:
  <a href="README.md"><b>English</b></a> ·
  <a href="README.zh.md">中文</a> ·
  <a href="README.ru.md">Русский</a>
</p>
```

**切换默认语言**：把想作为默认的 README 内容 → `README.md`，原 `README.md` → `README.{lang}.md`

### 踩坑记录

- ❌ 不要依赖 GitHub 自动检测语言——它只选一个 README.md 展示
- ❌ `README.en.md` 这种命名会让 GitHub 优先选 `README.md`（英文），如果中文是主版会导致中文用户看到英文

---

## 付费内容 / 私有复刻方案

GitHub **无法强制 fork 付费**（fork 是平台基础功能）。替代方案：

### 方案：README 说明 + 手动邀请

在 README 添加付费区块：
```markdown
## 🔒 Private Fork / Pro Access

**$20 one-time payment** — includes:
- Full source code
- Detailed documentation
- License key system

**Payment:** https://paypal.me/talkcn

After payment, contact via Telegram @Talkcn to receive private fork invitation.
```

付款后：在 GitHub 创建私人 fork（private repo），邀请用户成为 collaborator。

---

## git add 踩坑

- ❌ `git add -A` 会暂存**所有文件**（包括 node_modules、dist、.log、.env 等）
- ✅ 用 `git add README*.md` 精确指定要暂存的文件
- 如果已误暂存，用 `git reset HEAD <file>` 取消暂存

---

## 更多参考

- `references/actions-yaml-pitfalls.md` — CI/CD YAML 踩坑
- `references/ci-debugging.md` — CI 失败调试流程