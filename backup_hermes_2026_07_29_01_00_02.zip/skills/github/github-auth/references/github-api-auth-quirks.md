# GitHub API Auth Quirks

## `Authorization: token` vs `-u` (Basic auth)

When calling the GitHub API from Hermes cron jobs or scripts, `curl -s -H "Authorization: token <PAT>"` can return `401 Bad credentials` even when the token is valid. Switching to `curl -sL -u "<PAT>"` resolves it.

**Why it happens:** The token itself may be fine, but the `Authorization: token` header can be dropped or mishandled by intermediate redirects/proxy handling. The `-u` flag causes curl to send `Authorization: Basic <base64(PAT:)>`, which GitHub accepts and which is preserved across redirects.

**Verified pattern:**
```bash
# ❌ Can 401 in cron/script environments
curl -s -H "Authorization: token ghp_..." \
  "https://api.github.com/repos/OWNER/REPO/actions/runs?per_page=1"

# ✅ Works reliably — use this form
curl -sL -u "ghp_..." \
  "https://api.github.com/repos/OWNER/REPO/actions/runs?per_page=1"
```

**Notes:**
- Always include `-L` when hitting GitHub API endpoints that may redirect.
- The same token works for `git clone https://<token>@github.com/...` but not always for raw API headers in automated environments.
- When updating tokens in cron job prompts, update both the script file and the cronjob prompt text. The prompt text is the source of truth for scheduled runs.

## Token rotation checklist for Hermes cron jobs

1. Update the token in the underlying script (e.g., `~/.hermes/scripts/skills_sync.py`).
2. Update every cronjob prompt that hardcodes the token in a curl command.
3. Verify format: prefer `-u "<PAT>"` over `-H "Authorization: token <PAT>"`.
4. Verify with a direct API call before relying on the next scheduled run.
