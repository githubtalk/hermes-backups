# Privacy Cleanup Workflow for GitHub Repos

## Purpose
Remove personal information from public repositories before moving to private.

## Sensitive Patterns to Redact
- Emails: `\w+@\w+\.\w+`
- GitHub usernames: `github.com/username/...`
- PayPal: `paypal.me/...`
- BuyMeACoffee: `buymeacoffee.com/...`
- API keys: `nvapi-...`, `ghp_...`, `hf_...`
- Telegram handles: `@handle`

## Cleanup Steps

### 1. Scan for Sensitive Data
```bash
cd /tmp/Harmes-House
grep -r "clowlove\|imclaw\|talkcn\|paypal\|buymeacoffee" --include="*.md" -l
```

### 2. Redact Files
```python
import re
content = re.sub(r'github\.com/clowlove/...', 'github.com/[REDACTED]/...', content)
content = re.sub(r'paypal\.me/...', 'paypal.me/[REDACTED]', content)
content = re.sub(r'buymeacoffee\.com/...', 'buymeacoffee.com/[REDACTED]', content)
content = re.sub(r'nvapi-[\w-]+', '[REDACTED]', content)
content = re.sub(r'ghp_[\w-]+', '[REDACTED]', content)
```

### 3. Commit and Push
```bash
git add -A
git commit -m "chore: privacy redaction"
git push origin chore/privacy-redaction
```

### 4. Move to Private Repo
```bash
git clone https://github.com/clowlove/hermes-backups.git
cp -r /tmp/Harmes-House/* /tmp/hermes-backups/
git add -A
git commit -m "Add privacy-cleaned code"
git push
```

## Pitfalls
- Private repo clone may timeout (network issues)
- Image src URLs in README badges need separate cleanup
- API keys in env files need special handling
- Memory.md contains user info - must redact

## Session Reference
- 2026-05-22: Completed privacy cleanup on Harmes-House
- 23 files redacted, pushed to chore/privacy-redaction branch
