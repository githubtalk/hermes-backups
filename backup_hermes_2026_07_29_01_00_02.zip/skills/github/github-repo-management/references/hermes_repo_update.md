# hermes_repo_update.py Reference

## Location
`/home/ubuntu/.hermes/scripts/hermes_repo_update.py`

## Purpose
Automatically updates the `clowlove/Harmes-House` repository description based on live stats (stars, skills count, commits). Runs on a daily cron schedule.

## Usage
```bash
python3 /home/ubuntu/.hermes/scripts/hermes_repo_update.py
```

## Output Format
English-only, pipe-separated, max 160 chars:
```
AI Agent Evolution Hub | {skills}+ Skills | Multi-Agent | Self-Evolving | {random_highlights} | Please give this repo a star with your lucky hand⭐
```

## Patching This Script — Pitfall

**When patching fails**: This script is also written by a sibling subagent (`20260517_180938_26d54a`). If your patch appears to apply but the script reverts to old content on the next run, the sibling overwrote it. 

**Fix**: Use `write_file` (full overwrite) instead of `patch` when the script state is unclear or when you need guaranteed atomic replacement.

## GitHub Description Field Limits
- **description**: max 160 characters (hard limit, enforced by GitHub)
- **homepageUrl**: can hold secondary content but avoid putting URLs here unnecessarily — an empty-looking link displays poorly

## Quick Edit Commands
```bash
# View current description
gh repo view clowlove/Harmes-House --json description --jq '.description'

# Set description only
gh repo edit clowlove/Harmes-House --description "Your description here"

# Clear homepage URL
gh repo edit clowlove/Harmes-House --homepage ""

# View both
gh repo view clowlove/Harmes-House --json description,homepageUrl --jq '{description, homepageUrl}'
```