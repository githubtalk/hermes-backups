# Repository Rename Workflow

When a GitHub repository is renamed, references to the old name persist in multiple places. This checklist ensures all references are updated.

## Why This Matters

GitHub automatically redirects web URLs and git clone operations from the old name to the new one. However:
- Hardcoded API URLs return 404 for the old name
- Scripts with `REPO = "owner/old-name"` constants break
- Cron job prompts with embedded URLs or tokens targeting the old repo fail
- Generated documentation/badges with old URLs become stale

## Checklist

### 1. Update Source Scripts

Search for the old repo name across all scripts:

```bash
grep -rn "owner/old-name" ~/.hermes/scripts/
```

Update `REPO` constants, clone URLs, and API endpoints in:
- Sync scripts (`skills_sync.py`, `github_sync.py`)
- CI check scripts (`check_ci.py`)
- Evolution/learning scripts (`autonomous_learning.py`, `update_evolution.py`)
- Profile/repo update scripts

### 2. Update Cron Job Prompts

Cron jobs often embed repo names and API commands directly in their prompts:

```bash
# List all cron jobs
cronjob action='list'

# Update each affected job's prompt to use the new repo name
cronjob action='update' job_id='...' prompt='...'
```

### 3. Update Generated Output References

Historical cron output in `~/.hermes/cron/output/` retains old URLs. This is acceptable for history, but new runs should use the new name.

### 4. Verify the New Name

```bash
# Confirm the new repo exists and is accessible
curl -sL -u "$GITHUB_TOKEN" "https://api.github.com/repos/owner/new-name" | python3 -c "import sys,json; print(json.load(sys.stdin)['full_name'])"

# Test clone
git clone --depth 1 https://github.com/owner/new-name.git /tmp/rename-test
```

## Pitfalls

- **GitHub redirects hide breakage**: `git clone` and web URLs still work with the old name, so the problem may not surface until an API call fails with 404.
- **Cron jobs run with stale prompts**: The prompt text is stored in `jobs.json` and persists until explicitly updated.
- **Embedded tokens in prompts**: If a cron job prompt contains an auth token, update it at the same time to avoid future auth failures.
