# GitHub README Beautification — Services & Templates

## Services

### Capsule Render (Header/Footer Waves)
- **URL**: `https://capsule-render.vercel.app/api`
- **Key params**: `type` (waving/softRounded/etc), `color` (hex no #), `height`, `section` (header/footer), `text`, `fontSize`, `fontColor`, `animation` (fadeIn/etc), `desc`, `descSize`, `descAlignY`, `fontAlignY`
- **Docs**: https://github.com/kyechan99/capsule-render

### Readme Typing SVG
- **URL**: `https://readme-typing-svg.demolab.com`
- **Key params**: `font`, `weight`, `size`, `pause`, `color`, `center`, `vCenter`, `multiline`, `repeat`, `width`, `height`, `lines` (semicolon-separated)
- **Docs**: https://github.com/DenverCoder1/readme-typing-svg

### Star History
- **URL**: `https://api.star-history.com/svg?repos=owner/repo&type=Date`
- **Link to**: `https://star-history.com/#owner/repo&Date`

### Shields.io Badges
- **Style**: `flat-square` (modern), `for-the-badge` (bold)
- **Colors**: `6366f1` (indigo), `fbbf24` (gold), `10b981` (green), `26A5E4` (telegram blue)
- **Common**: stars, forks, issues, license, language, custom

## Template: Modern README Skeleton

```markdown
<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=6366f1&height=180&section=header&text=PROJECT_NAME&fontSize=80&fontColor=ffffff&animation=fadeIn&fontAlignY=35&desc=SUBTITLE&descSize=20&descAlignY=55" width="100%"/>

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=22&pause=1000&color=6366f1&center=true&vCenter=true&multiline=true&repeat=true&width=600&height=100&lines=Line+1;Line+2)](https://git.io/typing-svg)

<br/>

[![Badge1](https://img.shields.io/badge/Label-Value-6366f1?style=flat-square&logo=github)](url)
[![Badge2](https://img.shields.io/badge/Label-Value-fbbf24?style=flat-square&logo=github)](url)

</div>

---

## Section 1

Content here...

---

## Section 2

Content here...

---

<div align="center">

[![Star History](https://api.star-history.com/svg?repos=owner/repo&type=Date)](https://star-history.com/#owner/repo&Date)

<br/>

<img src="https://capsule-render.vercel.app/api?type=waving&color=6366f1&height=120&section=footer" width="100%"/>

</div>
```

## Color Palette (Hermes Brand)

| Name | Hex | Use |
|------|-----|-----|
| Indigo | `6366f1` | Primary, headers, accents |
| Gold | `fbbf24` | Stars, highlights |
| Green | `10b981` | Success, active status |
| Telegram Blue | `26A5E4` | Telegram links |
| White | `ffffff` | Text on dark backgrounds |
