# Hermès Agent-Friendly Skills

Standardized SKILL.md format for AI agents to discover and use Hermès capabilities.

## 🎯 Purpose

- Other AI agents to discover capabilities
- Automated tool discovery
- Consistent documentation across tools

## 📚 Available Skills

| Skill | Description | For Agents |
|-------|-------------|------------|
| [hermes-github](hermes-github/) | GitHub repo management, PR workflow, code review | Claude Code, Copilot, Cursor |
| [hermes-research](hermes-research/) | ArXiv papers, trends, news aggregation, reports | Research agents |
| [hermes-terminal](hermes-terminal/) | Shell commands, scripts, process management | All agents |
| [hermes-web](hermes-web/) | Browser automation, scraping, screenshots | Web automation agents |
| [hermes-notification](hermes-notification/) | Multi-channel notifications | Alert/monitoring agents |

## 🔧 Usage

### For AI Agents

Each skill can be loaded to understand Hermès capabilities:

```
Load skill: hermes-<capability>
Example: Load skill: hermes-github
```

### For Developers

Add new skills to this directory following the SKILL.md template:

```markdown
---
name: "hermes-<skill-name>"
description: >-
  One-line description of what this capability does
---

# hermes-<skill-name>

```

## 📋 SKILL.md Template

Each skill should include:

1. **YAML Frontmatter** — `name` and `description`
2. **Installation** — Any prerequisites
3. **Usage** — Basic command examples
4. **Command Groups** — Tables of available commands
5. **Examples** — Real-world usage examples
6. **For AI Agents** — Specific guidance for programmatic use
7. **Output Formats** — Human vs machine-readable
8. **More Information** — Links to full docs

## 🌟 Contributing

To add a new skill:

1. Create directory: `hermes-<skill-name>/`
2. Write `SKILL.md` following the template
3. Add examples with real commands
4. Include "For AI Agents" section
5. Update this README

## 📖 Full Documentation

- [Hermès Agent Docs](https://hermes-agent.nousresearch.com)

## License

MIT