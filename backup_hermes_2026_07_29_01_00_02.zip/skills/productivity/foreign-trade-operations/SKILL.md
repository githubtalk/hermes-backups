---
name: foreign-trade-operations
description: >-
  Use this skill when managing a tractor/farm-machinery export business website.
  Covers: product listing creation, image optimization, SEO for international
  markets, search engine submission, site maintenance workflows, and
  comprehensive PHP website system with built-in SEO optimization.
# Pitfalls learned from sessions:
# 1. Page-loader: REMOVED entirely — CDN blocked in China = infinite white screen. See references/page-loader-pitfalls.md
# 2. CSS literal \\n breaks selectors. Fix: sed -i 's/\\\\n/\\n/g'. See references/css-bugs-and-style-preferences.md
# 3. Bundle files: update bundle directly, not source files.
# 4. Google Fonts/Font Awesome: use media="print" onload="this.media='all'" with <noscript> fallback.
# 5. User prefers LIGHT backgrounds. Dark gradients rejected. Use #f0f4f8, #e8eef5, #e8edf3.
# 6. "去掉" = remove immediately, no confirmation needed.
# 7. Section padding: standard 3rem, newsletter 2rem, category-showcase 4rem 0 2rem.
# 8. Cloudflare bot protection: use curl, not browser tools.
# 9. D1 schema: name,category,description,detailed_description,specifications,image_url,gallery_images,is_featured,is_active — NO price/stock_status. See references/d1-database-image-conventions.md
# 10. Invalid CSS var names cause Workers 500 errors — match layout.js. Never use --primary-color, --text-light, --bg-light, --text-dark.
# 11. shengtuo.cc.cd detail pages return 404 — extract images from listing page only (browser console on /products).

triggers:
  - "发布新产品"
  - "更新图片"
  - "SEO 优化"
  - "SEO关键词"
  - "关键词优化"
  - "meta_title"
  - "meta_keywords"
  - "meta_description"
  - "Product Schema"
  - "JSON-LD修复"
  - "sitemap修复"
  - "标题层级"
  - "heading hierarchy"
  - "提交搜索引擎"
  - "外贸网站运营"
  - "tractor export"
  - "Flash 已不支持"
  - "Adobe Flash"
  - "轮播图替换"
  - "这个样式"
  - "图片风格"
  - "参考这个图片"
  - "按这个颜色"
  - "shengtuo-tractor"
  - "统一商务简洁"
  - "商务风格"
  - "professional appearance"
  - "business style"
  - "加宽"
  - "加宽网站"
  - "宽度不变"
  - "浮动联系栏"
  - "whatsapp"
  - "网页板块上移"
  - "板块上移"
  - "页面紧凑"
  - "间距太大"
  - "section间距"
  - "去掉Newsletter"
  - "去掉导航栏WhatsApp"
  - "页面转圈"
  - "loading转圈"
  - "spinner"
  - "页面加载不出来"
  - "白屏"
  - "看不见内容"
  - "背景太暗"
  - "深色背景"
  - "白色文字看不见"
  - "板块间距"
  - "Newsletter"
  - "Newsletter宽度"
  - "bundle-v2.min.js"
  - "b2b-enhance.js"
  - "page-loader"
  - "whatsapp-float"
  - "wa-float-btn"
  - "轮播板块间距"
  - "restore carousel spacing"
  - "页面一直转圈"
  - "加载不出来"
  - "page-loader"
  - "加载动画"
  - "loading spinner"
  - "Google Fonts"
  - "异步加载"
  - "CSS选择器失效"
  - "浮动按钮不显示"
  - "whatsapp不显示"
  - "页面加载优化"
  - "转圈"
  - "loading"
  - "spinner"
  - "page-loader"
  - "字体加载"
  - "Google Fonts"
  - "异步加载"
  - "bundle文件"
  - "CSS解析错误"
  - "缓存问题"
  - "浏览器缓存"
  - "打开速度"
  - "加载速度"
  - "加载不出来"
  - "去掉MSN"
  - "去掉QQ"
  - "左下角"
  - "footer清理"
  - "Footer清理"
  - "页脚清理"
  - "垂直对齐"
  - "页面转圈"
  - "一直加载"
  - "打不开"
  - "加载不出来"
  - "页面白屏"
  - "加载速度"
  - "打开速度"
  - "性能优化"
  - "网页对齐"
  - "重新写个网站"
  - "网站系统"
  - "PHP网站"
  - "后台管理"
  - "admin panel"
  - "auth.php"
  - "shared template"
  - "CSRF保护"
  - "flash消息"
  - "CRUD管理"
  - "测试后台"
  - "外键约束"
  - "foreign key"
  - "category_id"
  - "schema mismatch"
  - "column not found"
  - "silent failure"
  - "session expired"
  - "0 bytes"
  - "admin testing"
  - "后台测试流程"
  - "借鉴优点"
  - "参考项目"
  - "web_b2b"
  - "modern UI"
  - "现代设计"
  - "产品卡片升级"
  - "hover效果"
  - "lightbox"
  - "证书展示"
  - "统计数据"
  - "全部测试"
  - "admin functions"
  - "结构布局优化"
  - "Homepage Section Rhythm Pattern"
  - "section合并"
  - "背景交替"
  - "15个section"
  - "10个section"
  - "页面太长"
  - "滚动疲劳"
  - "同色背景"
  - "section太多"
  - "floating WhatsApp"
  - "back to top"
  - "回到顶部"
  - "page loader"
  - "loading animation"
  - "加载动画"
  - "partner logos"
  - "合作伙伴"
  - "client logos"
  - "newsletter"
  - "订阅"
  - "inquiry modal"
  - "询价弹窗"
  - "sticky navbar"
  - "粘性导航"
  - "scroll shadow"
  - "Dashboard统计"
  - "询盘管理"
  - "inquiries"
  - "structured data"
  - "JSON-LD"
  - "schema.org"
  - "PWA"
  - "service worker"
  - "sitemap生成"
  - "robots.txt"
  - "404页面"
  - "Meta标签"
  - "Open Graph"
  - "面包屑导航"
  - "Gzip压缩"
  - "浏览器缓存"
  - "SEO检查"
  - "nginx配置"
  - "PHP-FPM"
  - "部署PHP网站"
  - "域名绑定"
  - "域名联动"
  - "SEO联动"
  - "og:url"
  - "canonical"
  - "HTTPS检测"
  - "X-Forwarded-Proto"
  - "子域名测试"
  - "sudo tee"
  - "404页面不生效"
  - "index order"
  - "导入产品数据"
  - "爬取产品"
  - "scrape products"
  - "import products"
  - "产品迁移"
  - "数据迁移"
  - "校对图片"
  - "产品图片"
  - "图片替换"
  - "图片抓取"
  - "商务优化"
  - "首页美化"
  - "页面升级"
  - "模板统一"
  - "page-banner"
  - "产品详情页"
  - "联系页面"
  - "about页面"
  - "sub.aiv.qzz.io"
  - "scrape images"
  - "链接优化"
  - "link audit"
  - "clean URL"
  - "broken links"
  - "断链"
  - "404修复"
  - "nginx clean URL"
  - "robots.txt"
  - "SITE_URL"
  - "产品宣传"
  - "产品主导"
  - "product-focused"
  - "HP筛选"
  - "马力筛选"
  - "horsepower filter"
  - "分类卡片"
  - "category cards"
  - "产品徽章"
  - "product badge"
  - "热门产品"
  - "hot products"
  - "best seller"
  - "Tab筛选"
  - "tab filtering"
  - "优化链接"
  - "fix links"
  - "broken links"
  - "断链"
  - "clean URL"
  - "clean url"
  - "链接审计"
  - "link audit"
  - "导航栏分类"
  - "navbar categories"
  - "产品主导"
  - "product-focused"
  - "产品优先"
  - "HP筛选"
  - "马力范围"
  - "图片自动缩放"
  - "视口缩放"
  - "响应式图片"
  - "轮播图响应式"
  - "产品图片比例"
  - "色彩优化"
  - "颜色比例"
  - "配色方案"
  - "color harmony"
  - "CSS变量"
  - "变量未定义"
  - "中英文切换"
  - "语言切换"
  - "i18n"
  - "多语言"
  - "language switch"
  - "翻译"
  - "lang_helper"
  - "t()"
  - "Chinese English"
---

# Foreign Trade Operations

## Website Overview

| Site | Platform | Domain | Canonical | Notes |
|------|----------|--------|----------|-------|
| 主站 | GitHub Pages + Cloudflare | shengtuo-tractor.com | → farm-implement.com | 已重定向 |
| 产品站 | GitHub Pages + Cloudflare | farm-implement.com | ✅ self | 主站，SEO 所有指向这里 |
| SADIN站 | GitHub Pages + Cloudflare | sadin-tractor.com | → farm-implement.com | 内容重复，通过 canonical 避免问题 |
| AIV站 | 本地服务器 + Cloudflare | aiv.qzz.io | ✅ self | 源码在 `/home/ubuntu/wwwroot/` |
| **sub.AIV站** | **本地Nginx + PHP-FPM** | **sub.aiv.qzz.io** | ✅ self | **PHP+MySQL新站** `/home/ubuntu/shengtuo-website/` |

**2026-05-18 SEO 优化完成:**
- farm-implement.com: canonical/sitemap/OG/JSON-LD 全部指向正式域名 ✅
- sadin-tractor.com: 通过 canonical 指向 farm-implement.com 避免重复内容
- aiv.qzz.io: 独立优化，添加完整 OGP/JSON-LD，源码本地

⚠️ **Cloudflare 覆盖 robots.txt**：Cloudflare Dashboard 的 Rules 可以覆盖源站 robots.txt。更新后不生效请检查 Cloudflare 设置。

**代码库：** `githubtalk/shengtuo-tractor`

### 三站托管区别

| 站点 | 托管方式 | 修改方式 | FTP信息 |
|------|----------|----------|---------|
| farm-implement.com | GitHub Pages | `git push` | 无需 |
| sadin-tractor.com | GitHub Pages (fork) | `git push` | 无需 |
| aiv.qzz.io | 本地服务器 `/home/ubuntu/wwwroot/` | 直接编辑，nginx立即生效 | 无需 |
| **shengtuo-tractor.com** | **Windows共享主机** | **需要FTP上传** | **gotoftp4.com 管理** |

> ⚠️ **shengtuo-tractor.com 是 Windows 主机**，不在本地服务器上。如需修改，需要：
> 1. 下载 index.html
> 2. 本地修复
> 3. FTP上传到主机

**修改流程**：
```bash
# 1. 下载（需FTP账号）
wget --user=用户名 --password=密码 ftp://主机地址/index.html

# 2. 本地修复后打包
tar -czvf flash_fix.tar.gz index.html

# 3. FTP上传（用 FileZilla 或 lftp）
lftp -u 用户,密码 ftp.主机地址 -e "put flash_fix.tar.gz; bye"
```

### 重要：SEO canonical 指向

- **farm-implement.com** — 主站，所有 canonical/OG/sitemap 指向这里
- **sadin-tractor.com** — 内容相同，通过 canonical 避免重复内容问题
- **aiv.qzz.io** — 独立站，有自己的源码和 sitemap

> ⚠️ **GitHub Pages 部署需要 ~5分钟**，不是 1-2 分钟。推送后不能立即验证。

### 源文件路径

| 站点 | 源文件位置 | 部署方式 |
|------|-----------|----------|
| farm/sadin | `/tmp/shengtuo-tractor/` (git clone) 或 `/home/ubuntu/shengtuo-tractor/` | GitHub Pages |
| AIV站 | `/home/ubuntu/wwwroot/` (nginx 直接服务) | 本地修改，直接生效，无需上传 |
| **sub.AIV站** | **`/home/ubuntu/shengtuo-website/`** (Nginx + PHP-FPM + MySQL) | **后台管理：`/admin/` 用户名admin 密码shengtuo2026** |

---

## Product Listing Workflow

### 1. 准备产品图片

图片规范（参考 `compress-images.js`）：

```bash
# 压缩所有图片（已配置）
node compress-images.js

# 手动压缩单张（可选）
# - JPG: quality 75-80, progressive
# - PNG: compressionLevel 9
# - 最大尺寸: 1200x800px
# - 产品图建议: 800x600px
```

**命名规范：** `产品型号-角度-序号.jpg`
例：`ST904-侧面-1.jpg`、`MF904-正面-2.jpg`

### 2. 添加产品页面

产品页面存放路径：`/products/` 目录

每个产品页面需包含：
- 产品型号、名称（英文）
- 主要参数表格（发动机、功率、工作效率）
- 产品图片（带 alt 英文描述）
- PDF规格书下载链接（如有）
- 询盘按钮链接（mailto 或表单）

### 3. 更新 sitemap

生成 sitemap 后确保：
- 所有产品页面链接正确
- `lastmod` 更新为当天日期
- `priority` 按重要性：首页 1.0，产品列表 0.8，单品 0.6

---

## Image Optimization Script

路径：`/home/ubuntu/shengtuo-tractor/compress-images.js`

**用法：**
```bash
cd /home/ubuntu/shengtuo-tractor
node compress-images.js
```

**输出：** 报告压缩文件数 + 节省空间

---

## SEO Checklist

### 每次发布新产品后必做

- [ ] 产品标题含核心关键词（英文）
- [ ] 产品描述含长尾关键词（至少 3 处自然出现）
- [ ] 图片有 alt 英文描述
- [ ] sitemap 更新并提交（模板见 `references/sitemap-robots-template.md`）
- [ ] Google Search Console 提交 URL
- [ ] Bing Webmaster 提交 URL
- [ ] Yandex Webmaster 提交 URL（如面向俄语市场）
- [ ] Baidu Webmaster 提交 URL（如面向中国市场）

### Meta Tags（各平台验证）

| 平台 | Tag | 位置 |
|------|-----|------|
| Google | `coJuNSF-ATVY_yxIm1lR6a4DphP3zTWYrzKABqat_Wg` | index.html |
| Baidu | `codeva-NbRNAmGaEy` (shengtuo-tractor.com) | index.html |
| Baidu | `codeva-1ecpfnMFSE` (farm-implement.com) | index.html |
| Yandex | `3fdba79f71c66d1b` | index.html |

---

## Search Engine Submission

### Google Search Console
URL: https://search.google.com/search-console
- 提交 sitemap: `https://www.shengtuo-tractor.com/sitemap.xml`
- 检测覆盖率错误
- 查看关键词排名

### Bing Webmaster
URL: https://www.bing.com/webmasters
- 需注册/登录 Microsoft 账户
- 支持扫码验证

### Yandex Webmaster
URL: https://webmaster.yandex.com
- 适合俄语、中亚、欧洲市场

### Baidu Webmaster
URL: https://ziyuan.baidu.com
- 中国市场必备
- 支持 HTML 文件验证或 Meta 标签验证

---

## SEO 优化标准流程（GitHub Pages）

当修改 GitHub Pages 站点时，所有 SEO 相关文件必须同步更新：

### 必须更新的 4 个文件

```bash
cd /home/ubuntu/shengtuo-tractor

# 1. index.html - canonical/OG/JSON-LD/sitemap/robots.txt
sed -i 's|old-domain|new-domain|g' index.html

# 2. categories.html（如有）
sed -i 's|old-domain|new-domain|g' categories.html

# 3. sitemap.xml
# 手动更新 <loc> 标签中的域名

# 4. robots.txt
# 更新 Sitemap 行
```

### GitHub Pages 部署流程

```bash
# 1. 修改文件
git add .
git commit -m "SEO update: canonical/OG/JSON-LD"

# 2. 推送到 GitHub（如有冲突）
git pull --rebase origin master
# 如有冲突：
# - 解决冲突
# - git add .
# - git rebase --skip  # 当无法设置 EDITOR 时用 skip

# 3. 推送
git push origin master

# 4. 等待 ~5 分钟生效
# 验证：curl https://raw.githubusercontent.com/USER/REPO/master/robots.txt
```

### AIV 站优化流程（本地服务器）

```bash
# 源文件在 /home/ubuntu/wwwroot/
# nginx root 已配置为 /home/ubuntu/wwwroot
# 修改后直接生效（无需上传）

# 更新包打包（需手动上传到其他服务器时）：
tar -czvf /tmp/aiv_seo_update.tar.gz index.html robots.txt sitemap.xml
```

### 域名绑定状态

- `shengtuo-tractor.com` → Cloudflare DNS，CNAME 指向源站
- `farm-implement.com` → GitHub Pages custom domain
- `sadin-tractor.com` → GitHub Pages custom domain（fork 仓库）

**注意：** GitHub Pages 如使用自定义域名，`Enforce HTTPS` 选项在 GitHub 后台可能不可点击（正常），由 Cloudflare 处理 HTTPS 跳转。

---

## 产品描述模板

英文产品描述结构（用于 SEO）：

```html
<!-- 产品标题 -->
<h1>[型号] Agricultural [产品类型] for Sale</h1>

<!-- 产品描述段落 -->
<p>The [型号] is a high-performance agricultural [产品类型] designed for
[主要应用场景]. Featuring [核心参数], it delivers reliable performance
in [适用地形/作物类型] operations across [目标市场].</p>

<!-- 参数列表 -->
<ul>
  <li><strong>Engine:</strong> [发动机型号]</li>
  <li><strong>Power:</strong> [功率] HP</li>
  <li><strong>Working Width:</strong> [工作宽度]</li>
  <li><strong>Application:</strong> [适用场景]</li>
</ul>

<!-- 关键词自然分布 -->
<p>This [产品类型] is ideal for [目标国家/地区] farmers looking for
cost-effective farming equipment. Competitive price, fast delivery,
and [其他卖点].</p>
```

---

## 市场关键词参考

| 市场 | 高频搜索词 |
|------|-----------|
| 东南亚 | tractor price, agricultural tractor, 4WD tractor |
| 非洲 | tractor for sale, farm equipment, affordable tractor |
| 欧洲 | agricultural machinery, farm tractor, CE certified |
| 南美 | tractor agrícola, equipo de granja, tractor económico |
| 中东 | farming equipment, agricultural implements |

---

## 关键 Pitfalls（必读）

### 1. CSS 字面量 `\n` 会破坏选择器
**问题**: CSS 合并文件中如果出现字面量 `\n`（反斜杠+n），CSS 解析器会把后面的 `.wa-float-btn` 解析为 `n .wa-float-btn`，导致样式完全失效。
**症状**: 浮动 WhatsApp 按钮不显示、某些 CSS 类不生效。
**排查**: `cat -A bundle.css | grep '\\\\n'` 或浏览器 DevTools 检查计算样式。
**修复**: `sed -i 's/\\n/\n/g' bundle.css` 或手动替换。

### 2. Page Loader + 外部 CDN = 无限转圈（中国必修）
**问题**: `.page-loader` 使用 `window.addEventListener('load', ...)` 隐藏时，Google Fonts/Font Awesome 等外部 CDN 在中国可能超时，`load` 事件永远不触发，白色遮罩+转圈永远不消失。
**修复方案**:
- JS 用 `DOMContentLoaded` 代替 `load`
- 加 3 秒超时兜底: `setTimeout(hideLoader, 3000)`
- CSS 动画兜底: `@keyframes autoHideLoader { 85% { opacity:1 } 100% { opacity:0; visibility:hidden } }`
- Google Fonts/Font Awesome 异步加载: `<link rel="stylesheet" href="..." media="print" onload="this.media='all'">`

### 3. 合并文件必须直接修改
**问题**: `b2b-enhance.js` 等源文件修改不会生效，实际加载的是 `bundle-v2.min.js`。
**修复**: 必须修改 bundle 文件。CSS 同理（`bundle-v8.min.css`）。
**验证**: 改完后更新缓存版本号 `?v=<?= time() ?>`。

### 4. Cloudflare 缓存排查
CSS/JS 用 `<?= time() ?>` 自动更新版本号。用户看不到最新页面时，优先让他们用无痕模式验证。

## 常见问题

### 图片太大会影响加载速度
运行 `node compress-images.js` 批量压缩，建议单图 ≤ 200KB。

### sitemap 更新后搜索引擎没更新收录
手动到各平台 Search Console 提交 URL 或重新提交 sitemap，通常 3-7 天更新。

### Cloudflare HTTPS 525 错误
检查源站是否有有效 SSL 证书。无独立 IP 的共享主机建议使用 Cloudflare **Flexible SSL** 模式。

### Cloudflare Flexible SSL 重定向循环（ERR_TOO_MANY_REDIRECTS）

**症状：** 浏览器报 `ERR_TOO_MANY_REDIRECTS`，curl 返回 301 但 body 为空。

**原因：** Cloudflare Flexible SSL 通过 HTTP 连接源站，但 nginx 将 HTTP 重定向到 HTTPS，形成循环：
`Client→HTTPS→CF→HTTP→Origin→301→HTTPS→CF→HTTP→Origin→...`

**修复：** nginx 80 端口直接提供内容，不重定向到 HTTPS。
完整配置见 `references/nginx-cloudflare-flexible-ssl.conf`

**关键点：**
- 80 端口服务器块：直接提供内容，不要 `return 301 https://...`
- 443 端口服务器块：正常 SSL 配置
- 两个服务器块都配置相同的 location 规则

**相关权限问题：** Let's Encrypt 证书目录默认 700 权限，nginx worker 无法读取：
```bash
sudo chmod 755 /etc/letsencrypt/{live,archive}
sudo chmod 644 /etc/letsencrypt/archive/aiv.qzz.io/*.pem
sudo nginx -t && sudo systemctl reload nginx
```

**验证修复：**
```bash
# HTTP 应该返回 200（不是 301）
curl -sI http://aiv.qzz.io | head -5

# HTTPS 应该返回 200
curl -sI https://aiv.qzz.io | head -5
```

### Baidu 验证失败
确保验证文件正确上传到服务器根目录，或使用 Meta 标签验证方式（直接添加到 index.html 最优）。

---

## 工具路径速查

| 工具 | 路径 |
|------|------|
| 图片压缩脚本 | `/home/ubuntu/shengtuo-tractor/compress-images.js` |
| sitemap | `/home/ubuntu/shengtuo-tractor/sitemap.xml` |
| 主页 | `/home/ubuntu/shengtuo-tractor/index.html` |
| GitHub 仓库 | https://github.com/githubtalk/shengtuo-tractor |
| Cloudflare | https://dash.cloudflare.com |

---

### 报价单翻译工作流

将盛拓农机报价单（`.docx`）翻译为法语、西班牙语等版本，保持格式不变。

### 盛拓报价单结构（实际文档）

共有 **13个表格**，按马力段分布：

| 表格 | 产品系列 | 马力范围 |
|------|----------|----------|
| Table 0 | TS170-ST200 | 17-20HP |
| Table 1 | ST254Y-ST504Y | 25-50HP |
| Table 2 | ST304-ST504 | 30-50HP |
| Table 3 | ST504D MINI.GARDEN | 50HP |
| Table 4 | ST504-ST704 GARDEN | 50-70HP |
| Table 5 | ST504-ST704 | 50-70HP |
| Table 6 | ST604-ST704 | 60-70HP |
| Table 7 | ST504B-ST1004B | 50-100HP |
| Table 8 | ST904-ST1304 | 90-130HP |
| Table 9 | ST1404-ST1804 | 140-180HP |
| Table 10 | ST2004-ST2104 | 200-210HP |
| Table 11 | ST2204-ST2404 | 220-240HP |
| Table 12 | ST2604 | 260HP |

**段落内容（需翻译）：**
- Paragraph 1: 公司介绍（长段落，包含多句）
- Paragraph 2: "We are looking forward to cooperating with you!"

**不翻译内容：**
- Heading 1: 文档标题（"Shengtuo" Company Profile...）
- Heading 3: "Get in Touch:" / "Follow Us for Updates & Videos:"
- 联系信息段落（人名 Henry、电话、邮箱、地址、社交媒体）

### 扩展技术词汇（英→法）

| 英文 | 法语 |
|------|------|
| 2WD / TWO WHEEL DRIVE | 2RM / DEUX ROUES MOTRICES |
| 4WD / FOUR WHEEL DRIVE | 4RM / QUATRE ROUES MOTRICES |
| Type de roues | Type de roues |
| Empattement | wheel base |
| Garde au sol | Ground Clearance |
| Masse | Structure mass |
| Lest roue avant/arrière | Front/Rear Wheel ballast |
| Marque moteur | Engine Brand |
| Type moteur | Engine Type |
| Carburant | Fuel |
| Gasole | Diesel oil |
| Pneumatique | Tyre |
| Roue avant/arrière | Front/Rear wheel |
| Embrayage mono-disque | Single-stage clutch |
| Direction mécanique | Mechanical steering |
| Direction assistée | Power steering |
| Boîte de vitesses | Transmission box |
| Méthode de transmission | Transmission method |
| Courroie trapézoïdale | V-belt |
| Suspension trois points | Tri-point suspension |
| PDF latérale / Prise de force | SIDE PTO |
| Type semi-indépendant | Semi-indenendent type |
| Cadre métallique | iron frame |
| Conteneur | container |
| Conteneur 40' | 40' container / 40HQ |
| Tracteur de jardin | Garden tractor |
| Mini tracteur | Mini tractor |
| AVEC CABINE | CABIN ADD |
| CLIMATISATION | A/C |
| PDF AVANT ET SUSPENSION | FRONT PTO AND SUSPENSION |
| ARCEAU | ROPS |
| Toit solaire | Sun canopy |
| INVERSEUR | SHUTTLE SHIFTS |
| Secteur denté | Gear sector |
| REFROIDISSEUR | water cooled |
| Refroidi par eau | water cooled |
| Cylindre unique horizontal | Single cylinder Horizontal |
| Frein sec, disques | Dry brake,discs |
| Type suralimenté | Turbo / Aspiration |
| Jusqu'à l'évent d'échappement | to the exhaust vent |
| Jusqu'au lest avant | to front ballast |

### 段落翻译示例（公司介绍）

**原文：**
> Shandong Shengtuo Heavy Industry Co.,Ltd.(short for Shengtuo) is a high-level agricultural equipment manufacturer. Shengtuo is located in Weifang City Shandong province, with investment amount of one hundred million Yuan, covers an area of 25,000 square meters, The annual production capacity is 15,000 sets of agricultural machines. The main product is tractor of 25hp--260hp. All the tractor models have been in the List of Government subsidies. Shengtuo has marketing network all over the China, and the tractors have been exported to more than 20 countries. Shengtuo, believes in "honesty, innovation, quality and win-win", for us, the responsibility is the most important, and we will never change the first mind to con-centrate on making tractors, to push the modern Mechanized agriculture!

**译文：**
> Shandong Shengtuo Heavy Industry Co., Ltd. (abréviation : Shengtuo) est un fabricant d'équipements agricoles de haut niveau. Shengtuo est situé dans la ville de Weifang, province du Shandong, avec un investissement de cent millions de yuans, couvrant une superficie de 25 000 mètres carrés. La capacité de production annuelle est de 15 000 ensembles de machines agricoles. Le produit principal est le tracteur de 25 à 260 ch. Tous les modèles de tracteurs sont inscrits sur la liste des subventions gouvernementales. Shengtuo dispose d'un réseau commercial dans toute la Chine, et les tracteurs ont été exportés vers plus de 20 pays. Shengtuo croit en « honnêteté, innovation, qualité et gain partagé » ; pour nous, la responsabilité est la plus importante, et nous ne changerons jamais notre engagement à nous concentrer sur la fabrication de tracteurs, pour promouvoir l'agriculture mécanisée moderne !

### Python 环境注意

**关键发现：** Hermes Agent 的 venv 在 `/home/ubuntu/.hermes/hermes-agent/venv/bin/python3` 没有 python-docx。系统 Python 在 `/usr/bin/python3` 有（通过 pip install --user 安装）。

**运行翻译脚本必须用：**
```bash
/usr/bin/python3 /path/to/translate_script.py
```

不要用 `hermes-agent` 的 venv Python，会报 `ModuleNotFoundError: No module named 'docx'`。

### 翻译脚本模板

```python
#!/usr/bin/env python3
"""Translate document to target language"""

from docx import Document

TRANSLATIONS = {
    # 原文: 译文
    "Original English text": "Translated text",
}

def translate_text(text):
    if not text:
        return text
    for eng, fr in TRANSLATIONS.items():
        if eng in text:
            text = text.replace(eng, fr)
    return text

def process_document(input_path, output_path):
    doc = Document(input_path)
    
    for para in doc.paragraphs:
        # Skip headers
        if para.style and 'Heading' in para.style.name:
            continue
        original = para.text
        if original.strip():
            translated = translate_text(original)
            if translated != original:
                for run in para.runs:
                    run.text = ""
                para.runs[0].text = translated if para.runs else translated
    
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    if para.style and 'Heading' in para.style.name:
                        continue
                    original = para.text.strip()
                    if original:
                        translated = translate_text(original)
                        if translated != original:
                            for run in para.runs:
                                run.text = ""
                            para.runs[0].text = translated if para.runs else translated
    
    doc.save(output_path)

if __name__ == "__main__":
    import sys
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    process_document(input_file, output_file)
```

**运行：**
```bash
/usr/bin/python3 translate_doc.py input.docx output.docx
```

### 关键原则

1. **参数标签翻译**：Horsepower → Puissance，但数值和单位保留
2. **型号名称不翻译**：TS904、ST504D 等保持原样
3. **价格不翻译**：US$、FOB QINGDAO 保留
4. **技术规格不翻译**：发动机品牌、型号、轮胎规格等
5. **人名/联系信息不翻译**：Henry、电话、邮箱、地址
6. **页眉不翻译**：Heading 样式跳过

---

## ⚠️ 关键原则：用户尺寸约束（"不变"原则）

当用户对某个尺寸明确说"不变"时，这是**硬约束**，绝对不能修改。

**已知不变尺寸：**
- `#header` 高度：`min-height: 136px`
- `.flash` Banner 高度：`height: 373px`

**违反此原则 = 用户不满。** 每次修改 CSS 前检查这些值。

**⚠️ execute_code 中 read_file 的两个陷阱（2026-05-30 实战发现）：**

**陷阱1：key 名称不同。** 直接调用 `read_file` 工具返回 `content` 键，但在 `execute_code` 内部调用 `from hermes_tools import read_file` 时返回的键是 `content_returned`，不是 `content`。

```python
# ❌ 错误
content = read_file("/path/to/file")["content"]  # KeyError!

# ✅ 正确
content = read_file("/path/to/file")["content_returned"]
```

**陷阱2：dedup 会返回 False。** 如果同一会话中已经用 `read_file` 工具读过该文件，`execute_code` 内的 `read_file` 会检测到内容未变化，返回 `content_returned: False`（布尔值），后续 `.replace()` 会报 `AttributeError: 'bool' object has no attribute 'replace'`。

**解决方案：**
- 用 `patch` 工具代替 `execute_code` 内的 read+modify+write 流程
- 或者用 `terminal` 的 `sed` 做简单替换
- 如果必须在 `execute_code` 中修改文件，先检查 `content_returned` 类型

**⚠️ 核心工作原则（用户授权型风格）：**

用户亨利（Henry）是授权型 — "你去做吧"、"你直接调动就可以"，不需要每步确认。但这也意味着：
- 做错了用户会直接骂（"笨蛋"、"你真笨"）
- 必须**先诊断再动手**，不要盲目尝试
- 修完**必须验证**，不要说"搞定了"但实际没好
- 用户说"全部恢复"时**一步到位**，不要分多步

**用户沟通风格：**
- 中文交流，偏好简洁直接
- 不要长篇解释，直接做
- 不要问"你想怎么做"，直接给方案
- 但做错了会被骂，所以要谨慎

**商务简洁设计模式：** `references/css-business-professional-design.md`
包含：CSS 变量、配色方案、产品卡片样式、导航栏渐变、批量更新所有页面的 5 步工作流（含 ASP 索引文件更新）、宽度变体（980px/1200px）、尺寸约束清单。
验证脚本：`scripts/verify_css_version.py`

**移动端设计：** `references/css-mobile-responsive-patterns.md`
包含：⚠️ 已过时 — 用户明确要求手机和电脑显示一样（不要响应式）。viewport 标签 + 删除 @media 查询即可。

**CSS 宽度调整工作流：** `references/css-width-widening-workflow.md`
包含：网站加宽时需要更新的所有选择器清单、列宽比例计算、完整 5 步上传流程。

当用户要求 "SEO优化" 或 "外形美观" 时，**不要替换产品结构**。只做：
- 增强 CSS（hover 效果、阴影、过渡动画）
- 添加/改进结构化数据（Schema.org）
- 添加 hreflang、geo meta 标签
- 更新 sitemap.xml

**不要做：**
- 把产品表格改成卡片布局
- 删除或重组原有内容区块
- 替换整个 HTML 文件

> 用户原话："不要动原来的产品结构" — 这是明确的偏好，必须遵守。

**正确做法：** 用 `patch` 工具对 `index.html` 做局部修改，不要用 `write_file` 整体替换。

### CSS/JS 叠加美化模式（推荐）

当用户要求"美化外观"但明确说"不动后台/产品结构"时，使用此模式：

1. **添加新文件**：`css/custom.css` + `js/custom.js`
2. **只改 `<head>`**：在现有 CSS/JS 引用后各加一行
3. **用 CSS 覆盖**：通过 `!important` 和更高优先级选择器覆盖原样式
4. **不碰 HTML 结构**：产品列表、表格、内容块保持原样

详细模板和示例见 `references/css-js-overlay-beautification.md`

## ⚠️ 关键陷阱：read_file 行号污染文件

**问题：** `read_file` 工具输出格式是 `行号|内容`（如 `1|*{margin:0px;}`）。如果把 read_file 的输出直接写入文件（通过 execute_code 的 write_file、terminal heredoc、或任何方式），行号前缀会成为文件内容的一部分。

**后果：**
- CSS 文件每行变成 `1|*{margin:0px;}` → 浏览器解析失败，**所有样式丢失**
- HTML 文件同理会损坏
- 结合 Cloudflare 缓存，损坏的文件被 CDN 缓存后更难修复

**症状诊断：**
```javascript
// 浏览器 Console 中检查
const sheet = Array.from(document.styleSheets).find(s => s.href && s.href.includes('style.css'));
console.log(sheet.cssRules.length); // 如果是 0，CSS 文件已损坏！
```

```bash
# 服务端检查 — 正常 CSS 不应有行号前缀
curl -s "https://www.shengtuo-tractor.com/css/style.css" | head -3
# 损坏: "1|*{margin:0px; padding:0px;}"
# 正常: "*{margin:0px; padding:0px;}"
```

**预防措施：**
1. **永远不要** 直接把 read_file 输出写入文件
2. 用 `patch` 工具做精确替换，而不是 read → modify → write
3. 如果必须 read + write，先用 `sed 's/^[[:space:]]*[0-9]*|//'` 清理行号
4. 上传后**必须**验证文件内容（`curl -s URL | head -3`）

**修复方法：**
```bash
# 清理行号前缀
curl -s -u "USER:PASS" ftp://HOST/wwwroot/css/style.css | sed 's/^[[:space:]]*[0-9]*|//' > /tmp/style-fixed.css
curl -T /tmp/style-fixed.css -u "USER:PASS" ftp://HOST/wwwroot/css/style.css
```

## 动态页面模板系统（ASP）

shengtuo-tractor.com 使用 **LankeCMS ASP 模板系统**生成动态页面。有两种页面类型：

### 页面类型区分

| 类型 | 文件格式 | 示例 | 修改方式 |
|------|---------|------|---------|
| 静态 HTML | `.html` | about/2.html, products/224.html | FTP 直接上传 |
| 动态 ASP | `.asp` | products/index.asp, message/index.asp | 修改 Inc/ 模板文件 |

**关键发现（2026-05-29）：** ASP 页面的 footer、侧边栏、浮动栏都由 `Inc/` 目录下的模板文件控制，不是写在 `.asp` 文件里。修改 ASP 页面必须改模板！

### ASP 模板文件清单

| 模板路径 | 控制内容 | 关键变量 |
|---------|---------|---------|
| `Inc/foot.asp` | Footer + 浮动栏 + 分享按钮 | `config("copyright")`, `config("share")`, eqq.asp |
| `Inc/hot.asp` | 侧边栏 CONTACT US 区域 | `config("dz")`, `config("tel")`, `config("fax")`, `config("mail")`, `config("name")` |
| `Inc/left.asp` | 左侧导航栏 | `Lankecms_leftnav` |
| `Inc/header.asp` | 页面头部 | - |
| `Inc/config.asp` | 全站配置读取 | 从数据库 `config` 表读取 |
| `module/eqq.asp` | 旧浮动联系栏（MSN/QQ/淘宝）| 生成 rightDiv HTML |

### 踩坑：config("copyright") 包含注入脚本

**问题：** 数据库 `config` 表的 `copyright` 字段值里嵌入了 AddThis 分享按钮代码和 Google Analytics 脚本。直接 `<%=config("copyright")%>` 会把这些脚本一起输出到页面。

**症状：** footer 的 `<div class="copyright">` 里混入了 `<div class="addthis_toolbox">`、GA `<script>` 等代码。

**修复方法 — ASP 端字符串清理：**
```asp
<%
dim cleanCopyright
cleanCopyright = config("copyright")
' Strip AddThis block
dim addThisStart, addThisEnd
addThisStart = instr(cleanCopyright, "<!-- AddThis")
if addThisStart > 0 then
    addThisEnd = instr(addThisStart, cleanCopyright, "<!-- AddThis Button END -->")
    if addThisEnd > 0 then
        cleanCopyright = left(cleanCopyright, addThisStart - 1) & mid(cleanCopyright, addThisEnd + len("<!-- AddThis Button END -->"))
    end if
end if
' Strip Google Analytics script
dim gaStart, gaEnd
gaStart = instr(cleanCopyright, "<script>")
if gaStart > 0 then
    gaEnd = instr(gaStart, cleanCopyright, "</script>")
    if gaEnd > 0 then
        cleanCopyright = left(cleanCopyright, gaStart - 1) & mid(cleanCopyright, gaEnd + len("</script>"))
    end if
end if
cleanCopyright = replace(cleanCopyright, vbcrlf & vbcrlf, vbcrlf)
%>
```

### 完整修复后的 foot.asp 模板

```asp
<%
dim cleanCopyright
cleanCopyright = config("copyright")
' Strip AddThis and GA scripts from copyright value
dim addThisStart, addThisEnd, gaStart, gaEnd
addThisStart = instr(cleanCopyright, "<!-- AddThis")
if addThisStart > 0 then
    addThisEnd = instr(addThisStart, cleanCopyright, "<!-- AddThis Button END -->")
    if addThisEnd > 0 then
        cleanCopyright = left(cleanCopyright, addThisStart - 1) & mid(cleanCopyright, addThisEnd + len("<!-- AddThis Button END -->"))
    end if
end if
gaStart = instr(cleanCopyright, "<script>")
if gaStart > 0 then
    gaEnd = instr(gaStart, cleanCopyright, "</script>")
    if gaEnd > 0 then
        cleanCopyright = left(cleanCopyright, gaStart - 1) & mid(cleanCopyright, gaEnd + len("</script>"))
    end if
end if
cleanCopyright = replace(cleanCopyright, vbcrlf & vbcrlf, vbcrlf)
%>
<div id="footer">
    <div class="links">
        Links：
        <a href='https://www.instagram.com/shengtuo_tractor' target='_blank'>shengtuo-Tractor Company Video</a> | 
    </div>  
    <div class="copyright">
        <p><%=cleanCopyright%> <a href="<%=root%>/sitemap.html" target="_blank">Sitemap</a></p>
        <p>Add：<%=config("dz")%> &nbsp;Tel：<%=config("tel")%></p>
    </div>
    <div class="clear"></div>
</div>

<!-- WhatsApp Floating Button -->
<a href="https://wa.me/8613806461474" target="_blank" class="whatsapp-float" title="Chat with us on WhatsApp">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" fill="#fff">
        <path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/>
    </svg>
</a>
```

### 修复后的 hot.asp 模板（侧边栏 CONTACT US）

```asp
<!--#include file="../module/hot.asp" -->
        
        <div class="category_title">CONTACT US</div>
        <ul class="contact">
            <li>Add：<%=config("dz")%></li>
            <li>Tel：<%=config("tel")%></li>
            <li>E-mail：<%=config("mail")%></li>
            <li>Contacts：<%=config("name")%></li>
        </ul>
```

**关键变化：** 移除了 `<li>Fax：<%=config("fax")%></li>`（Fax 字段为空）。

### ASP 页面修改工作流

```
1. 确认目标是 ASP 还是 HTML（curl 检查文件扩展名）
2. 如果是 ASP → 修改 Inc/ 模板文件
3. 如果是 HTML → 直接修改并 FTP 上传
4. 修改模板后，所有使用该模板的 ASP 页面自动生效
5. 但已生成的静态 HTML 页面不会自动更新！
```

### ASP 索引文件速查

| 文件 | FTP 路径 | 用途 |
|------|---------|------|
| products/index.asp | /wwwroot/products/index.asp | 产品分类列表 |
| News/index.asp | /wwwroot/News/index.asp | 新闻列表 |
| cases/index.asp | /wwwroot/cases/index.asp | 案例列表 |
| download/index.asp | /wwwroot/download/index.asp | 下载列表 |
| Inquiry/index.asp | /wwwroot/Inquiry/index.asp | 询盘表单 |
| message/index.asp | /wwwroot/message/index.asp | 留言板 |

**注意：** 这些文件不在 sitemap 中，批量更新 CSS 引用时需要单独处理。

**FTP 凭证（shengtuo-tractor.com）：**
- 用户名：shanweituo
- 密码：C2r3h2q7K3
- 主机：shanweituo.gotoftp4.com
- 路径：/wwwroot/

**快速命令模板：**
```bash
# 下载文件
curl -o /tmp/file.html ftp://shanweituo.gotoftp4.com/wwwroot/file.html --user "shanweituo:C2r3h2q7K3"

# 上传文件
curl -T /tmp/file.html ftp://shanweituo.gotoftp4.com/wwwroot/file.html --user "shanweituo:C2r3h2q7K3"

# 列出目录
curl -s ftp://shanweituo.gotoftp4.com/wwwroot/ --user "shanweituo:C2r3h2q7K3"
```

**⚠️ 间距调整原则（2026-05-28 实战发现）：**

当用户要求"紧贴"、"靠着"、"不留空白"时，需要同时调整：
1. 上方元素的底部间距（`margin-bottom: 0`）
2. 下方元素的顶部间距（`margin-top: 0`）
3. 父容器的内边距（`padding: 0`）

**示例：ABOUT US 紧贴轮播栏**
```css
.flash { margin-bottom: 0; }  /* 轮播栏底部间距 */
.index_about { margin-top: 0; margin-bottom: 0; }  /* ABOUT US 顶部间距 */
#center { padding: 0; }  /* 内容区内边距 */
```

**⚠️ 重要：** 只调整间距，不要改变其他结构（宽度、高度、布局等）。

**⚠️ CSS 文件引用名是 `style_v8.css`（当前生产版本）：**

shengtuo-tractor.com 的 HTML 当前加载的是 `css/style_v8.css`。修改其他 CSS 文件不会生效！

```bash
# 检查实际加载的 CSS 文件
curl -s https://www.shengtuo-tractor.com | grep 'stylesheet'
# 输出: <link href="css/style_v8.css" ...>

# 正确的修改目标
curl -s ftp://shanweituo.gotoftp4.com/wwwroot/css/style_v8.css > /tmp/style_v8.css
# 修改后上传
curl -T /tmp/style_v8.css ftp://shanweituo.gotoftp4.com/wwwroot/css/style_v8.css
```

**⚠️ Footer 定位陷阱（2026-05-29 实战发现）：**

**问题1：Footer 不居中。** `#main` 有 `margin: 0 auto` 所以居中，但 `#footer` 只有 `width: 980px` 没有 margin 设置，会左对齐。

**问题2：Footer 出现在产品栏旁边（最常见！）。** `#center` 的子元素 `#left` 和 `#right` 都是 float，父容器没有清除浮动，导致 footer 紧跟在 `#center` 后面而不是在所有内容之后。

**症状：** 用户说"footer 放在产品栏一侧"、"不要放到一侧"、"放在网站底部"。

**根本原因：** `#center` 没有 `overflow: hidden`，浮动子元素不参与父容器高度计算。

**修复：** 两个问题一起修：
```css
#center {
    width: 980px;
    min-height: 500px;
    padding: 0;
    overflow: hidden;  /* 关键！包含浮动子元素 */
}

#footer {
    width: 980px;
    margin: 0 auto;    /* 居中 */
    background: #333;
    ...
}
```

**诊断方法：** 浏览器 Console 检查布局：
```javascript
const footer = document.getElementById('footer');
const center = document.getElementById('center');
const right = document.getElementById('right');
console.log('center height:', center.getBoundingClientRect().height);
console.log('right height:', right.getBoundingClientRect().height);
console.log('footer top:', footer.getBoundingClientRect().top);
// 如果 center height < right height，说明浮动未清除！
// 如果 footer top < center bottom + center height，说明 footer 位置不对
```

**症状：** footer 贴在浏览器左侧，不在页面中央。

**修复：** 在 CSS 的 `#footer` 选择器中添加 `margin: 0 auto`：
```css
#footer {
    width: 980px;
    margin: 0 auto;  /* 添加这一行 */
    background: #333;
    ...
}
```
## CSS `.links` 类
**Footer Links 区域 CSS（必须添加）：**

Footer 的 Links 区域需要 `.links` CSS 类才能正确显示分隔线和间距（当前在 style_v8.css 中）：
```css
#footer .links {
    padding-bottom: 10px;
    border-bottom: 1px solid rgba(255,255,255,0.15);
    margin-bottom: 10px;
}

#footer .links a {
    color: #60a5fa;
}
```

## About 页面内容样式

about/ 页面使用 `.content_title` 和 `.content` 类（不是 `#content .content-title`），需要单独添加样式：

```css
/* About Pages Content */
.content_title {
    font-size: 24px;
    font-weight: bold;
    color: #333;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid #2563eb;
}

.content {
    padding: 20px;
    line-height: 1.8;
    color: #666;
}

.content h3 {
    font-size: 18px;
    font-weight: bold;
    color: #333;
    margin: 20px 0 10px;
}

.content p {
    margin-bottom: 15px;
}

.content img {
    max-width: 100%;
    height: auto;
    margin: 10px 0;
}
```

**完整 Footer 一致性模式：** `references/footer-consistency-pattern.md`

**诊断方法：** 浏览器 Console 检查 footer 位置：
```javascript
const footer = document.getElementById('footer');
const main = document.getElementById('main');
const fr = footer.getBoundingClientRect();
const mr = main.getBoundingClientRect();
console.log('footer left:', fr.left, 'main left:', mr.left);
// 如果不相等，footer 没有居中
```

**⚠️ CMS 生成的 HTML 可能包含注入脚本（2026-05-29 实战发现）：**

LankeCMS 的模板占位符（如 `{Lankecms_beian}`、`{Lankecms_copyright}`）在 CMS 后台可能被填入了额外脚本（AddThis、Google Analytics 等），导致生成的 `index.html` footer 区域混乱。

**症状：** footer 里混入了 `<script>`、AddThis 分享按钮代码、GA 代码，导致布局错乱或内容被脚本分割。

**诊断方法：**
```bash
# 检查生成的 HTML footer 内容
curl -s ftp://shanweituo.gotoftp4.com/wwwroot/index.html --user "shanweituo:C2r3h2q7K3" | grep -A 30 'id="footer"'

# 检查模板文件是否干净
curl -s ftp://shanweituo.gotoftp4.com/wwwroot/template/index.htm --user "shanweituo:C2r3h2q7K3" | grep -A 15 'footer'
```

**修复方法：**
1. 下载生成的 `index.html`
2. 找到 `<div id="footer">` 到 `</div>` 的 footer 区域
3. 用 `execute_code` 精确替换 footer 内容（移除注入的脚本，保留有效信息）
4. FTP 上传修复后的文件

**示例清理代码：**
```python
# 下载 index.html
terminal("curl -s ftp://... --user ... > /tmp/index_edit.html")

# 读取并清理 footer
with open("/tmp/index_edit.html", "r") as f:
    content = f.read()

old_footer_start = '<div id="footer">'
old_footer_end = '</div>\n\n<script'  # footer 结束后紧跟的 script 标签

start_idx = content.find(old_footer_start)
end_idx = content.find(old_footer_end, start_idx)

# 替换为干净的 footer
new_footer = '''<div id="footer">
    <div class="links">Links：<a href='...'>Company Video</a> |</div>
    <div class="copyright">
        <p>COMPANY NAME &nbsp;ICP:XXXXXX &nbsp;<a href="/sitemap.html">Sitemap</a></p>
        <p>Add：ADDRESS &nbsp;Tel：PHONE</p>
    </div>
    <div class="clear"></div>
</div>'''

content = content[:start_idx] + new_footer + content[end_idx:]

with open("/tmp/index_edit.html", "w") as f:
    f.write(content)

# 上传
terminal("curl -T /tmp/index_edit.html ftp://... --user ...")
```

**关键点：** 模板文件可能是干净的，问题出在 CMS 后台填写的数据。直接修改生成的 HTML 是最快的修复方式，但 CMS 重新生成页面时会覆盖修改。

**模板文件位置：** `/wwwroot/template/`

| 模板文件 | 生成页面类型 |
|---------|-------------|
| index.htm | 首页 |
| about.htm | 关于我们页面 |
| download.htm | 下载页面 |
| showcases.htm | 案例展示页面 |
| ShowNews.htm | 新闻列表页面 |
| showshop.htm | 产品列表页面 |
| webtitu.htm | 网站标题页 |

**⚠️ 重要：** 修改模板文件后，已生成的静态 HTML 页面**不会自动更新**。必须：
1. 更新模板文件
2. 手动批量更新已生成的 HTML 文件（使用 sitemap 批量更新流程）

**⚠️ 批量更新子页面是必须的（2026-05-29 实战验证）：**

shengtuo-tractor.com 有 71+ 个静态 HTML 页面（about/、cases/、download/、News/、products/），每个都独立包含 CSS 引用、浮动栏代码等。修改 index.html 后，子页面不会自动更新。

**批量更新脚本模式：**
```python
import subprocess
FTP = "ftp://shanweituo:C2r3h2q7K3@shanweituo.gotoftp4.com/wwwroot"
dirs = ['about', 'cases', 'download', 'News', 'products']
all_files = ['index.html']
for d in dirs:
    r = subprocess.run(['curl', '-s', '--list-only', f'{FTP}/{d}/'], capture_output=True, text=True)
    for f in r.stdout.strip().split('\n'):
        if '.html' in f:
            all_files.append(f"{d}/{f.strip()}")
# 然后遍历 all_files 做修改
```

## 批量清理脚本（推荐方式）

当需要清理 50+ 页面时，逐个用 `patch` 工具太慢。使用批量脚本一次性处理：

```bash
#!/bin/bash
# 批量清理 footer + 旧浮动栏 + AddThis/GA/G+
FTP="ftp://shanweituo:C2r3h2q7K3@shanweituo.gotoftp4.com/wwwroot"
UPDATED=0

for id in <file_ids>; do
  local="/home/ubuntu/website/generated/<dir>/$id.html"
  mkdir -p "$(dirname "$local")"
  wget -q "$FTP/<dir>/$id.html" -O "$local" 2>/dev/null || continue
  
  python3 << 'PYEOF'
import re
with open("LOCAL_PATH", 'r', encoding='utf-8-sig') as f:
    content = f.read()
original = content

NEW_FOOTER = '''<div id="footer">
    <div class="links">
        Links：
        <a href='https://www.instagram.com/shengtuo_tractor' target='_blank'>shengtuo-Tractor Company Video</a> | 
    </div>  
    <div class="copyright">
        <p>SHENGTUO TRACTOR,TRACTOR ,SHENGTUO,TRACTOR,CHINA AGRICULTRUAL MACHINE,CHINA TRACTOR &nbsp;ICP:0232829 &nbsp;<a href="/sitemap.html" target="_blank">Sitemap</a></p>
        <p>Add：Address: No.1008 Huaixu North Road,Changle County,Weifang city, Shandong Province, China &nbsp;Tel：+86-13806461474</p>
    </div>
    <div class="clear"></div>
</div>'''

# Replace footer block
footer_match = re.search(r'<div id="footer">\s*\n', content)
if footer_match:
    footer_start = footer_match.start()
    whatsapp_match = re.search(r'<!-- WhatsApp|<a href="https://wa\.me', content[footer_start:])
    if whatsapp_match:
        clean_start = footer_start + whatsapp_match.start()
        content = content[:footer_start] + NEW_FOOTER + '\n\n' + content[clean_start:]

# Remove rightDiv
content = re.sub(r"<div id='rightDiv'[^>]*>.*?</div>\s*</div>\s*</div>\s*</div>\s*", '', content, flags=re.DOTALL)
# Remove g-plus share
content = re.sub(r'<!-- Place this tag where you want.*?<script type="text/javascript">\s*\(function\(\).*?</script>\s*', '', content, flags=re.DOTALL)
# Remove Fax from sidebar
content = re.sub(r'\s*<li>Fax：</li>\n?', '', content)

with open("LOCAL_PATH", 'w', encoding='utf-8') as f:
    f.write(content)
print("CHANGED" if content != original else "NOCHANGE")
PYEOF

  curl -s -T "$local" "$FTP/<dir>/$id.html" --ftp-create-dirs >/dev/null 2>&1
  echo "✅ <dir>/$id.html"
done
```

**文件 ID 清单（从 update_generated.py 提取）：**

| 目录 | 文件 ID |
|------|---------|
| about/ | 2, 3, 6, 7, 8 |
| cases/ | 31-43 |
| download/ | 4, 5, 13 |
| News/ | 66-78 |
| products/ | 58, 61, 62, 64-68, 137, 171, 172, 175, 183, 224-248 |
| message/ | 需探测（尝试 1-15） |

## 验证脚本

```bash
# 检查所有页面是否干净
for dir in about cases download News products message; do
  for id in <ids>; do
    count=$(curl -s "https://www.shengtuo-tractor.com/$dir/$id.html" | grep -c "rightDiv\|addthis\|g-plus\|Fax")
    [ "$count" -gt 0 ] && echo "❌ $dir/$id.html: issues=$count"
  done
done
echo "✅ 验证完成"
```

## 相关参考

- **浮动联系栏移除：** `references/floating-contact-bar-whatsapp.md`
- **Footer 定位调试：** `references/float-layout-footer-debugging.md`
- **批量更新工作流：** `references/floating-contact-bar-whatsapp.md` (Step 3)
- **批量清理脚本：** `scripts/batch_clean_footer.sh`

## 垂直对齐（Vertical Alignment）

当用户说"垂直对齐"或"网页对齐"时，指的是：

1. **左右栏顶部对齐** — `#left` 和 `#right` 应该从同一垂直位置开始
2. **Footer 在页面底部** — 不在产品栏旁边
3. **页面结构干净** — 没有多余的脚本、浮动栏等干扰布局

### 方法 A：Flexbox 布局（推荐，2026-05-29 验证）

```css
#center {
    display: flex;
    align-items: flex-start;  /* 顶部对齐 */
    width: 980px;
    min-height: 500px;
    padding: 0;
    overflow: hidden;
}

#left {
    width: 230px;
    flex-shrink: 0;  /* 不压缩侧边栏 */
}

#right {
    flex: 1;
    min-width: 0;  /* 防止内容溢出 */
}
```

**优点：** 左右栏自动顶部对齐，不需要 float 清除，更可靠。

### 方法 B：Float 布局（传统方式）

```css
#center {
    width: 980px;
    min-height: 500px;
    padding: 0;
    overflow: hidden;  /* 关键！清除浮动 */
}

#left {
    float: left;
    width: 230px;
}

#right {
    float: right;
    width: 720px;
}
```

### CDN 缓存绕过

修改 CSS 后如果 Cloudflare 缓存未刷新，**创建新 CSS 文件名**是最可靠方法：

```bash
# 1. 上传新 CSS
curl -T /tmp/style_v8.css ftp://USER:PASS@HOST/wwwroot/css/style_v8.css

# 2. 批量更新所有 HTML 引用
for file in about/2.html about/3.html ...; do
  sed -i 's/style_v7\.css/style_v8.css/g' /tmp/$file
  curl -T /tmp/$file ftp://USER:PASS@HOST/wwwroot/$file
done
```

**当前生产版本：** `style_v8.css`（包含 flexbox 垂直对齐 + about 页面内容样式）

**批量更新 CSS 引用脚本：** `scripts/batch_update_css_ref.sh`
```bash
# 用法
bash scripts/batch_update_css_ref.sh style_v7.css style_v8.css
```

### 常见问题

- 如果 `#right` 内容比 `#left` 长，`#left` 底部会有空白 — 这是正常行为
- 如果 `#left` 比 `#right` 长，`#right` 底部会有空白 — 也是正常行为
- 用户说"垂直对齐"通常是指顶部对齐，不是等高

### 验证

```javascript
// 浏览器 Console 检查
const left = document.getElementById('left');
const right = document.getElementById('right');
const center = document.getElementById('center');
console.log('center display:', getComputedStyle(center).display);
console.log('left top:', left.getBoundingClientRect().top);
console.log('right top:', right.getBoundingClientRect().top);
// 两者应该相等（或非常接近）
```
包含：搜索栏移除、LOGO 上移、LOGO 在导航栏上方、header padding 调整的完整工作流。

shengtuo-tractor.com 的 header 结构：
```html
<div id="header">    ← padding: 20px (或 5px 20px 20px 20px)
    <div id="logo">  ← float: left, 400px 宽
    <div class="globalsearchformzone">  ← 搜索栏（可移除）
    <div id="nav">   ← 导航菜单
</div>
```

**移除搜索栏：** 删除 `.globalsearchformzone` 整个 div 即可，不影响其他布局。
**LOGO 上移：** 减少 `#header` 的 `padding-top`（如 20px → 5px），LOGO 和导航都会上移。
**LOGO 在导航上方：** 将 `#nav` 移出 `#header`，header 设 `height: 90px; overflow: hidden`，nav 独立显示。

**⚠️ 浮动布局修复后 footer 居中验证（2026-05-29 实战）：**

当同时修复 footer 浮动和居中问题时，需要按顺序：
1. 先给 `#center` 加 `overflow: hidden`（解决 footer 在产品栏旁边）
2. 再给 `#footer` 加 `margin: 0 auto`（解决 footer 不居中）
3. 两个问题经常同时存在，一起修

**批量更新所有页面的工作流：**

```python
# 1. 从 sitemap.html 提取所有 URL
import re, subprocess

result = subprocess.run(['curl', '-s', 'https://www.shengtuo-tractor.com/sitemap.html'], 
                       capture_output=True, text=True)
urls = re.findall(r'href="https://www\.shengtuo-tractor\.com([^"]*)"', result.stdout)
urls = list(set(urls))  # 去重

# 2. 转换为 FTP 路径
ftp_paths = []
for url in urls:
    if url.endswith('/') or url.endswith('.html'):
        ftp_path = url + 'index.html' if url.endswith('/') else url
        ftp_paths.append(ftp_path)

# 3. 批量下载、修改 CSS 引用、上传
for ftp_path in ftp_paths:
    # 下载 HTML
    dl = subprocess.run(['curl', '-s', '-u', 'shanweituo:C2r3h2q7K3', 
                        f'ftp://shanweituo.gotoftp4.com/wwwroot{ftp_path}'],
                       capture_output=True, text=True)
    
    if dl.returncode != 0 or not dl.stdout:
        continue
    
    content = dl.stdout
    
    # 替换 CSS 引用
    if 'style.css' in content:
        new_content = content.replace('../css/style.css', '../css/style5.css')
        new_content = new_content.replace('css/style.css', 'css/style5.css')
        
        # 保存并上传
        with open(f'/tmp/{ftp_path.replace("/", "_")}', 'w') as f:
            f.write(new_content)
        
        subprocess.run(['curl', '-s', '-T', f'/tmp/{ftp_path.replace("/", "_")}', 
                       '-u', 'shanweituo:C2r3h2q7K3',
                       f'ftp://shanweituo.gotoftp4.com/wwwroot{ftp_path}'],
                      capture_output=True, text=True)
```

**模板文件 CSS 更新：**

```bash
# 下载模板
curl -s -u "shanweituo:C2r3h2q7K3" ftp://shanweituo.gotoftp4.com/wwwroot/template/ShowNews.htm -o /tmp/template_ShowNews.htm

# 修改 CSS 引用
sed -i 's|../css/style.css|../css/style5.css|g' /tmp/template_ShowNews.htm

# 上传
curl -T /tmp/template_ShowNews.htm -u "shanweituo:C2r3h2q7K3" ftp://shanweituo.gotoftp4.com/wwwroot/template/ShowNews.htm
```

**关键陷阱：** ASP 动态页面有 6 个索引文件需要单独更新（sitemap 不含这些链接）。完整清单和批量更新脚本见 `references/shengtuo-tractor-asp-pages.md`。

**⚠️ update_generated.py 脚本局限性（2026-05-29 实战发现）：**

`/home/ubuntu/website/update_generated.py` 脚本用于批量更新生成的 HTML 文件，但其正则表达式模式可能无法匹配所有变体的旧浮动联系栏代码。

**症状：** 运行脚本后，部分页面仍有旧代码残留（如 rightDiv、AddThis、GA 脚本等）。

**诊断：**
```bash
# 检查是否还有残留
curl -s https://www.shengtuo-tractor.com/about/2.html | grep -c "rightDiv"
curl -s https://www.shengtuo-tractor.com/about/2.html | grep -c "addthis"
```

**修复：** 使用 `patch` 工具精确替换每个残留页面的 footer 区域。详见 `references/footer-consistency-pattern.md`。

**ASP 索引文件速查：**
- `products/index.asp` - 产品分类列表
- `News/index.asp` - 新闻列表
- `cases/index.asp` - 案例列表
- `download/index.asp` - 下载列表
- `Inquiry/index.asp` - 询盘表单
- `message/index.asp` - 留言板

这些文件都用 `../css/style.css` 相对路径，批量替换时注意路径。

---

**⚠️ viewport 标签必须存在：**

shengtuo-tractor.com 原始 HTML 缺少 `<meta name="viewport">` 标签。没有它，手机浏览器会以 980px+ 宽度渲染页面，导致需要左右滑动。

**检查方法：**
```bash
curl -s https://www.shengtuo-tractor.com | grep -i "viewport"
# 如果输出为空，需要添加
```

**添加方法：**
```bash
sed -i 's/<head>/<head>\n<meta name="viewport" content="width=device-width, initial-scale=1.0" \/>/' /tmp/index.html
```

**CSS 版本递增模式（实战验证）**

在多次完整重设计会话中，CSS 文件名从 `style.css` 递增到 `style_v8.css`（共8+次迭代）。每次都需要更新所有 60+ 页面的引用。这证明了：

**当前生产版本：** `style_v8.css`（包含 flexbox 垂直对齐 + about 页面内容样式 + 标准 footer 样式）

1. **新文件名绕过 CDN 缓存是唯一可靠方法**（版本参数不够）
2. **批量更新脚本是必需的**（手动更新 60+ 页面不现实）
3. **ASP 索引文件必须单独更新**（6个文件不在 sitemap 中）

**建议：** 在开始重设计前，先准备好批量更新脚本（见下方 Step 2-3），避免每次迭代手动更新。

**⚠️ Cloudflare 缓存深度绕过**

shengtuo-tractor.com 和 sub.aiv.qzz.io 都使用 Cloudflare CDN。简单的版本参数 `?v=新版本号` **有时不够**：

**场景1：版本参数够用**
- CSS 内容正确，只是浏览器缓存 → `?v=20260528` 即可

**场景2：需要新文件名（推荐，最可靠）**
- 图片/CSS/LOGO 文件已更新但 Cloudflare 仍返回旧版本（或 404）
- **解决：重命名文件**，如 `product-1.jpg` → `product-1-v1780048106.jpg`，然后更新数据库引用
- **也适用于 LOGO：** `logo.png` → `logo-v2.png`，然后更新 header.php 中的引用
- 静态资源 nginx 配置 `expires 30d; add_header Cache-Control "public, immutable";` 导致 CDN 缓存 30 天
- 详细流程见 `references/cdn-cache-busting-images.md`

**验证 CDN 是否在 serve 旧内容：**
```bash
curl -s "https://SITE/path/to/file" | md5sum  # CDN 版本
md5sum /local/path/to/file                      # 本地版本
# 如果 MD5 不同，CDN 在 serve 旧内容！
```

```bash
# 上传修复后的 CSS 为新文件名
curl -T /tmp/style-fixed.css -u "USER:PASS" ftp://HOST/wwwroot/css/main.css

# 更新 HTML 引用
sed -i 's|css/style.css[^"]*|css/main.css|' /tmp/index.html
curl -T /tmp/index.html -u "USER:PASS" ftp://HOST/wwwroot/index.html
```

**验证 CSS 是否真正加载：**
```javascript
// 浏览器 Console
const sheets = Array.from(document.styleSheets);
const target = sheets.find(s => s.href && s.href.includes('main.css'));
console.log('Rules count:', target ? target.cssRules.length : 'NOT LOADED');
console.log('Body bg:', getComputedStyle(document.body).backgroundColor);
```

## 直接修改 CSS（背景/颜色调整）

当用户要求"背景加深"、"颜色调整"等小改动时，直接修改原 `css/style.css` 即可。

⚠️ **改背景色必须同步改文字颜色！** 白色背景换蓝灰色背景后，深灰文字会看不清。详见 `references/css-text-readability-patterns.md` 中的配色方案。

步骤：

1. **下载原 CSS**：`curl -s -u "用户:密码" ftp://主机/wwwroot/css/style.css -o /tmp/style.css`
2. **修改目标属性**：用 `patch` 工具精确替换
3. **上传修改后 CSS**：`curl -T /tmp/style.css -u "用户:密码" ftp://主机/wwwroot/css/style.css`
4. **强制缓存刷新**：在 HTML 中给 CSS 加版本号（关键！）

```bash
# 在 index.html 中修改 CSS 引用
sed -i 's|<link href="css/style.css"|<link href="css/style.css?v=20260528"|' /tmp/index.html
```

**⚠️ Cloudflare 缓存问题**：shengtuo-tractor.com 使用 Cloudflare CDN，CSS 修改后浏览器可能仍显示旧版本。必须在 CSS 链接后加版本参数 `?v=YYYYMMDD` 才能强制刷新。

### ⚠️ 恢复原始配置（用户不满意时）

CSS/JS 叠加美化后，如果用户说"恢复原来的配置"或不满意，按以下步骤恢复：

```bash
# 1. 重新下载当前 index.html（可能已被修改）
curl -s -u "USER:PASS" ftp://HOST/wwwroot/index.html -o /tmp/index.html

# 2. 移除 custom.css 和 custom.js 的引用
# 用 patch 工具精确替换：
# 删除 <link href="css/custom.css"...> 行
# 删除 <script ... custom.js> 行

# 3. 上传恢复后的文件
curl -T /tmp/index.html -u "USER:PASS" ftp://HOST/wwwroot/index.html

# 4. 如果修改了原 style.css，也需要恢复
# 重新下载原始 CSS 并上传（或用 git 恢复）
```

**关键原则：** custom.css 和 custom.js 文件可以保留在服务器上（不影响页面），只需移除 HTML 中的引用即可恢复原样。

**如果已经修改了原 style.css：**
```bash
# 从 git 仓库获取原始 CSS（如果有）
# 或手动将修改过的属性改回原值
# body { background-color: #FFFFFF; }  # 恢复白色
# #main { background-color: transparent; box-shadow: none; }  # 移除阴影
```

**如果已经做了错误的重设计：**
```bash
# 1. 恢复原始文件
git checkout <good-commit-hash> -- index.html sitemap.xml
# 2. 重新应用安全的增强（通过 patch）
# 3. 提交并推送
```

**完整增强模式参考：** `references/seo-enhancement-patterns.md`
包含：FAQ schema、Aggregate Rating、hreflang、CSS hover 动画、Intersection Observer 滚动动画等。

**Sitemap/Robots 模板：** `references/sitemap-robots-template.md`
包含：sitemap.xml 模板、robots.txt 模板、优先级指南。

**shengtuo-tractor.com 维护：** `references/shengtuo-tractor-com-maintenance.md`
包含：FTP 下载/上传命令、后台管理面板（/admin_v19）、失效链接清单、WhatsApp inline SVG 按钮代码。

**Flash 轮播替换：** `references/flash-to-html-slider.md`
包含：Adobe Flash 替换为 HTML/CSS/JS 轮播的完整模板和验证步骤。

**CSS/JS 叠加美化模式：** `references/css-js-overlay-beautification.md`
包含：不动后台/产品结构，只添加 custom.css + custom.js 实现视觉美化的完整工作流。

**商务简洁设计模式：** `references/css-business-professional-design.md`
包含：当用户要求"统一商务简洁外观"时的 CSS 变量、配色方案、产品卡片样式、导航栏渐变、批量更新所有页面的 5 步工作流（含 ASP 索引文件更新）。

**图片转 CSS 配色：** `references/image-to-css-color-extraction.md`
包含：用户提供参考图片时，用 Python PIL 提取主色调并生成 CSS 覆盖样式的方法。当 browser_vision 不可用时的备用方案。

**CSS 文字可读性：** `references/css-text-readability-patterns.md`
包含：更换背景色时的文字颜色调整方案、WCAG 对比度标准、蓝灰色背景实测配色值。

**ASP 动态页面清单：** `references/shengtuo-tractor-asp-pages.md`
包含：6 个 ASP 索引文件完整清单、批量更新脚本、完整站点 CSS 更新 5 步流程。

**Comprehensive SEO Optimization:** `references/comprehensive-seo-optimization.md`
包含：PHP网站SEO完整实现 — SEO类（Meta/JSON-LD/面包屑/站点地图）、PWA支持、.htaccess优化、robots.txt、错误页面、SEO检查工具。

**Nginx + PHP-FPM 部署：** `references/nginx-php-fpm-deployment.md`
包含：Nginx配置模板、PHP-FPM socket路径、部署步骤、7个关键陷阱（index顺序、404处理、require路径、文件权限、写入敏感路径、Cloudflare覆盖robots.txt、测试文件清理）。**⚠️ 新增陷阱#12：index.html覆盖index.php、陷阱#13：try_files $uri传完整路径导致产品详情页302。陷阱#14：Clean URL需要独立nginx location规则（/about ≠ /about.html）。****⚠️ 新增：添加新页面的nginx路由流程、PHP模板函数依赖（escape/getCurrentUrl）、数据库驱动页面完整创建流程。** **⚠️ 新增陷阱#11：PHP函数重复声明导致所有页面500错误 — 必须确保header.php的include顺序正确（database→functions→seo）。**

**Admin Panel & DB Setup:** `references/php-website-admin-panel.md`
包含：管理员密码hash修复（关键陷阱）、MySQL数据库完整设置流程、Admin CRUD页面模板、验证清单。**⚠️ 新增：500错误诊断流程 — header.php函数依赖（escape/getCurrentUrl/$pdo）是常见原因。** **⚠️ 新增：共享auth.php模板模式 — 单文件认证+侧边栏+头部+CSRF+Flash消息，所有admin页面include即可。**

- **Dynamic Settings & Domain Binding:** `references/dynamic-settings-domain-binding.md`
包含：从数据库动态加载网站配置（域名/SEO/商务）、loadSiteSettings()模式、settings表设计（37项5组）、后台5标签设置页面模板、header.php使用动态常量。**⚠️ 关键：config/database.php中define用!defined()守卫避免重复定义，functions.php中loadSiteSettings()必须在页面逻辑前调用。**

**Admin Panel i18n Pattern:** `references/admin-i18n-pattern.md`
包含：PHP后台中英文切换完整实现 — lang_helper.php（initLang/t()/getLang/langSwitchUrl）、语言文件格式（PHP数组200+词条）、auth.php集成（侧边栏翻译+语言切换器按钮）、登录页翻译、Flash消息翻译。Session持久化，URL参数`?lang=zh/en`切换。

**Admin i18n Batch Translation Pitfalls:** `references/admin-i18n-batch-translation-pitfalls.md`
包含：perl正则批量翻译的陷阱 — HTML文本安全替换 vs PHP三元表达式危险替换、安全/不安全模式对照表、7步批量翻译工作流、验证方法。

**International Trade Website System (sub.aiv.qzz.io):**
完整国际贸易网站体系已搭建并通过全面测试（2026-05-30），包含：
- 前台11页面：首页/产品列表/产品详情/关于/新闻/新闻详情/联系/搜索/出口贸易/为何选择/Sitemap
- 后台15页面：Dashboard/Products(Add/Edit)/Categories(Add)/News(Create)/Sliders(Messages/Inquiries(Detail)/Pages(Create)/Settings/Login/Logout/SEO-Checker
- **RFQ询盘系统**：`api/inquiry.php`（JSON POST）→ `inquiries` 表（status: new/replied/quoted/closed）→ `admin/inquiries.php` 管理（详情/状态更新/备注/删除）
- **联系表单系统**：`api/message.php`（POST）→ `messages` 表 → `admin/messages.php` 管理
- **产品详情页嵌入询盘表单**：国家下拉(26国)+数量+预填留言+fetch提交+WhatsApp快速链接
- **商务页面**：`export.php`（6步出口流程+贸易条款+FAQ）、`why-us.php`（公司优势+认证+全球服务+评价）
- **导航栏商务入口**：Why Us + Export + Get Quote按钮(金色) + WhatsApp按钮(绿色)
- **Footer商务信息**：贸易条款(FOB/CIF/EXW)+付款方式(T/T/L/C/WU)+认证徽章(ISO/EPA/CE/EAC)
- **动态设置**：37项设置从数据库读取，后台5标签页(域名/联系/SEO/验证/商务)
- **CSS Bundle**：7文件合并为1个bundle.min.css(58KB)，filemtime版本号绕Cloudflare缓存
- **运维**：DB自动备份(cron daily)+日志轮转(weekly)+nginx安全头+gzip+分级缓存
- **数据库统计**：38产品、2分类、4新闻、3轮播图、4页面、37设置项
- **API端点**：3个（inquiry.php/message.php/products.php）全部测试通过
- **已修复的Bug**：inquiries.php $_GET拼写、Dashboard缺询盘统计、news.php FK约束0→NULL、api/message.php schema不匹配、pages表缺template列、og:url协议错误(http→https)、og:image相对路径、getCurrentUrl() Cloudflare HTTPS检测

**Security Hardening Pattern:** `references/security-hardening-pattern.md`
包含：登录失败限流（IP+用户名5次/15分钟）、nginx安全头（X-Frame/X-Content-Type/X-XSS/Referrer）、上传目录禁止PHP执行（nginx+.htaccess双保险）、生产环境测试文件清理清单。

- **PHP Site SEO Deep Optimization:** `references/php-site-seo-deep-optimization.md`
包含：产品meta_title/keywords批量生成SQL模板、Product Schema修复（绝对URL/price=0/offer URL）、sitemap新增页面、站点级SEO设置更新、页面级关键词策略、Admin i18n批量翻译陷阱（perl正则破坏PHP三元表达式）、CSS Bundle去重（58KB→38KB）、标题层级修复（H5→H3 class="h5"）。

- **Domain × SEO Linkage:** `references/domain-seo-linkage-pattern.md`
包含：Cloudflare HTTPS协议检测（HTTP_X_FORWARDED_PROTO）、og:image绝对URL补全、域名变更联动清单（canonical/og/sitemap/JSON-LD）、设置→前端生效流程。**⚠️ 关键：Cloudflare Flexible SSL下$_SERVER['HTTPS']不被设置，getCurrentUrl()返回http://，导致所有meta标签协议错误。** **⚠️ 新增（2026-05-30 SEO优化）：首页H1标签（轮播图第一张改H1+CSS）、产品meta_description批量生成SQL模板（CONCAT name+hp+description...）、sitemap.php添加loadSiteSettings()调用（否则SITE_URL未定义500错误）、sitemap新增/products和/export页面、sitemap.xml需手动覆盖（nginx serve静态文件不经过PHP）、验证清单12项（H1/meta_desc/og:url/og:image/sitemap/robots/json-ld/canonical/product_meta/performance/php_errors）。

**⚠️ 产品meta_description批量生成SQL模板（2026-05-30 实战验证）：**

所有39个产品meta_description为空→用SQL批量生成：

```sql
UPDATE products SET meta_description = CONCAT(
    name, ' - ',
    IF(horsepower != '', CONCAT(horsepower, ' '), ''),
    'agricultural tractor by Shengtuo. ',
    LEFT(REPLACE(REPLACE(REPLACE(description, '\r', ' '), '\n', ' '), '  ', ' '), 120),
    '... Export from China. Inquire now!'
)
WHERE (meta_description IS NULL OR meta_description = '') AND is_active = 1;
```

**⚠️ sitemap.php新增页面模板：** 产品列表页`/products`和出口贸易页`/export`必须手动添加到sitemap。在contact页面之前插入：

```php
$sitemap .= $this->addSitemapUrl($this->baseUrl . '/products', '0.9', 'daily');
$sitemap .= $this->addSitemapUrl($this->baseUrl . '/export', '0.7', 'monthly');
```

**⚠️ sitemap.xml静态文件覆盖问题：** nginx直接serve sitemap.xml静态文件，不经过PHP。sitemap.php生成新内容后，必须手动覆盖：`curl -s https://site/sitemap.php > /path/to/sitemap.xml`

**⚠️ 首页H1标签实现：** 轮播图第一张slide的`<h2>`改为`<h1 class="hero-slide-title">`，其余保持`<h2>`。CSS样式：

```css
.hero-slider .carousel-caption h2,
.hero-slider .carousel-caption h1.hero-slide-title {
    font-size: 2.2rem;
    text-shadow: 0 2px 20px rgba(0,0,0,0.3);
    color: #fff;
    margin-bottom: 1rem;
    font-weight: 700;
}
```

**⚠️ getCurrentUrl() Cloudflare修复模板：**

```php
function getCurrentUrl() {
    if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') $proto = 'https';
    elseif (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') $proto = 'https';
    else $proto = 'http';
    return $proto . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}
```

此函数在两个文件中定义：`templates/header.php`和`includes/functions.php`，都需要修复。

**⚠️ og:image绝对URL补全模板（seo.php）：**

```php
$image = $pageImage ?: ($this->baseUrl . '/assets/images/logo-v2.png');
if ($image && strpos($image, 'http') !== 0) $image = $this->baseUrl . $image;
```

**Product Data Import:** `references/product-data-import-workflow.md`
包含：从现有ASP网站爬取产品数据、JSON格式转换、PHP导入脚本、公司信息导入、重复slug处理。

- **Product Image Scraping:** `references/product-image-scraping-workflow.md`
包含：从原网站抓取产品图片、sitemap提取产品URL、下载图片、更新数据库路径、占位图检测、权限处理。**⚠️ 新增：优先使用本地FTP备份（/home/ubuntu/wwwroot/）直接复制，比curl下载更快更可靠。用PHP提取产品描述（bash grep处理不了特殊字符）。**

- **Admin Testing Pitfalls:** `references/admin-testing-pitfalls.md`
包含：Dashboard必须跟踪所有模块的统计、PHP超全局变量`$_GET`拼写错误的静默失败、后台功能系统性测试流程。**⚠️ 新增（2026-05-30）：curl-based CRUD完整测试模板（CSRF提取+session管理+DB验证）、产品删除用GET csrf参数（不是POST）、API schema不匹配（messages表无status列）、外键约束0→NULL、数据库缺失列、Cloudflare HTTPS检测（X-Forwarded-Proto）、og:image绝对URL补全、8项bug修复checklist。** **⚠️ 新增（2026-05-30 综合测试）：session管理必须用同一cookie文件（登录→GET→POST全流程）、CSRF token从同session的GET页面提取、查询用`head -1`取第一个匹配、产品删除用GET csrf参数不是POST、sitemap.php必须调用loadSiteSettings()否则SITE_URL未定义返回500、pages表缺template列需ALTER TABLE添加、轮播图image字段NOT NULL约束需改为可空或要求上传图片、消息API用错列名(status→is_read/replied)。完整35项测试覆盖：10后台页面+10 CRUD操作+2 API端点+11前台页面+2 SEO联动。

**⚠️ 新增Bug清单（2026-05-30 后台全面测试）：**

| Bug | 文件 | 修复 |
|-----|------|------|
| `$GET['action']` 拼写错误 | inquiries.php:54 | → `$_GET['action']` |
| Dashboard缺询盘统计 | admin/index.php | 新增inquiries统计卡片+列表 |
| news category_id FK约束 | news.php:59 | `(int)` → `!empty() ? (int) : null` |
| api/message.php schema不匹配 | api/message.php | `status` → `is_read/replied`, 补`company`字段 |
| pages表缺template列 | 数据库 | `ALTER TABLE pages ADD COLUMN template` |
| og:url用http非https | header.php+functions.php | getCurrentUrl()加`HTTP_X_FORWARDED_PROTO`检测 |
| og:image相对路径 | seo.php | `if(strpos($image,'http')!==0) $image = $baseUrl.$image` |
| sitemap.php返回500 | sitemap.php | 添加`loadSiteSettings()`调用 |

**⚠️ CRUD测试session陷阱：** curl测试时必须用同一cookie文件完成登录→GET→POST全流程。`/tmp/admin.txt` 作为cookie jar，所有curl命令加 `-b /tmp/admin.txt`。否则CSRF token验证失败（session不匹配），POST返回200但数据库不变。

**⚠️ 产品删除用GET参数：** products.php的删除逻辑检查`$_GET['csrf']`（不是`$_POST['csrf_token']`）。curl删除命令：`curl -b cookies 'URL?action=delete&id=X&csrf=TOKEN'`

**⚠️ 外键约束0→NULL：** news.category_id和products.category_id有FK约束。空值`(int)`转为0但0不在reference表中。必须用`!empty() ? (int) : null`。同理，表单的default option应`value=""`不是`value="0"`。

**⚠️ 数据库缺失列：** pages表缺`template`列（PHP INSERT包含此列→静默失败）。ALTER TABLE添加后恢复正常。类似问题用`SHOW CREATE TABLE`诊断。

**⚠️ sitemap.php必须调用loadSiteSettings()：** config/database.php导出`getDBConnection()`函数和`loadSiteSettings()`函数。sitemap.php/include seo.php之前必须调用`loadSiteSettings()`，否则SITE_URL常量未定义→500错误。

**Product-Focused Homepage Pattern:** `references/product-focused-homepage-pattern.md`
包含：以产品宣传为主导的首页布局模板 — 分类卡片区(背景图+渐变遮罩)、HP马力区间展示(可点击筛选)、推荐产品扩展(8个+HOT/POPULAR/BEST SELLER徽章+HP标签+快速操作按钮)、热门产品条(深色背景横向展示)、产品Tab分类筛选(带动画过渡)、公司简介压缩后移。CSS变量、JS筛选逻辑、PHP数据查询模板。**⚠️ 关键：分类slug必须从数据库动态读取，不能硬编码(tractors/implements/parts都不对，实际是shengtuo-tractor/shengtuo-farm-equipment)。**

**Full Site Link Audit Pattern:** `references/site-link-audit-pattern.md`
包含：全站链接系统性检查流程 — 1)提取所有内部链接 2)逐一HTTP状态码测试 3)分类修复(nginx路由/PHP文件/静态资源) 4)clean URL添加 5)robots.txt/sitemap域名一致性 6)favicon缺失检测。**⚠️ 关键发现：robots.txt的Sitemap指向旧域名、SITE_URL配置指向旧域名、favicon.png/apple-touch-icon.png缺失 — 这三个问题在新部署的子站上几乎必然出现。**

**⚠️ Cloudflare CSS缓存也需要重命名文件** — 不仅图片，CSS文件同样需要重命名绕过CDN缓存。visual-v5.css 添加了logo样式但CDN仍serve旧版本(10794 bytes vs 本地12834 bytes)。解决：`cp visual-v5.css visual-v5b.css` 然后更新header.php引用。验证方法：`curl -s URL | wc -c` 对比本地文件大小。

**⚠️ sub.aiv.qzz.io CSS版本引用模式（2026-05-30 实战发现）：**

header.php 使用 `style-v{timestamp}.css` 文件名引用CSS（不是 `?v=` 查询参数）。`sed` 更新版本号后，实际文件 `style.css` 不会自动重命名，导致404。

**⚠️ 关键调试知识库：** 详见 `references/css-js-pitfalls.md`，包含：
- Page Loader 转圈不消失的修复方案（DOMContentLoaded + timeout + CSS animation 三重兜底）
- 外部资源异步加载模式（media="print" onload）— 在中国访问时 Google Fonts/Font Awesome CDN 经常超时
- CSS 字面量 `\n` 导致选择器失效的调试方法
- Bundle 文件 vs 源文件的加载链路（编辑 `b2b-enhance.js` 无效，必须改 `bundle-v2.min.js`）
- 导航栏一行显示参数

**两种解决方案：**
```bash
# 方案A（推荐）：创建新文件名绕过CDN缓存
cp style.css style-responsive.css
sed -i 's|style-v[0-9]*.css|style-responsive.css|' templates/header.php

# 方案B：使用查询参数（但CDN可能忽略query string）
sed -i 's|style-v[0-9]*.css|style.css?v='$(date +%s)'|' templates/header.php
```

**⚠️ Nginx 静态资源 location 缺少 try_files（2026-05-30 实战发现）：**

**问题：** 静态资源 location block 拦截了 CSS/JS 请求但没有 `try_files`，导致不存在的版本号文件（如 `style-v123.css`）返回 HTML 内容（被 PHP 处理）而不是 404。

**症状：** `curl -sI /assets/css/style-v123.css` 返回 200 但内容是 HTML 页面。

**修复：**
    # Static asset caching
    location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot|webp)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
        access_log off;
        try_files $uri =404;  # 必须！否则不存在的文件会被路由到PHP
    }
}
```

**验证：**
```bash
# 应该返回 404（不是 200）
curl -sI "https://sub.aiv.qzz.io/assets/css/nonexistent.css"
```

**⚠️ 响应式图片高度用 vw 不用 vh（2026-05-30 实战发现）：**

用 `vh`（视口高度）设置图片高度时，手机端高度太短会挤压图片内容。用 `vw`（视口宽度）更好，因为图片随屏幕宽度等比缩放，不会裁切变形。此规则适用于**轮播图**和**产品卡片图片**。

```css
/* ❌ 旧方式：vh 在手机端高度太短 */
.carousel-item { height: 60vh; min-height: 400px; }

/* ✅ 轮播图：vw 基于宽度，自动等比缩放 */
.carousel-item {
    height: 50vw;      /* 桌面端 */
    max-height: 600px;
    min-height: 300px;
}
@media (max-width: 991.98px) { .carousel-item { height: 45vw; max-height: 500px; } }
@media (max-width: 767.98px) { .carousel-item { height: 55vw; max-height: 400px; } }
@media (max-width: 575.98px) { .carousel-item { height: 60vw; max-height: 300px; } }

/* ✅ 产品卡片图片：同样用 vw */
.product-image {
    height: 14vw;       /* 桌面端，4列时约14%宽度 */
    min-height: 140px;
    max-height: 220px;
}
@media (max-width: 991.98px) { .product-image { height: 18vw; min-height: 130px; max-height: 200px; } }
@media (max-width: 767.98px) { .product-image { height: 50vw; min-height: 160px; max-height: 280px; } }
```

配合 `object-fit: cover` + `object-position: center center` 确保主体居中显示。

**产品图片 vw 计算逻辑：** 桌面端4列布局，每列约25%宽度，所以 `14vw` ≈ 56%的列宽（留白后），图片比例约 4:3。移动端1列时 `50vw` 使图片更大更清晰。

**⚠️ 当产品图片宽高比不一致时，用 `aspect-ratio` 替代 `height: vw`（2026-05-30 实战发现）：**

当产品图片来源尺寸差异大时（如 302x227 到 887x885），用 `height: vw` 会导致不同图片显示效果不一致。用 `aspect-ratio` 可以强制统一宽高比：

```css
/* ✅ 最佳方案：aspect-ratio 强制统一比例 */
.product-image {
    position: relative;
    overflow: hidden;
    aspect-ratio: 4/3;  /* 固定宽高比 */
    width: 100%;
}
.product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
}

/* 响应式宽高比调整 */
@media (max-width: 991.98px) { .product-image { aspect-ratio: 3/2; } }
@media (max-width: 767.98px) { .product-image { aspect-ratio: 1/1; } }
@media (max-width: 575.98px) { .product-image { aspect-ratio: 4/3; } }
```

**选择指南：**
- 图片来源尺寸一致 → 用 `height: vw`（更灵活）
- 图片来源尺寸差异大 → 用 `aspect-ratio`（强制统一）
- 两者都配合 `object-fit: cover` + `object-position: center`

**完整响应式图片模式参考：** `references/responsive-image-scaling-patterns.md`

**⚠️ Favicon生成陷阱** — 直接复制logo(428x105)作为favicon会导致浏览器显示异常。必须用PIL裁剪内容区域后缩放到32x32。apple-touch-icon同理(180x180)。

- **Dynamic Settings & Domain Binding:** `references/dynamic-settings-domain-binding.md`
- **Security Hardening:** `references/security-hardening-pattern.md`
- **Product-Focused Homepage Pattern:** `references/product-focused-homepage-pattern.md`
包含：以产品宣传为主导的首页布局模板、分类卡片、HP区间筛选、产品徽章逻辑、Tab筛选JS、数据库查询模板。⚠️ 分类slug必须从数据库读取。
- **CSS Color Harmony Pattern:** `references/css-color-harmony-pattern.md`
包含：CSS变量一致性修复（多文件引用未定义变量的静默失效）、60/30/10色彩比例、完整变量清单（10级灰阶+品牌色+语义色）、Bootstrap class覆盖陷阱、组件颜色映射表、Cloudflare缓存绕过、浏览器Console验证脚本。
- **Site Link Audit Pattern:** `references/site-link-audit-pattern.md`
包含：全站链接系统性检查流程 — 提取链接→HTTP测试→Nginx clean URL→slug清理→域名一致性→缺失资源。⚠️ 新子站几乎必然缺失favicon/SITE_URL/robots.txt域名。
- **Logo & Favicon Optimization:** `references/logo-favicon-optimization.md`
包含：PIL裁剪生成favicon(32x32)/apple-touch-icon(180x180)、Logo CSS增强(圆角/投影/悬停)、Nav链接渐变下划线。⚠️ 不要直接复制logo作为favicon。
- **CDN Cache Busting for Images:** `references/cdn-cache-busting-images.md`
包含：更新图片后Cloudflare仍显示旧图的解决方案 — 文件重命名绕过CDN缓存、诊断方法、浏览器验证脚本。**⚠️ 新增：Logo图片缓存绕过（logo.png→logo-v2.png更新header.php引用）。** ⚠️ Logo更新必须同步修改所有引用文件（index.html、header.php、seo.php、admin/login.php、admin/index.php），用 `grep -rn 'logo\\.png' /path/ --include='*.php' --include='*.html'` 查找所有引用。

**Link Optimization & Clean URLs:** `references/link-optimization-clean-urls.md`
包含：全站链接审计脚本、clean URL nginx配置、**全站clean URL迁移工作流（5步：header→footer→batch PHP→seo.php→sitemap）**、产品slug SEO优化（语义化命名）、sitemap生成修复（$pdo变量+is_active字段）、news详情页slug解析、域名一致性检查清单、HP马力筛选实现。**⚠️ 关键：navbar分类slug必须从数据库动态读取。sitemap.php需要getDBConnection()和is_active=1。footer链接现在用clean URL（不带.html后缀）。**

**Product-Focused Design Patterns:** `references/product-focused-design-patterns.md`
包含：产品主导首页重构布局（分类卡片/HP范围展示/产品徽章/热门产品条/Tab筛选）、HP马力范围筛选功能、动态导航分类加载、新闻详情页slug解析、系统化链接审计工作流。CSS+JS+PHP模板。**⚠️ 新增：nginx clean URL路由模式（不带.html后缀的URL需要独立的location规则）。**

**PHP Site Business Enhancement:** `references/php-site-business-enhancement-pattern.md`
包含：B2B网站商务增强完整模式 — 滚动动画(reveal)、客户评价卡片、信任徽章栏、Hero打字效果、产品图片放大镜、移动端Sticky CTA、数字滚动计数器、懒加载。CSS+JS+HTML模板和集成清单。

**Product-Focused Homepage Pattern:** `references/product-focused-homepage-pattern.md`
包含：以产品宣传为主导的首页重构模式 — 分类卡片(category-card)、HP马力区间筛选(hp-range-card)、产品徽章(HOT/POPULAR/BEST SELLER)、热门产品条(hot-products-strip)、Tab分类筛选、Quick Actions按钮。CSS分层策略(style→enhance→product-focus→visual)。

**Nginx Link Audit & Clean URLs:** `references/nginx-link-audit-workflow.md`
包含：全站链接审计流程、Nginx clean URL路由配置、news详情页slug解析陷阱(前缀/后缀清理)、robots.txt域名修正、SITE_URL配置、favicon缺失修复。36项链接验证清单。

**Product-Focused Homepage Design:** `references/product-focused-homepage-design.md`
包含：以产品宣传为主导的首页布局模板 — 分类卡片、HP马力范围展示、产品徽章(HOT/POPULAR/BEST SELLER)、产品Tab筛选JS、热门产品条、公司简介压缩到底部。适用于B2B外贸农机网站。**⚠️ 核心原则：产品前置，公司信息后移。**

**Product-Focused Layout Pattern:** `references/product-focused-layout-pattern.md`
包含：以产品宣传为主导的首页重构模式 — 产品分类卡片区、HP马力范围展示、产品徽章系统(HOT/POPULAR/BEST SELLER)、热门产品条、产品Tab分类筛选、快速操作按钮(详情+WhatsApp)、HP筛选产品列表页。⚠️ 关键PHP陷阱：if/elseif/else分支后不能有无条件的$stmt->fetchAll()，会覆盖分支内已设置的$products变量。

**⚠️ 首页 index.html 是静态文件，不走PHP模板系统。** 添加新板块（公司介绍等）直接编辑 index.html，不需要创建PHP文件。但 index.html 中的 logo 引用、OG meta、JSON-LD 等也必须手动更新。

**CSS Bundling Pattern（2026-05-30 实战发现）：** 多个CSS文件（5-7个）应合并为1个bundle.min.css减少HTTP请求。详见 `references/css-bundling-pattern.md`。

**⚠️ CSS Bundle 增量合并（2026-05-30 实战发现）：** 当已有 bundle.min.css 后新增了 color-harmony.css、layout-v2.css、modern-ui-v6.css 等文件时，应再次合并为单一文件（如 bundle-v7.min.css），减少 HTTP 请求。流程：
```bash
echo "/* Consolidated CSS */" > bundle-v7.min.css
cat bundle.min.css >> bundle-v7.min.css
cat color-harmony.css >> bundle-v7.min.css
cat layout-v2.css >> bundle-v7.min.css
cat modern-ui-v6.css >> bundle-v7.min.css
```
然后更新 header.php：删除旧的 4 个 `<link>` 标签，替换为 1 个 `bundle-v7.min.css` 引用（带 `?v=timestamp`）。

**⚠️ Hero 打字动画去重（2026-05-30 实战发现）：** `data-strings` 数组中如有重复字符串（如 `["Professional Tractor Manufacturer","Professional Tractor Manufacturer",...]`），打字效果会显示两次相同文本。修复：替换为不同的标语（如 `"Quality Agricultural Machinery"`）。

**Testing Methodology:** `references/testing-methodology.md` — full test suite for backend+frontend+API+SEO.

**⚠️ Database Backup + Log Rotation（运维必做）：** 创建 `scripts/backup-db.sh`（mysqldump+gzip，保留7份）和 `scripts/rotate-logs.sh`（7天压缩，30天清理），加入crontab。详见 `references/security-hardening-pattern.md`。

**⚠️ CSS 变量一致性陷阱（2026-05-30 实战发现）：**

多个CSS文件（enhance-v3, product-focus-v4, visual-v5c）引用了 `--primary`、`--accent`、`--gray-100` 等变量，但 `style-v3.css` 的 `:root` 中**只定义了 `--primary-color`、`--secondary-color`**，没有定义 `--primary`、`--accent`。这导致大量颜色样式静默失效（浏览器忽略未定义的变量，不报错）。**另外 `var(--dark)` 和 `var(--dark-color)` 是不同变量** — about.php 等页面的 inline style 用了 `var(--dark)` 但只有 `--dark-color` 被定义，导致图标背景和徽章颜色失效。

**诊断：**
```javascript
(function(){
    const s = getComputedStyle(document.documentElement);
    return JSON.stringify({
        primary: s.getPropertyValue('--primary').trim() || 'UNDEFINED',
        accent: s.getPropertyValue('--accent').trim() || 'UNDEFINED',
    });
})();
```

**修复：** 创建 `color-harmony.css` 在 `:root` 中定义所有缺失变量，放在 header.php 最后加载。色彩比例 60/30/10（白/深蓝/金色）。

**⚠️ 白字白底陷阱（2026-05-30 实战发现）：** 当 overlay CSS 把 section 背景从深色改为白色时，**必须同步覆盖所有子元素的文字颜色**。原 CSS 为深色背景设计的白色文字在白色背景上完全不可见。修完后用浏览器 Console 扫描白字白底元素验证。详见 `references/css-color-harmony-pattern.md`。

**⚠️ Reveal 动画 opacity:0 兜底（2026-05-30 实战发现）：** `.reveal` 初始 `opacity:0`，依赖 JS IntersectionObserver。JS 未触发时 40+ 个元素永远不可见。必须在 color-harmony.css 中添加 CSS animation 兜底（2秒后自动显示）。详见 `references/css-color-harmony-pattern.md`。

**⚠️ Reveal 动画 JS/CSS 类名不匹配陷阱（2026-05-30 实战发现）：** CSS 定义 `.reveal.revealed { opacity: 1; }` 但 JS 添加的是 `.active` 类，导致所有 reveal 元素永远不可见。**必须确保 CSS 和 JS 使用完全相同的类名。** 诊断：`document.querySelectorAll('.reveal.revealed').length` 应等于 `.reveal` 总数。修复：将 JS 中的 `classList.add('active')` 改为 `classList.add('revealed')`。详见 `references/glass-morphism-visual-polish-pattern.md`。

**⚠️ 页面加载器(Page Loader)卡死陷阱（2026-05-30 实战发现）：**

**问题：** `.page-loader` 使用 `window.addEventListener('load', ...)` 隐藏，但 `load` 事件要求**所有外部资源**（Google Fonts、Font Awesome、Bootstrap CDN）加载完毕才触发。在中国网络环境下，这些CDN经常加载缓慢或超时，导致 `load` 事件**永远不触发**，白色遮罩+转圈永远显示。

**症状：** 用户报告"页面一直转圈加载不出来"，但服务器返回200、页面内容正常、无JS错误。

**三重修复方案（缺一不可）：**

```javascript
// 1. DOMContentLoaded — DOM渲染完就隐藏（不等外部资源）
function hideLoader() {
    const loader = document.querySelector('.page-loader');
    if (loader) {
        loader.classList.add('loaded');
        setTimeout(() => loader.remove(), 500);
    }
}
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(hideLoader, 200);
});
// 2. 3秒超时兜底 — 强制隐藏
setTimeout(hideLoader, 3000);
// 3. load 事件也监听（正常情况下的快速路径）
window.addEventListener('load', hideLoader);
```

```css
/* 4. CSS动画兜底 — 即使JS完全失败也能隐藏 */
@keyframes autoHideLoader {
    0%, 85% { opacity: 1; visibility: visible; }
    100% { opacity: 0; visibility: hidden; pointer-events: none; }
}
.page-loader {
    animation: autoHideLoader 3s ease forwards;
}
```

**⚠️ 关键：修改 b2b-enhance.js 后必须同步更新 bundle-v2.min.js！**（见下方Bundle文件陷阱）

**⚠️ 外部CDN异步加载（防止阻塞渲染）：**

Google Fonts 和 Font Awesome 使用 `media="print" onload` 模式异步加载，不阻塞页面渲染：

```html
<!-- Google Fonts — 异步加载 -->
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" 
      rel="stylesheet" media="print" onload="this.media='all'">
<noscript><link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet"></noscript>

<!-- Font Awesome — 异步加载 -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" 
      media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"></noscript>

<!-- Bootstrap CSS — 保持同步（核心样式不能延迟） -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
```

**原理：** `media="print"` 让浏览器以低优先级加载（不阻塞渲染），`onload` 触发后切换为 `media='all'` 恢复正常显示。`<noscript>` 兜底确保禁用JS时也能加载。

**⚠️ Bundle 文件编辑陷阱（2026-05-30 实战发现）：**

**问题：** 修改了源文件（如 `b2b-enhance.js`）但实际页面加载的是合并后的 bundle 文件（如 `bundle-v2.min.js`）。源文件的修改不会生效！

**诊断方法：**
```bash
# 检查实际加载的JS文件
curl -s https://SITE/ | grep -oP 'src="[^"]*\.js[^"]*"'
# 输出: /assets/js/bundle-v2.min.js?v=1780146726

# 检查 bundle 中是否包含目标函数
grep -n 'hideLoader\|page-loader' /path/to/bundle-v2.min.js
```

**正确做法：**
1. 先确认实际加载的文件名（从HTML中grep）
2. 直接修改 bundle 文件（不是源文件）
3. 更新缓存版本号（`?v=<?= time() ?>` 或新文件名）
4. 源文件也同步更新（保持一致性）

**⚠️ 缓存版本号更新：**
```php
<!-- header.php — CSS 已用 time() 自动更新 -->
<link href="/assets/css/bundle-v8.min.css?v=<?= time() ?>" rel="stylesheet">

<!-- footer.php — JS 也要用 time() 自动更新 -->
<script src="/assets/js/bundle-v2.min.js?v=<?= time() ?>"></script>
```

如果用静态版本号（如 `?v=1780146726`），每次修改后必须手动更新。推荐用 `<?= time() ?>` 自动刷新（开发阶段），生产环境用文件mtime。

**⚠️ Bootstrap Carousel 自动轮播验证（2026-05-30 实战发现）：**

用户反馈"轮播图片没有自动轮播"。根因：Bootstrap JS 在 footer 底部加载，Carousel 可能在 JS 加载前就尝试初始化。

**诊断方法：** 浏览器 Console 检查：
```javascript
typeof bootstrap !== 'undefined'  // 应为 true
bootstrap.Carousel.getInstance(document.querySelector('#heroCarousel'))  // 应返回对象
```

**验证自动轮播：**
```javascript
// 等5秒后检查 active item 是否变化
const items = document.querySelectorAll('.carousel-item');
const before = Array.from(items).indexOf(document.querySelector('.carousel-item.active'));
setTimeout(() => {
    const after = Array.from(items).indexOf(document.querySelector('.carousel-item.active'));
    console.log('Carousel moved:', before !== after);
}, 5000);
```

**关键配置：** `data-bs-ride="carousel"` + `data-bs-interval="5000"` 必须在 carousel div 上。

**⚠️ 轮播图替换完整工作流（2026-05-30 实战发现）：**

替换轮播图需要同时更新文件和数据库，并绕过 CDN 缓存：

```bash
# 1. 复制新图片到 slider 目录
cp /path/to/new-banner.jpg /assets/images/slider/slider1.jpg

# 2. 更新数据库记录
mysql -u USER -p'PASS' DB -e "UPDATE sliders SET image='/assets/images/slider/slider1-v2.jpg', title='新标题' WHERE id=1"

# 3. 重命名文件绕过 Cloudflare CDN 缓存（关键！）
cp slider1.jpg slider1-v2.jpg

# 4. 验证
curl -sI https://SITE/assets/images/slider/slider1-v2.jpg | grep 'content-length\|cf-cache'
# 应显示正确的文件大小 + cf-cache-status: MISS
```

**⚠️ 2列分类卡片布局（2026-05-30 实战发现）：**

当只有2个分类时，用 `col-lg-4` 会导致3列布局（第3列空缺）。正确做法：

```php
<!-- 改为 col-lg-6（2列）+ 居中 -->
<div class="row g-4 justify-content-center">
    <?php foreach ($categories as $i => $cat): ?>
    <div class="col-lg-6 col-md-6">
        <!-- 分类卡片 -->
    </div>
    <?php endforeach; ?>
</div>
```

分类图片应使用高清产品图（≥1200×900），不要用缩略图。

**完整色彩方案和变量清单：** `references/css-color-harmony-pattern.md`

**⚠️ Bootstrap class 覆盖陷阱：** footer 有 `class="bg-dark"` 时，CSS 必须用 `footer.bg-dark` 选择器 + `!important` 才能覆盖 Bootstrap 的 `#212529`。

**CSS Layering (PHP site uses 3+ files, loaded in order):**
1. `bundle-v7.min.css` (77KB) — Merged: bundle.min.css + color-harmony.css + layout-v2.css + modern-ui-v6.css
2. `b2b-enhance.css` (14KB) — B2B professional elements (WhatsApp float, back-to-top, partners, newsletter, inquiry modal, loader)
3. `visual-polish-v8.css` (37KB, gzip 8KB) — Glass morphism, shadows, hover effects, custom scrollbar, all section styles (category cards, feature boxes, testimonials, trust badges, news cards, HP range, cert gallery, footer, buttons, responsive breakpoints)
4. Page-specific inline `<style>` blocks (if needed)

**⚠️ Comprehensive Multi-Round Testing Workflow（用户要求"反复测试直到没有问题"时）：**

当用户说"反复测试直到没有问题"时，执行以下多轮测试：

**Round 1 — 前台页面 HTTP 状态码**
```bash
for p in / /products /about /contact /news /export /search /why-us /sitemap.xml /robots.txt; do
  curl -s -o /dev/null -w '%{http_code}' "https://SITE$p"
done
# 产品详情页（全部slug）
mysql -u USER -p'PASS' DB -N -e "SELECT slug FROM products WHERE is_active=1" | while read slug; do
  curl -s -o /dev/null -w '%{http_code}' "https://SITE/product/$slug"
done
```

**Round 2 — 后台页面（cookie jar 登录）**
```bash
# 登录获取session
curl -s -c /tmp/admin_cookie -L -o /dev/null -X POST 'https://SITE/admin/login.php' -d 'username=admin&password=PASS'
# 测试所有admin页面
for p in /admin/ /admin/products.php /admin/categories.php /admin/news.php /admin/sliders.php /admin/messages.php /admin/inquiries.php /admin/pages.php /admin/settings.php /admin/seo-checker.php; do
  curl -s -b /tmp/admin_cookie -o /dev/null -w '%{http_code}' "https://SITE$p"
done
# 测试admin子页面（CRUD）
for p in '/admin/products.php?action=add' '/admin/products.php?action=edit&id=1' '/admin/news.php?action=add'; do
  curl -s -b /tmp/admin_cookie -o /dev/null -w '%{http_code}' "https://SITE$p"
done
```

**Round 3 — PHP 语法检查**
```bash
find /path/to/site -name '*.php' -exec php -l {} \; 2>&1 | grep -v 'No syntax errors'
```

**Round 4 — 链接/图片/资源检查**
```bash
# 内部链接
curl -s https://SITE/ | grep -oP 'href="(/[^"]*)"' | sed 's/href="//;s/"$//' | \
  grep -v '#' | grep -v 'javascript:' | grep -v '\\$' | sort -u | while read url; do
  code=$(curl -s -o /dev/null -w '%{http_code}' "https://SITE${url}")
  [ "$code" != "200" ] && echo "❌ ${url} → ${code}"
done
# 图片
curl -s https://SITE/ | grep -oP 'src="(/assets/images/[^"]*)"' | sed 's/src="//;s/"$//' | sort -u | while read img; do
  code=$(curl -s -o /dev/null -w '%{http_code}' "https://SITE${img}")
  [ "$code" != "200" ] && echo "❌ ${img} → ${code}"
done
```

**Round 5 — API 端点测试**
```bash
curl -s "https://SITE/api/products.php?page=1&limit=8" | head -1  # 应返回JSON
curl -s -X POST "https://SITE/api/message.php" -d "test=1" | head -1  # 应返回验证错误
```

**Round 6 — Nginx 错误日志**
```bash
sudo truncate -s 0 /var/log/nginx/error.log
# 重新加载所有页面...
sudo tail -5 /var/log/nginx/error.log | grep -v 'notice\|signal\|exit'
```

**Round 7 — 性能基准**
```bash
curl -s -o /dev/null -w 'Load: %{time_total}s | Size: %{size_download}B' https://SITE/
curl -sI -H "Accept-Encoding: gzip" https://SITE/assets/css/visual-polish-v8.css | grep content-encoding
```

**Round 8 — 浏览器验证（关键页面）**
- 浏览器打开首页，Console 检查 JS 错误
- 后台登录，检查 Dashboard/Products/Settings 页面
- 滚动页面验证 reveal 动画触发

**重复 Round 1-8 直到所有检查通过。不要在 Round 1 修完就说"搞定了"。**

**JS Files (3 files):**
1. `main.js` — Core functionality
2. `enhance-v3.js` — Scroll animations, testimonials
3. `b2b-enhance.js` (6.5KB) — B2B interactions (loader, back-to-top, sticky nav, reveal, partner marquee, product tabs, counter animation)

- **B2B Professional Enhancement:** `references/b2b-professional-enhancement-pattern.md`
包含：8大B2B外贸网站必备元素 — 浮动WhatsApp按钮(脉冲动画+预填消息)、回到顶部按钮、粘性导航栏(滚动阴影)、页面加载动画、合作伙伴Logo跑马灯(无限滚动)、Newsletter订阅区、产品询价弹窗(Bootstrap Modal)、现代Footer(四栏+贸易徽章)。完整CSS+HTML+JS模板和集成清单。
- **Glass Morphism & Visual Polish:** `references/glass-morphism-visual-polish-pattern.md`
包含：Hero毛玻璃效果(backdrop-filter blur+saturate)、滚动后Navbar毛玻璃、产品卡片阴影hover效果、轮播控制按钮hover显示、自定义滚动条(蓝→金渐变)、CSS分层加载策略(bundle→b2b→visual-polish)。**⚠️ 关键陷阱：JS添加`.active`类但CSS定义`.revealed`类导致45个元素永远不可见 — 必须确保CSS和JS使用同一类名。**
- **Admin Page Structure Pitfalls:** `references/admin-page-structure-pitfalls.md`
包含：auth.php集成后的重复HTML结构Bug诊断和修复、null数组访问在create/edit双模式表单中的修复、logs目录权限问题。**⚠️ 关键：auth.php输出完整HTML结构(DOCTYPE/head/sidebar/content-area open)，内容页只输出内容+闭合标签。**
- **Visual Polish B2B CSS:** `references/visual-polish-b2b-css-pattern.md`
包含：完整的B2B网站视觉增强CSS模式 — 玻璃毛磨砂导航、产品卡片阴影hover、轮播控制按钮、自定义滚动条、所有section样式(分类卡片/特性框/评价/信任徽章/新闻/HP范围/证书画廊/Footer)。CSS分层加载策略(bundle→b2b→visual-polish)。gzip仅8KB。**⚠️ 关键：产品卡片之前没有box-shadow是重大视觉缺陷。**
- **Image Asset Sourcing:** `references/image-asset-sourcing-workflow.md`
包含：从参考网站采集图片素材的工作流 — curl提取图片URL、Python struct模块检查JPG/PNG尺寸（无需PIL）、按质量分级(绿≥800×600/黄≥400×300/红<400×300)、Telegram发送图片给用户审核。中国网站常见图片路径(/upload/、/upload/img/、/image/)。
- **Admin Profile Page Pattern:** `references/admin-profile-page-pattern.md`
包含：用户资料编辑+密码修改完整模板 — auth.php集成、CSRF保护、密码强度检测、Session更新、侧边栏/头部集成、语言词条。**⚠️ 关键：不要重复HTML结构，末尾必须echo闭合标签。**
- **Modern UI Design Patterns (from web_b2b):** `references/modern-ui-design-patterns-from-web-b2b.md`
包含：从React+Django参考项目提取的CSS设计模式 — 方形产品卡片(hover缩放+overlay)、圆角分类卡片(圆形蒙层扩展)、统一Section标题(居中+下划线)、统计数据展示、客户评价现代卡片、资质证书画廊(lightbox+键盘导航)、特性卡片(图标圆形+渐变边框)。完整CSS+HTML模板。**⚠️ 跨技术栈移植方法论：分析参考项目→提取CSS模式→适配现有Bootstrap 5。**

**Homepage Section Rhythm Pattern:** `references/homepage-section-rhythm-pattern.md`
包含：首页section交替背景节奏优化 — 诊断脚本(Console检查背景色)、10-section模板(浅蓝→白→灰→白→浅蓝→白→灰→深蓝渐变→黑)、section合并策略(Featured+Hot合并、Why Us+Stats合并、Testimonials+Trust合并、About+CTA合并)、统一padding标准(4.5rem inline style)、About+CTA深蓝渐变合并模式、Contact CTA黑色背景模式。**⚠️ 核心规则：相邻section背景色不能相同，section数量≤10。**

**⚠️ Iterative Testing Until Clean（2026-05-30 实战发现）：**

用户说"反复测试.直到没有问题为止"时，必须执行多轮测试直到零错误：
1. **Round 1**: curl 扫描所有页面 HTTP 状态码 + PHP 错误
2. **Round 2**: 修复发现的问题
3. **Round 3**: 重新测试所有页面（包括修复的页面）
4. **Round 4**: 检查 nginx error log 确认无新 PHP warning
5. **Round 5**: 浏览器验证关键页面视觉效果
6. **重复直到 Round N 全部通过**

不要在 Round 1 修完就说"搞定了"。用户要求的是零错误，不是"大部分通过"。

**⚠️ Nginx Error Log 是最终真相来源：** curl 输出可能不显示 PHP warning（被 HTML 包裹），但 nginx error log 会记录所有。每次修复后必须检查：
```bash
tail -5 /var/log/nginx/sub-aiv-error.log
# 或清空后重新测试
sudo truncate -s 0 /var/log/nginx/sub-aiv-error.log
# 重新测试所有页面...
cat /var/log/nginx/sub-aiv-error.log
```

**⚠️ Broken Symlink Detection（2026-05-30 实战发现）：**
CSS 文件是符号链接但目标不存在时，`wc -c` 报 0 bytes，nginx 返回 HTML 内容（被 PHP 处理）。诊断：`ls -la *.css | grep '\->'` + 检查目标是否存在。修复：`rm` 断链符号链接。

**⚠️ CSS Bundle Deduplication（2026-05-30 实战发现）：** style-responsive.css, style-v2.css, style-v3.css 包含相同的 `:root` 变量和基础样式。visual-v5.css = visual-v5c.css（md5相同）。盲目合并会导致同一规则重复2-3次，bundle膨胀到58KB。修复：`md5sum *.css` 检查重复，只合并唯一文件，重建后38KB（减少34%）。

**⚠️ CSS var() + !important 覆盖陷阱（2026-05-30 实战发现）：** 当用新CSS文件覆盖bundle.min.css中的样式时，使用`var()`变量的`!important`声明可能不生效（浏览器忽略未解析的变量）。症状：Console显示padding仍为旧值。修复：在覆盖文件中使用直接值（如`padding: 4rem 0 !important;`）而非`padding: var(--section-py) 0 !important;`。验证：`getComputedStyle(el).paddingTop` 应返回 "64px"。详见 `references/layout-optimization-pattern.md`。

**⚠️ 首页Section Padding标准化（2026-05-30 实战发现）：** 首页各section的padding值混乱（0px/32px/40px/48px/64px/80px混用），其中why-choose-us、latest-news、contact-cta三个section的padding为0px。修复：创建layout-v2.css统一覆盖，标准值为：大section 5rem、标准section 4rem、小section 3rem。详见 `references/layout-optimization-pattern.md`。

**⚠️ 内页Banner统一（2026-05-30 实战发现）：** 各内页（products/about/contact/news/export/why-us）的banner样式不一致，有的用inline style，有的用class。修复：统一使用`page-banner` class，CSS中定义固定高度（260px）和padding（4rem），移动端缩减到180px/2.5rem。

**⚠️ Footer精简（2026-05-30 实战发现）：** Footer高度635px过大，使用Bootstrap列布局导致间距不可控。修复：改用CSS Grid（`grid-template-columns: 1.5fr 1fr 1fr 1.2fr`），减少padding（2.5rem/1.5rem），响应式断点自动调整列数。

**⚠️ CSS var() + !important 覆盖陷阱（2026-05-30 实战发现）：**

当用新CSS文件覆盖bundle.min.css中的padding时，使用 `padding: var(--section-py) 0 !important;` 可能不生效。原因是浏览器缓存或CSS变量解析时机问题。

**症状：** 浏览器Console中 `getComputedStyle(el).paddingTop` 仍返回旧值（如 "0px"），尽管CSS文件已更新且!important已声明。

**修复：** 使用直接值而非CSS变量：
```css
/* ❌ 可能不生效 */
.why-choose-us { padding: var(--section-py) 0 !important; }

/* ✅ 直接值，必定生效 */
.why-choose-us { padding: 4rem 0 !important; }
```

**验证方法：** 浏览器Console检查：
```javascript
const el = document.querySelector('.why-choose-us');
console.log('padding:', getComputedStyle(el).paddingTop);
// 应返回 "64px" (4rem)，不是 "0px"
```

**layout-v2.css 模式（统一布局覆盖文件）：**

创建独立的 `layout-v2.css` 放在 bundle 之后加载，用 `!important` 覆盖 bundle 中的不一致padding：

```css
/* 首页Section统一间距 */
.featured-products, .testimonials-section { padding: 5rem 0 !important; }
.category-showcase, .hp-range-section, .hot-products-strip,
.trust-bar, .company-intro-compact, .product-cta-strip { padding: 4rem 0 !important; }
.why-choose-us, .latest-news, .contact-cta { padding: 4rem 0 !important; }

/* 内页Banner统一 */
.page-banner { padding: 4rem 0 !important; min-height: 260px; display: flex; align-items: center; }
```

**加载顺序：** bundle.min.css → color-harmony.css → layout-v2.css（最后加载，覆盖优先级最高）

**⚠️ 内页Banner必须统一class（2026-05-30 实战发现）：**

所有内页（products/about/contact/news/export/why-us/search）的banner必须使用 `class="page-banner"`，不要各自写inline style。检查方法：
```bash
for f in products.php about.php contact.php news.php export.php why-us.php; do
    grep -q 'class="page-banner"' "$f" && echo "✅ $f" || echo "❌ $f"
done
```

**⚠️ Footer精简（2026-05-30 实战发现）：**

Footer高度635px过长。用CSS Grid替代Bootstrap列布局可更好控制：
```css
footer.bg-dark { padding-top: 2.5rem !important; padding-bottom: 1.5rem !important; }
.footer-grid { display: grid; grid-template-columns: 1.5fr 1fr 1fr 1.2fr; gap: 2rem; }
@media (max-width: 991.98px) { .footer-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 575.98px) { .footer-grid { grid-template-columns: 1fr; } }
```

**⚠️ PHP Admin Duplicate HTML Structure Bug（2026-05-30 实战发现）：**

当 admin 页面 `require_once auth.php` 后又输出自己的 `<!DOCTYPE html>`、`<head>`、`<body>`、`sidebar include` 时，会导致：
- 浏览器收到两个 `<html>` 标签（嵌套或并列）
- sidebar 被渲染两次
- CSS/JS 重复加载
- Nginx error log 出现 `Failed to open stream: No such file or directory` (sidebar.php 不存在)

**症状诊断：**
```bash
for f in /path/admin/*.php; do
    has_doctype=$(grep -c "<!DOCTYPE" "$f")
    has_sidebar=$(grep -c "includes/sidebar.php" "$f")
    [ "$has_doctype" -gt 0 ] && echo "ISSUE: $(basename $f) DOCTYPE:$has_doctype sidebar:$has_sidebar"
done
```

**修复：** 删除 auth.php 之后的重复 HTML 结构（`<!DOCTYPE html>` 到 `<body>` 之间），只保留页面特定的 `<style>` 和内容。auth.php 已输出完整的 HTML header + sidebar + opens content-area div。

**⚠️ Null Array Access in Create/Edit Dual-Mode Forms（2026-05-30 实战发现）：**

PHP 表单同时处理 create 和 edit 时，`$news['field']` 在 create 模式下 `$news` 为 null，导致：
```
PHP Warning: Trying to access array offset on null
```

**修复：** 所有 `$news['field']` 改为 `$news['field'] ?? $_POST['field'] ?? ''`，日期字段改为 `isset($news['field']) && $news['field'] ? ... : default`。

**⚠️ Logs Directory Permission（2026-05-30 实战发现）：**
`file_put_contents(logs/)`: Permission denied — logs/ 目录权限不足。修复：`chmod 777 logs/` 或 `chown www-data:www-data logs/`。

**⚠️ CSS var() 在 !important 覆盖中可能不生效（2026-05-30 实战发现）：**

用 `layout-v2.css` 覆盖 `bundle.min.css` 中的 section padding 时，使用 `padding: var(--section-py) 0 !important;` 不生效。原因是 CSS 变量在 `:root` 中定义但被 bundle 的 `:root` 覆盖（同级选择器，后加载的赢），导致变量值为空。

**症状：** 浏览器 Console 中 `getComputedStyle(document.documentElement).getPropertyValue('--section-py')` 返回空字符串。

**修复：** 在覆盖文件中使用直接值而非变量引用：
```css
/* ❌ 不生效 — 变量可能被覆盖 */
.why-choose-us { padding: var(--section-py) 0 !important; }

/* ✅ 生效 — 直接值 */
.why-choose-us { padding: 4rem 0 !important; }
```

**验证方法：**
```javascript
const el = document.querySelector('.why-choose-us');
console.log(getComputedStyle(el).paddingTop); // 应为 "64px" (4rem)
```

**⚠️ 首页Section Padding标准化（2026-05-30 实战发现）：**

首页section padding不一致是常见问题。诊断数据：
- category-showcase: 64/32px（不对称）
- featured-products: 80/80px（偏大）
- why-choose-us: 0/0px（无间距！）
- latest-news: 0/0px（无间距！）
- contact-cta: 0/0px（无间距！）

**标准值：** 大section 5rem，标准section 4rem，小section 3rem。

**layout-v2.css 统一覆盖模板：**
```css
/* 标准大section: 5rem */
.featured-products,
.testimonials-section { padding: 5rem 0 !important; }

/* 标准section: 4rem */
.category-showcase,
.hp-range-section,
.hot-products-strip,
.trust-bar,
.company-intro-compact,
.product-cta-strip,
.why-choose-us,
.latest-news,
.contact-cta { padding: 4rem 0 !important; }
```

**⚠️ 内页Banner统一模式（2026-05-30 实战发现）：**

内页（products/about/contact/news/export/why-us）应统一使用 `page-banner` class，不要各自写 inline style。CSS中定义统一高度和居中：
```css
.page-banner {
    padding: 4rem 0 !important;
    min-height: 260px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
}
.page-banner h1 { color: #fff; font-size: 2.5rem; font-weight: 800; }
@media (max-width: 767.98px) {
    .page-banner { padding: 2.5rem 0 !important; min-height: 180px; }
    .page-banner h1 { font-size: 1.8rem; }
}
```

**验证清单：** 所有内页HTML应有 `class="page-banner"`，不要有独立的 `padding:3rem 0` 或 `padding:5rem 0` inline style。

**⚠️ color-harmony.css 必须单独加载（2026-05-30 实战发现）：** 创建 color-harmony.css 后，必须在 `templates/header.php` 中显式添加 `<link>` 标签。它不会自动包含在 bundle.min.css 中。必须放在 bundle 之后加载（CSS级联：后加载的覆盖先加载的）。验证：浏览器Console `getComputedStyle(document.documentElement).getPropertyValue('--primary').trim()` 应返回 `#0f2b5b`（不是 `#2563eb`）。

Each later file overrides earlier. Don't use `!important` — rely on load order and specificity.

**⚠️ Nav Active State（2026-05-30 实战发现）：** 每个页面设置 `$currentPage`，header.php 用条件类名高亮当前导航：
```php
<a class="nav-link<?= ($currentPage ?? '') === 'about' ? ' active' : '' ?>" href="/about">About Us</a>
```
CSS 下划线效果已在 bundle 中（`nav-link::after` + `nav-link.active::after`）。

**⚠️ Heading Hierarchy for SEO（2026-05-30 实战发现）：** 产品卡片用 `<h5>` 在 `<h2>` 下会跳级（H2→H5），SEO扣分。正确做法：`<h3 class="h5">` — 语义层级H3正确，视觉大小由 `h5` class 控制。同样适用于特性框（H4→H3）、联系方法标题（H5→H3）、新闻卡片标题（H5→H3）。

**⚠️ Contact Info Consistency（2026-05-30 实战发现）：** Header 顶部栏不要硬编码电话/邮箱，必须用 PHP 常量 `CONTACT_PHONE`、`CONTACT_EMAIL`、`SOCIAL_FACEBOOK` 等。社交链接不要用 `#`（死链接），没有实际URL的社交平台直接不显示。添加 `aria-label` 无障碍标签。

**⚠️ Perl Regex Breaking PHP Ternary（2026-05-30 实战发现）：** 用 `perl -pi -e` 替换 PHP 三元表达式中的文本会创建嵌套 PHP 标签导致语法错误：
```php
// perl 替换后（BROKEN）：
<?= $action === 'add' ? '<?= t('Add Product') ?>' : '<?= t('Edit Product') ?>' ?>
// 正确做法：
<?= $action === 'add' ? t('Add Product') : t('Edit Product') ?>
```
安全做法：用 `patch` 工具手动替换三元表达式内的文本，不要用 perl 正则批量替换。

**⚠️ CSS版本命名陷阱（2026-05-30 实战发现）：** header.php 用 `style-v{timestamp}.css` 引用CSS，但实际文件是 `style.css`。sed更新版本号后文件不存在→404。解决：创建新文件名（如 `style-responsive.css`、`style-v2.css`）然后更新header引用。每次CDN缓存问题都创建新文件名。

**⚠️ Product slug unique constraint — batch update 陷阱：**
MySQL `products.slug` 有 UNIQUE 约束。批量 UPDATE 时如果新 slug 与其他行冲突，整条语句静默失败。必须逐条检查或用 `WHERE name LIKE '%keyword%'` 精确匹配。更新后验证：`SELECT id, name, slug FROM products WHERE id IN (目标ID);`

**⚠️ sitemap.php 必须调用 getDBConnection()：**
`config/database.php` 导出的是 `getDBConnection()` 函数，不是 `$pdo` 变量。sitemap.php 和其他需要数据库的页面必须先调用 `$pdo = getDBConnection();`。SEO 类还使用 `status = 1`，但数据库实际字段是 `is_active = 1` — 需要修复。

**AJAX "Load More" 产品加载模式：**
适用于首页产品展示需要"点击加载更多"的场景。创建 `/api/products.php` API 端点，支持分页参数 `?page=N&limit=N&check=true`。前端用 `fetch()` + `insertAdjacentHTML()` 动态插入产品卡片。详见 `references/ajax-load-more-pattern.md`。

**PHP 站点商务简洁设计：** `references/php-site-business-clean-design.md`
包含：深蓝+金色配色方案（#0F2B5B/#D4A843）、CSS设计系统（section-badge/stats-banner/feature-box/icon-wrapper）、产品卡片样式、Bootstrap容器布局、首页7板块结构模板。与ASP站点设计模式不同（固定980px vs Bootstrap 1200px）。**⚠️ 新增：page-banner内页模板、模板统一工作流（standalone→shared header/footer）、5种内页设计模式（About/Contact/Products/Detail/News）、新闻图片占位符、Nginx slug路由陷阱、图片来源（本地备份/wwwroot/）。**

**Nginx index.html优先级陷阱：** `references/nginx-php-index-precedence-pitfall.md`
包含：index.html会静默覆盖index.php的完整诊断和修复流程。症状：修改index.php后页面不变。根因：Nginx `index`指令按顺序匹配。修复：移走index.html + reload nginx。

**PHP Page Creation & Admin Connection:** `references/php-page-creation-workflow.md`
包含：创建新PHP页面完整流程（about/contact/news）、nginx路由添加、header.php函数依赖修复（escape/getCurrentUrl/$pdo）、联系表单→后台消息管道、新闻→后台管理管道、文件权限问题、验证清单。

**Nginx + PHP-FPM 部署：** `references/nginx-php-fpm-deployment.md`
包含：完整Nginx配置模板、PHP-FPM socket路径、部署7步流程、**12个关键陷阱**（index.html优先于index.php、404处理、require路径、文件权限、敏感路径写入、Cloudflare覆盖robots.txt、测试文件清理等）。验证清单（8项curl检查）。**⚠️ 新增陷阱#12：index.html会静默覆盖index.php。⚠️ 新增陷阱#13：try_files $uri传完整路径 — 产品和新闻详情页slug必须在PHP中清理（去除/news/前缀和.html后缀）。⚠️ 新增陷阱#14：clean URL需要独立nginx路由（/about不等于/about.html）。**

**Nginx + Cloudflare 配置参考：** `references/nginx-cloudflare-flexible-ssl.conf`
包含：Cloudflare Flexible SSL下Nginx配置、避免重定向循环。

---

**⚠️ CSS 选择器验证（必须先做！）：**

写CSS前**必须**先检查HTML的实际ID/class，不要凭记忆写选择器。

```bash
# 检查所有 ID
curl -s https://www.shengtuo-tractor.com | grep -oE 'id="[^"]*"' | sort -u

# 检查所有 class
curl -s https://www.shengtuo-tractor.com | grep -oE 'class="[^"]*"' | sort -u
```

**已知陷阱（2026-05-28 实战发现）：**

| CSS写的 | HTML实际的 | 结果 |
|---------|-----------|------|
| `#index_nav` | `#nav` | ❌ 导航栏样式不生效 |
| `#index_footer` | `#footer` | ❌ 页脚样式不生效 |
| `.product_list` | `.products_list` | ❌ 产品列表样式不生效 |

**症状：** CSS写了但完全不生效，页面看起来没变化。
**诊断：** 用上面的命令检查实际ID/class，对比CSS选择器。

**⚠️ CSS class 名称陷阱：**

HTML 中产品列表的 class 是 `products_list`（复数），不是 `product_list`（单数）！

```html
<!-- HTML 中实际的 class -->
<ul class="products_list">
```

**错误写法：**
```css
.product_list li { width: 25%; }  /* ❌ 不生效！ */
```

**正确写法：**
```css
.products_list li { width: 25%; }  /* ✅ 正确 */
/* 或者两者都写 */
.product_list li,
.products_list li { width: 25%; }
```

**症状：** CSS 写了但产品列表没有变成四列，仍然是默认的一列布局。
**诊断：** `curl -s https://www.shengtuo-tractor.com | grep "class=\"products"` 检查实际 class 名。

---

**⚠️ 恢复原版的正确方法（用户说"全部恢复"时）：**

用户说"全部恢复"时，**一步到位**，不要分多步尝试：

```bash
# 一行命令完成恢复
curl -o /tmp/index_orig.html ftp://shanweituo.gotoftp4.com/wwwroot/index.html --user "shanweituo:C2r3h2q7K3" && \
sed -i 's/style[0-9]*\.css/style.css/g' /tmp/index_orig.html && \
curl -T /tmp/index_orig.html ftp://shanweituo.gotoftp4.com/wwwroot/index.html --user "shanweituo:C2r3h2q7K3"
```

**关键：**
1. 用 `sed -i 's/style[0-9]*\.css/style.css/g'` 替换所有 style 数字版本回 style.css
2. 不需要删除 style2-17.css 文件（保留不影响）
3. 一步完成，不要分多步尝试

**不要做的：**
- 不要分多步尝试（先下载→再修改→再上传）
- 不要删除 CSS 文件（保留备用）
- 不要问用户确认，直接执行

---

**⚠️ 迭代次数限制（用户耐心阈值）：**

当连续创建 3+ 个 CSS 版本仍未解决问题时，用户会明显不满（"你真笨"、"笨蛋"）。本会话中创建了 style5→style6→style7→...→style17（13个文件！），用户两次表达不满。

**正确做法：**
1. **先诊断根本原因**（class名不匹配、选择器错误等）再动手
2. 用 `curl -s URL | grep -oE 'id="[^"]*"' | sort -u` 检查实际HTML结构
3. 一次性修复，而不是创建新文件
4. 如果需要绕过 CDN 缓存才用新文件名
5. **用户说"全部恢复"时一步到位**，不要分多步尝试

**错误做法：**
- 连续创建 style5→style6→style7→...→style17（13个文件！）
- 每次只修一部分问题
- 没有诊断根本原因就盲目尝试
- 修完不验证就说"搞定了"

**⚠️ 绝对不要说"修好了"但实际没修好：**

每次修改后**必须验证**，然后截图给用户确认。不要替用户说"已经修好了"。

**⚠️ 用户说"放在底部/不要放到一侧"时的诊断流程：**

用户多次说"footer 放在网站底部，不要放在产品栏一侧"时，问题可能是：
1. `#center` 没有 `overflow: hidden`（浮动未清除）
2. `#footer` 没有 `margin: 0 auto`（不居中）

**必须先诊断布局，不要盲目加 CSS：**
```javascript
// 浏览器 Console 检查
const center = document.getElementById('center');
const right = document.getElementById('right');
const footer = document.getElementById('footer');
console.log('center height:', center.getBoundingClientRect().height);
console.log('right height:', right.getBoundingClientRect().height);
console.log('footer top:', footer.getBoundingClientRect().top);
// center height < right height → 浮动未清除
// footer left != main left → 未居中
```

**修完后验证：** footer.top >= main.bottom，footer.left == main.left

每次修改后**必须验证**，然后截图给用户确认。不要替用户说"已经修好了"。

```bash
# 修完后验证步骤：
# 1. 检查CSS是否正确上传
curl -s https://www.shengtuo-tractor.com/css/style.css | head -5

# 2. 检查HTML引用是否正确
curl -s https://www.shengtuo-tractor.com | grep "stylesheet"

# 3. 截图给用户看（不要自己说修好了）
# 用 Playwright 截图，发给用户确认
```

**⚠️ 原始CSS文件被覆盖后的恢复策略：**

当用户要求"全部恢复"但原始 `style.css` 已被覆盖时：

**方案1（推荐）：从 git 仓库恢复**
```bash
cd /home/ubuntu/shengtuo-tractor
git log --oneline css/style.css  # 找到原始版本的 commit
git checkout <commit-hash> -- css/style.css
git push origin master
```

**方案2（无 git 时）：创建最小化CSS**
如果原始CSS无法恢复，创建一个简单的CSS，只设置基本布局：
- 980px 固定宽度
- 基本字体和颜色
- 无动画、无渐变、无现代效果
- 匹配实际HTML的ID/class（先检查！）

**关键：不要凭记忆写CSS，必须先检查实际HTML结构！**

**⚠️ CSS Grid 响应式陷阱（2026-05-28 实战发现）：**

桌面端用 `display: grid; grid-template-columns: repeat(4, 1fr);` 时，不能用 `width` 控制移动端列数：

```css
/* ❌ 错误：CSS Grid 中 width 不控制列数 */
@media (max-width: 980px) {
    .products_list li { width: calc(50% - 5px); }  /* 只让卡片变窄，还是4列！ */
}

/* ✅ 正确：用 grid-template-columns 覆盖 */
@media (max-width: 980px) {
    .products_list { grid-template-columns: repeat(2, 1fr); }
}
```

**调试顺序（必须按此执行）：**
1. `curl -s URL | grep -oE 'id="[^"]*"' | sort -u` — 检查实际HTML ID
2. `curl -s URL/css/style.css | grep "选择器名"` — 检查CSS是否匹配
3. `curl -s URL | grep -i "viewport"` — 检查viewport标签
4. 修复 → 上传 → 验证 → 再告诉用户

---

**⚠️ Flash 替换正则陷阱（2026-05-28 实战发现）：**

替换 Flash 时，正则表达式 `r'<div class="flash">.*?</div>\s*</div>'` 配合 `re.DOTALL` 会匹配过多内容（因为 div 嵌套），导致产品列表和公司介绍全部丢失！

**正确做法：** 使用 `<!-- end of flash -->` 注释作为精确边界：
```python
flash_start = content.find('<div class="flash">')
flash_end = content.find('<!-- end of flash -->', flash_start)
flash_end_full = flash_end + len('<!-- end of flash -->')
new_content = content[:flash_start] + slider_html + '\n    ' + content[flash_end_full:]
```

**替换后必须验证：** `grep -c "category_title\|index_about\|index_product" /tmp/index.html` 应 > 0

**⚠️ 用户明确要求：手机和电脑显示一样！**（但注意：不同会话偏好可能变化，先确认）

用户原话："手机浏览网站效果比例要自动缩放" — 这意味着**不要响应式设计**，要viewport自动缩放。

但也可能在其他会话说"手机端产品是两列" — 这意味着**要响应式设计**。

**正确做法：先问用户手机端想怎么显示。** 详见 `references/css-mobile-responsive-patterns.md`。

**方案A（自动缩放）：**
1. 确保 HTML 有 `<meta name="viewport" content="width=device-width, initial-scale=1.0" />`
2. 删除所有 `@media` 响应式查询（或不添加）
3. 手机浏览器会自动缩放 980px 固定宽度页面，效果和电脑一致

**方案B（响应式2列产品）：** 添加 @media 查询，手机端产品2列，桌面端4列。详见 `references/css-mobile-responsive-patterns.md`。

```bash
# 检查viewport标签
curl -s https://www.shengtuo-tractor.com | grep -i "viewport"
# 如果没有，添加：
sed -i 's/<head>/<head>\n<meta name="viewport" content="width=device-width, initial-scale=1.0" \/>/' /tmp/index.html

# 从 CSS 中删除所有 @media 块（如果存在）
sed -i '/@media/,/^}/d' /tmp/style.css
```

**之前错误做法（已验证失败）：** 添加 @media 响应式查询让手机显示不同布局 → 用户不满（"你为什么什么都不懂！"）。

**移动端"重影"问题的替代方案：**
如果用户报告重影但**不想**改变布局（要手机和电脑一样），问题是固定宽度元素溢出。解决方案：
- 添加 viewport meta 标签让浏览器自动缩放
- 删除 @media 查询保持一致显示
- 不需要响应式布局
## 发截图给用户的注意事项

- 电脑截图和手机截图**不一样**（手机会缩放），不要说"效果一样"
- 分别发电脑和手机截图，让用户自己判断
- 不要替用户说"已经修好了"，让用户确认

## ⚠️ 本会话教训（2026-05-28）

**用户说"你为什么什么都不懂！"的原因：**
1. 我没有先检查HTML结构就写CSS选择器（#index_nav vs #nav）
2. 修完没有验证就说"搞定了"
3. 创建了13+个CSS文件而没有诊断根本原因
4. 发了电脑和手机截图说"效果一样"但实际不一样

**正确流程：**
1. 先检查HTML：`curl -s URL | grep -oE 'id="[^"]*"' | sort -u`
2. 写CSS时选择器必须匹配实际ID/class

---

## ⚠️ 页面加载优化 Pitfalls（2026-05-30）

### Loading Spinner 永不消失
**问题**：`.page-loader` 使用 `window.addEventListener('load')` 隐藏，但 `load` 事件要求**所有外部资源**加载完毕才触发。Google Fonts、Font Awesome 等 CDN 在中国经常加载缓慢或超时，导致 spinner 永远转圈。

**正确做法**：
```javascript
// ❌ 错误：load 事件可能永远不触发
window.addEventListener('load', function() {
    const loader = document.querySelector('.page-loader');
    if (loader) loader.classList.add('loaded');
});

// ✅ 正确：DOMContentLoaded + 超时兜底
function hideLoader() {
    const loader = document.querySelector('.page-loader');
    if (loader) {
        loader.classList.add('loaded');
        setTimeout(() => loader.remove(), 500);
    }
}
document.addEventListener('DOMContentLoaded', () => setTimeout(hideLoader, 200));
setTimeout(hideLoader, 3000); // 3秒强制兜底
window.addEventListener('load', hideLoader);
```

**CSS 兜底**（即使 JS 失败也能自动隐藏）：
```css
@keyframes autoHideLoader {
    0%, 85% { opacity: 1; visibility: visible; }
    100% { opacity: 0; visibility: hidden; pointer-events: none; }
}
.page-loader { animation: autoHideLoader 3s ease forwards; }
```

### 外部字体/图标阻塞渲染
**问题**：Google Fonts、Font Awesome 的 `<link rel="stylesheet">` 是渲染阻塞资源，在中国 CDN 慢时会卡住整个页面。

**正确做法**：异步加载不阻塞渲染：
```html
<!-- ✅ 异步加载 -->
<link href="https://fonts.googleapis.com/css2?family=Roboto..." rel="stylesheet" media="print" onload="this.media='all'">
<noscript><link href="..." rel="stylesheet"></noscript>
<link rel="stylesheet" href=".../font-awesome.css" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href=".../font-awesome.css"></noscript>
```

### CSS 字面量 `\n` 破坏选择器
**问题**：CSS 合并文件中偶尔出现字面量 `\n`（反斜杠+n，不是换行），导致后续选择器被解析错误。例如 `.wa-float-btn` 被解析为 `n .wa-float-btn`，样式完全失效。

**排查方法**：
```bash
cat -A file.css | grep '\\n'  # 检查字面量 \n
sed -n '1720,1725p' file.css | cat -A  # 逐行检查特殊字符
```

**修复**：`sed -i 's/\\n\/\*/\n\/\*/' file.css`

### Bundle 文件必须直接编辑
**问题**：网站使用合并后的 bundle 文件（如 `bundle-v2.min.js`、`bundle-v8.min.css`），修改源文件（如 `b2b-enhance.js`）不会生效。

**流程**：
1. 找到实际加载的 bundle 文件：`grep 'bundle' templates/footer.php templates/header.php`
2. 直接编辑 bundle 文件
3. 更新版本号：`?v=<?= time() ?>` 或手动改时间戳
4. 验证修改生效

### 用户反馈"页面还在显示已删除内容"
**排查顺序**：
1. `curl -s URL | grep '关键词'` — 确认服务器端 HTML 是否真的已删除
2. 如已删除 → **浏览器缓存**，建议用户用无痕模式验证
3. 如未删除 → 检查 PHP opcache：`sudo systemctl reload php8.3-fpm`
4. Cloudflare CDN 缓存：`cache-control: no-store` 已设置，CF 标记为 DYNAMIC 不缓存 HTML
3. 上传后验证：`curl -s URL/css/style.css | head -5`
4. 截图发给用户确认，不要自己说"修好了"

**用户布局偏好（2026-05-28 确认）：**
- 产品栏和 ABOUT US 栏要上移、左边对齐，中间不留空白
- `.index_about { margin-bottom: 0; }`
- `.index_product { margin-top: 0; }`
- `#center { padding: 0; }`

**CSS 间距调整模式：** `references/css-spacing-layout-adjustments.md`
包含：紧贴布局的三层调整（上方底部间距、下方顶部间距、父容器内边距）、常见场景示例、验证方法。

**Float 布局和 Footer 定位调试：** `references/float-layout-footer-debugging.md`
包含：shengtuo-tractor.com 布局结构图、常见 footer 位置问题诊断、浏览器 Console 诊断脚本、CSS 修复模板。

**浮动联系栏移除和 WhatsApp 按钮：** `references/floating-contact-bar-whatsapp.md`
包含：旧浮动联系栏（MSN/QQ/Taobao）移除方法、WhatsApp 浮动按钮 HTML+CSS 代码。

**Footer 一致性模式：** `references/footer-consistency-pattern.md`
包含：子页面 Footer 清理方法、标准 Footer 结构、CSS `.links` 类、验证清单。

## 网站全面重设计流程

当用户明确要求全面重设计（不仅仅是 SEO/美化）时，才使用以下流程：

### 设计模式（工业/B2B 网站）

**Hero 区域：**
- 渐变背景（深色到亮色）
- 动画标题 + 打字效果
- 徽章标签（如 "Trusted by 50+ Countries"）
- 统计数字动画（15+ Years, 50+ Countries）
- 双按钮布局（主 CTA + 次 CTA）

**产品展示：**
- 卡片布局替代表格（更美观）
- 产品图片 + 徽章（Popular/Heavy Duty）
- 规格标签（HP, 4WD, Diesel）
- 特性列表（✓ Easy Operation）
- 双按钮（Get Quote + Learn More）

**信任模块：**
- 客户评价卡片（头像 + 引用 + 公司信息）
- Why Choose Us 特性网格
- 认证徽章（CE, ISO）

**联系区域：**
- 左侧联系信息 + 右侧询价表单
- WhatsApp 浮动按钮（右下角）
- 营业时间显示

### SEO 增强模式

**Schema.org 结构化数据（必须包含）：**
```json
{
  "@type": "Organization",     // 公司信息
  "@type": "WebSite",          // 网站信息
  "@type": "WebPage",          // 页面信息
  "@type": "BreadcrumbList",   // 面包屑导航
  "@type": "Product",          // 产品信息
  "@type": "FAQPage"           // 常见问题
}
```

**hreflang 多语言标签：**
```html
<link rel="alternate" hreflang="en" href="https://example.com/">
<link rel="alternate" hreflang="zh" href="https://example.com/zh/">
<link rel="alternate" hreflang="x-default" href="https://example.com/">
```

**Open Graph 增强：**
```html
<meta property="og:locale:alternate" content="zh_CN">
<meta property="og:site_name" content="Brand Name">
```

### GitHub Pages 完全重设计推送

当进行完全重设计时，可能遇到合并冲突。使用 force push：

```bash
# 1. 尝试正常推送
git push origin master

# 2. 如果被拒绝（有冲突），先 rebase
git pull origin master --rebase

# 3. 如果 rebase 有冲突且是完全重设计，abort 并 force push
git rebase --abort
git push origin master --force
```

⚠️ **注意**：Force push 会覆盖远程的所有更改。只在完全重设计时使用。

### 部署验证

```bash
# GitHub Pages 部署需要 ~5 分钟
# 验证方式：
# 1. 直接访问 GitHub raw 文件
curl https://raw.githubusercontent.com/USER/REPO/master/index.html

# 2. 检查 CNAME 文件
cat CNAME  # 确认域名正确

# 3. 等待后访问网站
# 注意：可能重定向到自定义域名
```