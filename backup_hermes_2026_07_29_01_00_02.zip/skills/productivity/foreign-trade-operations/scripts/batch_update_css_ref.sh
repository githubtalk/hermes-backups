#!/bin/bash
# Batch update CSS reference in all HTML files
# Usage: bash batch_update_css_ref.sh <old_css> <new_css>
# Example: bash batch_update_css_ref.sh style_v7.css style_v8.css

OLD_CSS="${1:-style_v7.css}"
NEW_CSS="${2:-style_v8.css}"
FTP="ftp://shanweituo:C2r3h2q7K3@shanweituo.gotoftp4.com/wwwroot"
UPDATED=0

update_file() {
    local dir=$1
    local id=$2
    local remote="$dir/$id.html"
    local local_file="/tmp/batch_css/$dir/$id.html"
    
    mkdir -p "$(dirname "$local_file")"
    wget -q "$FTP/$remote" -O "$local_file" 2>/dev/null
    
    if [ ! -s "$local_file" ]; then
        return 1
    fi
    
    if grep -q "$OLD_CSS" "$local_file"; then
        sed -i "s/$OLD_CSS/$NEW_CSS/g" "$local_file"
        curl -s -T "$local_file" "$FTP/$remote" --ftp-create-dirs >/dev/null 2>&1
        echo "✅ $remote"
        ((UPDATED++))
    fi
}

# Process all directories
for id in 2 3 6 7 8; do update_file "about" $id; done
for id in $(seq 66 78); do update_file "News" $id; done
for id in 4 5 13; do update_file "download" $id; done
for id in $(seq 31 43); do update_file "cases" $id; done
for id in 58 61 62 64 65 66 68 137 171 172 175 183 224 225 226 227 228 229 230 231 232 233 234 235 236 237 238 239 240 241 242 243 244 245 246 247 248; do update_file "products" $id; done
for id in $(seq 1 15); do update_file "message" $id; done

echo ""
echo "=== DONE ==="
echo "Total updated: $UPDATED"
echo "CSS: $OLD_CSS → $NEW_CSS"
