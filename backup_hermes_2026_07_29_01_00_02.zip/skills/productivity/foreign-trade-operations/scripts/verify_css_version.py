#!/usr/bin/env python3
"""
Verify all pages use the correct CSS file.
Usage: python3 verify_css.py style8.css
"""

import subprocess
import re
import sys

CSS_FILE = sys.argv[1] if len(sys.argv) > 1 else "style5.css"

# Pages to check
PAGES = [
    "/",
    "/products/",
    "/products/58.html",
    "/about/2.html",
    "/News/",
    "/cases/",
    "/download/",
    "/Inquiry/",
    "/message/",
]

def check_page(page):
    result = subprocess.run(
        ['curl', '-s', f'https://www.shengtuo-tractor.com{page}'],
        capture_output=True, text=True
    )
    if CSS_FILE in result.stdout:
        return "✅"
    else:
        # Check what CSS is being used
        match = re.search(r'style\d*\.css', result.stdout)
        found = match.group(0) if match else "未找到"
        return f"❌ (当前: {found})"

print(f"验证所有页面是否使用 {CSS_FILE}:\n")

all_ok = True
for page in PAGES:
    status = check_page(page)
    print(f"{status} {page}")
    if "❌" in status:
        all_ok = False

print(f"\n{'✅ 所有页面已更新' if all_ok else '❌ 部分页面未更新'}")
