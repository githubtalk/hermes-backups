#!/bin/bash
# 批量清理 shengtuo-tractor.com 子页面
# 移除: AddThis, GA, Google+, rightDiv, 空Fax
# 统一: Footer 结构 (Links + 公司信息)
# 用法: bash batch_clean_footer.sh [dir_name]
#   如不指定 dir_name，处理所有目录

FTP="ftp://shanweituo:C2r3h2q7K3@shanweituo.gotoftp4.com/wwwroot"
LOCAL_BASE="/home/ubuntu/website/generated"
UPDATED=0
SKIPPED=0

# 文件 ID 清单
declare -A DIR_IDS
DIR_IDS[about]="2 3 6 7 8"
DIR_IDS[cases]="$(seq 31 43)"
DIR_IDS[download]="4 5 13"
DIR_IDS[News]="$(seq 66 78)"
DIR_IDS[products]="58 61 62 64 65 66 68 137 171 172 175 183 $(seq 224 248)"
DIR_IDS[message]="$(seq 1 15)"

NEW_FOOTER='<div id="footer">
    <div class="links">
        Links：
        <a href='"'"'https://www.instagram.com/shengtuo_tractor'"'"' target='"'"'_blank'"'"'>shengtuo-Tractor Company Video</a> | 
    </div>  
    <div class="copyright">
        <p>SHENGTUO TRACTOR,TRACTOR ,SHENGTUO,TRACTOR,CHINA AGRICULTRUAL MACHINE,CHINA TRACTOR &nbsp;ICP:0232829 &nbsp;<a href="/sitemap.html" target="_blank">Sitemap</a></p>
        <p>Add：Address: No.1008 Huaixu North Road,Changle County,Weifang city, Shandong Province, China &nbsp;Tel：+86-13806461474</p>
    </div>
    <div class="clear"></div>
</div>'

process_page() {
    local dir=$1
    local id=$2
    local remote="$dir/$id.html"
    local local_file="$LOCAL_BASE/$dir/$id.html"
    
    mkdir -p "$(dirname "$local_file")"
    wget -q "$FTP/$remote" -O "$local_file" 2>/dev/null || return 1
    
    python3 - "$local_file" << 'PYEOF'
import re, sys

path = sys.argv[1]
with open(path, 'r', encoding='utf-8-sig') as f:
    content = f.read()
original = content

NEW_FOOTER = '''<div id="footer">
    <div class="links">
        Links：
        <a href='https://www.instagram.com/shengtuo_tractor' target='_blank'>shengtuo-Tractor Company Video</a> | 
    </div>  
    <div class="copyright">
        <p>SHENGTUO TRACTOR,TRACTOR ,SHENGTUO,TRACTOR,CHINA AGRICULTRUAL MACHINE,CHINA TRACTOR &nbsp;ICP:0232829 &nbsp;<a href="/sitemap.html" target="_blank">Sitemap</a></p>
        <p>Add：Address: No.1008 Huaixu North Road,Changle County,Weifang city, Shandong Province, China &nbsp;Tel：+86-13806461474</p>
    </div>
    <div class="clear"></div>
</div>'''

footer_match = re.search(r'<div id="footer">\s*\n', content)
if footer_match:
    footer_start = footer_match.start()
    whatsapp_match = re.search(r'<!-- WhatsApp|<a href="https://wa\.me', content[footer_start:])
    if whatsapp_match:
        clean_start = footer_start + whatsapp_match.start()
        content = content[:footer_start] + NEW_FOOTER + '\n\n' + content[clean_start:]

content = re.sub(r"<div id='rightDiv'[^>]*>.*?</div>\s*</div>\s*</div>\s*</div>\s*", '', content, flags=re.DOTALL)
content = re.sub(r'<!-- Place this tag where you want.*?<script type="text/javascript">\s*\(function\(\).*?</script>\s*', '', content, flags=re.DOTALL)
content = re.sub(r'\s*<li>Fax：</li>\n?', '', content)

with open(path, 'w', encoding='utf-8') as f:
    f.write(content)
print("CHANGED" if content != original else "NOCHANGE")
PYEOF

    local result=$(python3 - "$local_file" << 'PYEOF'
import re, sys
path = sys.argv[1]
with open(path, 'r', encoding='utf-8-sig') as f:
    content = f.read()
original = content
# ... (same cleanup as above)
PYEOF
)
    
    curl -s -T "$local_file" "$FTP/$remote" --ftp-create-dirs >/dev/null 2>&1
    echo "✅ $remote"
    return 0
}

# Main
TARGET_DIR=${1:-"all"}

for dir in "${!DIR_IDS[@]}"; do
    if [ "$TARGET_DIR" != "all" ] && [ "$dir" != "$TARGET_DIR" ]; then
        continue
    fi
    echo "=== Processing $dir/ ==="
    for id in ${DIR_IDS[$dir]}; do
        process_page "$dir" "$id"
    done
done

echo ""
echo "=== DONE ==="
