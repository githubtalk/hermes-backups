# D1 Database & Image Conventions for Shengtuo Website

## Products Table Schema

```sql
CREATE TABLE products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  detailed_description TEXT,
  specifications TEXT,
  image_url TEXT,
  gallery_images TEXT,        -- JSON array of image URLs
  category TEXT,
  is_featured BOOLEAN DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
```

Fields to AVOID (not in schema): `price`, `stock_status`, `stock_quantity`, `unit`.

## Image URL Format

All product images are hosted on shengtuo.cc.cd CDN:

```
https://shengtuo.cc.cd/assets/images/products/product-N-v1780048106.jpg
```

Where N = product number (1-37). The same image URL may be shared by multiple products — this is the source site's actual configuration, not an error.

## Image Extraction Workflow

When syncing products from shengtuo.cc.cd:

1. **Listing page only** — detail pages (e.g., `/products/st504-30-50hp-tractor`) return 404. Use the listing page (`/products`) with `browser_console`:
   ```js
   [...document.querySelectorAll('h3')].map(h => h.textContent.trim())
   [...document.querySelectorAll('img')].map(i => i.src).filter(s => s.includes('product-'))
   ```
2. Map each product name to its image URL by inspecting product cards on the listing page.
3. Run mismatch check: `curl /api/products | python3 -c "..."` comparing DB names → image_url against expected correct mapping.

## CSS Variables (cf-b2b Worker)

```css
:root {
  --primary: #1a7f37;        /* green — use this, NOT --primary-color */
  --primary-dark: #16652e;
  --accent: #e67e22;
  --dark: #1a1a2e;
  --gray-100: #f8f9fa;        /* NOT --bg-light */
  --gray-500: #6c757d;        /* NOT --text-light */
  --gray-900: #212529;        /* NOT --text-dark */
  --radius: 8px;
  --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
}
```

## CSS Class Patterns for Product Pages

```css
/* Image container — use this class for all product cards */
.card-image-wrap {
  height: 220px;
  overflow: hidden;
  background: var(--gray-100);
}
/* Child img element */
.card-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
/* Hover scale */
.card:hover .card-image { transform: scale(1.05); }
```

Image fallback: `https://shengtuo.cc.cd/images/logo.png`

## Wrangler D1 Commands

```bash
# Query
npx wrangler d1 execute b2b_database --command "SELECT ..." --remote

# Execute SQL file
npx wrangler d1 execute b2b_database --file=/tmp/update.sql --remote

# Schema check
npx wrangler d1 execute b2b_database --command "PRAGMA table_info(products)" --remote
```

## Cloudflare Worker Deployment

- Worker name: `cf-b2b-website`
- Account ID: a0e4e66e8ea4dc776e23626f79e70bdf
- D1: `b2b_database` (761a885a-2ce1-43da-9a9f-342affd90bea)
- Deploy: `cd /home/ubuntu/cf_b2b && npx wrangler deploy`

## Product Detail Page Routing

Product detail pages are routed via `router.js`:
- `/products/{id}` → `productDetailPage(request, env)` in `src/pages/product-detail.js`
- `/products` → `productsPage(env)` in `src/pages/products.js`

Both use `createLayout` from `./layout`.

## 500 Error Troubleshooting

1. Check `var()` CSS variables — invalid variable names cause runtime errors in template literals
2. Test with minimal hardcoded HTML before deploying full content
3. Use `curl -sI URL` to check status before inspecting content
4. Products listing page: if 500, check for template literal issues with backtick interpolation in JS

## Known Shared Images (source site default — do not change)

| Image File | Shared By |
|------------|-----------|
| product-3 | ST504 Tractor, ST304 Tractor, ST254 Tractor |
| product-19 | Shengtuo Rotary Tiller, Shengtuo Disc Harrow, Shengtuo Seed Drill, Shengtuo Sprayer |