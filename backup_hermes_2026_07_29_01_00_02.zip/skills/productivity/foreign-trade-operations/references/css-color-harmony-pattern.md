# CSS Color Harmony Pattern

## Problem: CSS Variable Inconsistency

When building a PHP site with multiple CSS files (style, enhance, product-focus, visual), variables referenced in later files may not be defined in the base stylesheet. Browsers silently ignore undefined CSS variables — no errors, no warnings.

**Common mismatch:**
| File defines | Later files reference | Result |
|---|---|---|
| `--primary-color` | `--primary` | ❌ Silent fail |
| `--secondary-color` | `--accent` | ❌ Silent fail |
| *(nothing)* | `--gray-100` to `--gray-900` | ❌ Silent fail |
| *(nothing)* | `--radius-lg`, `--transition` | ❌ Silent fail |

## Solution: Unified Color Harmony CSS

Create a single `color-harmony.css` file that:
1. Defines ALL variables used across ALL CSS files
2. Sets consistent colors for ALL components
3. Loads LAST in header.php (highest override priority)

## 60/30/10 Color Ratio

| Ratio | Role | Colors |
|-------|------|--------|
| 60% | Backgrounds | White `#fff`, Light gray `#f3f4f6` (alternating sections) |
| 30% | Brand primary | Navy blue `#0f2b5b` (nav, buttons, headings, footer) |
| 10% | Accent | Gold `#c8a23c` (badges, icons, hover states, highlights) |

## Complete Variable Definitions

```css
:root {
    /* Brand Primary - Navy Blue */
    --primary: #0f2b5b;
    --primary-light: #1a3a6e;
    --primary-dark: #0a1e3d;
    --primary-color: #0f2b5b;  /* legacy compat */
    
    /* Accent - Gold */
    --accent: #c8a23c;
    --accent-hover: #b8922e;
    --accent-light: rgba(200, 162, 60, 0.12);
    
    /* Semantic Colors */
    --success: #16a34a;
    --danger: #dc2626;
    --warning: #d97706;
    
    /* 10-Level Gray Scale */
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-400: #9ca3af;
    --gray-500: #6b7280;
    --gray-600: #4b5563;
    --gray-700: #374151;
    --gray-800: #1f2937;
    --gray-900: #111827;
    
    /* Legacy Variable Mapping */
    --secondary-color: var(--accent);
    --dark: var(--gray-800);           /* ⚠️ about.php inline styles use var(--dark) */
    --dark-color: var(--gray-800);
    --light-color: var(--gray-100);
    --text-color: var(--gray-700);
    --text-light: var(--gray-500);
    
    /* Border Radius & Transitions */
    --radius: 8px;
    --radius-lg: 14px;
    --transition: 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    
    /* Shadows */
    --shadow: 0 4px 12px rgba(0,0,0,0.08);
    --shadow-lg: 0 12px 40px rgba(0,0,0,0.12);
    --shadow-accent: 0 4px 20px rgba(200,162,60,0.25);
    --shadow-primary: 0 4px 20px rgba(15,43,91,0.2);
}
```

## Section Alternating Pattern

```css
/* White sections */
.category-showcase, .featured-products, .testimonials-section {
    background: var(--white);
}
/* Light gray sections */
.hp-range-section, .latest-news, .company-intro-compact {
    background: var(--gray-50);
}
```

## Component Color Mapping

| Component | Background | Text/Border | Accent |
|-----------|-----------|-------------|--------|
| Top bar | `--primary` | white | — |
| Nav links | white | `--gray-700` | hover: `--primary` |
| Section badge | — | `--accent` | `::after` gold line |
| Product badge (hot) | gradient red | white | — |
| Product badge (popular) | `--accent` gradient | white | — |
| Product badge (best-seller) | `--primary` gradient | white | — |
| HP tag | `rgba(15,43,91,0.92)` | `--accent` | — |
| Hot products strip | `--primary` gradient | white | `--accent` info |
| Trust icon | `--primary` gradient | white | hover: `--accent` |
| CTA strip | `--accent` gradient | white | white button |
| Footer | `--primary-dark` | white | `--accent` headings |
| WhatsApp | `#25D366` | white | hover: `#128C7E` |

## Bootstrap Class Override Pitfall

Footer with Bootstrap `bg-dark` class:
```html
<footer class="bg-dark text-white pt-5 pb-4">
```

Bootstrap sets `background: #212529 !important` for `.bg-dark`. To override:
```css
footer.bg-dark,  /* More specific than .bg-dark */
footer {
    background: var(--primary-dark) !important;
}
```

## Cloudflare Cache Busting

When creating new CSS files behind Cloudflare:
1. Create file with unique name (e.g., `color-harmony.css`)
2. Add `?v=N` query parameter in HTML `<link>` tag
3. Verify with `curl -s URL | md5sum` vs local file

```html
<link href="/assets/css/color-harmony.css?v=2" rel="stylesheet">
```

## ⚠️ Pitfall: White Text on White Background (2026-05-30)

**The #1 danger when changing section backgrounds.**

When color-harmony.css changes a section's background from dark to white, it MUST also override text colors for all child elements. The original CSS was designed for the dark background.

**Real example:**
- `style-v3.css` had `.feature-box h4 { color: var(--white) }` and `.feature-box p { color: rgba(255,255,255,0.8) }` — designed for dark "Why Choose Us" section
- `color-harmony.css` changed `.why-choose-us { background: var(--white) }` and `.feature-box { background: var(--white) }`
- Result: **WHITE TEXT ON WHITE BACKGROUND — completely invisible**

**Fix: ALWAYS override text colors when changing section backgrounds:**
```css
.feature-box h4 { color: var(--gray-800) !important; }
.feature-box p { color: var(--gray-600) !important; }
```

**Systematic check — scan for white text on white bg:**
```javascript
(function(){
    const els = document.querySelectorAll('h1,h2,h3,h4,h5,h6,p,span,a');
    const issues = [];
    els.forEach(el => {
        const cs = getComputedStyle(el);
        const color = cs.color;
        const bg = cs.backgroundColor;
        // Parse rgb values
        const cm = color.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
        const bm = bg.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
        if (cm && bm) {
            const [cr,cg,cb] = [parseInt(cm[1]),parseInt(cm[2]),parseInt(cm[3])];
            const [br,bg2,bb] = [parseInt(bm[1]),parseInt(bm[2]),parseInt(bm[3])];
            if (cr>240 && cg>240 && cb>240 && br>240 && bg2>240 && bb>240) {
                issues.push(el.tagName + ': ' + el.textContent.substring(0,30));
            }
        }
    });
    console.log(issues.length ? '❌ White-on-white: ' + issues.join(', ') : '✅ No white-on-white issues');
})();
```

**Checklist when changing ANY section background:**
1. Identify ALL text elements inside that section (h2, h3, h4, p, span, a, li)
2. Check their current computed `color` values
3. If background goes from dark→light, text must go from light→dark
4. Add `!important` overrides in the overlay CSS file
5. Verify with the scan script above

## ⚠️ Pitfall: Reveal Animation Opacity: 0 Fallback

**Problem:** `.reveal` elements start with `opacity: 0` and rely on JS `IntersectionObserver` to add `.revealed` class. If JS fails to execute, ALL content stays invisible.

**Symptoms:** User reports "fonts not displaying" or "content covered by colors" — but actually the content has `opacity: 0`.

**Diagnosis:**
```javascript
const reveals = document.querySelectorAll('.reveal');
const revealed = document.querySelectorAll('.reveal.revealed');
console.log('Total reveals:', reveals.length, 'Revealed:', revealed.length);
// If revealed = 0 after page load, JS isn't working
```

**Fix — CSS animation fallback (add to color-harmony.css):**
```css
/* Reveal fallback — content visible even if JS fails */
@keyframes reveal-fallback {
    to { opacity: 1; transform: translateY(0) translateX(0) scale(1); }
}
.reveal {
    animation: reveal-fallback 0.01s 2s forwards;
}
.reveal.revealed {
    animation: none;  /* JS is working, let CSS .revealed rule take over */
}
```

**How it works:**
- Normal case: JS fires IntersectionObserver → adds `.revealed` → CSS `opacity: 1` → animation cancelled
- JS fails: After 2 seconds, CSS animation kicks in → `opacity: 1` → content becomes visible
- No visual flash: The 2s delay is long enough for JS to fire normally

## ⚠️ Pitfall: `var(--dark)` vs `var(--dark-color)` (2026-05-30)

PHP pages (especially about.php) use inline styles with `var(--dark)` for icon backgrounds and badge colors. But the base `style-v3.css` only defines `--dark-color`, not `--dark`. These are **different variables** — `var(--dark)` resolves to nothing.

**Fix:** Add `--dark: var(--gray-800);` to the legacy mapping section.

**Scan for undefined variable usage in inline styles:**
```bash
grep -rn 'var(--dark)' /path/to/website/ --include="*.php" | grep -v 'var(--dark-color)'
```

## Debugging Workflow (Step by Step)

When user reports "text not showing" or "colors wrong":

1. **Check CSS variable definitions** — browser console:
   ```js
   const s = getComputedStyle(document.documentElement);
   ['--primary','--accent','--dark','--gray-100'].forEach(v =>
       console.log(v, '=', s.getPropertyValue(v).trim() || '❌ UNDEFINED'));
   ```

2. **Check element computed colors** — are text and bg the same?
   ```js
   document.querySelectorAll('.feature-box h4').forEach(el => {
       const cs = getComputedStyle(el);
       console.log(el.textContent.trim(), 'color:', cs.color, 'bg:', cs.backgroundColor);
   });
   ```

3. **Check reveal animation state**:
   ```js
   console.log('reveals:', document.querySelectorAll('.reveal').length,
               'visible:', document.querySelectorAll('.reveal.revealed').length);
   ```

4. **Check footer Bootstrap override**:
   ```js
   const f = document.querySelector('footer');
   console.log('footer bg:', getComputedStyle(f).backgroundColor,
               'classes:', f.className);
   ```

5. **Check Cloudflare serving latest CSS**:
   ```bash
   curl -sI "https://site/assets/css/color-harmony.css?v=N" | grep -E 'cf-cache-status|age'
   ```

## Combined "Invisible Text" Diagnosis

When user reports "text not showing" or "fonts covered by colors", there are **two root causes** — check both:

| Cause | Diagnosis | Fix |
|-------|-----------|-----|
| White text on white bg | `color: rgb(255,255,255)` + `bg: rgb(255,255,255)` | Override text color to dark |
| Reveal opacity: 0 | `.reveal` elements with `opacity: 0`, JS not triggered | CSS animation fallback |

**Quick combined check:**
```javascript
(function(){
    const issues = [];
    // Check 1: opacity:0 elements
    document.querySelectorAll('.reveal').forEach(el => {
        if (getComputedStyle(el).opacity === '0')
            issues.push('OPACITY:0 ' + el.tagName + ' ' + el.textContent.substring(0,30));
    });
    // Check 2: white-on-white text
    document.querySelectorAll('h1,h2,h3,h4,h5,h6,p').forEach(el => {
        const cs = getComputedStyle(el);
        const cm = cs.color.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
        const bm = cs.backgroundColor.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
        if (cm && bm && parseInt(cm[1])>240 && parseInt(bm[1])>240)
            issues.push('WHITE-ON-WHITE ' + el.tagName + ': ' + el.textContent.substring(0,30));
    });
    console.log(issues.length ? '❌ ' + issues.join('\n') : '✅ All text visible');
})();
```

## Verification

```javascript
// Browser Console - verify all variables defined
(function(){
    const s = getComputedStyle(document.documentElement);
    const vars = ['--primary', '--accent', '--gray-100', '--success', '--radius-lg'];
    const results = {};
    vars.forEach(v => {
        results[v] = s.getPropertyValue(v).trim() || '❌ UNDEFINED';
    });
    return JSON.stringify(results, null, 2);
})();

// Verify specific elements
(function(){
    const checks = {
        topbar: getComputedStyle(document.querySelector('.top-bar')).backgroundColor,
        footer: getComputedStyle(document.querySelector('footer')).backgroundColor,
        badge: getComputedStyle(document.querySelector('.section-badge')).color,
    };
    return JSON.stringify(checks);
})();
```
