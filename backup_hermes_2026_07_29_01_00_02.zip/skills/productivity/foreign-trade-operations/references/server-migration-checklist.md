# Server Migration Checklist for PHP/Nginx Sites

## Pre-Migration
1. Create backup: database dump + file archive
2. Verify backup integrity (check file count, DB record counts)
3. Document all Nginx location blocks from source server

## Migration Steps

### 1. Transfer Files
```bash
# From source server
mysqldump -uUSER -pPASS DBNAME > /tmp/database.sql
tar -czf /tmp/site-backup.tar.gz --exclude='logs/*.log' -C /parent site-dir

# Transfer to target
scp -i KEY /tmp/site-backup.tar.gz user@target:/tmp/
scp -i KEY /tmp/database.sql user@target:/tmp/
```

### 2. Install Dependencies on Target
```bash
sudo apt-get update
sudo apt-get install -y nginx mysql-server php-fpm php-mysql php-curl php-gd php-mbstring php-xml php-zip php-intl php-bcmath
```

### 3. Extract and Configure
```bash
sudo mkdir -p /var/www/site
cd /tmp && tar -xzf site-backup.tar.gz
sudo cp -r site/* /var/www/site/

# Import database
sudo mysql -e "CREATE DATABASE dbname CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
sudo mysql -e "CREATE USER 'user'@'localhost' IDENTIFIED BY 'pass';"
sudo mysql -e "GRANT ALL ON dbname.* TO 'user'@'localhost';"
mysql -uuser -ppass dbname < database.sql
```

### 4. Set Permissions
```bash
sudo chown -R www-data:www-data /var/www/site
sudo chmod -R 755 /var/www/site
sudo chmod -R 775 /var/www/site/uploads /var/www/site/logs /var/www/site/assets/images
```

### 5. Configure Nginx
**CRITICAL: Copy the FULL Nginx config from source server, not a minimal one.**
Missing location blocks = all pages show homepage.

```bash
# Get config from source
ssh -i KEY user@source "cat /etc/nginx/sites-available/site-config" > /tmp/nginx.conf
# Edit server_name and paths
sudo cp /tmp/nginx.conf /etc/nginx/sites-available/site
sudo ln -sf /etc/nginx/sites-available/site /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

### 6. Update Site Config
```bash
sudo sed -i "s|define('DB_PASSWORD'.*|define('DB_PASSWORD', 'newpass');|" /var/www/site/config/database.php
sudo sed -i "s|define('SITE_URL'.*|define('SITE_URL', 'https://newdomain');|" /var/www/site/config/database.php
```

### 7. Verify
```bash
# Test all pages return different content
for url in "/" "/products" "/about" "/contact"; do
    title=$(curl -s "http://target${url}" | grep -o "<title>[^<]*" | head -1)
    echo "$url → $title"
done

# Test API endpoints
curl -s -X POST "http://target/api/inquiry.php" -H "Content-Type: application/json" \
  -d '{"name":"test","email":"t@t.com","message":"test"}'
```

## Pitfalls
- **MySQL on micro instances**: Do NOT set `innodb_flush_method=O_DIRECT` — causes crash
- **tar exclude flags**: Must come BEFORE source paths: `tar -czf out.tar.gz --exclude='x' -C dir src`
- **PHP version**: Check exact version (8.1/8.2/8.3) — socket path differs
- **Session directory**: Ensure `/var/lib/php/sessions` is writable by www-data
- **Rate limiting**: Login attempts file needs writable logs directory
