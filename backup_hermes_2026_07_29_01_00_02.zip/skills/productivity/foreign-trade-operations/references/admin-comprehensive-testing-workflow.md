# Admin Comprehensive Testing Workflow

## Systematic Admin Page Test (curl-based)

```bash
# Login and get session cookie
curl -s -c /tmp/admin_test.txt -X POST https://SITE/admin/login.php \
  -d 'username=admin&password=PASS' -L > /dev/null

# Test all admin pages for HTTP status + PHP errors
for page in index.php products.php product-edit.php?id=1 categories.php \
  news.php news.php?action=edit&id=1 news.php?action=create \
  sliders.php messages.php inquiries.php pages.php settings.php seo-checker.php; do
    content=$(curl -s -b /tmp/admin_test.txt "https://SITE/admin/$page" 2>&1)
    status=$(curl -s -b /tmp/admin_test.txt -o /dev/null -w "%{http_code}" "https://SITE/admin/$page")
    php_err=$(echo "$content" | grep -oP '<b>(Warning|Fatal error|Parse error|Notice|Deprecated|Uncaught)</b>')
    if [ -n "$php_err" ]; then
        echo "❌ $page: HTTP $status — $php_err"
    else
        echo "✅ $page: HTTP $status"
    fi
done
```

## Language Switch Test

```bash
# Test EN
curl -s -b /tmp/admin_test.txt -c /tmp/admin_test.txt \
  -L 'https://SITE/admin/settings.php?lang=en' | grep -o "Settings\|Domain\|Contact"
# Should return English words

# Test ZH
curl -s -b /tmp/admin_test.txt -c /tmp/admin_test.txt \
  -L 'https://SITE/admin/settings.php?lang=zh' | grep -o "系统设置\|域名\|联系"
# Should return Chinese words
```

## Settings Save Test (with CSRF)

```bash
# Get CSRF token
csrf=$(curl -s -b /tmp/admin_test.txt 'https://SITE/admin/settings.php' | \
  grep -oP 'name="csrf_token"\s+value="\K[^"]+')

# POST save
curl -s -b /tmp/admin_test.txt -X POST 'https://SITE/admin/settings.php' \
  -d "csrf_token=$csrf&site_title=Test&save=1" -L | grep -o 'alert-success\|Settings saved'
```

## Frontend + API Full Test

```bash
# All frontend pages
for page in / /products /about /contact /news /export /search /why-us \
  /product/SLUG /products?category=CAT /products?hp=50-80 \
  /news/SLUG /sitemap.xml /robots.txt; do
    code=$(curl -sI -o /dev/null -w "%{http_code}" "https://SITE$page")
    echo "${page}: ${code}"
done

# API endpoints
curl -s -o /dev/null -w "%{http_code}" 'https://SITE/api/products.php?page=1&limit=4'
# POST-only endpoints return 405 on GET — that's correct behavior
curl -s -o /dev/null -w "%{http_code}" -X POST 'https://SITE/api/message.php' -d "name=Test"
curl -s -o /dev/null -w "%{http_code}" -X POST 'https://SITE/api/inquiry.php' -d "name=Test"
```

## Nginx Error Log Check (Ultimate Truth)

```bash
# Clear log before test
sudo truncate -s 0 /var/log/nginx/SITE-error.log

# Run all tests...

# Check for new PHP errors
cat /var/log/nginx/SITE-error.log | grep -c "PHP Warning\|PHP Fatal"
# Should be 0
```

## Common Admin Bugs Found in Testing

| Bug | Detection | Fix |
|-----|-----------|-----|
| Duplicate HTML structure | `grep -c "<!DOCTYPE" admin/*.php` > 0 for pages using auth.php | Remove duplicate `<html>/<body>` after `require auth.php` |
| Null array access in create mode | Nginx log: "Trying to access array offset on null" | Use `$var['key'] ?? $_POST['key'] ?? ''` |
| Missing sidebar.php include | Nginx log: "Failed to open stream: sidebar.php" | Remove include (auth.php provides sidebar) |
| Logs directory permission | Nginx log: "Permission denied" in functions.php | `chmod 777 logs/` or `chown www-data` |
| CSRF token mismatch | POST returns 200 but DB unchanged | Use same cookie jar for GET (token) and POST (submit) |
| Broken CSS symlink | `wc -c` returns 0, nginx serves HTML | `rm` the broken symlink |
