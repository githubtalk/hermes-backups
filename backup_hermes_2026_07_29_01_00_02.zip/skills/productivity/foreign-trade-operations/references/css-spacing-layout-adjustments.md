# CSS 间距与布局调整模式

## 紧贴布局（无间距）

当用户要求"紧贴"、"靠着"、"不留空白"时，需要同时调整三个层面：

### 1. 上方元素底部间距
```css
上方元素 {
    margin-bottom: 0;
}
```

### 2. 下方元素顶部间距
```css
下方元素 {
    margin-top: 0;
}
```

### 3. 父容器内边距
```css
父容器 {
    padding: 0;
}
```

## 常见场景

### 场景 1：轮播栏下方紧贴内容区
```css
.flash { margin-bottom: 0; }
.index_about { margin-top: 0; }
#center { padding: 0; }
```

### 场景 2：产品栏与 ABOUT US 栏对齐
```css
.index_about { margin-bottom: 0; }
.index_product { margin-top: 0; }
#center { padding: 0; }
```

### 场景 3：导航栏紧贴轮播栏
```css
#index_nav { margin-bottom: 0; }
.flash { margin-top: 0; }
```

## 关键点

1. **只调整间距**：不要改变宽度、高度、布局方式等其他属性
2. **检查父容器**：确保父容器没有内边距（padding）或外边距（margin）
3. **保留原装尺寸**：宽度 980px、轮播高度 373px、头部高度 136px 等不要改变
4. **移动端适配**：调整间距后需要检查移动端是否正常

## 验证方法

```bash
# 检查元素间距
curl -s https://www.example.com | grep -A5 "class=\"flash\""
curl -s https://www.example.com | grep -A5 "class=\"index_about\""

# 浏览器验证
# 打开开发者工具，检查 computed style 中的 margin/padding 值
```

## 常见陷阱

1. **漏掉父容器**：只调整子元素间距，但父容器有 padding，效果不明显
2. **CSS 优先级**：原样式可能有 !important，需要更高优先级覆盖
3. **浏览器缓存**：修改后需强制刷新（Ctrl+F5）
4. **Cloudflare 缓存**：需要使用新 CSS 文件名绕过

## 完整示例

```css
/* 原装布局 + ABOUT US 紧贴轮播栏 */
.flash {
    margin-bottom: 0;  /* 去掉底部间距 */
}

.index_about {
    margin-top: 0;  /* 去掉顶部间距 */
    margin-bottom: 0;
}

#center {
    padding: 0;  /* 去掉内边距 */
}
```

---

## PHP 站 Section 间距压缩（sub.aiv.qzz.io）

当用户说"板块上移"、"页面紧凑"、"间距太大"时，需要同时调整 **index.php 内联样式** 和 **bundle CSS**。

### 标准 Section Padding
| 元素 | 默认值 | 紧凑值 |
|------|--------|--------|
| Section padding | 4.5rem 0 | 3rem 0 |
| 较小 section | 4rem 0 | 2.5rem 0 |
| section-title margin-bottom | 2rem | 1.25rem |
| product-tabs margin-bottom | 2.5rem | 1.5rem |
| partner-section | 3rem 0 | 2.5rem 0 |

### 批量修改命令
```bash
# index.php — 内联样式
sed -i 's/padding:4\.5rem 0/padding:3rem 0/g' index.php
sed -i 's/padding:4rem 0/padding:2.5rem 0/g' index.php

# bundle CSS
sed -i 's/padding: 5rem 0;/padding: 3rem 0;/g' bundle-v8.min.css
sed -i 's/padding: 4rem 0;/padding: 2.5rem 0;/g' bundle-v8.min.css
sed -i 's/padding: 4rem 0 !important;/padding: 2.5rem 0 !important;/g' bundle-v8.min.css
sed -i 's/padding: 5rem 0 !important;/padding: 3rem 0 !important;/g' bundle-v8.min.css
sed -i 's/padding: 4rem 0 2rem;/padding: 2.5rem 0 1.5rem;/g' bundle-v8.min.css
sed -i 's/padding: 4rem 0 0;/padding: 2.5rem 0 0;/g' bundle-v8.min.css
```

### 验证
```bash
# 确认没有遗漏的大间距
grep -c 'padding: 4rem\|padding: 5rem' bundle-v8.min.css  # 应返回 0
grep -c 'padding:4\.5rem\|padding:4rem' index.php  # 应返回 0
```

### 注意事项
- 压缩后总页面长度减少约 30%，各板块视觉节奏更紧凑
- 移动端需要同步检查，必要时在 media query 中单独调整
- 不要压缩 hero-slider 和 footer 的间距（保持视觉层次）
