# Image-to-CSS Color Extraction

When the user provides a reference image (screenshot, design mockup, or website screenshot) and says "这个样式" (this style) or "参考这个" (reference this), extract the color palette and generate CSS.

## When to Use

- User sends an image and wants the website styled like it
- `browser_vision` is unavailable or fails (provider not configured)
- User says "按这个图片的风格" or similar

## Step 1: Analyze Image Colors

```python
from PIL import Image
import collections

img = Image.open('/path/to/image.jpg')
img = img.resize((100, 100))  # Downsample for speed
pixels = list(img.getdata())
counter = collections.Counter(pixels)
top_colors = counter.most_common(10)

for color, count in top_colors:
    hex_color = '#{:02x}{:02x}{:02x}'.format(*color)
    print(f"  {hex_color} - RGB{color} - {count} pixels")
```

## Step 2: Analyze Regional Colors

```python
import numpy as np

arr = np.array(img)
h, w = arr.shape[:2]

# Header area (top 25%)
top = arr[:h//4]
print(f"Header avg: RGB{top.mean(axis=(0,1)).astype(int)}")

# Content area (middle 50%)
mid = arr[h//4:3*h//4]
print(f"Content avg: RGB{mid.mean(axis=(0,1)).astype(int)}")

# Footer area (bottom 25%)
bot = arr[3*h//4:]
print(f"Footer avg: RGB{bot.mean(axis=(0,1)).astype(int)}")

# Row-by-row bands (8 bands)
for i in range(0, h, h//8):
    band = arr[i:i+h//8]
    avg = band.mean(axis=(0,1)).astype(int)
    print(f"  Row {i}-{i+h//8}: RGB({avg[0]}, {avg[1]}, {avg[2]})")
```

## Step 3: Map Colors to CSS

Based on the analysis, create CSS overrides:

| Image Region | CSS Target | Example |
|-------------|-----------|---------|
| Header avg color | `#header` background | `background: linear-gradient(135deg, #5B9BD5 0%, #76A7C7 100%)` |
| Nav bar color | `#nav` background | `background: linear-gradient(135deg, #4A8CC7 0%, #5B9BD5 100%)` |
| Content bg | `body` background | `background: #F5F5F5` |
| Main content | `#main` background | `background: #FFFFFF` |
| Footer color | `#footer` background | `background: linear-gradient(135deg, #2C3E50 0%, #34495E 100%)` |

## Step 4: Generate CSS with Gradients

```css
/* Generated from reference image analysis */
body {
    background: linear-gradient(180deg, [HEADER_COLOR] 0%, [CONTENT_COLOR] 30%) !important;
    background-attachment: fixed !important;
}

#header {
    background: linear-gradient(135deg, [HEADER_DARK] 0%, [HEADER_LIGHT] 100%) !important;
}

#nav {
    background: linear-gradient(135deg, [NAV_DARK] 0%, [NAV_LIGHT] 100%) !important;
    position: sticky !important;
    top: 0 !important;
}

#main {
    background: #FFFFFF !important;
    box-shadow: 0 0 30px rgba(0,0,0,0.08) !important;
}

#footer {
    background: linear-gradient(135deg, [FOOTER_DARK] 0%, [FOOTER_LIGHT] 100%) !important;
}
```

## Step 5: Apply via Direct CSS Modification

For shengtuo-tractor.com (FTP-based):

```bash
# 1. Download CSS
curl -s -u "USER:PASS" ftp://HOST/wwwroot/css/style.css -o /tmp/style.css

# 2. Append generated styles to end of CSS file

# 3. Upload
curl -T /tmp/style.css -u "USER:PASS" ftp://HOST/wwwroot/css/style.css

# 4. Update version for cache bust
sed -i 's|css/style.css?v=[0-9]*|css/style.css?v=YYYYMMDDNN|' /tmp/index.html
curl -T /tmp/index.html -u "USER:PASS" ftp://HOST/wwwroot/index.html
```

## Fallback: When browser_vision Fails

If `browser_vision` returns "No LLM provider configured for task=vision":
1. Use PIL color extraction (above) instead
2. Extract dominant colors per region
3. Map to CSS properties
4. User can verify via screenshot comparison

## ⚠️ Pitfall: background-image 覆盖 background-color

当原 CSS 已有 `background-image: url(../images/bg.jpg)` 时，设置 `background-color` **不会生效**（图片覆盖颜色）。

**解决方案：**
1. 替换背景图片文件本身（上传新的 bg.jpg 为目标颜色的纯色图）
2. 或在 CSS 中移除 `background-image`：`background-image: none !important;`

```bash
# 用 PIL 创建纯色背景图
python3 -c "
from PIL import Image
img = Image.new('RGB', (1920, 200), (117, 165, 193))  # #75a5c1
img.save('/tmp/bg.jpg', quality=95)
"
curl -T /tmp/bg.jpg -u "USER:PASS" ftp://HOST/wwwroot/images/bg.jpg
```

## Example: Steel Blue Theme from Reference Image

User provided image with:
- Header: RGB(118, 167, 199) → `#76A7C7` (steel blue)
- Content: RGB(224, 225, 224) → `#E0E0E0` (light gray)
- Footer: RGB(131, 131, 127) → `#83837F` (dark gray)

Generated CSS:
```css
body { background: linear-gradient(180deg, #76A7C7 0%, #F5F5F5 30%) !important; }
#header { background: linear-gradient(135deg, #5B9BD5 0%, #76A7C7 100%) !important; }
#nav { background: linear-gradient(135deg, #4A8CC7 0%, #5B9BD5 100%) !important; }
#footer { background: linear-gradient(135deg, #2C3E50 0%, #34495E 100%) !important; }
```
