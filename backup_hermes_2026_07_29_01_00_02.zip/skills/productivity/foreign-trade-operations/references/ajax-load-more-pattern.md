# AJAX "Load More" Product Loading Pattern

## When to Use
- 首页展示大量产品但不想一次性加载全部
- 用户点击"Load More"按钮动态加载下一批产品
- 需要分页但不想刷新页面

## Architecture

```
index.php (前端)
  ↓ fetch('/api/products.php?page=2&limit=8')
api/products.php (后端API)
  ↓ JSON response
index.php (JS插入DOM)
```

## Backend: api/products.php

```php
<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

try {
    $db = getDBConnection();  // 必须调用！config/database.php导出的是函数
    
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $limit = isset($_GET['limit']) ? min(50, max(1, intval($_GET['limit']))) : 8;
    $check = isset($_GET['check']) && $_GET['check'] === 'true';
    $offset = ($page - 1) * $limit;
    
    // Count total
    $totalStmt = $db->query("SELECT COUNT(*) as total FROM products WHERE is_active = 1 AND is_featured = 1");
    $total = $totalStmt->fetch()['total'];
    
    // Check-only mode (for initial "has more?" check)
    if ($check) {
        echo json_encode([
            'hasMore' => ($offset + $limit) < $total,
            'total' => $total
        ]);
        exit;
    }
    
    // Fetch products with pagination
    $stmt = $db->prepare("
        SELECT p.*, c.name as category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        WHERE p.is_active = 1 AND p.is_featured = 1 
        ORDER BY p.sort_order 
        LIMIT :limit OFFSET :offset
    ");
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $products = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'products' => $products,
        'hasMore' => ($offset + $limit) < $total,
        'total' => $total,
        'page' => $page,
        'showing' => count($products)
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
```

## Nginx Route

```nginx
# API endpoints
location /api/ {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    include fastcgi_params;
}
```

## Frontend: JavaScript

```javascript
let currentPage = 1;
const productsPerPage = 8;
let isLoading = false;

function loadMoreProducts() {
    if (isLoading) return;
    isLoading = true;
    currentPage++;
    
    const btn = document.getElementById('loadMoreBtn');
    const spinner = document.getElementById('loadingSpinner');
    const productGrid = document.querySelector('.featured-products .row.g-4');
    
    btn.style.display = 'none';
    spinner.style.display = 'block';
    
    fetch(`/api/products.php?page=${currentPage}&limit=${productsPerPage}`)
        .then(response => response.json())
        .then(data => {
            if (data.products && data.products.length > 0) {
                data.products.forEach((product, index) => {
                    productGrid.insertAdjacentHTML('beforeend', createProductCard(product, index));
                });
                initRevealAnimations();  // Re-init scroll animations
                btn.style.display = data.hasMore ? 'inline-block' : 'none';
            } else {
                btn.style.display = 'none';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            btn.style.display = 'inline-block';
        })
        .finally(() => {
            isLoading = false;
            spinner.style.display = 'none';
        });
}

function createProductCard(product, index) {
    return `
        <div class="col-lg-3 col-md-6 product-item">
            <div class="product-card h-100">
                <div class="product-image">
                    ${product.horsepower && product.horsepower !== 'N/A' ? 
                        `<span class="product-hp-tag"><i class="fas fa-bolt"></i> ${product.horsepower}</span>` : ''}
                    <img src="${product.image}" alt="${product.name}" loading="lazy">
                    <div class="product-quick-actions">
                        <a href="/product/${product.slug}" class="btn btn-primary btn-sm">Details</a>
                        <a href="https://wa.me/8613806461474?text=${encodeURIComponent('Interested in ' + product.name)}" 
                           class="btn btn-success btn-sm" target="_blank">
                            <i class="fab fa-whatsapp"></i>
                        </a>
                    </div>
                </div>
                <div class="product-info">
                    <h5>${product.name}</h5>
                    <p class="text-muted">${product.model || ''}</p>
                </div>
            </div>
        </div>
    `;
}

// Initial check: hide button if no more products
document.addEventListener('DOMContentLoaded', function() {
    fetch(`/api/products.php?page=2&limit=${productsPerPage}&check=true`)
        .then(r => r.json())
        .then(data => {
            if (!data.hasMore) document.getElementById('loadMoreBtn').style.display = 'none';
        })
        .catch(() => {});
});
```

## HTML Structure

```html
<div class="row g-4">
    <!-- Initial products rendered by PHP -->
    <?php foreach ($featuredProducts as $product): ?>
    <div class="col-lg-3 col-md-6 product-item">...</div>
    <?php endforeach; ?>
</div>

<div class="text-center mt-4">
    <button id="loadMoreBtn" class="btn btn-outline-primary btn-lg" onclick="loadMoreProducts()">
        <i class="fas fa-plus-circle me-2"></i>Load More Products
    </button>
    <a href="/products" class="btn btn-primary btn-lg">
        View All <?= count($allProducts) ?> Products
    </a>
</div>

<div id="loadingSpinner" class="text-center mt-3" style="display:none;">
    <div class="spinner-border text-primary" role="status"></div>
    <p class="mt-2 text-muted">Loading more products...</p>
</div>
```

## Pitfalls

1. **必须调用 `getDBConnection()`** — `config/database.php` 导出函数不是变量
2. **`LIMIT/OFFSET` 必须用 `bindValue` with `PDO::PARAM_INT`** — 否则SQL injection风险
3. **SEO类用 `status=1` 但数据库是 `is_active=1`** — 必须修复includes/seo.php
4. **`createProductCard` 中的 WhatsApp 链接** — `encodeURIComponent` 需要正确转义单引号
5. **DOM 插入后需要重新初始化动画** — `insertAdjacentHTML` 后新元素没有 `.reveal` 类触发
