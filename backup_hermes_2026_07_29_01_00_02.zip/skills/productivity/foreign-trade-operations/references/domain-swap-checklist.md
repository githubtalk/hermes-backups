# Domain Swap Checklist (sub.aiv.qzz.io → shengtuo.cc.cd)

## Files to update

All references to old domain → new domain:
- `sitemap.xml` — all <loc> URLs
- `robots.txt` — Sitemap: directive
- `config/database.php` — default SITE_URL constant
- MySQL: `settings` table, key=`site_url`
- Any static .html/.php files with hardcoded canonical/og:url meta tags

```bash
# Quick replace (verify before running)
sed -i 's|https://old-domain\.com|https://new-domain.com|g' \
  /home/ubuntu/shengtuo-website/sitemap.xml \
  /home/ubuntu/shengtuo-website/robots.txt \
  /home/ubuntu/shengtuo-website/config/database.php

# MySQL update
mysql -u shengtuo -pShengTuo2026! -e \
  "UPDATE shengtuo_website.settings SET setting_value='https://new-domain.com' WHERE setting_key='site_url';"
```

## Nginx config

- Use `curl -H "Host: domain.com" http://127.0.0.1` to test nginx routing **before** DNS propagates.
- Both domains on same nginx server block? Use separate `server_name` directives.
- When swapping domains between sites (old site → new site on same server):
  - Point old domain to old site root
  - Point new domain to new site root
  - Reload nginx: `sudo nginx -s reload`

## Cloudflare DNS (critical)

**Symptom**: New domain returns different content than expected, even though DNS looks correct.

**Root cause**: Cloudflare can route different proxied domains to different origin servers, even when DNS A records show the same IP. This happens because:
- Cloudflare uses internal Anycast routing
- Different domain configurations (different Cloudflare accounts, different CDN settings, cached redirects)
- Workers/Page Rules can intercept and redirect

**Debug steps**:
```bash
# Compare SSL certs from Cloudflare edge
echo | openssl s_client -connect new-domain.com:443 -servername new-domain.com 2>/dev/null | openssl x509 -noout -issuer
echo | openssl s_client -connect old-domain.com:443 -servername old-domain.com 2>/dev/null | openssl x509 -noout -issuer

# Compare IPs resolved
dig +short new-domain.com
dig +short old-domain.com

# Test origin directly (bypass Cloudflare)
curl -s -H "Host: new-domain.com" http://ORIGIN_SERVER_IP | head -5
```

**Fix**: Cloudflare Dashboard → DNS → Records → verify A record points to correct origin. Purge Cloudflare cache (Caching → Configuration → Purge Everything).