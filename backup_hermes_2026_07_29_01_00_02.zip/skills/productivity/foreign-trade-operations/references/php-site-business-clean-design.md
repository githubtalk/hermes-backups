# PHP Site Business-Clean CSS Design System (sub.aiv.qzz.io)

## Color Scheme (2026-05-29 Verified)

```css
:root {
    --primary: #0F2B5B;        /* Deep navy - headers, nav, CTA */
    --primary-light: #1a3d7a;  /* Hover state */
    --accent: #D4A843;         /* Gold - badges, icons, highlights */
    --accent-hover: #c49a2f;   /* Gold hover */
    --dark: #0a1628;           /* Darkest - footer, top bar */
    --gray-900: #111827;       /* Headings */
    --gray-700: #374151;       /* Body text */
    --gray-500: #6b7280;       /* Subtle text */
    --gray-300: #d1d5db;       /* Borders */
    --gray-100: #f3f4f6;       /* Light backgrounds */
    --success: #059669;        /* Checkmarks */
    --whatsapp: #25D366;       /* WhatsApp button */
}
```

## Key CSS Patterns

### Section Badge (category label above title)
```css
.section-badge {
    display: inline-block;
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 3px;
    color: var(--accent);
    margin-bottom: 0.75rem;
}
```
Usage: `<span class="section-badge">About Us</span>`

### Stats Banner (dark gradient with gold numbers)
```css
.stats-banner {
    background: linear-gradient(135deg, var(--primary), var(--dark));
    padding: 4rem 0;
}
.stat-number {
    font-size: 3rem;
    font-weight: 800;
    color: var(--accent);
}
.stat-label {
    font-size: 0.9rem;
    color: rgba(255,255,255,0.7);
    text-transform: uppercase;
    letter-spacing: 2px;
}
```

### Feature Boxes (icon + title + description)
```css
.feature-box .icon-wrapper {
    width: 70px; height: 70px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--accent), var(--accent-hover));
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 1.5rem;
}
```

### Product Cards
- Background: white, border-radius: 16px
- Image: `object-fit: contain` with padding (not `cover` — shows full tractor)
- Hover: overlay with blue-gold gradient
- Shadow progression: sm → xl on hover

### Button Hierarchy
- `btn-primary`: Deep navy background
- `btn-accent`: Gold background (primary CTA)
- `btn-outline-primary`: Navy border, transparent bg
- `btn-outline-light`: White border (on dark backgrounds)
- All buttons: 2px border, `border-radius: 8px`, hover lifts -2px with shadow

### Navigation
- `position: sticky; top: 0`
- `box-shadow: 0 2px 20px rgba(0,0,0,0.06)`
- Nav links: uppercase, letter-spacing 1.5px, gold underline on hover (::after pseudo-element)

## Homepage Sections Order (PHP template)

**⚠️ 2026-05-30 Updated to product-focused layout.** See `references/product-focused-homepage-pattern.md` for the new pattern.

New order (products dominate first scroll):
1. Hero Slider (with Browse Products + Get Quote buttons)
2. Category Cards (browse by category with product counts)
3. HP Range Showcase (4 horsepower range cards)
4. Featured Products (8 items with badges + HP tags + quick actions)
5. Hot Products Strip (dark gradient best-seller banner)
6. Why Choose Us (trust building)
7. Trust Bar (ISO/CE/EPA/Export badges)
8. Testimonials (3 client quotes)
9. Latest News (3 cards)
10. Company Intro (condensed single-row with inline stats)
11. Product CTA Strip (gold gradient conversion bar)
12. Contact CTA (WhatsApp/Email/Form)

## CSS Version Strategy

For the PHP site, CSS files use timestamp-based naming:
```
assets/css/style-v1780052000.css
```

Header template (`templates/header.php`) references the CSS file directly.
To update: create new CSS file with new timestamp → update `header.php` reference.

**Important:** The Nginx config has `expires 30d; add_header Cache-Control "public, immutable"` for static assets. After CSS update, must use new filename to bypass Cloudflare CDN cache.

## Differences from ASP Site Design

| Aspect | ASP Site (shengtuo-tractor.com) | PHP Site (sub.aiv.qzz.io) |
|--------|--------------------------------|--------------------------|
| Width | Fixed 980px | Bootstrap container (1200px max) |
| Layout | Float-based (#left/#right) | Bootstrap grid (col-lg-3) |
| CSS | Single style_v8.css | Versioned style-v{timestamp}.css |
| Colors | Blue (#2563eb) | Navy+Gold (#0F2B5B/#D4A843) |
| Products | Table/list layout | Card grid with overlay |
| Footer | Simple copyright bar | 4-column with social links |
| Responsive | viewport auto-scale | Bootstrap responsive |

## Page Banner Pattern (Inner Pages)

All inner pages use a consistent banner with dark navy gradient overlay:
```html
<section class="page-banner" style="background:linear-gradient(135deg,rgba(15,43,91,0.92),rgba(10,22,40,0.85)),url('/assets/images/company.jpg') center/cover;">
    <div class="container text-center">
        <span class="section-badge" style="color:rgba(212,168,67,0.9);">Section</span>
        <h1 style="color:#fff;font-size:2.5rem;font-weight:800;">Page Title</h1>
        <p style="color:rgba(255,255,255,0.7);font-size:1.1rem;">Subtitle</p>
    </div>
</section>
```
CSS: `.page-banner { padding: 5rem 0 4rem; }` Mobile: `3.5rem 0 2.5rem`

## Template Unification Workflow

Convert standalone pages to shared `header.php`/`footer.php`:
1. Replace `require_once 'config/database.php'` → `require_once __DIR__ . '/includes/functions.php'`
2. Set `$pageTitle`, `$pageDescription`, `$currentPage` before `include 'templates/header.php'`
3. Remove duplicate `<html>`, `<head>`, `<nav>`, `<footer>`, Bootstrap/FA includes
4. Remove duplicate WhatsApp button (now in footer.php)
5. **Pitfall:** `escape()`, `getDBConnection()` depend on `functions.php` — always load it first

## Inner Page Design Patterns

**About:** Banner → overview (image+stats) → product series cards → capabilities → certifications (dark gradient) → CTA
**Contact:** Banner → 3 contact cards → form (left) + company info/hours (right)
**Products:** Banner → category filter pills + count → card grid → CTA
**Product Detail:** Breadcrumb → image + badges + description + CTAs → features + specs → related products
**News:** Banner → cards with gradient placeholder for missing images

**News image placeholder** (when image is NULL):
```php
<div style="height:200px;background:linear-gradient(135deg,var(--primary),var(--dark));display:flex;align-items:center;justify-content:center;">
    <i class="fas fa-newspaper" style="font-size:3rem;color:rgba(255,255,255,0.2);"></i>
</div>
```

## Nginx Product Slug Routing Pitfall

`try_files $uri $uri/ /product.php?slug=$uri` passes full path (`/product/slug-name`) as slug.
**Fix in PHP:** Strip prefix: `if ($slug && strpos($slug, '/product/') === 0) $slug = substr($slug, 9);`
**Symptom:** 302 redirect instead of 200 on product detail pages.

## Image Sourcing for PHP Site

Missing slider/banner images → copy from original site backup:
```bash
ls /home/ubuntu/wwwroot/uploadfile/          # Available images
grep -oP 'uploadfile/[^"]+\.(jpg|png)' /home/ubuntu/wwwroot/index.html  # Original references
cp /home/ubuntu/wwwroot/uploadfile/FILE.jpg /home/ubuntu/shengtuo-website/assets/images/slider/slider1.jpg
```

## Files

- CSS: `/home/ubuntu/shengtuo-website/assets/css/style-v1780052000.css`
- Header: `/home/ubuntu/shengtuo-website/templates/header.php`
- Footer: `/home/ubuntu/shengtuo-website/templates/footer.php` (includes WhatsApp float)
- Index: `/home/ubuntu/shengtuo-website/index.php`
- About: `/home/ubuntu/shengtuo-website/about.php`
- Contact: `/home/ubuntu/shengtuo-website/contact.php`
- Products: `/home/ubuntu/shengtuo-website/products.php`
- Product Detail: `/home/ubuntu/shengtuo-website/product.php`
- News: `/home/ubuntu/shengtuo-website/news.php`
