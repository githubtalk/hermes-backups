# CSS Text Readability on Colored Backgrounds

When changing website background color (e.g., white → blue-gray), text colors MUST be adjusted for contrast. Leaving dark-gray text on a medium-blue background makes it unreadable.

## Blue-Gray Background (#75a5c1) — Tested Values

```css
/* Background */
body {
    background-color: #75a5c1;
    text-shadow: 0 1px 2px rgba(0,0,0,0.1);  /* subtle depth */
}

/* Body text — deep black for maximum contrast */
body { color: #1a1a1a; }

/* Links — white on blue-gray */
a { color: #ffffff; }
a:visited { color: #e0e0e0; }
a:hover { color: #ffffff; }
a:active { color: #ffffff; }

/* Navigation — bold white with shadow */
#nav a {
    color: #ffffff !important;
    text-shadow: 0 1px 3px rgba(0,0,0,0.2);
    font-weight: bold;
}
#nav a:hover {
    background-color: rgba(255,255,255,0.2);  /* subtle hover highlight */
}

/* Section titles */
.category_title {
    color: #ffffff !important;
    border-bottom-color: rgba(255,255,255,0.3);
}
```

## Contrast Ratio Guidelines (WCAG)

| Text Type | Min Ratio | On #75a5c1 |
|-----------|-----------|------------|
| Body text (normal) | 4.5:1 | #1a1a1a ✅ (10.5:1) |
| Large text (18px+) | 3:1 | #222222 ✅ |
| Links | 4.5:1 | #ffffff ✅ (7.2:1) |
| Subtle text | 3:1 | #333333 ✅ |

## Pattern for Other Background Colors

1. **Dark backgrounds** (navy, dark gray): Use white (#ffffff) or light gray (#e0e0e0) text
2. **Light backgrounds** (white, cream): Use dark gray (#333, #505050) text
3. **Medium backgrounds** (blue-gray, sage): Use deep black (#1a1a1a) text + white links
4. **Colored backgrounds**: Always check contrast — use WebAIM Contrast Checker

## Common Mistake

Changing background without adjusting text → invisible text. Always pair background color changes with corresponding text color updates.

## Restoring Original Colors

When user says "复原到原来的颜色" (restore original color) or is not satisfied with color changes:

**Original values**:
```css
body {
    background-color: #FFFFFF;
    background-image: url(../images/bg.jpg);
    background-repeat: repeat-x;
    color: #505050;
}
a { color: #575656; }
a:visited { color: #727272; }
a:hover { color: #404040; }
```

**Workflow to restore**:
```bash
# Download current CSS
curl -s -u "shanweituo:C2r3h2q7K3" ftp://shanweituo.gotoftp4.com/wwwroot/css/main.css > /tmp/main.css

# Replace colors back to original
sed -i 's/#75a5c1/#FFFFFF/g' /tmp/main.css
sed -i 's/#1a1a1a/#505050/g' /tmp/main.css
sed -i 's/color: #ffffff/color: #575656/g' /tmp/main.css

# Upload as NEW filename to bypass cache
curl -T /tmp/main.css -u "shanweituo:C2r3h2q7K3" ftp://shanweituo.gotoftp4.com/wwwroot/css/style2.css
```

**Key lesson**: When restoring, always use a NEW CSS filename to bypass Cloudflare cache.

## Quick CSS Override Template

For overlay mode (custom.css), override all text-related styles:

```css
/* Override text colors for new background */
body { background-color: #75a5c1; color: #1a1a1a !important; }
a, a:link, a:visited, a:hover, a:active { color: #ffffff !important; }
#nav a { color: #ffffff !important; font-weight: bold; }
.category_title, .category_title span { color: #ffffff !important; }
.footer { color: #e0e0e0 !important; }
.footer a { color: #ffffff !important; }
```
