# Domain × SEO Linkage Pattern

When the site sits behind Cloudflare (especially Flexible SSL), several URL-generation mechanisms break silently.

## Cloudflare HTTPS Detection

**PROBLEM:** `$_SERVER['HTTPS']` is not set when Cloudflare connects to origin via HTTP (Flexible SSL mode). All `getCurrentUrl()` calls return `http://` instead of `https://`, breaking canonical, og:url, twitter:url, and JSON-LD.

**FIX:** Check `HTTP_X_FORWARDED_PROTO` first (Cloudflare sets this to `https`):

```php
function getCurrentUrl() {
    if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') $proto = 'https';
    elseif (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') $proto = 'https';
    else $proto = 'http';
    return $proto . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}
```

**WHERE TO FIX:** Every file that defines `getCurrentUrl()`:
- `templates/header.php` (used by frontend pages)
- `includes/functions.php` (used by API/admin pages)

**VERIFICATION:**
```bash
# All should show https://
curl -s https://SITE/ | grep -E 'canonical|og:url' 
# Expected: href="https://SITE/" and content="https://SITE/"
# Broken: href="http://SITE/" (missing X-Forwarded-Proto check)
```

## og:image Absolute URL

**PROBLEM:** Product images stored as relative paths (`/assets/images/products/product.jpg`). When passed to SEO meta tags, they appear as relative URLs in og:image, which Facebook/LinkedIn cannot resolve.

**FIX:** In `seo.php` `generateMetaTags()`, prepend base URL to relative image paths:

```php
$image = $pageImage ?: ($this->baseUrl . '/assets/images/logo-v2.png');
if ($image && strpos($image, 'http') !== 0) $image = $this->baseUrl . $image;
```

## Domain-SEO Linkage Checklist

When `site_url` is changed in admin settings, ALL of these update automatically:
- [x] `<link rel="canonical">` — via `getCurrentUrl()` or `$this->baseUrl`
- [x] `<meta property="og:url">` — via `getCurrentUrl()`
- [x] `<meta property="og:image">` — via SEO class with base URL prepend
- [x] `<meta property="twitter:url">` — via `getCurrentUrl()`
- [x] Sitemap `<loc>` URLs — via `SITE_URL` constant
- [x] Robots.txt `Sitemap:` line — via `SITE_URL` constant
- [x] JSON-LD `url` and `logo` — via `SITE_URL` constant

**NOT automatically updated (must be manually configured):**
- [ ] Google Search Console property
- [ ] Baidu Webmaster site
- [ ] Cloudflare DNS records
- [ ] SSL certificates

## Admin Settings → Frontend Flow

```
admin/settings.php (POST)
  → UPDATE settings SET setting_value=? WHERE setting_key=?
  → loadSiteSettings() on next page load
  → define('SITE_URL', ...) etc.
  → All frontend pages use these constants
```

Settings load order: `database.php → loadSiteSettings() → functions.php → pages`
