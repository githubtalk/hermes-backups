# PHP + Nginx + MySQL on blank Ubuntu 经验总结

## 部署顺序（适用于全新 /root/shengtuo-website 站点）

### 1. 先停掉冲突的 default site
```bash
rm -f /etc/nginx/sites-enabled/default
```
Nginx Proxy Manager 容器已经占住了 80/443。如果 default 也 listen 80，主 nginx 根本起不来。

用 `nginx -c /etc/nginx/nginx.conf -g "daemon on;"` 启动时若报 `bind() to :80 failed`，第一反应就是删 default site。

### 2. 确保 nginx.pid 存在
```bash
cat /run/nginx.pid
```
如果 `No such file or directory`，先 `nginx -s stop`，再 `nginx` 生成 pid，之后再 reload。

### 3. PHP-FPM socket 路径必须一致
Ubuntu 安装 php8.1-fpm 后 socket 常见位置：
- `/run/php/php-fpm.sock`（alternatives 符号链接）
- `/run/php/php8.1-fpm.sock`

用 `ls /run/php/*.sock` 确认。fastcgi_pass 写错会导致 upstream `Primary script unknown`。

### 4. /root 目录权限
www-data 默认不可遍历 /root。`chmod o+rx /root` 并且 `chmod -R o+rx /root/shengtuo-website`。

### 5. SSH 中粘贴长 heredoc 要分段
一个完整的 nginx server 块直接转义粘贴容易被截断，替代方案：
- 拆成多段 `cat >>`
- 或上传文件后直接加载
- 不要把多条带分号的命令挤在一行

### 6. 数据库数据灌入顺序
```bash
mysql -u root -e "CREATE DATABASE ...;"
mysql -u root -e "CREATE USER ...; GRANT ...;"
mysql -u <user> -p<pass> <dbname> < schema.sql
```
如果 schema.sql 只有表结构，没有 INSERT 数据，后台产品/新闻会是空表，前台显示 "0 Products"。

## 快速验证
```bash
ss -tlnp | grep ':8087\|nginx'
curl -I http://127.0.0.1:8087/
curl -I http://127.0.0.1:8087/products
curl -I http://127.0.0.1:8087/product/<slug>
curl -I http://127.0.0.1:8087/news/<slug>
```
