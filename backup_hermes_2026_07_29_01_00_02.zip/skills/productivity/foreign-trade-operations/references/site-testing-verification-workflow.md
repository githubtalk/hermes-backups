# Comprehensive Site Testing & Verification Workflow

## When to Use
After any major site change (new pages, CSS updates, security hardening, backend upgrades). Run the full suite before telling the user "it's done."

## Step 1: HTTP Status Code Check (all pages)

```bash
# Frontend pages
for p in "/" "/about" "/products" "/contact" "/news" "/search" "/search?q=tractor" "/sitemap.xml" "/robots.txt"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "https://SITE$p")
  echo "  $p => $code"
done

# Product detail pages (all slugs)
mysql -u USER -p'PASS' DB -e "SELECT slug FROM products WHERE is_active=1" 2>/dev/null | tail -n +2 | while read slug; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "https://SITE/product/$slug")
  [ "$code" != "200" ] && echo "  ❌ /product/$slug => $code"
done

# Admin pages (should be 200 for login, 302 for others)
for p in "/admin/login.php" "/admin/products.php" "/admin/categories.php" "/admin/news.php" "/admin/sliders.php" "/admin/messages.php" "/admin/pages.php" "/admin/settings.php" "/admin/logout.php"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "https://SITE$p")
  echo "  $p => $code"
done
```

## Step 2: PHP Error Check

```bash
for p in "/" "/about" "/products" "/contact" "/news" "/search?q=test"; do
  errors=$(curl -s "https://SITE$p" | grep -ci 'fatal\|warning\|notice\|deprecated\|parse error\|uncaught\|undefined')
  [ "$errors" -gt 0 ] && echo "  ❌ $p has $errors errors" || echo "  ✅ $p clean"
done
```

## Step 3: Key Element Verification (Browser Console)

```javascript
(function(){
    const s = getComputedStyle(document.documentElement);
    return JSON.stringify({
        cssVars: {primary: s.getPropertyValue('--primary').trim(), accent: s.getPropertyValue('--accent').trim()},
        sections: {
            hero: !!document.querySelector('.hero-slider'),
            categories: !!document.querySelector('.category-showcase'),
            featured: !!document.querySelector('.featured-products'),
            footer: !!document.querySelector('footer')
        },
        productCards: document.querySelectorAll('.product-card').length,
        featureBoxColor: document.querySelector('.feature-box h4') ? getComputedStyle(document.querySelector('.feature-box h4')).color : 'N/A',
        featureBoxVisible: document.querySelector('.feature-box h4') ? getComputedStyle(document.querySelector('.feature-box h4')).color !== 'rgb(255, 255, 255)' : false,
        revealFirstOpacity: document.querySelector('.reveal') ? getComputedStyle(document.querySelector('.reveal')).opacity : 'N/A',
        footerBg: document.querySelector('footer') ? getComputedStyle(document.querySelector('footer')).backgroundColor : 'N/A',
    });
})();
```

**What to check:**
- `cssVars.primary` not empty → CSS variables loaded
- `featureBoxVisible: true` → No white-on-white text
- `revealFirstOpacity: "1"` → Reveal fallback working
- `footerBg` should be dark navy

## Step 4: Security + Performance

```bash
# Security headers
curl -sI https://SITE/ | grep -i "x-frame\|x-content-type\|x-xss\|referrer"

# Gzip (needs Accept-Encoding header!)
curl -sI -H "Accept-Encoding: gzip" https://SITE/ | grep -i "content-encoding: gzip"

# CSS bundle loads
curl -s https://SITE/ | grep -q 'bundle.min.css' && echo "✅ CSS Bundle" || echo "❌ CSS Bundle"
```

## Step 5: SEO Verification

```bash
curl -s https://SITE/product/SLUG | grep -q 'application/ld+json' && echo "✅ JSON-LD" || echo "❌ JSON-LD"
curl -s https://SITE/product/SLUG | grep -q 'og:title' && echo "✅ Open Graph" || echo "❌ Open Graph"
curl -s https://SITE/sitemap.xml | grep -q 'urlset' && echo "✅ Sitemap" || echo "❌ Sitemap"
```

## Step 6: White-on-White Text Scan

```javascript
(function(){
    const allText = document.querySelectorAll('h1,h2,h3,h4,h5,h6,p,span,a,li');
    const issues = [];
    allText.forEach(el => {
        const cs = getComputedStyle(el);
        const m = cs.color.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
        if (m && m[1]>240 && m[2]>240 && m[3]>240) {
            const bm = cs.backgroundColor.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
            if (bm && bm[1]>240 && bm[2]>240 && bm[3]>240) {
                issues.push(el.tagName + ': ' + el.textContent.substring(0,30));
            }
        }
    });
    return issues.length ? '❌ ' + issues.join(', ') : '✅ No white-on-white';
})();
```

## Key Pitfalls
1. **Always test with `?v=1` cache-busting** — Cloudflare serves stale pages
2. **Gzip needs `Accept-Encoding: gzip` header** — plain `curl -sI` won't trigger it
3. **Admin 302 = correct** — auth gate redirects unauthenticated requests
4. **Run Browser Console checks on fresh page load** — previous JS modifications persist
5. **PHP `grep -i 'warning'` may match JS code** — `console.error('Error loading...')` is not a PHP error. Use `grep -i 'fatal\|parse error\|uncaught'` for real errors.
6. **execute_code tool limit = 50 calls** — Long batch scripts hit this limit. Split into separate execute_code blocks or use `terminal` with shell loops.

## Multi-Round Testing Template (user says "反复测试直到没有问题")

```bash
#!/bin/bash
# comprehensive-test.sh — Run until zero errors
SITE="https://sub.aiv.qzz.io"
COOKIE="/tmp/admin_cookie"
ERRORS=0

echo "=== [1] Frontend Pages ==="
for p in / /products /about /contact /news /export /search /why-us /sitemap.xml /robots.txt; do
  code=$(curl -s -o /dev/null -w '%{http_code}' "${SITE}${p}")
  [ "$code" != "200" ] && { echo "❌ ${p} → ${code}"; ((ERRORS++)); }
done
echo "  Frontend done. Errors: $ERRORS"

echo "=== [2] Product Detail Pages ==="
mysql -u shengtuo -p'ShengTuo2026!' shengtuo_website -N -e "SELECT slug FROM products WHERE is_active=1" 2>/dev/null | while read slug; do
  code=$(curl -s -o /dev/null -w '%{http_code}' "${SITE}/product/${slug}")
  [ "$code" != "200" ] && echo "❌ /product/${slug} → ${code}"
done

echo "=== [3] Admin Pages ==="
curl -s -c $COOKIE -L -o /dev/null -X POST "${SITE}/admin/login.php" -d 'username=admin&password=shengtuo2026'
for p in /admin/ /admin/products.php /admin/categories.php /admin/news.php /admin/sliders.php /admin/messages.php /admin/inquiries.php /admin/pages.php /admin/settings.php /admin/seo-checker.php; do
  code=$(curl -s -b $COOKIE -o /dev/null -w '%{http_code}' "${SITE}${p}")
  [ "$code" != "200" ] && [ "$code" != "302" ] && echo "❌ ${p} → ${code}"
done

echo "=== [4] PHP Syntax ==="
find /home/ubuntu/shengtuo-website -name '*.php' -exec php -l {} \; 2>&1 | grep -v 'No syntax errors'

echo "=== [5] Internal Links ==="
curl -s ${SITE}/ | grep -oP 'href="(/[^"]*)"' | sed 's/href="//;s/"$//' | \
  grep -v '#' | grep -v 'javascript:' | grep -v '\\$' | grep -v 'cdn-cgi' | sort -u | while read url; do
  code=$(curl -s -o /dev/null -w '%{http_code}' "${SITE}${url}")
  [ "$code" != "200" ] && echo "❌ ${url} → ${code}"
done

echo "=== [6] Nginx Error Log ==="
sudo tail -5 /var/log/nginx/error.log 2>/dev/null | grep -v 'notice\|signal\|exit'

echo "=== [7] Performance ==="
curl -s -o /dev/null -w 'Load: %{time_total}s | Size: %{size_download}B\n' ${SITE}/

echo "=== DONE ==="
```

**Run multiple rounds until all sections show zero errors.**
