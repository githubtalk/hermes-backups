# CSS Grid Layout System for B2B Website

## Overview
Replace Bootstrap row/col with CSS Grid for cleaner, more maintainable layouts.
File: `/assets/css/layout-optimize.css` (25KB, gzip 4.6KB)

## Grid Components

### Product Grid (4 columns)
```css
.product-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.5rem;
}
```

### Category Grid (2 columns)
```css
.category-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 2rem;
    max-width: 900px;
    margin: 0 auto;
}
```

### HP Range Grid (4 columns)
```css
.hp-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.5rem;
}
```

### Feature Grid (4 columns)
```css
.feature-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.5rem;
}
```

### Stats Grid (4 columns)
```css
.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 2rem;
    padding-top: 3rem;
    border-top: 1px solid var(--gray-200, #e5e7eb);
}
```

### Testimonial Grid (3 columns)
```css
.testimonial-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1.5rem;
}
```

### Trust Grid (4 columns)
```css
.trust-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.5rem;
    padding-top: 2.5rem;
    border-top: 1px solid rgba(255,255,255,0.2);
}
```

### Certification Gallery (4 columns)
```css
.cert-gallery {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.5rem;
}
```

## Responsive Breakpoints

```css
@media (max-width: 1199.98px) {
    .product-grid { grid-template-columns: repeat(3, 1fr); }
    .hp-grid { grid-template-columns: repeat(2, 1fr); }
    .feature-grid { grid-template-columns: repeat(2, 1fr); }
    .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 1.5rem; }
    .trust-grid { grid-template-columns: repeat(2, 1fr); }
    .cert-gallery { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 991.98px) {
    .product-grid { grid-template-columns: repeat(2, 1fr); }
    .testimonial-grid { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 767.98px) {
    .product-grid { grid-template-columns: repeat(2, 1fr); gap: 1rem; }
    .hp-grid { grid-template-columns: repeat(2, 1fr); gap: 1rem; }
    .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 1rem; }
    .trust-grid { grid-template-columns: repeat(2, 1fr); gap: 1rem; }
    .cert-gallery { grid-template-columns: repeat(2, 1fr); gap: 1rem; }
}

@media (max-width: 575.98px) {
    .product-grid { grid-template-columns: 1fr; }
}
```

## Section System

### Section Classes
```css
.section { padding: 5rem 0; position: relative; }
.section-sm { padding: 3rem 0; }
.section-lg { padding: 6rem 0; }
.section-white { background: #fff; }
.section-light { background: var(--primary-light, #f0f4f8); }
.section-gray { background: var(--gray-50, #f9fafb); }
.section-dark { background: var(--gray-900, #111827); color: #fff; }
```

### Section Header
```css
.section-header {
    text-align: center;
    margin-bottom: 3.5rem;
}

.section-badge {
    display: inline-block;
    font-size: 0.75rem;
    font-weight: 700;
    letter-spacing: 3px;
    text-transform: uppercase;
    color: var(--accent, #D4A843);
    margin-bottom: 1rem;
}

.section-badge::after {
    content: '';
    display: block;
    width: 50px;
    height: 2px;
    background: linear-gradient(90deg, var(--primary, #0f2b5b), var(--accent, #D4A843));
    margin: 0.75rem auto 0;
    border-radius: 1px;
}

.section-title {
    font-size: 2.25rem;
    font-weight: 800;
    color: var(--gray-900, #111827);
    margin-bottom: 1rem;
    letter-spacing: -0.5px;
    line-height: 1.2;
}

.section-subtitle {
    font-size: 1.05rem;
    color: var(--gray-500, #6b7280);
    max-width: 600px;
    margin: 0 auto;
    line-height: 1.6;
}
```

## Product Card Pattern

```css
.product-card {
    background: #fff;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 2px 12px rgba(0,0,0,0.06);
    border: 1px solid rgba(0,0,0,0.04);
    transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
}

.product-card:hover {
    transform: translateY(-6px);
    box-shadow: 0 12px 40px rgba(0,0,0,0.12);
}

.product-card-image {
    position: relative;
    overflow: hidden;
    aspect-ratio: 4/3;
    background: linear-gradient(135deg, #f8f9fa, #eef0f3);
}

.product-card-body {
    padding: 1.25rem;
}
```

## Button System

```css
.btn-primary {
    background: var(--primary, #0f2b5b);
    color: #fff;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-accent {
    background: var(--accent, #D4A843);
    color: #fff;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-outline {
    background: transparent;
    color: #fff;
    border: 2px solid rgba(255,255,255,0.4);
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}
```

## Implementation Notes

1. **Remove inline styles** - Use CSS classes instead of `style="..."` attributes
2. **Consistent spacing** - Use `.section` class with modifiers for padding
3. **Alternating backgrounds** - White → Light Blue → Gray → White rhythm
4. **Section headers** - Always use `.section-header` with `.section-badge`, `.section-title`, `.section-subtitle`
5. **Grid layouts** - Use CSS Grid for all multi-column layouts
6. **Responsive** - Grid columns reduce at breakpoints (4→3→2→1)

## File Structure

```
/assets/css/
├── bundle-v8.min.css      # Main bundle (129KB)
├── layout-optimize.css    # Layout system (25KB, gzip 4.6KB)
└── ...
```

## Performance

- HTML size: ~65KB
- Layout CSS: 25KB (gzip 4.6KB)
- Page load: 0.12s
- TTFB: 0.12s
