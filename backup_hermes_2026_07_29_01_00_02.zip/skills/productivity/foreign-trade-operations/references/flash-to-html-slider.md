# Flash 轮播替换为 HTML/CSS 方案

aiv.qzz.io 使用旧版 Flash 轮播（`focus.swf`），已替换为纯 HTML/CSS/JS 轮播。

## 替换位置

- **文件**: `/home/ubuntu/wwwroot/index.html`
- **目标 div**: `<div class="flash">`
- **涉及图片**: `/uploadfile/20252251419397278.jpg`, `/uploadfile/20252251419134430.jpg`

## 替换代码模板

```html
<!-- Slider replaced Flash - May 2026 -->
<style>
.slider-container {position:relative;width:968px;height:373px;margin:0 auto;overflow:hidden;}
.slider-wrapper {position:relative;width:100%;height:100%;}
.slider-slide {position:absolute;top:0;left:0;width:100%;height:100%;opacity:0;transition:opacity 0.8s ease-in-out;pointer-events:none;}
.slider-slide.active {opacity:1;pointer-events:auto;}
.slider-slide img {width:100%;height:100%;object-fit:cover;display:block;}
.slider-dots {position:absolute;bottom:15px;left:50%;transform:translateX(-50%);display:flex;gap:10px;z-index:10;}
.slider-dot {width:12px;height:12px;border-radius:50%;background:rgba(255,255,255,0.5);cursor:pointer;transition:all 0.3s;border:none;}
.slider-dot.active {background:#eb6100;transform:scale(1.2);}
.slider-dot:hover {background:rgba(255,255,255,0.8);}
.slider-arrow {position:absolute;top:50%;transform:translateY(-50%);background:rgba(0,0,0,0.4);color:#fff;border:none;padding:15px 12px;cursor:pointer;font-size:20px;z-index:10;transition:background 0.3s;}
.slider-arrow:hover {background:rgba(0,0,0,0.7);}
.slider-arrow.prev {left:10px;border-radius:0 4px 4px 0;}
.slider-arrow.next {right:10px;border-radius:4px 0 0 4px;}
</style>
<div class="flash">
<div class="slider-container">
<div class="slider-wrapper">
<div class="slider-slide active"><a href="链接1" target="_blank"><img src="/图片路径1.jpg" alt="描述1"></a></div>
<div class="slider-slide"><a href="链接2" target="_blank"><img src="/图片路径2.jpg" alt="描述2"></a></div>
</div>
<div class="slider-dots"><button class="slider-dot active" onclick="goSlide(0)"></button><button class="slider-dot" onclick="goSlide(1)"></button></div>
<button class="slider-arrow prev" onclick="prevSlide()">&#10094;</button>
<button class="slider-arrow next" onclick="nextSlide()">&#10095;</button>
</div>
<script>
(function(){var i=0,s=document.querySelectorAll('.slider-slide'),d=document.querySelectorAll('.slider-dot');function goSlide(n){s[i].classList.remove('active');d[i].classList.remove('active');i=n;s[i].classList.add('active');d[i].classList.add('active')}function nextSlide(){goSlide((i+1)%s.length)}function prevSlide(){goSlide((i-1+s.length)%s.length)}window.goSlide=goSlide;window.nextSlide=nextSlide;window.prevSlide=prevSlide;setInterval(nextSlide,5000)})();
</script>
</div>
```

## shengtuo-tractor.com Windows 主机 FTP 工作流

**主机**: `shanweituo.gotoftp4.com` | **路径**: `/wwwroot/`

### FTP 操作（curl 方式）

```bash
# 下载文件
curl -s -u shanweituo:密码 ftp://shanweituo.gotoftp4.com/wwwroot/about/3.html -o /tmp/shengtuo-about3.html

# 上传文件
curl -s -u shanweituo:密码 -T /tmp/shengtuo-about3.html ftp://shanweituo.gotoftp4.com/wwwroot/about/3.html
```

### 已修复页面（2026-05 批量）

| 页面 | 路径 | 状态 |
|------|------|------|
| 主页 | `/wwwroot/index.html` | ✅ |
| 关于我们 | `/wwwroot/about/2.html` | ✅ |
| 联系我们 | `/wwwroot/about/3.html` | ✅ |
| 共享头部 | `/wwwroot/Inc/header.asp` | ✅ (ASP 页面共享) |

### 验证命令

```bash
# 确认 Flash 已清除（返回 0 = 无残留）
curl -s http://www.shengtuo-tractor.com/about/3.html | grep -ci "flash\|swf\|shockwave\|flashplayer"

# 确认 Slider 已植入（返回 >0 = 成功）
curl -s http://www.shengtuo-tractor.com/about/3.html | grep -c "slider-container"
```

## 检测 Flash 的方法

```bash
# 检查页面中的 Flash 引用
curl -s https://aiv.qzz.io/ | grep -i -E "flash|swf|shockwave|flashplayer"

# 检查 focus.swf 文件是否存在
curl -sI https://aiv.qzz.io/images/focus.swf
```

## 验证修复

```bash
# 确认无 Flash 残留
curl -s https://aiv.qzz.io/ | grep -i "shockwave\|flashplayer\|swf"

# 应返回空，表示已清除

# 确认轮播已生效
curl -s https://aiv.qzz.io/ | grep -E "slider-container|slider-slide"
```

## 旧版 Flash 典型代码模式

```html
<!-- 典型 Flash embed 结构 -->
<div class="flash">
<script type="text/javascript">
var swf_width=968;var swf_height=350;
var files='|/path/to/image1.jpg|/path/to/image2.jpg';
var links='|http://link1.com|http://link2.com';
document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" ...>');
document.write('<param name="movie" value="/images/focus.swf" />');
document.write('<embed src="/images/focus.swf" ... type="application/x-shockwave-flash" />');
document.write('</object>');
</script>
</div>
```

**替换策略**: 保留 `files` 和 `links` 变量中的图片路径和链接，转换为新的 HTML 结构。

---

## ⚠️ 关键陷阱：正则表达式替换 Flash 时删除过多内容

**问题：** 使用 `re.DOTALL` 模式的正则 `<div class="flash">.*?</div>` 会匹配到 Flash div 后面的第一个 `</div>`，但由于 Flash 内部有嵌套 div，这个正则会跳过产品列表、公司介绍等所有后续内容。

**后果：** 首页产品列表、公司介绍、联系信息全部丢失！

**错误代码示例：**
```python
flash_pattern = r'<div class="flash">.*?</div>\s*</div>'
match = re.search(flash_pattern, content, re.DOTALL)
# 这会匹配从 <div class="flash"> 到很后面的 </div>，把中间所有内容都吃掉！
```

**正确做法：**
```python
# 方法1：使用明确的结束标记
flash_start = content.find('<div class="flash">')
flash_end = content.find('<!-- end of flash -->', flash_start)

if flash_start >= 0 and flash_end >= 0:
    flash_end_full = flash_end + len('<!-- end of flash -->')
    new_content = content[:flash_start] + slider_html + content[flash_end_full:]

# 方法2：如果无结束标记，用 Flash 特定字符串定位
flash_start = content.find('<div class="flash">')
flash_end = content.find('</script>', content.find('focus.swf', flash_start))
flash_end = content.find('</div>', flash_end) + len('</div>')
```

**验证步骤（必须执行）：**
```python
# 替换后验证关键内容未丢失
if 'category_title' in new_content and 'index_about' in new_content:
    print("✅ 内容保留完整")
else:
    print("❌ 内容丢失，拒绝上传！")
```

**修复已丢失的内容：**
```bash
# 从备份恢复（如果有）
cp /tmp/index_backup.html /tmp/index_fixed.html

# 或从 FTP 下载旧版本
curl -s -u "USER:PASS" ftp://HOST/wwwroot/index.html -o /tmp/index_old.html
```