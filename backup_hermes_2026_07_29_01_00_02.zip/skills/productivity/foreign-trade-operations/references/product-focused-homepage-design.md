# Product-Focused Homepage Design for B2B Agricultural Sites

## Overview

Restructuring a B2B homepage to prioritize product promotion over company information. Applied to sub.aiv.qzz.io (2026-05-30).

## Layout Order (Product-First)

```
1. Hero Slider (with product CTAs: "Browse Products" + "Get Quote")
2. Product Category Cards (visual cards with product count)
3. HP Range Showcase (clickable horsepower range cards)
4. Featured Products (with badges + HP tags + tab filtering)
5. Hot Products Strip (dark background, compact cards)
6. Why Choose Us (trust building)
7. Trust Bar (certification badges)
8. Testimonials (social proof)
9. Latest News (condensed, 3 items max)
10. Company Intro (condensed, moved to bottom)
11. Product CTA Strip (gold gradient, "Ready to Find Your Perfect Tractor?")
12. Contact CTA (final conversion)
```

**Key principle:** Products first, company info last. Visitors come for tractors, not company history.

## Category Cards Design

```html
<div class="category-card">
    <div class="category-card-bg" style="background-image:url('...');"></div>
    <div class="category-card-overlay">
        <span class="category-count">16 Products</span>
        <div class="category-card-icon"><i class="fas fa-tractor"></i></div>
        <h3>SHENGTUO TRACTOR</h3>
        <p>25HP to 260HP tractors for every farm size</p>
    </div>
</div>
```

CSS: 280px height, hover scale 1.08 on bg, gradient overlay from transparent to dark.

## Product Card Badges

```php
// Badge assignment logic
if ($index < 2) $badge = 'hot';        // Red pulse animation
elseif ($index < 4) $badge = 'popular'; // Gold
elseif ($index < 6) $badge = 'best-seller'; // Blue
```

HP tag (top-right, semi-transparent):
```php
<?php if ($product['horsepower'] && $product['horsepower'] !== 'N/A'): ?>
<span class="product-hp-tag"><i class="fas fa-bolt"></i> <?= escape($product['horsepower']) ?></span>
<?php endif; ?>
```

## Product Tab Filtering (JS)

```javascript
document.querySelectorAll('.product-tab').forEach(tab => {
    tab.addEventListener('click', function() {
        document.querySelectorAll('.product-tab').forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        const filter = this.dataset.filter;
        document.querySelectorAll('.product-item').forEach(item => {
            if (filter === 'all' || item.dataset.category === filter) {
                item.style.display = '';
                // Fade-in animation
                item.style.opacity = '0';
                item.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    item.style.transition = 'all 0.4s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'translateY(0)';
                }, 50);
            } else {
                item.style.display = 'none';
            }
        });
    });
});
```

## HP Range Cards

Clickable cards linking to `/products.html?hp=25-50` etc.:
```html
<a href="/products.html?hp=25-50" class="text-decoration-none">
    <div class="hp-range-card">
        <div class="hp-range-number">25-50</div>
        <div class="hp-range-unit">Horsepower</div>
        <div class="hp-range-label">Small Farm & Garden</div>
    </div>
</a>
```

## CSS Files

- `product-focus-v4.css` — Category cards, HP range, product badges, hot products strip, CTA strip
- `enhance-v3.css` — Scroll reveal, testimonials, trust bar, typing effect, sticky CTA
- `style-v1780052000.css` — Base design system (colors, buttons, nav, footer)

## Company Intro Condensed Pattern

Moved to bottom, split into text + stats side-by-side:
```html
<section class="company-intro-compact">
    <div class="row align-items-center">
        <div class="col-lg-8">
            <h3>Company Name</h3>
            <p>2-3 sentence summary</p>
            <a href="/about.html" class="btn btn-outline-primary btn-sm">Learn More</a>
        </div>
        <div class="col-lg-4">
            <div class="intro-stats">
                <!-- 4 mini stat blocks -->
            </div>
        </div>
    </div>
</section>
```
