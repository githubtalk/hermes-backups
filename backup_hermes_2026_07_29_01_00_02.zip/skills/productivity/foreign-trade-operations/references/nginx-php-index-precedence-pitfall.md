# Nginx index.html vs index.php Precedence Pitfall

## Problem

Nginx `index` directive processes files **in order**. The standard config:

```nginx
index index.html index.htm index.php;
```

This means: if `index.html` exists in the document root, Nginx serves it **instead of** `index.php`. No error, no warning — the PHP file is silently ignored.

## Symptoms

- You update `index.php` but the website shows old content
- `curl -sI https://site.com` shows `last-modified` matching `index.html`, not `index.php`
- Browser console shows sections/classes from an old static page, not the PHP template
- Cloudflare `cf-cache-status: DYNAMIC` (not HIT) — it's the origin serving stale content, not CDN cache

## Diagnosis

```bash
# 1. Check if both files exist
ls -la /var/www/site/index.*

# 2. Check which file is being served (look at last-modified)
curl -sI https://sub.aiv.qzz.io/ | grep -i last-modified

# 3. Compare timestamps
stat /home/ubuntu/shengtuo-website/index.html
stat /home/ubuntu/shengtuo-website/index.php
# If index.html is newer or exists, it's being served instead

# 4. Check CSS being loaded (should be your new CSS, not old)
curl -s https://site.com | grep 'stylesheet'
# If it shows old CSS file, the HTML file is stale
```

## Fix

```bash
# Option A: Remove/rename the HTML file (recommended)
mv /path/to/index.html /path/to/index.html.bak
sudo systemctl reload nginx

# Option B: Change Nginx index directive order
# In /etc/nginx/sites-enabled/site-config:
# Change: index index.html index.htm index.php;
# To:     index index.php index.html index.htm;
# Then: sudo systemctl reload nginx

# Option C: If index.html is a static version you want to keep
# Move it to a subdirectory so it doesn't compete with index.php
mv /path/to/index.html /path/to/static/index.html
```

## When This Happens

This pitfall commonly occurs when:

1. **Migrating from static HTML to PHP** — old `index.html` was never removed
2. **Building a new PHP site alongside an existing static site** — both files coexist
3. **Restoring from backup** — backup includes old `index.html`
4. **Static page generators** (Hugo, Jekyll) create `index.html` that overrides PHP

## Prevention

When deploying a new PHP site:

```bash
# Before starting, check for competing index files
ls -la /var/www/newsite/index.*

# If migrating from static, remove old index first
# Don't just create index.php alongside index.html!
```

## Verification After Fix

```bash
# 1. Reload nginx
sudo systemctl reload nginx

# 2. Check the page is PHP-generated
curl -s https://site.com | head -5
# Should see PHP-generated HTML (dynamic timestamps, database content)

# 3. Check CSS reference
curl -s https://site.com | grep 'style-v'
# Should show your latest CSS file

# 4. Check last-modified is recent (matches your PHP build time)
curl -sI https://site.com | grep -i last-modified

# 5. Browser console verification
# document.querySelector('link[href*="style-v"]')?.href
# Should return your new CSS path
```

## Real-World Example (sub.aiv.qzz.io, 2026-05-29)

```
Problem: Updated index.php with new business-clean design, but site showed old page
Root cause: /home/ubuntu/shengtuo-website/index.html (13KB, static) existed alongside index.php (12KB, dynamic)
Nginx config: index index.html index.htm index.php; (html first!)
Fix: mv index.html index.html.bak && sudo systemctl reload nginx
Result: New PHP homepage with all 7 sections loaded immediately
```
