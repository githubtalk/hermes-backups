# Admin i18n Batch Translation Pitfalls

## Perl Regex Breaking PHP Ternary Expressions

**PROBLEM:** Using `perl -pi -e` to replace hardcoded English text with `t()` calls fails when text is inside PHP ternary expressions:

```php
// ORIGINAL:
<h4><?= $action === 'add' ? 'Add New Product' : 'Edit Product' ?></h4>

// AFTER perl (BROKEN — nested PHP tags):
<h4><?= $action === 'add' ? '<?= t('Add New Product') ?>' : '<?= t('Edit Product') ?>' ?></h4>
```

**FIX:** Use `patch` tool for ternary expressions:
```php
<h4><?= $action === 'add' ? t('Add New Product') : t('Edit Product') ?></h4>
```

## Safe vs Unsafe Replacement Patterns

| Pattern | Safe with perl? | Example |
|---------|----------------|---------|
| `>Text</tag>` (HTML text) | ✅ Yes | `>Name</th>` → `><?= t('Name') ?></th>` |
| `'text'` (PHP string in ternary) | ❌ No | Use `patch` tool instead |
| `"text"` (PHP double-quote string) | ❌ No | Use `patch` tool instead |
| `confirm('text')` (JS confirm) | ⚠️ Careful | Must escape quotes properly |

## Batch Translation Workflow

1. **Common table headers** — perl safe: `<th>Name</th>` → `<th><?= t('Name') ?></th>`
2. **Common buttons** — perl safe: `>View All</a>` → `><?= t('View All') ?></a>`
3. **Status badges** — perl safe: `? 'Active' : 'Inactive'` → `? t('Active') : t('Inactive')`
4. **Empty states** — perl safe: `>No messages yet<` → `><?= t('No messages yet') ?><`
5. **Ternary expressions** — MUST use patch: `$action === 'add' ? 'Add' : 'Edit'` → `$action === 'add' ? t('Add') : t('Edit')`
6. **Flash messages** — MUST use patch: `$_SESSION['flash_msg'] = 'Product created successfully.'` → `$_SESSION['flash_msg'] = t('Product created successfully.')`
7. **Confirm dialogs** — MUST use patch: `confirm('Delete this product?')` → `confirm('<?= t('Delete this product?') ?>')`

## Verification

After each file:
```bash
php -l admin/page.php
```

After all pages, verify language switching works:
```bash
curl -s -b /tmp/admin.txt "https://site/admin/products.php?lang=zh" | grep -c '产品管理'
curl -s -b /tmp/admin.txt "https://site/admin/products.php?lang=en" | grep -c 'Products'
```
