# Admin Profile Page Pattern

## Overview

Creating a user profile and password settings page for the PHP admin panel.

## Correct Auth.php Integration (2026-05-30 verified)

**⚠️ CRITICAL: Do NOT duplicate HTML structure.** auth.php outputs full DOCTYPE/head/body/sidebar. Content pages only output content + closing tags.

**Correct pattern:**
```php
<?php
$pageTitle = 'Profile';
$currentPage = 'profile';
require_once __DIR__ . '/auth.php';  // Outputs full HTML + sidebar + opens content-area
// Page logic...
?>
<!-- Page-specific styles (optional) -->
<style>...</style>
<!-- Content only — NO DOCTYPE/head/body/sidebar -->
<div class="row">...</div>
<?php
// MUST close HTML tags that auth.php opened
echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>';
echo '</div></div></body></html>';
?>
```

**Wrong (causes duplicate sidebar):**
```php
<?php require_once __DIR__ . '/auth.php'; ?>
<!DOCTYPE html>  <!-- ❌ auth.php already output this -->
<html><body><div class="sidebar">...</div>  <!-- ❌ Duplicate! -->
```

**Verification:** `curl -s URL | grep -c 'sidebar'` should be ~17 (CSS/JS refs), not 34+.

## Header Username → Profile Link
```php
<a href="/admin/profile.php" class="text-decoration-none d-flex align-items-center gap-2 text-dark">
    <div class="user-avatar"><i class="fas fa-user"></i></div>
    <span><?= escape($adminUsername) ?></span>
</a>
```

## File: `/admin/profile.php`

### Template Pattern (auth.php integration)

```php
<?php
$pageTitle = 'Profile';
$currentPage = 'profile';
require_once __DIR__ . '/auth.php';

$adminId = $_SESSION['admin_id'] ?? 0;
$error = '';

// Get current admin info
$stmt = $db->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$adminId]);
$admin = $stmt->fetch();

if (!$admin) {
    header('Location: /admin/logout.php');
    exit;
}

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';
    
    if (!verifyCSRFToken($csrf)) {
        $error = 'Invalid request token';
    } else {
        if ($action === 'update_profile') {
            // ... update username/email
        }
        if ($action === 'change_password') {
            // ... verify current, update new
        }
    }
}
?>

<!-- Content only (auth.php provides HTML structure) -->
<style>/* Page-specific styles */</style>

<!-- Profile card + forms -->

<?php
// Close HTML from auth.php
echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>';
echo '</div></div></body></html>';
?>
```

### Key Features

1. **Profile Info Card** — Username, email, account status, ID, last login, registration date
2. **Password Change** — Current password verification, strength indicator, confirm match
3. **CSRF Protection** — Token validation on all POST
4. **Session Update** — `$_SESSION['admin_username']` updated after username change

### Password Strength Indicator (JS)

```javascript
function checkStrength(pwd) {
    let s = 0;
    if (pwd.length >= 6) s++;
    if (pwd.length >= 10) s++;
    if (/[A-Z]/.test(pwd)) s++;
    if (/[0-9]/.test(pwd)) s++;
    if (/[^A-Za-z0-9]/.test(pwd)) s++;
    // levels: 20%/40%/60%/80%/100% with red/orange/yellow/green/green
}
```

### Sidebar Integration

In `auth.php`, add profile link:

```php
<li class="nav-item">
    <a class="nav-link <?= ($currentPage??'')==='profile'?'active':'' ?>" 
       href="/admin/profile.php">
        <i class="fas fa-user-circle"></i> <?= t('Profile') ?>
    </a>
</li>
```

### Header Username Link

Make the username clickable to profile page:

```php
<div class="user-info">
    <a href="/admin/profile.php" class="text-decoration-none d-flex align-items-center gap-2 text-dark">
        <div class="user-avatar"><i class="fas fa-user"></i></div>
        <span><?= escape($adminUsername) ?></span>
    </a>
</div>
```

### Language Entries Required

```php
// zh.php
'Profile' => '个人资料',

// en.php  
'Profile' => 'Profile',
```

### Pitfalls

- **Don't duplicate HTML structure** — auth.php provides DOCTYPE/head/sidebar/content-area
- **Close HTML at end** — Must echo `</div></div></body></html>` to close auth.php's opened tags
- **Session admin_id** — login.php must store `$_SESSION['admin_id']` (already done)
- **Password hash** — Use `password_hash()` / `password_verify()`, never plain text
- **Username uniqueness** — Check against other users (`WHERE id != ?`), not just self

### Verification

```bash
# PHP syntax
php -l /path/admin/profile.php

# HTTP status (with session cookie)
curl -s -b /tmp/admin_cookie -o /dev/null -w '%{http_code}' https://SITE/admin/profile.php

# No duplicate sidebar
curl -s -b /tmp/admin_cookie https://SITE/admin/profile.php | grep -c 'sidebar'  # should be ~1 (CSS refs)
```
