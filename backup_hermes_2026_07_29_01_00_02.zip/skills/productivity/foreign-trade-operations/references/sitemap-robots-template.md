# Sitemap Template for Tractor Websites

## sitemap.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
        http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
    
    <!-- Main Pages -->
    <url>
        <loc>https://www.example.com/</loc>
        <lastmod>2026-05-27</lastmod>
        <changefreq>weekly</changefreq>
        <priority>1.0</priority>
        <xhtml:link rel="alternate" hreflang="en" href="https://www.example.com/"/>
        <xhtml:link rel="alternate" hreflang="x-default" href="https://www.example.com/"/>
    </url>
    
    <!-- Products Page -->
    <url>
        <loc>https://www.example.com/products/</loc>
        <lastmod>2026-05-27</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.9</priority>
    </url>
    
    <!-- About Page -->
    <url>
        <loc>https://www.example.com/about/</loc>
        <lastmod>2026-05-27</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.8</priority>
    </url>
    
    <!-- Contact Page -->
    <url>
        <loc>https://www.example.com/contact/</loc>
        <lastmod>2026-05-27</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.8</priority>
    </url>
    
    <!-- Individual Products (add one per product) -->
    <url>
        <loc>https://www.example.com/products/st504.html</loc>
        <lastmod>2026-05-27</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.6</priority>
    </url>
    
</urlset>
```

## robots.txt

```
# Robots.txt for [Company Name]
User-agent: *
Allow: /

# Sitemap
Sitemap: https://www.example.com/sitemap.xml

# Crawl-delay
Crawl-delay: 10

# Disallow admin pages
Disallow: /admin/
Disallow: /admin_v19/
Disallow: /aspnet_client/
Disallow: /Inc/
Disallow: /data/
```

## Priority Guidelines

| Page Type | Priority | Changefreq |
|-----------|----------|------------|
| Homepage | 1.0 | weekly |
| Products listing | 0.9 | weekly |
| About/Contact | 0.8 | monthly |
| Individual products | 0.6 | monthly |
| News/Blog | 0.7 | weekly |
| Sitemap | 0.3 | monthly |

## Notes

- Update `lastmod` date when content changes
- Include `hreflang` tags for multilingual sites
- Submit sitemap to Google Search Console, Bing Webmaster, Yandex Webmaster
