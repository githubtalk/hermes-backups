# PHP Website System for ShengTuo Tractor

## Overview

A complete PHP + MySQL website system created to replace the legacy ASP/LankeCMS system on shengtuo-tractor.com. Designed for Linux hosting with modern SEO and responsive design.

**Location:** `/home/ubuntu/shengtuo-website/`

## Architecture

```
shengtuo-website/
├── admin/                  # Admin panel (login.php, index.php)
├── assets/{css,js,images}  # Static assets
├── config/
│   ├── database.php       # DB config + site settings
│   └── database.sql       # Full schema + seed data
├── includes/
│   └── functions.php      # Helper functions (auth, upload, SEO, etc.)
├── templates/
│   ├── header.php         # Shared header (nav, meta, structured data)
│   └── footer.php         # Shared footer (links, contact, WhatsApp)
├── uploads/{products,news,sliders}
├── .htaccess              # Apache rewrite + security + caching
├── index.php              # Homepage
├── sitemap.php            # Dynamic XML sitemap generator
├── robots.php             # Dynamic robots.txt
└── README.md              # Full installation guide
```

## Tech Stack

- **Backend:** PHP 7.4+ / 8.0+ with PDO
- **Database:** MySQL 5.7+ / MariaDB 10.2+
- **Frontend:** Bootstrap 5 + Font Awesome 6
- **Server:** Apache 2.4+ with mod_rewrite (or Nginx)

## Key Features

### SEO Built-in
- Semantic HTML5 structure
- Open Graph + Twitter Card meta tags
- JSON-LD structured data (Organization, Product, BreadcrumbList)
- Dynamic sitemap.xml and robots.txt
- Clean URLs via .htaccess rewrite
- HTTPS enforcement
- Gzip compression + browser caching

### Admin Panel
- Login: `/admin/` (default: admin / shengtuo2026)
- Product CRUD with categories
- News management
- Slider management
- Message inbox
- Page content editor
- Site settings

### Responsive Design
- Bootstrap 5 grid system
- Mobile-first approach
- WhatsApp floating button
- Back-to-top button
- Lazy loading images

## Database Tables

| Table | Purpose |
|-------|---------|
| admins | Admin users |
| categories | Product categories |
| products | Product catalog |
| news_categories | News categories |
| news | News articles |
| sliders | Homepage carousel |
| cases | Success cases |
| downloads | Downloadable files |
| messages | Contact form submissions |
| pages | Static pages (about, contact, etc.) |
| certificates | ISO/CE certificates |
| settings | Site-wide config |

## Deployment Steps

### 1. MySQL Database Setup

When MySQL root password is unknown, use `debian-sys-maint` credentials:

```bash
# Get debian-sys-maint password
sudo cat /etc/mysql/debian.cnf | grep password | head -1

# Create database
sudo mysql -u debian-sys-maint -p'PASS' -e \
  "CREATE DATABASE IF NOT EXISTS shengtuo_website CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# Create dedicated app user (never use root!)
sudo mysql -u debian-sys-maint -p'PASS' -e \
  "CREATE USER IF NOT EXISTS 'shengtuo'@'localhost' IDENTIFIED BY 'ShengTuo2026!';
   GRANT ALL PRIVILEGES ON shengtuo_website.* TO 'shengtuo'@'localhost';
   FLUSH PRIVILEGES;"

# Import schema + seed data
sudo mysql -u shengtuo -p'ShengTuo2026!' shengtuo_website < config/database.sql
```

**⚠️ Update database.php** to use the dedicated user:
```php
define('DB_USER', 'shengtuo');     // not 'root'
define('DB_PASS', 'ShengTuo2026!'); // not ''
```

### 2. Set Permissions

### Nginx + PHP-FPM (verified 2026-05-29)

Full template and pitfalls: see `references/nginx-php-fpm-deployment.md`

```bash
# 1. Create nginx config (must use sudo tee for /etc/nginx/)
sudo tee /etc/nginx/sites-available/site-name > /dev/null << 'EOF'
server {
    listen 80;
    server_name sub.example.com;
    root /home/ubuntu/shengtuo-website;
    index index.html index.htm index.php;  # ⚠️ html BEFORE php!
    location / {
        try_files $uri $uri/ /index.php?$query_string =404;  # ⚠️ =404 critical!
    }
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.3-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
    error_page 404 /404.html;
    location = /404.html { internal; }
}
EOF

# 2. Enable and test
sudo ln -sf /etc/nginx/sites-available/site-name /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# 3. Set ownership
sudo chown -R www-data:www-data /home/ubuntu/shengtuo-website
```

**Key pitfalls:**
- `index index.php ...` makes PHP execute even when index.html exists → put html first
- Missing `=404` in try_files returns 200 for ALL URLs (including nonexistent)
- `require_once __DIR__ . '/database.php'` in includes/ looks in includes/, not config/ → use `__DIR__ . '/../config/database.php'`
- `write_file` tool refuses `/etc/nginx/` paths → use `sudo tee` in terminal
- Cloudflare can override robots.txt with its managed version → check both
- Remove test.php/phpinfo() before production → exposes server config

## Migration from ASP

The PHP system replaces the LankeCMS ASP system. Key differences:

| Aspect | Old (ASP) | New (PHP) |
|--------|-----------|-----------|
| Server | Windows/IIS | Linux/Apache |
| Database | MySQL 5.1 | MySQL 5.7+ |
| Templates | Inc/*.asp includes | templates/*.php |
| Admin | /admin_v19 | /admin/ |
| SEO | Manual | Built-in |
| Mobile | Fixed 980px | Responsive |
| Flash | focus.swf | HTML5 slider |

## Mono + Apache Alternative

If keeping the ASP code is preferred, Mono can run it on Linux:
- **Disk:** ~500MB-1GB (Mono runtime + Apache + MySQL)
- **RAM:** ~300-500MB base, 1-2GB under load
- **Recommended:** 2 CPU, 2GB RAM, 20GB disk
- **SEO impact:** Positive (faster, HTTPS, better uptime)

## Test Domain Deployment (sub.aiv.qzz.io)

Verified deployment on 2026-05-29:
- **Server:** 43.155.135.188 (local)
- **Web:** Nginx + PHP 8.3-FPM
- **DB:** MySQL (user: shengtuo, db: shengtuo_website)
- **Root:** /home/ubuntu/shengtuo-website/
- **Config:** /etc/nginx/sites-available/sub-aiv

**Deployment steps actually used:**
1. `sudo tee` nginx config to `/etc/nginx/sites-available/sub-aiv`
2. `sudo ln -sf` to enable, `sudo nginx -t && sudo systemctl reload nginx`
3. Get `debian-sys-maint` password from `/etc/mysql/debian.cnf`
4. Create database + user via `sudo mysql -u debian-sys-maint`
5. Import `config/database.sql` with new user
6. Insert sample products/news/cases via separate SQL
7. Fix `require_once __DIR__ . '/database.php'` → `__DIR__ . '/../config/database.php'` in `includes/functions.php`
8. Set `index index.html index.htm index.php` (html before php!)
9. Set `chown -R www-data:www-data` on site directory
10. Create static `index.html` for fast homepage (bypass PHP/DB)

**Key lesson:** Always create a static `index.html` alongside `index.php` — if PHP/DB has issues, the homepage still loads.

## ⚠️ Admin Password Hash Mismatch

The `config/database.sql` inserts admin with hash for "password", NOT "shengtuo2026". Login will fail until you update the hash. See `references/php-website-admin-panel.md` for the fix.

**Quick fix:**
```bash
PASSWORD_HASH=$(php -r "echo password_hash('shengtuo2026', PASSWORD_DEFAULT);")
sudo mysql -u shengtuo -p'ShengTuo2026!' -e \
  "USE shengtuo_website; UPDATE admins SET password_hash = '$PASSWORD_HASH' WHERE username = 'admin';"
```

## Admin Panel CRUD Pages

See `references/php-website-admin-panel.md` for complete admin page templates (products, news, messages management).

**Test results:**
- Homepage: 200 OK (0.054s)
- Sitemap: 200 OK
- Robots.txt: 200 OK
- 404 page: 404 OK
- SEO checker: 200 OK
- DB connection: 8 products, 4 news, 2 cases loaded
