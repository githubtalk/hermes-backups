# shengtuo-tractor.com ASP 动态页面完整清单

## ASP 索引文件列表

shengtuo-tractor.com 有 6 个 ASP 动态索引文件，**sitemap.html 不包含这些链接**，
批量更新 CSS 引用时必须单独处理。

| 目录 | ASP 文件 | CSS 相对路径 | 说明 |
|------|----------|-------------|------|
| products/ | index.asp | `../css/style.css` | 产品分类列表页 |
| News/ | index.asp | `../css/style.css` | 新闻列表页 |
| cases/ | index.asp | `../css/style.css` | 案例展示列表页 |
| download/ | index.asp | `../css/style.css` | 下载中心列表页 |
| Inquiry/ | index.asp | `../css/style.css` | 询盘表单页 |
| message/ | index.asp | `../css/style.css` | 留言板页面 |

## 批量更新 ASP 文件工作流

```python
import subprocess

asp_files = [
    'products/index.asp',
    'News/index.asp',
    'cases/index.asp',
    'download/index.asp',
    'Inquiry/index.asp',
    'message/index.asp',
]

for asp_file in asp_files:
    # 1. 下载
    dl = subprocess.run(
        ['curl', '-s', '-u', 'shanweituo:C2r3h2q7K3',
         f'ftp://shanweituo.gotoftp4.com/wwwroot/{asp_file}'],
        capture_output=True, text=True
    )
    
    if dl.returncode != 0 or not dl.stdout:
        print(f"跳过 {asp_file}")
        continue
    
    # 2. 替换 CSS 引用
    content = dl.stdout
    new_content = content.replace('../css/style.css', '../css/style5.css')
    
    # 3. 保存并上传
    local_name = asp_file.replace('/', '_')
    with open(f'/tmp/{local_name}', 'w') as f:
        f.write(new_content)
    
    ul = subprocess.run(
        ['curl', '-s', '-T', f'/tmp/{local_name}',
         '-u', 'shanweituo:C2r3h2q7K3',
         f'ftp://shanweituo.gotoftp4.com/wwwroot/{asp_file}'],
        capture_output=True, text=True
    )
    
    if ul.returncode == 0:
        print(f"✅ 更新: {asp_file}")
    else:
        print(f"❌ 失败: {asp_file}")
```

## 完整站点 CSS 更新流程

当需要更新整个站点的 CSS 时，按以下顺序操作：

### 第1步：上传新 CSS 文件
```bash
# 使用新文件名绕过 Cloudflare 缓存
curl -T /tmp/style-beautified.css -u "shanweituo:C2r3h2q7K3" \
  ftp://shanweituo.gotoftp4.com/wwwroot/css/style5.css
```

### 第2步：更新静态 HTML 页面（从 sitemap）
```python
# 从 sitemap.html 提取所有 URL
# 下载 → 替换 CSS 引用 → 上传
# 覆盖：index.html, about/*.html, products/*.html, News/*.html, cases/*.html, download/*.html
```

### 第3步：更新 ASP 索引文件（6个）
```python
# 按上面的 asp_files 列表逐个更新
```

### 第4步：更新模板文件（7个）
```bash
# 模板文件位置：/wwwroot/template/
# index.htm, about.htm, download.htm, showcases.htm, ShowNews.htm, showshop.htm, webtitu.htm
```

### 第5步：验证
```bash
# 验证所有页面使用新 CSS
for page in "/" "/products/" "/products/58.html" "/about/2.html" \
            "/News/" "/cases/" "/download/" "/Inquiry/" "/message/"; do
    echo -n "$page: "
    curl -s "https://www.shengtuo-tractor.com$page" | grep -o "style5.css" || echo "❌ 未更新"
done
```

## 常见陷阱

1. **sitemap 不含 ASP 页面**：sitemap.html 只有静态 HTML 链接
2. **ASP 文件用相对路径**：`../css/style.css`（不是 `css/style.css`）
3. **模板更新 ≠ 页面更新**：修改 template/*.htm 后，已生成的页面不会自动更新
4. **Cloudflare 缓存**：必须用新文件名，版本参数 `?v=xxx` 不够可靠

## ASP 模板系统（Inc/ 目录）

ASP 页面的 HTML 结构由 `Inc/` 目录下的模板 include 文件控制，不是写在 `.asp` 文件里。

### 模板 include 关系

```
products/index.asp
  ├── #include file="../Inc/utf-8.asp"      ← 编码设置
  ├── #include file="../Inc/sql.asp"        ← SQL 工具
  ├── #include file="../Inc/conn.asp"       ← 数据库连接
  ├── #include file="../Inc/config.asp"     ← 全站配置（从 DB config 表读取）
  ├── #include file="../Inc/page.asp"       ← 分页工具
  ├── #include file="../Inc/CSQL.asp"       ← CSQL 工具
  ├── #include file="../Inc/header.asp"     ← 页面头部
  ├── #include file="../Inc/left.asp"       ← 左侧导航栏
  │     ├── #include file="../module/left.asp"  ← 产品分类导航（DB查询）
  │     └── #include file="hot.asp"             ← CONTACT US 侧边栏
  └── #include file="../Inc/foot.asp"       ← Footer + 浮动栏 + 分享按钮
```

### 关键模板文件

| 文件 | 路径 | 控制内容 |
|------|------|---------|
| foot.asp | Inc/foot.asp | Footer 区域 + eqq 浮动栏 + share 分享按钮 |
| hot.asp | Inc/hot.asp | 侧边栏 CONTACT US 联系信息 |
| left.asp | Inc/left.asp | 左侧产品分类导航 |
| header.asp | Inc/header.asp | 页面头部 |
| config.asp | Inc/config.asp | 数据库配置读取 |
| eqq.asp | module/eqq.asp | 旧浮动联系栏（MSN/QQ/淘宝）生成 |

### 数据库配置表（config 表）

ASP 模板通过 `config("字段名")` 读取数据库配置：

| 字段 | 用途 | 模板调用 |
|------|------|---------|
| copyright | 版权文本（⚠️ 包含注入脚本） | `config("copyright")` |
| beian | ICP 备案号 | `config("beian")` |
| dz | 公司地址 | `config("dz")` |
| tel | 电话号码 | `config("tel")` |
| fax | 传真号码 | `config("fax")`（通常为空） |
| mail | 邮箱地址 | `config("mail")` |
| name | 联系人姓名 | `config("name")` |
| share | 分享按钮代码（⚠️ 包含 AddThis） | `config("share")` |

### 踩坑记录

**1. config("copyright") 包含注入脚本**
数据库的 copyright 字段值里嵌入了 AddThis + GA 代码。必须在 ASP 端用字符串函数清理（见主 SKILL.md）。

**2. eqq.asp 生成旧浮动联系栏**
`module/eqq.asp` 生成 MSN/QQ/淘宝的 rightDiv 浮动栏。移除方式：从 foot.asp 中删除 `#include file="../module/eqq.asp"` 和 `<%=eqq%>`。

**3. config("share") 生成 AddThis 分享按钮**
数据库 share 字段包含 AddThis 代码。移除方式：从 foot.asp 中删除 `<%=config("share")%>`。

**4. 修改模板后 ASP 页面自动生效，但静态 HTML 不会**
Inc/ 模板文件修改后，所有 ASP 动态页面会立即使用新模板。但之前手动生成的静态 HTML 页面（about/2.html 等）不会更新，需要单独处理。

### 批量修改模板 + 静态页面的完整流程

```
1. 修改 Inc/foot.asp（Footer + 浮动栏 + 分享按钮）
2. 修改 Inc/hot.asp（侧边栏 CONTACT US）
3. 验证 ASP 页面：curl -s https://www.shengtuo-tractor.com/products/ | grep "rightDiv\|addthis"
4. 批量清理静态 HTML 页面（使用 batch_clean_footer.sh 脚本）
5. 验证所有页面干净
```
