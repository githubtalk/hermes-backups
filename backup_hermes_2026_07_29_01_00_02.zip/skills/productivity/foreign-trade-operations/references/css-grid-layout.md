# CSS Grid Layout Optimization for B2B Websites

## Layout System
Replace Bootstrap row/col with CSS Grid for cleaner, more predictable layouts.

### Grid Classes
```css
/* Product grid: 4 columns on desktop */
.product-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.5rem;
}

/* Responsive breakpoints */
@media (max-width: 1199.98px) { .product-grid { grid-template-columns: repeat(3, 1fr); } }
@media (max-width: 991.98px) { .product-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 575.98px) { .product-grid { grid-template-columns: 1fr; } }
```

### Section System
```css
.section { padding: 5rem 0; }
.section-sm { padding: 3rem 0; }
.section-white { background: #fff; }
.section-light { background: var(--primary-light); }
.section-gray { background: var(--gray-50); }
.section-dark { background: var(--gray-900); color: #fff; }
```

### Section Header Pattern
```html
<div class="section-header reveal">
    <span class="section-badge">Category</span>
    <h2 class="section-title">Title</h2>
    <p class="section-subtitle">Description</p>
</div>
```

### Alternating Backgrounds
Always alternate: white → light → gray → white → light
Never two same backgrounds adjacent.

## Card Patterns
- Product cards: 16px border-radius, 4:3 aspect ratio images
- Category cards: 2 columns, 320px height, overlay gradient
- Feature boxes: icon circle + title + description
- Testimonial cards: quote icon + stars + text + author

## Inline Style Elimination
Move ALL inline `style=""` to CSS classes. Benefits:
- Smaller HTML (saves ~30% on pages with many inline styles)
- Consistent styling
- Easier maintenance
- Better caching (CSS cached separately)

## Verification
```bash
# Count inline styles (should be minimal)
curl -s https://site/ | grep -c 'style="'

# Check grid layout working
# In browser console:
document.querySelector('.product-grid') ? 
  getComputedStyle(document.querySelector('.product-grid')).display : 'missing'
```
