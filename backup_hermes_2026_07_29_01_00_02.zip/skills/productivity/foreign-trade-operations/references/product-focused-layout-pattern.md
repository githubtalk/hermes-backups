# Product-Focused Layout Pattern

## When to Use
用户要求"以产品宣传为主导"、"产品优先"、"product-focused"时，将首页从公司介绍优先改为产品展示优先。

## Homepage Section Ordering (产品主导)

```
1. Hero Slider (双按钮: Browse Products + Get Quote)
2. Product Category Cards (分类卡片区 — 按类别浏览)
3. HP Range Showcase (马力范围展示 — 4档位卡片)
4. Featured Products (推荐产品 — 带徽章+HP标签+Tab筛选)
5. Hot Products Strip (热门产品条 — 深色背景横向展示)
6. Why Choose Us (信任模块)
7. Trust Bar (认证徽章)
8. Testimonials (客户评价)
9. Latest News (新闻 — 精简为3条)
10. Company Intro (公司简介 — 压缩为一段式，移到下方)
11. Product CTA Strip (金色渐变行动号召)
12. Contact CTA (联系方式)
```

**对比旧布局**（公司优先）：Hero → Company Intro → Stats → Featured Products(5个) → Why Us → News → Trust → Testimonials → CTA

## CSS File: product-focus-v4.css

### Category Cards (分类卡片)
```css
.category-card { height: 280px; border-radius: 16px; overflow: hidden; }
.category-card-bg { background-size: cover; transition: transform 0.6s; }
.category-card:hover .category-card-bg { transform: scale(1.08); }
.category-card-overlay { gradient遮罩 + flex-end布局 }
.category-count { 右上角产品数量标签 }
```

### HP Range Cards (马力范围卡片)
```css
.hp-range-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.25rem; }
.hp-range-card { border: 2px solid transparent; }
.hp-range-card::before { 顶部4px彩色条, scaleX(0) → scaleX(1) on hover }
.hp-range-number { font-size: 2.2rem; font-weight: 800; color: var(--primary); }
```

### Product Badges (产品徽章)
```css
.product-badge.hot { background: linear-gradient(135deg, #ef4444, #dc2626); animation: badge-pulse 2s; }
.product-badge.popular { background: var(--accent); }
.product-badge.new { background: var(--success); }
.product-badge.best-seller { background: var(--primary); }
```

### HP Tags (马力标签)
```css
.product-hp-tag { position: absolute; top: 12px; right: 12px; background: rgba(15,43,91,0.9); color: var(--accent); }
```

### Quick Actions (快速操作)
```css
.product-quick-actions { opacity: 0; transform: translateY(10px); transition: all 0.3s; }
.product-card:hover .product-quick-actions { opacity: 1; transform: translateY(0); }
```

### Hot Products Strip (热门产品条)
```css
.hot-products-strip { background: linear-gradient(135deg, var(--primary), #0a1e3d); }
.hot-product-item { display: flex; gap: 1rem; background: rgba(255,255,255,0.06); }
```

## Product Tab Filtering (分类Tab筛选)

### HTML
```html
<div class="product-tabs">
    <button class="product-tab active" data-filter="all">All Featured</button>
    <button class="product-tab" data-filter="cat-1">TRACTOR</button>
    <button class="product-tab" data-filter="cat-2">EQUIPMENT</button>
</div>
<div class="product-item" data-category="cat-1">...</div>
```

### JS (enhance-v3.js)
```javascript
const productTabs = document.querySelectorAll('.product-tab');
const productItems = document.querySelectorAll('.product-item');
productTabs.forEach(tab => {
    tab.addEventListener('click', function() {
        productTabs.forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        const filter = this.dataset.filter;
        productItems.forEach(item => {
            if (filter === 'all' || item.dataset.category === filter) {
                item.style.display = '';
                // 淡入动画
                item.style.opacity = '0';
                item.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    item.style.transition = 'all 0.4s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'translateY(0)';
                }, 50);
            } else {
                item.style.display = 'none';
            }
        });
    });
});
```

## HP Range Filtering (马力范围筛选)

### URL Pattern
`/products.html?hp=25-50` or `/products.html?hp=80-140`

### PHP Implementation (products.php)
```php
$hpRange = $_GET['hp'] ?? null;
if ($hpRange) {
    $parts = explode('-', $hpRange);
    if (count($parts) == 2) {
        $minHp = (int)$parts[0];
        $maxHp = (int)$parts[1];
        $stmt = $db->prepare("SELECT ... WHERE is_active = 1 AND category_id = 1");
        $stmt->execute();
        $allProds = $stmt->fetchAll();
        $products = array_filter($allProds, function($p) use ($minHp, $maxHp) {
            if (empty($p['horsepower']) || $p['horsepower'] === 'N/A') return false;
            preg_match_all('/\d+/', $p['horsepower'], $matches);
            if (empty($matches[0])) return false;
            $hp = (int)$matches[0][0];
            return $hp >= $minHp && $hp <= $maxHp;
        });
        $products = array_values($products);
    }
}
```

### Dynamic Page Title
```php
if ($hpRange) {
    $pageTitle = $hpRange . 'HP Tractors - Shengtuo Tractor';
    $pageDescription = 'Browse tractors in the ' . $hpRange . 'HP range.';
}
```

## ⚠️ PHP Pitfall: fetchAll() Overwriting Filtered Results

**问题：** if/elseif/else 分支内设置了 `$products`，但分支外有无条件的 `$products = $stmt->fetchAll()`，会覆盖分支内的结果。

```php
// ❌ 错误
if ($categoryId) {
    $stmt = ...; $stmt->execute();
} elseif ($hpRange) {
    $products = array_filter(...);  // 设置了 $products
} else {
    $stmt = ...;
}
$products = $stmt->fetchAll();  // 覆盖了 $hpRange 分支的结果！
```

```php
// ✅ 正确 — 每个分支都设置 $products
if ($categoryId) {
    $stmt = ...; $stmt->execute();
    $products = $stmt->fetchAll();
} elseif ($hpRange) {
    $products = array_filter(...);
    $products = array_values($products);
} else {
    $stmt = ...;
    $products = $stmt->fetchAll();
}
// 没有无条件的 $products = ...
```

**症状：** HP筛选页面显示"0 products found"，但直接查询数据库有数据。
**诊断：** 检查 if/elseif/else 块之后是否有无条件的 `$stmt->fetchAll()` 或 `$products = ...`。

## Product Badge Assignment Logic

```php
$badge = '';
if ($index < 2) $badge = 'hot';        // 前2个 = HOT
elseif ($index < 4) $badge = 'popular';  // 3-4 = POPULAR
elseif ($index < 6) $badge = 'best-seller'; // 5-6 = BEST SELLER
// 7+ = no badge
```

## Database Queries Used

```php
// 分类统计（带产品数量）
"SELECT c.*, COUNT(p.id) as product_count FROM categories c 
 LEFT JOIN products p ON p.category_id = c.id AND p.is_active = 1 
 WHERE c.is_active = 1 GROUP BY c.id ORDER BY c.sort_order"

// 推荐产品（扩展到8个）
"SELECT p.*, c.name as category_name FROM products p 
 LEFT JOIN categories c ON p.category_id = c.id 
 WHERE p.is_active = 1 AND p.is_featured = 1 
 ORDER BY p.sort_order LIMIT 8"
```
