# Glass Morphism & Visual Polish Pattern (B2B Website)

## Glass Morphism CSS

Backdrop-filter blur creates frosted glass effect on hero captions, navbars, and overlays.

### Hero Caption (Glass Morphism)

```css
.hero-slider .carousel-caption {
    z-index: 2;
    background: rgba(0,0,0,0.35);
    backdrop-filter: blur(12px) saturate(150%);
    -webkit-backdrop-filter: blur(12px) saturate(150%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 16px;
    padding: 2rem 2.5rem;
    bottom: 18%;
    left: 50%;
    transform: translateX(-50%);
    width: 90%;
    max-width: 720px;
    text-align: center;
}

/* Multi-layer gradient overlay on hero images */
.hero-slider .carousel-item::after {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(
        180deg,
        rgba(0,0,0,0.15) 0%,
        rgba(0,0,0,0.05) 40%,
        rgba(0,0,0,0.35) 75%,
        rgba(0,0,0,0.55) 100%
    );
    pointer-events: none;
    z-index: 1;
}
```

### Sticky Navbar (Glass Morphism on Scroll)

```css
.navbar.sticky-top {
    transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
    border-bottom: 1px solid rgba(0,0,0,0.04);
}

.navbar.sticky-top.scrolled {
    background: rgba(255,255,255,0.92) !important;
    backdrop-filter: blur(16px) saturate(180%);
    -webkit-backdrop-filter: blur(16px) saturate(180%);
    box-shadow: 0 2px 20px rgba(0,0,0,0.06);
    border-bottom: 1px solid rgba(0,0,0,0.06);
}
```

**JS (b2b-enhance.js):**
```javascript
function initStickyNav() {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;
    window.addEventListener('scroll', () => {
        navbar.classList.toggle('scrolled', window.scrollY > 50);
    });
}
```

### Trust Badges (Half-transparent pills)

```css
.hero-trust-item {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.15);
    padding: 0.35rem 0.8rem;
    border-radius: 25px;
    font-size: 0.78rem;
    font-weight: 600;
    color: rgba(255,255,255,0.9);
    backdrop-filter: blur(4px);
}
```

## Visual Polish CSS Layering (sub.aiv.qzz.io)

CSS files load in order, each overriding earlier ones:

1. `bundle-v7.min.css` (77KB) — Base styles, variables, components
2. `b2b-enhance.css` (14KB) — B2B elements (WhatsApp, back-to-top, partners)
3. `visual-polish-v8.css` (37KB, gzip 8KB) — Glass morphism, shadows, hover effects

**Key:** New visual polish file goes LAST in header.php `<link>` tags. No `!important` needed — CSS cascade handles overrides.

**Header.php pattern:**
```php
<link href="/assets/css/bundle-v7.min.css?v=1780140818" rel="stylesheet">
<link href="/assets/css/b2b-enhance.css?v=1780141327" rel="stylesheet">
<link href="/assets/css/visual-polish-v8.css?v=<?= time() ?>" rel="stylesheet">
```

## ⚠️ Pitfall: JS/CSS Class Mismatch for Scroll Animations

**Problem:** CSS defines `.reveal.revealed { opacity: 1; }` but JS adds `.active` class. Result: 45 elements stay invisible (opacity: 0).

**Diagnosis:**
```javascript
document.querySelectorAll('.reveal').length;          // 45 elements
document.querySelectorAll('.reveal.revealed').length;  // 0 — CSS class not added!
document.querySelectorAll('.reveal.active').length;    // 45 — wrong class!
```

**Fix:** Update JS to match CSS class name:
```javascript
// ❌ Wrong — CSS uses .revealed
entry.target.classList.add('active');

// ✅ Correct — matches CSS
entry.target.classList.add('revealed');
```

**Prevention:** When creating scroll animations, pick ONE class name and use it consistently in both CSS and JS. Common convention: `.revealed` (not `.active`, which conflicts with Bootstrap's active state).

## Product Card Visual Enhancements

```css
.product-card-modern {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
    border: 1px solid rgba(0,0,0,0.04);
    transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
}

.product-card-modern:hover {
    box-shadow: 0 16px 40px rgba(15,43,91,0.12), 0 6px 12px rgba(0,0,0,0.04);
    transform: translateY(-6px);
    border-color: rgba(212,168,67,0.15);
}
```

## Carousel Controls (Hover reveal)

```css
.hero-slider .carousel-control-prev,
.hero-slider .carousel-control-next {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(8px);
    opacity: 0;
    transition: all 0.3s ease;
    border: 1px solid rgba(255,255,255,0.2);
}

.hero-slider:hover .carousel-control-prev,
.hero-slider:hover .carousel-control-next {
    opacity: 1;
}
```

## Custom Scrollbar

```css
::-webkit-scrollbar { width: 8px; }
::-webkit-scrollbar-track { background: #F3F4F6; }
::-webkit-scrollbar-thumb {
    background: linear-gradient(180deg, #1B3A5C, #D4A843);
    border-radius: 4px;
}
```

## Performance Impact

- visual-polish-v8.css: 37KB raw, **8KB gzipped**
- Page load time: **0.13 seconds** (unchanged)
- All pages verified HTTP 200 after adding new CSS

## Complete Section CSS Patterns (visual-polish-v8.css)

The visual-polish-v8.css covers ALL sections, not just glass morphism. Key selectors:

| Section | Key Class | Notable Style |
|---------|-----------|---------------|
| Hero caption | `.hero-slider .carousel-caption` | backdrop-filter blur + saturate |
| Hero overlay | `.hero-slider .carousel-item::after` | 4-stop gradient overlay |
| Hero controls | `.carousel-control-prev/next` | Hover reveal, 50px circle |
| Hero indicators | `.carousel-indicators button` | Gold active bar |
| Category cards | `.category-card-modern` | Gradient overlay, hover scale |
| Product cards | `.product-card-modern` | Shadow + border + hover translateY(-6px) |
| Product badges | `.card-badge.badge-hot/popular/bestseller` | Gradient backgrounds |
| Product overlay | `.card-overlay` | Gradient fade-in on hover |
| Feature boxes | `.feature-box-modern` | Icon circle gradient, hover gold |
| Stats | `.stat-number` | Blue→gold gradient text |
| Testimonials | `.testimonial-card-modern` | Top gradient bar, quote icon |
| Trust badges | `.trust-icon` | Hover gold transform |
| News cards | `.news-card-modern` | Image hover zoom |
| HP range | `.hp-range-card` | Top bar scale animation |
| Certs | `.cert-item` | 3:4 aspect ratio, gold border hover |
| Partners | `.partner-section` | Grayscale → color on hover |
| Newsletter | `.newsletter-form` | Pill-shaped input + button |
| Footer | `.footer-modern` | 3px gradient top border |
| Buttons | `.btn-modern-accent/outline` | 30px border-radius, shadow |
| Scrollbar | `::-webkit-scrollbar` | Blue→gold gradient thumb |

**Responsive breakpoints:** 991px (tablet), 767px (mobile), 575px (small mobile)
**Key responsive changes:** Hero caption shrinks, trust badges hide on mobile, newsletter stacks vertically, stats grid 2-col, HP grid 2-col, cert gallery 2-col.
