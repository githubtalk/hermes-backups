# Comprehensive SEO Optimization Patterns for PHP Websites

## Overview

Complete SEO implementation for a PHP + MySQL business website, covering technical SEO, structured data, PWA support, and performance optimization. All files located at `/home/ubuntu/shengtuo-website/`.

## Architecture

```
includes/seo.php           # Core SEO class (Meta, JSON-LD, Breadcrumbs, Sitemap)
config/seo.php             # Page-specific meta configurations
admin/seo-checker.php      # SEO analysis tool (scores 0-100)
templates/header.php       # Dynamic meta tag generation
.htaccess                  # Apache SEO/performance config
robots.txt                 # Crawler configuration
sitemap.xml                # Static sitemap
sitemap.php                # Dynamic sitemap generator
manifest.json              # PWA configuration
service-worker.js          # Offline support + caching
404.html / 500.html / offline.html  # Error pages
```

## SEO Class (`includes/seo.php`)

### Core Methods

```php
$seo = new SEO($pdo, SITE_URL);

// Generate complete meta tags
$seo->generateMetaTags($title, $description, $keywords, $url, $image);

// Generate JSON-LD structured data
$seo->generateJsonLD('organization');    // Company info
$seo->generateJsonLD('product', $data);  // Product schema
$seo->generateJsonLD('article', $data);  // News article
$seo->generateJsonLD('breadcrumb', ['items' => $items]);
$seo->generateJsonLD('website');         // SearchAction
$seo->generateJsonLD('local_business');  // Local SEO

// Generate breadcrumb navigation
$seo->generateBreadcrumbs([
    ['name' => 'Home', 'url' => '/'],
    ['name' => 'Products', 'url' => '/products.html'],
    ['name' => 'Tractor Model', 'url' => '']
]);

// Generate sitemap XML
$sitemap = $seo->generateSitemap();

// Generate hreflang tags
$seo->generateHreflang($currentUrl, ['en', 'zh']);
```

### Schema.org Types Implemented

| Type | Use Case | Key Fields |
|------|----------|------------|
| Organization | Company identity | name, url, logo, address, contactPoint, sameAs |
| LocalBusiness | Local SEO | geo, openingHoursSpecification, telephone |
| WebSite | Site search | potentialAction.SearchAction |
| Product | Product pages | name, description, brand, offers |
| Article | News articles | headline, datePublished, publisher |
| BreadcrumbList | Navigation | itemListElement with position |

### Meta Tag Template (header.php)

```php
// Dynamic per-page configuration
$pageTitle = 'Product Detail - Shengtuo Tractor';
$pageDescription = 'View Shengtuo tractor specifications';
$pageKeywords = 'tractor, agricultural machinery';
$pageImage = '/assets/images/products/model.jpg'; // OG image

// header.php auto-generates:
// - Primary meta (title, description, keywords, robots)
// - Canonical URL
// - Open Graph (type, url, title, description, image, site_name, locale)
// - Twitter Card (card, url, title, description, image)
// - Geo meta (region, placename, position, ICBM)
// - Apple/mobile meta (theme-color, apple-mobile-web-app-*)
```

## Page-Specific SEO Config (`config/seo.php`)

```php
$pageMeta = [
    'home' => [
        'title' => 'Shengtuo Tractor - Professional Agricultural Machinery Manufacturer',
        'description' => 'Leading Chinese manufacturer of high-quality agricultural tractors...',
        'keywords' => 'tractor, agricultural machinery, farming equipment, China tractor'
    ],
    'products' => [
        'title' => 'Our Products - Shengtuo Agricultural Tractors and Equipment',
        'description' => 'Explore our full range of agricultural tractors...',
        'keywords' => 'tractor products, agricultural equipment, farming machines'
    ],
    // ... contact, about, news
];

// Helper functions
$pageMeta = getPageMeta('products', ['title' => 'Custom Title']);
$title = generateMetaTitle('Products', true); // "Products | Shengtuo Tractor"
$desc = optimizeMetaDescription($longText);    // Truncate at 160 chars
$keywords = extractKeywords($content, 10);     // Auto-extract from text
```

## .htaccess Optimization

### Key Rules

```apache
# SEO-friendly URLs
RewriteRule ^product/([a-zA-Z0-9-]+)/?$ product.php?slug=$1 [L,QSA]
RewriteRule ^news/([a-zA-Z0-9-]+)/?$ news_detail.php?slug=$1 [L,QSA]

# Remove trailing slash
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)/$ /$1 [R=301,L]

# Gzip compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/css application/javascript
    AddOutputFilterByType DEFLATE application/json image/svg+xml
</IfModule>

# Browser caching
<IfModule mod_expires.c>
    ExpiresByType text/css "access plus 1 week"
    ExpiresByType application/javascript "access plus 1 week"
    ExpiresByType image/jpeg "access plus 1 month"
    ExpiresByType image/webp "access plus 1 month"
    ExpiresByType font/woff2 "access plus 1 month"
</IfModule>

# Security headers
Header set X-Content-Type-Options "nosniff"
Header set X-Frame-Options "SAMEORIGIN"
Header set X-XSS-Protection "1; mode=block"
Header set Referrer-Policy "strict-origin-when-cross-origin"

# Block sensitive files
<FilesMatch "\.(log|sql|bak|backup|old)$">
    Order allow,deny
    Deny from all
</FilesMatch>
```

## robots.txt Pattern

```
User-agent: *
Allow: /
Disallow: /admin/
Disallow: /config/
Disallow: /includes/

Sitemap: https://www.shengtuo-tractor.com/sitemap.xml
Crawl-delay: 1

# Block aggressive crawlers
User-agent: AhrefsBot
Disallow: /
```

## PWA Support

### manifest.json Key Fields

```json
{
    "name": "Shengtuo Tractor - Agricultural Machinery Manufacturer",
    "short_name": "Shengtuo",
    "start_url": "/",
    "display": "standalone",
    "theme_color": "#0066cc",
    "icons": [
        {"src": "/assets/images/icons/icon-192x192.png", "sizes": "192x192", "type": "image/png"},
        {"src": "/assets/images/icons/icon-512x512.png", "sizes": "512x512", "type": "image/png"}
    ],
    "shortcuts": [
        {"name": "Products", "url": "/products.html"},
        {"name": "Contact", "url": "/contact.html"}
    ]
}
```

### Service Worker Caching Strategy

| Resource Type | Strategy | Cache Name |
|--------------|----------|------------|
| HTML pages | Network First | dynamic |
| CSS/JS | Stale While Revalidate | dynamic |
| Images | Cache First | images |
| API calls | Network First | dynamic |

## SEO Checker Tool (`admin/seo-checker.php`)

Checks performed:
- Meta tags (description, keywords, viewport)
- Title length (30-60 chars)
- Description length (70-160 chars)
- Image alt attributes
- Structured data presence
- Mobile viewport
- Performance (image count, inline styles)

Score: 100 - deductions per issue. Access at `/admin/seo-checker.php`.

## Error Pages

| Page | Status | Features |
|------|--------|----------|
| 404.html | 404 | Navigation links, contact info, GA event tracking |
| 500.html | 500 | Error details, support contact, timestamp |
| offline.html | - | Network status detection, auto-reload on reconnect |

## Sitemap Generation

### Static (sitemap.xml)
Pre-defined URLs with priority and changefreq.

### Dynamic (sitemap.php)
Queries database for products and news, generates XML with lastmod dates.

### Script (scripts/generate-sitemap.sh)
Bash script for cron job generation:
```bash
0 3 * * * /home/ubuntu/shengtuo-website/scripts/generate-sitemap.sh
```

## Breadcrumb Navigation

```php
$breadcrumbs = [
    ['name' => 'Home', 'url' => '/'],
    ['name' => 'Products', 'url' => '/products.html'],
    ['name' => 'Tractor ST-1200', 'url' => '']
];

// In template:
<?= $seo->generateBreadcrumbs($breadcrumbs) ?>

// Generates both HTML and JSON-LD BreadcrumbList schema
```

## SEO Best Practices Checklist

### Per-Page Requirements
- [ ] Unique title (30-60 chars)
- [ ] Unique description (70-160 chars)
- [ ] Canonical URL
- [ ] Open Graph tags
- [ ] H1 tag with primary keyword
- [ ] Image alt tags
- [ ] Internal links (3-5)
- [ ] Breadcrumb navigation

### Technical Requirements
- [ ] HTTPS enabled
- [ ] Mobile viewport
- [ ] Gzip compression
- [ ] Browser caching
- [ ] robots.txt configured
- [ ] sitemap.xml submitted
- [ ] 404 page exists
- [ ] Security headers

### Content Requirements
- [ ] Keyword density 2-3%
- [ ] Content length 300+ words
- [ ] Heading hierarchy (H1-H6)
- [ ] No duplicate content
- [ ] Image optimization (<200KB)
