# Anti-Patterns for Foreign Trade Site Work
## Destructive Operations
- **NEVER suggest `rm -rf` on production web directories.** User reacted with "垃圾" when this was suggested as a cleanup step.
- Always verify contents with `ls` before any deletion.
- Prefer `mv` to a quarantine directory; only delete after explicit user approval.
- When extracting tar files to `/root`, use a clean subdirectory with `--strip-components=1` to avoid scattering files into `/root`.

## Web Directory Cleanup
- Treat existing `/root/shengtuo-website` or equivalent site directories as state.
- Do not extract archives directly into `/root` without checking top-level directory names.
- Confirm via `ls -la` before and after any extraction or deletion.

## Nginx / PHP Troubleshooting
- 8087/8088 port conflicts: existing `sites-enabled/default` listens on `:80` inside container topology but may also block other ports; remove default after verifying real sites.
- `Permission denied` on `/root/*` => Nginx worker `www-data` needs `+rx` on `/root` and site dir.
- PHP-FPM socket commonly at `/run/php/php8.1-fpm.sock`; if missing, check if NGINX_PROXY_MANAGER itself uses a port, not socket.
- MySQL not installed => `apt install mysql-server` then `service mysql start`; create DB/user/table before app runs.

## Product / News Slug Routes
- `/product/{slug}` must map to `/product.php?slug={slug}` via nginx rewrite.
- `/news/{slug}` must map to `/news_detail.php?slug={slug}` via nginx rewrite.
- Ensure `try_files $uri $uri/ /index.php?$args;` exists in main `/` location; add slug rewrites in dedicated blocks BEFORE generic `\.php$` block.
