# CSS Concatenation Bugs

## Literal `\\n` Breaking Selectors
When concatenating CSS files (e.g., `cat file1.css file2.css > bundle.css`), a literal `\\n` (backslash+n, not newline) can get inserted at the boundary.

**Symptom**: Selector `.wa-float-btn` becomes `n .wa-float-btn` → styles don't apply, element appears unstyled.

**Detection**: 
```bash
grep -o '\\\\n' bundle.css  # finds literal \\n

# Or check specific selector:
grep 'wa-float-btn' bundle.css | head -5
```

**Fix**:
```bash
sed -i 's/\\\\n/\\n/g' bundle.css
```

**Prevention**: When building CSS bundles, use `echo "" >> bundle.css` between files instead of `\\n`.

---

# Background Color Preferences (China B2B Sites)

## User's Strong Preference: Light Backgrounds
The user explicitly rejected dark gradient backgrounds with white text. When asked about color changes, they said "还是不行" (still not working) and "去掉" (remove it).

**Acceptable backgrounds**:
- `#f0f4f8` (light gray-blue)
- `#e8eef5` (lighter gray-blue)  
- `#e8edf3 → #dce3ed` (subtle gradient)
- `#fff` (white)
- `var(--gray-50, #f9fafb)`

**NOT acceptable**:
- `linear-gradient(135deg, #1B3A5C, #0F2640)` — too dark
- `linear-gradient(135deg, #2c5f8a, #3a7ab5)` — still too dark
- Any background requiring white text (`color: #fff`)

## Section Padding Guidelines
- Standard sections: `3rem 0` (compressed from 4.5rem)
- Newsletter: `2rem 0` (compact)
- Category showcase (after carousel): `4rem 0 2rem` (user specifically restored this)
- CTA/Footer sections: `2.5rem 0`

## Newsletter Section Preferences
- `max-width: 560px` (not full width)
- Small fonts: h3 1.15rem, p 0.82rem, input/button 0.85rem
- Tight padding: `2rem 0`
- Input border: `1px solid #ccc`
- Button: accent color (`#D4A843`), white text

---

# Inline Styles Removal Pattern

## Problem
PHP templates with 27+ inline `style="..."` attributes are hard to maintain and override.

## Solution
1. Create a dedicated CSS file (e.g., `layout-optimize.css`)
2. Extract inline styles to CSS classes
3. Replace `style="padding:3rem 0;background:#fff;"` with `class="section section-white"`
4. Add CSS file to header.php after bundle

## Example Transformation
```php
<!-- Before -->
<section style="padding:3rem 0;background:var(--primary-light);">
    <div class="modern-section-title reveal">

<!-- After -->
<section class="section section-light">
    <div class="section-header reveal">
```

## CSS Class Naming Convention
- `.section` - base padding (5rem)
- `.section-sm` - small padding (3rem)
- `.section-white` - white background
- `.section-light` - light blue background
- `.section-gray` - gray background
- `.section-dark` - dark background with white text
- `.section-header` - centered title block
- `.section-badge` - uppercase label above title
- `.section-title` - main heading
- `.section-subtitle` - description text
