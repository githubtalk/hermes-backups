# 浮动联系栏移除 & WhatsApp 按钮

## 旧浮动联系栏（rightDiv + eqq.js）

shengtuo-tractor.com 左下角有旧的浮动联系栏，由 `eqq.js` 脚本生成，包含 MSN、QQ、淘宝等已废弃链接。

**触发词：** "去掉左下角的浮动联系栏"、"把 MSN/QQ 去掉"、"加个 WhatsApp"

### HTML 结构（需删除）

```html
<script type='text/javascript' src='/js/eqq.js'></script>
<div id='leftDiv' style='top:210px; left:10px;'></div>
<div id='rightDiv' style='top:210px; right:10px;'>
<div id='rightDiv_top'></div>
<div id='rightDiv_middle'>
<a href='msnim:chat?contact=mydemail@hotmail.com' target='blank'>
<img src='/images/msn.jpg' border='0' />
<span>&nbsp;Henry</span>
</a>
<a target='_blank' href='http://wpa.qq.com/msgrd?v=3&uin=307774615&Site=Henry&menu=yes'>
<img border='0' src='http://wpa.qq.com/pa?p=1:307774615:4'>
<span>&nbsp;Henry</span>
</a>
<a target='_blank' href='http://www.taobao.com/webww/ww.php?ver=3&touid=情系鸢飞&siteid=cntaobao&status=1&charset=utf-8'>
<img border='0' src='http://amos.alicdn.com/realonline.aw?v=2&uid=情系鸢飞&site=cntaobao&s=1&charset=utf-8' />
</a>
<a target='_blank' href='http://amos.alicdn.com/msg.aw?v=2&uid=agromachine&site=cnalichn&s=10&charset=UTF-8'>
<img border='0' src='http://amos.alicdn.com/online.aw?v=2&uid=agromachine&site=cnalichn&s=10&charset=UTF-8' />
</a>
</div>
<div id='rightDiv_bottom'></div>
</div>
```

### 删除方法

用 `execute_code` 精确匹配并删除整个 `rightDiv` 块：

```python
old_floating = '''<div id='rightDiv' style='top:210px; right:10px;'>
<div id='rightDiv_top'></div>
<div id='rightDiv_middle'>
...
</div>
<div id='rightDiv_bottom'></div>
</div>'''

content = content.replace(old_floating, '')

# 同时删除 eqq.js 引用
content = content.replace("<script type='text/javascript' src='/js/eqq.js'></script>", '')
```

**注意：** `leftDiv` 通常由 `eqq.js` 脚本动态生成，删除脚本引用后它就不会出现。但保险起见也删除 HTML 中的 `leftDiv`。

---

## WhatsApp 浮动按钮

**号码：** +86 138 0646 1474
**链接：** https://wa.me/8613806461474

### 方案1：CSS 类 + Inline SVG（推荐）

**HTML（插入到 `</body>` 前）：**
```html
<!-- WhatsApp Floating Button -->
<a href="https://wa.me/8613806461474" target="_blank" class="whatsapp-float" title="Chat with us on WhatsApp">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" fill="#fff">
        <path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/>
    </svg>
</a>
```

**CSS（添加到 CSS 文件末尾）：**
```css
/* WhatsApp Floating Button */
.whatsapp-float {
    position: fixed;
    bottom: 25px;
    right: 25px;
    z-index: 9999;
    cursor: pointer;
    background-color: #25D366;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    transition: all 0.3s ease;
}

.whatsapp-float:hover {
    background-color: #128C7E;
    transform: scale(1.1);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.4);
}

.whatsapp-float svg {
    width: 32px;
    height: 32px;
    fill: #fff;
}
```

### 方案2：纯 Inline 样式（不修改 CSS 文件）

适合快速添加，不需要额外 CSS 文件：

```html
<a href="https://wa.me/8613806461474" target="_blank" style="position:fixed;bottom:30px;right:30px;width:60px;height:60px;background:#25D366;color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:28px;box-shadow:0 4px 15px rgba(37,211,102,0.4);z-index:1000;text-decoration:none;">
  <svg viewBox="0 0 24 24" width="32" height="32" fill="white">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
  </svg>
</a>
```

---

## 完整工作流：移除旧联系栏 + 添加 WhatsApp

### ⚠️ 关键：必须同时更新所有子页面！

仅更新 `index.html` 不够。shengtuo-tractor.com 有 71+ 个静态 HTML 页面分布在子目录中，每个都独立加载 CSS 和包含浮动栏代码。

**子页面目录清单：**
- `about/` (5个: 2,3,6,7,8.html)
- `cases/` (13个: 31-43.html)
- `download/` (3个: 4,5,13.html)
- `News/` (13个: 66-78.html)
- `products/` (37个: 58-248.html)

### Step 1: 更新 index.html

1. 下载 `index.html`
2. 删除 `eqq.js` 引用、`leftDiv`、`rightDiv` 整个块
3. 在 `</body>` 前添加 WhatsApp 按钮 HTML
4. 上传修改后的 `index.html`

### Step 2: 更新 CSS 文件

1. 下载 CSS 文件，添加 WhatsApp 样式
2. 上传为新文件名（如 `style_v7.css`）绕过 CDN 缓存

### Step 3: 批量更新所有子页面（必须！）

**⚠️ sed 对嵌套 div 不可靠，必须用 Python：**

```python
import re
import subprocess

FTP = "ftp://shanweituo:C2r3h2q7K3@shanweituo.gotoftp4.com/wwwroot"

dirs = ['about', 'cases', 'download', 'News', 'products']
all_files = ['index.html']

for d in dirs:
    result = subprocess.run(['curl', '-s', '--list-only', f'{FTP}/{d}/'], capture_output=True, text=True)
    for f in result.stdout.strip().split('\n'):
        if '.html' in f:
            all_files.append(f"{d}/{f.strip()}")

for f in all_files:
    result = subprocess.run(['curl', '-s', f'{FTP}/{f}'], capture_output=True, text=True)
    content = result.stdout
    
    if 'rightDiv' in content or 'leftDiv' in content or 'msnim:chat' in content:
        # 用正则删除嵌套的 rightDiv 块（sed 不可靠！）
        content = re.sub(r'<div id=\'leftDiv\'[^>]*>.*?</div>', '', content, flags=re.DOTALL)
        content = re.sub(r'<div id=\'rightDiv\'[^>]*>.*?<div id=\'rightDiv_bottom\'[^>]*></div>\s*</div>', '', content, flags=re.DOTALL)
        content = re.sub(r'<div id=\'rightDiv[^\']*\'[^>]*>.*?</div>', '', content, flags=re.DOTALL)
        
        # 删除 Google+ 分享按钮
        content = re.sub(r'<!-- Place this tag where you want the share button to render\. -->.*?</script>', '', content, flags=re.DOTALL)
        content = re.sub(r'<div class="g-plus"[^>]*>.*?</div>', '', content, flags=re.DOTALL)
        
        # 添加 WhatsApp 按钮（如果没有）
        if 'whatsapp-float' not in content:
            whatsapp = '''\n<!-- WhatsApp Floating Button -->\n<a href="https://wa.me/8613806461474" target="_blank" class="whatsapp-float" title="Chat with us on WhatsApp">\n    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" fill="#fff"><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/></svg>\n</a>\n'''
            content = content.replace('</body>', whatsapp + '</body>')
        
        with open('/tmp/page_tmp.html', 'w') as file:
            file.write(content)
        subprocess.run(['curl', '-T', '/tmp/page_tmp.html', f'{FTP}/{f}'], capture_output=True)
        print(f"Updated: {f}")
```

### Step 4: 验证所有页面（必须！）

```python
# 验证旧浮动栏已移除
still_old = []
for f in all_files:
    r = subprocess.run(['curl', '-s', f'{FTP}/{f}'], capture_output=True, text=True)
    if 'rightDiv' in r.stdout or 'msnim:chat' in r.stdout:
        still_old.append(f)

# 验证 WhatsApp 按钮存在
no_wa = []
for f in all_files:
    r = subprocess.run(['curl', '-s', f'{FTP}/{f}'], capture_output=True, text=True)
    if 'whatsapp-float' not in r.stdout:
        no_wa.append(f)

if still_old: print(f"❌ Still has old bar: {still_old}")
if no_wa: print(f"❌ Missing WhatsApp: {no_wa}")
if not still_old and not no_wa: print("✅ All pages clean!")
```

### 常见陷阱

1. **sed 对嵌套 div 不可靠** — `rightDiv` 内部有多个嵌套 div，sed 正则会匹配错误的闭合标签。必须用 Python `re.DOTALL`。

2. **仅更新 index.html 不够** — 子页面独立加载 CSS 和包含浮动栏代码，必须批量更新 71+ 个页面。

3. **验证步骤不能省** — 更新后必须验证所有 72 个页面都已清理干净。2026-05-29 实战：第一次 sed 更新后仍有 44 个页面残留旧代码。

### Footer 清理（2026-05-29 新增）

子页面的 footer 可能仍有 AddThis、GA、Google+ 等残留代码。

**⚠️ 批量清理比逐个 patch 快得多（2026-05-29 实战验证）：**

当需要清理 50+ 页面时，用 `scripts/batch_clean_footer.sh` 一次性处理。逐个用 `patch` 工具需要多次工具调用，而批量脚本只需一次 `terminal` 调用。

**批量脚本核心模式（bash + 嵌套 Python）：**
```bash
for id in <ids>; do
  wget -q "$FTP/$dir/$id.html" -O "$local"
  python3 << 'PYEOF'  # 用 heredoc 嵌套 Python 清理
import re
# 读取 → 清理 footer/rightDiv/G+/Fax → 写回
PYEOF
  curl -s -T "$local" "$FTP/$dir/$id.html"
done
```

**脚本位置：** `scripts/batch_clean_footer.sh`

**用 `patch` 工具精确替换 footer 区域：**
```python
# 删除 AddThis 代码块
old_addthis = '''<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_floating_style addthis_32x32_style" style="left:12px;top:100px;">
<a class="addthis_button_preferred_1"></a>
<a class="addthis_button_preferred_2"></a>
<a class="addthis_button_preferred_3"></a>
<a class="addthis_button_preferred_4"></a>
<a class="addthis_button_compact"></a>
</div>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=xa-5122440b3fe9ccc6"></script>
<!-- AddThis Button END -->'''
content = content.replace(old_addthis, '')

# 删除 GA 脚本
content = re.sub(r'<script>\s*\(function\(i,s,o,g,r,a,m\).*?</script>', '', content, flags=re.DOTALL)

# 删除 Google+ 分享
content = re.sub(r'<!-- Place this tag where you want the share button to render\. -->.*?</script>', '', content, flags=re.DOTALL)
content = re.sub(r'<div class="g-plus"[^>]*>.*?</div>', '', content, flags=re.DOTALL)

# 删除空 Fax 字段
content = content.replace('<li>Fax：</li>', '')
```

**详细清理流程和标准 Footer 结构：** `references/footer-consistency-pattern.md`
