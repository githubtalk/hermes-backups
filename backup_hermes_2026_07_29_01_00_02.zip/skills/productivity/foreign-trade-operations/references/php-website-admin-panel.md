# PHP Website Admin Panel & Database Setup

## Admin Password Hash Fix (CRITICAL)

The `config/database.sql` inserts admin with hash `$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi` which is the Laravel default for the word **"password"**, NOT "shengtuo2026".

**Symptom:** Login with `admin` / `shengtuo2026` shows "Invalid username or password".

**Fix — update hash after DB import:**
```bash
PASSWORD_HASH=$(php -r "echo password_hash('shengtuo2026', PASSWORD_DEFAULT);")
sudo mysql -u shengtuo -p'ShengTuo2026!' -e \
  "USE shengtuo_website; UPDATE admins SET password_hash = '$PASSWORD_HASH' WHERE username = 'admin';"
```

**Verify login works:**
```bash
curl -s -X POST https://site/admin/login.php \
  -d "username=admin&password=shengtuo2026" \
  -c /tmp/cookies.txt -L -o /dev/null -w "%{http_code}"
# Should return 200 (login success, redirected to dashboard)
```

## MySQL Database Setup Workflow

### Step 1: Get debian-sys-maint credentials
```bash
sudo cat /etc/mysql/debian.cnf | grep password | head -1
```

### Step 2: Create database and user
```bash
sudo mysql -u debian-sys-maint -p'FOUND_PASSWORD' -e \
  "CREATE DATABASE IF NOT EXISTS shengtuo_website CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER IF NOT EXISTS 'shengtuo'@'localhost' IDENTIFIED BY 'ShengTuo2026!';
   GRANT ALL PRIVILEGES ON shengtuo_website.* TO 'shengtuo'@'localhost';
   FLUSH PRIVILEGES;"
```

### Step 3: Import schema
```bash
sudo mysql -u shengtuo -p'ShengTuo2026!' shengtuo_website < config/database.sql
```

### Step 4: Update config/database.php
```php
define('DB_USER', 'shengtuo');      // not 'root'
define('DB_PASS', 'ShengTuo2026!'); // not ''
```

### Step 5: Fix admin password hash (see CRITICAL section above)

### Step 6: Insert sample data (optional)
```bash
sudo mysql -u shengtuo -p'ShengTuo2026!' shengtuo_website < /tmp/sample_data.sql
```

## Shared Auth Template Pattern (Recommended)

Instead of duplicating sidebar/header/CSS in every admin page, create a shared `admin/auth.php`:

```php
<?php
// admin/auth.php — Include at top of every admin page
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$db = getDBConnection();
$csrfToken = generateCSRFToken();
$flashMsg = $_SESSION['flash_msg'] ?? '';
$flashType = $_SESSION['flash_type'] ?? 'success';
unset($_SESSION['flash_msg'], $_SESSION['flash_type']);
?>
<!DOCTYPE html>
<html><head><!-- Bootstrap + Font Awesome + shared admin CSS --></head>
<body>
    <div class="sidebar"><!-- shared nav with $currentPage active state --></div>
    <div class="main-content">
        <div class="admin-header"><!-- sticky header --></div>
        <div class="content-area">
            <?php if($flashMsg): ?>
            <div class="alert alert-<?= $flashType ?>"><?= escape($flashMsg) ?></div>
            <?php endif; ?>
```

Each page then only needs:
```php
<?php
$pageTitle = 'Products';
$currentPage = 'products';
require_once __DIR__ . '/auth.php';
// ... page-specific logic and HTML ...
// Close with: </div></div><script src="bootstrap.bundle.min.js"></script></body></html>
```

**Benefits:** Single source for sidebar, header, CSS, CSRF, flash messages, auth check. Active menu state via `$currentPage`.

## Admin Panel CRUD Pages

After `admin/index.php` (dashboard) and `admin/login.php`, create management pages:

| File | Purpose | Key Features |
|------|---------|-------------|
| `admin/products.php` | Product list | Table view, delete with confirm |
| `admin/categories.php` | Category list | CRUD for product categories |
| `admin/news.php` | News list | Category filter, date display |
| `admin/sliders.php` | Slider management | Image preview, sort order |
| `admin/messages.php` | Message inbox | Mark read, unread highlighting |
| `admin/pages.php` | Static pages | About, Contact, Culture pages |
| `admin/settings.php` | Site settings | Form with POST update, grouped by section (General/Contact/Social) |
| `admin/seo-checker.php` | SEO audit | URL input, score display |

### ⚠️ Pitfall: Dashboard Links Use Directory Paths

When `admin/index.php` is generated from a template, sidebar links may use directory-style paths instead of `.php` file paths:

```
# ❌ WRONG - directory style (returns 404)
/admin/products/
/admin/news/
/admin/messages/

# ✅ CORRECT - .php file style
/admin/products.php
/admin/news.php
/admin/messages.php
```

**Symptom:** All sidebar links in dashboard return 404.

**Fix — batch sed replacement:**
```bash
sudo sed -i 's|/admin/products/|/admin/products.php|g' /home/ubuntu/site/admin/index.php
sudo sed -i 's|/admin/categories/|/admin/categories.php|g' /home/ubuntu/site/admin/index.php
sudo sed -i 's|/admin/news/|/admin/news.php|g' /home/ubuntu/site/admin/index.php
sudo sed -i 's|/admin/sliders/|/admin/sliders.php|g' /home/ubuntu/site/admin/index.php
sudo sed -i 's|/admin/messages/|/admin/messages.php|g' /home/ubuntu/site/admin/index.php
sudo sed -i 's|/admin/pages/|/admin/pages.php|g' /home/ubuntu/site/admin/index.php
sudo sed -i 's|/admin/settings/|/admin/settings.php|g' /home/ubuntu/site/admin/index.php
```

**Also watch for compound errors** from overlapping sed patterns (e.g., `news.phpedit.php` instead of `news-edit.php`):
```bash
# Check for compound links
curl -s -b /tmp/cookies.txt https://site/admin/ | grep -oP 'href="/admin/[^"]*"' | sort | uniq
# Look for patterns like "news.phpedit.php" — fix with:
sudo sed -i 's|/admin/news.phpedit.php|/admin/news-edit.php|g' /home/ubuntu/site/admin/index.php
```

**Verification:**
```bash
# All should return 200
for page in products.php categories.php news.php sliders.php messages.php pages.php settings.php seo-checker.php; do
  curl -s -b /tmp/cookies.txt -o /dev/null -w "$page: %{http_code}\n" https://site/admin/$page
done
```

### Writing Admin Files

Files in admin/ are owned by www-data. Use `sudo tee`:

```bash
sudo tee /home/ubuntu/shengtuo-website/admin/products.php > /dev/null << 'EOFILE'
<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$db = getDBConnection();

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    header('Location: /admin/products.php?deleted=1');
    exit;
}

$products = $db->query("
    SELECT p.*, c.name as category_name 
    FROM products p 
    LEFT JOIN categories c ON p.category_id = c.id 
    ORDER BY p.sort_order, p.created_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<!-- Bootstrap 5 + sidebar nav + table with edit/delete buttons -->
EOFILE
```

## Settings Page Pattern

The settings page uses a self-posting form pattern with grouped sections:

```php
<?php
// Handle POST update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST as $key => $value) {
        if ($key !== 'submit') {
            $stmt = $db->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
            $stmt->execute([$value, $key]);
        }
    }
    $success = 'Settings updated successfully!';
}

// Load settings as key-value map
$settings = $db->query("SELECT * FROM settings ORDER BY id")->fetchAll();
$settingsMap = [];
foreach ($settings as $s) {
    $settingsMap[$s['setting_key']] = $s['setting_value'];
}
?>

<!-- Grouped form sections -->
<form method="POST">
    <div class="card mb-4">
        <div class="card-header"><h5>General Settings</h5></div>
        <div class="card-body">
            <div class="mb-3">
                <label class="form-label">Site Name</label>
                <input type="text" class="form-control" name="site_name" 
                       value="<?= escape($settingsMap['site_name'] ?? '') ?>">
            </div>
            <!-- more fields... -->
        </div>
    </div>
    <!-- Contact Information section -->
    <!-- Social Media section -->
    <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Settings</button>
</form>
```

## Static Homepage Fallback

Always create a static `index.html` alongside `index.php`. If PHP/DB has issues, the homepage still loads with full SEO meta tags, navigation, product previews, footer, and WhatsApp button.

## Verification Checklist

```bash
# 1. Database connection
curl -s https://site/db-test.php | grep "数据库连接成功"

# 2. Admin login
curl -s -X POST https://site/admin/login.php \
  -d "username=admin&password=shengtuo2026" -L -o /dev/null -w "%{http_code}"

# 3. Dashboard loads
curl -s -b /tmp/cookies.txt https://site/admin/ | grep "Dashboard"

# 4. Products page
curl -s -b /tmp/cookies.txt https://site/admin/products.php | grep "Products Management"
```

## Frontend-Backend Link Architecture

The admin panel and frontend product pages form a complete editing loop:

```
Admin Panel (/admin/)
├── /admin/products.php         → Product list (table with View/Edit/Delete)
│   ├── [View 👁️] → /product.php?id=X      (opens frontend in new tab)
│   ├── [Edit ✏️] → /admin/product-edit.php?id=X  (edit form)
│   └── [Delete 🗑️] → /admin/products.php?delete=X (with confirm)
│
├── /admin/product-edit.php?id=X → Edit form with "View on Website" button
│
Frontend (/)
├── /products.php               → Product grid with category filter
│   └── [View Details] → /product.php?id=X
│
├── /product.php?id=X           → Full product page
│   ├── Product info (name, model, HP, description, features, specs)
│   ├── WhatsApp CTA button
│   ├── Get Quote button
│   └── Related Products section
```

### Adding "View on Website" Button to Edit Page

```php
<!-- In admin/product-edit.php, top-right area -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="fas fa-edit me-2"></i>Edit Product</h2>
    <div>
        <a href="/product.php?id=<?= $product['id'] ?>" class="btn btn-success" target="_blank">
            <i class="fas fa-eye me-2"></i>View on Website
        </a>
        <a href="/admin/products.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to List
        </a>
    </div>
</div>
```

### Adding "View" Button to Product List Table

```php
<!-- In admin/products.php, actions column -->
<td>
    <a href="/product.php?id=<?= $product['id'] ?>" class="btn btn-sm btn-outline-success me-1" target="_blank">
        <i class="fas fa-eye"></i>
    </a>
    <a href="/admin/product-edit.php?id=<?= $product['id'] ?>" class="btn btn-sm btn-outline-primary">
        <i class="fas fa-edit"></i>
    </a>
    <a href="/admin/products.php?delete=<?= $product['id'] ?>" class="btn btn-sm btn-outline-danger" 
       onclick="return confirm('Are you sure?')">
        <i class="fas fa-trash"></i>
    </a>
</td>
```

### Nginx URL Rewrites for Clean URLs

```nginx
# In nginx site config
location = /products.html {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/products.php;
    include fastcgi_params;
}

location = /product.html {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/product.php;
    include fastcgi_params;
}
```

Then users can access: `https://site/products.html` (product list) and `https://site/product.html?id=1` (product detail).

## 500 Error Diagnosis: Function Redeclaration

When ALL pages return 500 after editing config files, check for function redeclaration:

```bash
php /home/ubuntu/site/products.php 2>&1 | head -5
# Look for: "Cannot redeclare escape()" or "Cannot redeclare getCurrentUrl()"
```

**Fix:** Ensure `header.php` loads includes in correct order — `database.php` → `functions.php` → `seo.php`. Remove duplicate function definitions from `database.php` if `functions.php` already has them.

## Login Credentials

```
Admin Panel:  https://site/admin/
Username:     admin
Password:     shengtuo2026

Database:     shengtuo_website
DB User:      shengtuo
DB Password:  ShengTuo2026!
```
