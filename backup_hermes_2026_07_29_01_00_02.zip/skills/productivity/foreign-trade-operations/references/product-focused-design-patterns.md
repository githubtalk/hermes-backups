# Product-Focused Homepage & Link Optimization Patterns

## Overview
Pattern for restructuring a B2B website homepage from company-info-focused to product-promotion-focused. Includes product card enhancements, category browsing, HP range filtering, and systematic link optimization.

**Verified on:** sub.aiv.qzz.io (2026-05-30), Bootstrap 5 + PHP + MySQL

## Product-Focused Homepage Layout

```
1. Hero Slider (with dual CTA: Browse Products + Get Quote)
2. Product Category Cards (browse by category with background images)
3. HP Range Showcase (clickable horsepower range cards)
4. Featured Products (with badges + HP tags + tab filtering)
5. Hot Products Strip (horizontal list of best sellers)
6. Why Choose Us (4 feature boxes)
7. Trust Bar (certifications)
8. Testimonials
9. Latest News (condensed, 3 items)
10. Company Intro (condensed, moved to bottom)
11. Product CTA Strip (golden gradient)
12. Contact CTA
```

## Files to Create
- `assets/css/product-focus-v4.css` — Product-focused design styles

## CSS Patterns

### Product Category Cards
```css
.category-showcase { padding:4rem 0 2rem; background:var(--white); }
.category-card { position:relative; border-radius:16px; overflow:hidden; height:280px; cursor:pointer; transition:all 0.4s; box-shadow:0 4px 12px rgba(0,0,0,0.1); }
.category-card:hover { transform:translateY(-10px); box-shadow:0 20px 60px rgba(0,0,0,0.2); }
.category-card-bg { position:absolute; inset:0; background-size:cover; background-position:center; transition:transform 0.6s; }
.category-card:hover .category-card-bg { transform:scale(1.08); }
.category-card-overlay { position:absolute; inset:0; background:linear-gradient(180deg,rgba(15,43,91,0.3),rgba(10,22,40,0.85)); display:flex; flex-direction:column; justify-content:flex-end; padding:2rem; }
.category-card-icon { width:56px; height:56px; border-radius:50%; background:rgba(212,168,67,0.9); display:flex; align-items:center; justify-content:center; margin-bottom:1rem; font-size:1.4rem; color:#fff; }
.category-card h3 { color:#fff; font-size:1.4rem; font-weight:800; }
.category-card p { color:rgba(255,255,255,0.7); font-size:0.9rem; }
.category-card .category-count { position:absolute; top:1rem; right:1rem; background:var(--accent); color:#fff; padding:0.3rem 0.8rem; border-radius:20px; font-size:0.75rem; font-weight:700; }
```

### HP Range Cards
```css
.hp-range-section { padding:4rem 0; background:linear-gradient(135deg,var(--gray-100),#e8ecf1); }
.hp-range-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:1.25rem; }
.hp-range-card { background:#fff; border-radius:16px; padding:1.5rem; text-align:center; border:2px solid transparent; transition:all 0.3s; cursor:pointer; position:relative; overflow:hidden; }
.hp-range-card::before { content:''; position:absolute; top:0; left:0; right:0; height:4px; background:linear-gradient(90deg,var(--primary),var(--accent)); transform:scaleX(0); transition:transform 0.3s; }
.hp-range-card:hover::before { transform:scaleX(1); }
.hp-range-card:hover { border-color:var(--accent); transform:translateY(-5px); }
.hp-range-number { font-size:2.2rem; font-weight:800; color:var(--primary); font-family:'Roboto',sans-serif; }
.hp-range-unit { font-size:0.8rem; color:var(--accent); font-weight:700; text-transform:uppercase; letter-spacing:2px; }
```

### Product Card Badges
```css
.product-badge { position:absolute; top:12px; left:12px; z-index:5; padding:0.3rem 0.75rem; border-radius:20px; font-size:0.7rem; font-weight:700; text-transform:uppercase; color:#fff; }
.product-badge.hot { background:linear-gradient(135deg,#ef4444,#dc2626); animation:badge-pulse 2s ease-in-out infinite; }
.product-badge.popular { background:linear-gradient(135deg,var(--accent),var(--accent-hover)); }
.product-badge.best-seller { background:linear-gradient(135deg,var(--primary),var(--primary-light)); }
@keyframes badge-pulse { 0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,0.4)} 50%{box-shadow:0 0 0 6px rgba(239,68,68,0)} }
.product-hp-tag { position:absolute; top:12px; right:12px; z-index:5; background:rgba(15,43,91,0.9); color:var(--accent); padding:0.3rem 0.7rem; border-radius:6px; font-size:0.75rem; font-weight:800; }
```

### Product Quick Actions (hover overlay)
```css
.product-quick-actions { position:absolute; bottom:0; left:0; right:0; padding:0.75rem; background:linear-gradient(transparent,rgba(0,0,0,0.7)); display:flex; gap:0.5rem; justify-content:center; opacity:0; transform:translateY(10px); transition:all 0.3s; z-index:5; }
.product-card:hover .product-quick-actions { opacity:1; transform:translateY(0); }
```

### Product Tab Filtering
```css
.product-tabs { display:flex; justify-content:center; gap:0.5rem; margin-bottom:2.5rem; flex-wrap:wrap; }
.product-tab { padding:0.6rem 1.5rem; border:2px solid var(--gray-300); border-radius:30px; background:transparent; color:var(--gray-600); font-weight:600; cursor:pointer; transition:all 0.3s; }
.product-tab.active { background:var(--primary); border-color:var(--primary); color:#fff; }
```

### Hot Products Strip (dark background)
```css
.hot-products-strip { padding:3rem 0; background:linear-gradient(135deg,var(--primary),#0a1e3d); }
.hot-product-item { display:flex; align-items:center; gap:1rem; padding:1rem; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.1); border-radius:16px; transition:all 0.3s; text-decoration:none; color:inherit; }
.hot-product-item:hover { background:rgba(255,255,255,0.12); border-color:var(--accent); transform:translateY(-3px); }
.hot-product-img { width:80px; height:60px; object-fit:contain; border-radius:8px; background:rgba(255,255,255,0.1); padding:4px; flex-shrink:0; }
```

### Product CTA Strip (golden gradient)
```css
.product-cta-strip { padding:3rem 0; background:linear-gradient(135deg,var(--accent),#b8922e); text-align:center; }
.product-cta-strip h2 { color:#fff; font-weight:800; }
.product-cta-strip .btn-light { background:#fff; color:var(--primary); font-weight:700; border:none; }
```

## JS: Product Tab Filtering

```js
const productTabs = document.querySelectorAll('.product-tab');
const productItems = document.querySelectorAll('.product-item');
productTabs.forEach(tab => {
    tab.addEventListener('click', function() {
        productTabs.forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        const filter = this.dataset.filter;
        productItems.forEach(item => {
            if (filter === 'all' || item.dataset.category === filter) {
                item.style.display = '';
                item.style.opacity = '0';
                item.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    item.style.transition = 'all 0.4s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'translateY(0)';
                }, 50);
            } else {
                item.style.display = 'none';
            }
        });
    });
});
```

**HTML:** Add `data-category="cat-<?= $product['category_id'] ?>"` to each `.product-item` div, and `data-filter="cat-ID"` / `data-filter="all"` to tab buttons.

## HP Range Filtering (products.php)

URL pattern: `/products.html?hp=25-50`

```php
$hpRange = $_GET['hp'] ?? null;
if ($hpRange) {
    $parts = explode('-', $hpRange);
    if (count($parts) == 2) {
        $minHp = (int)$parts[0];
        $maxHp = (int)$parts[1];
        $stmt = $db->prepare("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.is_active = 1 AND p.category_id = 1 ORDER BY p.sort_order");
        $stmt->execute();
        $allProds = $stmt->fetchAll();
        $products = array_filter($allProds, function($p) use ($minHp, $maxHp) {
            if (empty($p['horsepower']) || $p['horsepower'] === 'N/A') return false;
            preg_match_all('/\d+/', $p['horsepower'], $matches);
            if (empty($matches[0])) return false;
            $hp = (int)$matches[0][0];
            return $hp >= $minHp && $hp <= $maxHp;
        });
        $products = array_values($products);
    }
}
```

**⚠️ Pitfall:** Don't put `$products = $stmt->fetchAll()` AFTER the if/elseif/else block — it overwrites filtered results. Each branch must set `$products` independently.

## Dynamic Navbar Categories

Instead of hardcoding category slugs, load from database:

```php
// In header.php
$navCategories = $db->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order")->fetchAll();
foreach ($navCategories as $navCat):
?>
<li><a class="dropdown-item" href="/products.html?category=<?= escape($navCat['slug']) ?>"><?= escape($navCat['name']) ?></a></li>
<?php endforeach; ?>
```

## News Detail Slug Parsing

Nginx `try_files $uri $uri/ /news_detail.php?slug=$uri` passes the FULL URI path as slug. The PHP script must clean it:

```php
$slug = $_GET['slug'] ?? '';
$slug = preg_replace('#^/news/#', '', $slug);  // Strip /news/ prefix
$slug = preg_replace('#\.html$#', '', $slug);   // Strip .html suffix
$slug = trim($slug, '/');
```

Same pattern applies to `/product/` routes (see nginx-php-fpm-deployment.md Pitfall #13).

## Systematic Link Audit Workflow

When asked to "optimize all links" or "fix broken links":

1. **Extract all internal links** from rendered pages:
   ```bash
   curl -s URL | grep -oP 'href="(/[^"]*)"' | sed 's/href="//;s/"//' | sort -u
   ```

2. **Test each unique path**:
   ```bash
   for path in /about /products /contact /news ...; do
     status=$(curl -s -o /dev/null -w "%{http_code}" "https://site${path}")
     echo "$status $path"
   done
   ```

3. **Check nginx routes** for missing clean URLs:
   ```bash
   grep -E 'location\s' /etc/nginx/sites-enabled/site-name
   ```

4. **Fix in order**: nginx routes → PHP slug parsing → HTML link references → footer/navbar consistency

5. **Verify all 200s** after fixes

## Pitfalls

- **Category slug mismatch**: Navbar may hardcode `tractors` but DB slug is `shengtuo-tractor`. Always use DB slugs.
- **Missing .html route + missing clean URL route**: Both `/about` and `/about.html` need nginx routes. Add exact-match clean URLs alongside .html routes.
- **News links with .html suffix**: If nginx passes `/news/slug.html` to PHP, the `.html` becomes part of the slug. Must strip in PHP.
- **Footer links to non-existent pages**: `/cases`, `/privacy`, `/terms` are common defaults that may not exist. Remove or create them.
- **`$products = $stmt->fetchAll()` after if/elseif/else**: This unconditionally overwrites any filtered result set in the branches above. Each branch must independently set `$products`.
- **Cloudflare email protection**: `grep` may find `/cdn-cgi/l/email-protection` links — these are Cloudflare's auto-generated email obfuscation, not real broken links.
