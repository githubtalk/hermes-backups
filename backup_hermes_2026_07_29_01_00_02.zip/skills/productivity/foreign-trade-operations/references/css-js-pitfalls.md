# CSS/JS 调试陷阱 — sub.aiv.qzz.io

## 1. Page Loader 永远不消失（转圈问题）

**症状**: 页面白色遮罩 + 转圈动画永远不消失，用户看到"一直转圈"。

**根因**: `.page-loader` 使用 `window.addEventListener('load', ...)` 隐藏，但 `load` 事件要求**所有外部资源**（Google Fonts、Font Awesome、Bootstrap CDN）加载完毕才触发。在中国，这些 CDN 经常加载缓慢或超时。

**正确实现** (bundle-v2.min.js):
```javascript
function hideLoader() {
    const loader = document.querySelector('.page-loader');
    if (loader) {
        loader.classList.add('loaded');
        setTimeout(() => loader.remove(), 500);
    }
}
// DOM 渲染完就隐藏（不等外部资源）
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(hideLoader, 200);
});
// 3 秒超时兜底
setTimeout(hideLoader, 3000);
// 全加载完也隐藏
window.addEventListener('load', hideLoader);
```

**CSS 兜底** (bundle-v8.min.css):
```css
.page-loader {
    animation: autoHideLoader 3s ease forwards;
}
@keyframes autoHideLoader {
    0%, 85% { opacity: 1; visibility: visible; }
    100% { opacity: 0; visibility: hidden; pointer-events: none; }
}
```

## 2. 外部资源异步加载（避免渲染阻塞）

**问题**: Google Fonts、Font Awesome 的 `<link rel="stylesheet">` 是渲染阻塞资源。在中国加载慢会导致白屏。

**正确写法** (templates/header.php):
```html
<!-- Google Fonts - 异步加载不阻塞渲染 -->
<link href="https://fonts.googleapis.com/css2?family=..." rel="stylesheet" 
      media="print" onload="this.media='all'">
<noscript><link href="..." rel="stylesheet"></noscript>

<!-- Font Awesome - 异步加载 -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/..." 
      media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="..."></noscript>
```

**原理**: `media="print"` 让浏览器不阻塞渲染加载，`onload` 切换回 `all` 生效。`<noscript>` 兜底无 JS 环境。

## 3. CSS 字面量 `\n` 导致选择器失效

**症状**: `.wa-float-btn` 的 CSS 规则完全不生效，computed style 显示 `position: static`。

**根因**: CSS 文件中有字面量 `\n`（反斜杠+n，不是换行），导致 CSS 解析器把 `.wa-float-btn` 解析为 `n .wa-float-btn`。

**调试方法**:
```javascript
// 浏览器控制台检查选择器是否匹配
document.querySelector('.wa-float-btn') // 存在但样式不对
getComputedStyle(btn).position // "static" 而非 "fixed"

// 检查实际解析的选择器
for (let s of document.styleSheets) {
    for (let r of s.cssRules) {
        if (r.selectorText && r.selectorText.includes('wa-float')) {
            console.log(r.selectorText); // 显示 "n .wa-float-btn" 而非 ".wa-float-btn"
        }
    }
}
```

**修复**: `sed -i 's/\\n\/\* === B2B Enhancement === \*\//\n\/\* === B2B Enhancement === *\//' bundle-v8.min.css`

**检测**: `grep -c '\\\\n' bundle-v8.min.css` — 应该返回 0。

## 4. Bundle 文件 vs 源文件

**规则**: 编辑的必须是**实际加载的文件**，不是源文件。

**当前加载链路**:
- CSS: `bundle-v8.min.css` (header.php 加载)
- JS: `bundle-v2.min.js` (footer.php 加载)
- `b2b-enhance.js` 等源文件已合并进 bundle，**编辑源文件无效**

**缓存版本号**: 使用 `<?= time() ?>` 确保每次请求新版本：
```php
<link href="/assets/css/bundle-v8.min.css?v=<?= time() ?>" rel="stylesheet">
<script src="/assets/js/bundle-v2.min.js?v=<?= time() ?>"></script>
```

## 5. 导航栏一行显示优化

**参数** (用户偏好，尺寸硬约束):
- Header 高度: 36px (单行)
- Logo margin-right: 1.5rem
- 导航字体: 0.78rem
- 导航项间距: 0.75rem
- 导航项数量: 7 (HOME, PRODUCTS, ABOUT US, NEWS, CONTACT, WHY US, EXPORT)
