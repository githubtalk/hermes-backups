# Modern UI Design Patterns (Ported from web_b2b React+Django)

## Source Project
- **Repo:** https://github.com/geeeeeeeek/web_b2b
- **Stack:** Next.js 14 + React 18 + Ant Design + TailwindCSS + Django REST
- **Status:** Stopped maintenance (2025-09), but design patterns are valuable
- **Template:** template10 (latest, most polished)

## Patterns Ported to PHP Site (sub.aiv.qzz.io)

### 1. Product Cards (Square + Hover Zoom + Overlay)

**web_b2b approach:** Square aspect ratio via `padding-bottom: 100%`, absolute-positioned image, hover scale 1.1, overlay buttons with staggered fade-in.

**CSS implementation:**
```css
.product-card-modern .card-image-wrap {
    position: relative;
    overflow: hidden;
    background: var(--gray-100);
    padding-bottom: 100%; /* Square aspect ratio */
}
.product-card-modern .card-image-wrap img {
    position: absolute;
    top: 0; left: 0;
    width: 100%; height: 100%;
    object-fit: cover;
    transition: transform 700ms cubic-bezier(0.4, 0, 0.2, 1);
}
.product-card-modern:hover .card-image-wrap img {
    transform: scale(1.1);
}
```

**PHP HTML structure:**
```html
<div class="product-card-modern">
    <div class="card-image-wrap">
        <span class="card-badge badge-hot">HOT</span>
        <span class="hp-tag"><i class="fas fa-bolt"></i> 220-240HP</span>
        <img src="..." alt="..." loading="lazy">
        <div class="card-overlay">
            <a href="/product/slug" class="btn-overlay"><i class="fas fa-eye"></i></a>
            <a href="https://wa.me/..." class="btn-overlay" target="_blank"><i class="fab fa-whatsapp"></i></a>
        </div>
    </div>
    <div class="card-body">
        <h3><a href="/product/slug">Product Name</a></h3>
        <span class="card-model">Model Number</span>
    </div>
</div>
```

### 2. Category Cards (Rounded + Circle Mask + Gradient Overlay)

**web_b2b approach:** `rounded-3xl` (1.5rem), expanding circle mask on hover (`width: 0 → 200%`), gradient bottom overlay with category name.

**CSS:**
```css
.category-card-modern .cat-image-wrap {
    border-radius: 1.5rem;
    overflow: hidden;
    padding-bottom: 100%;
}
.category-card-modern .cat-circle-mask::before {
    content: '';
    width: 0; height: 0;
    border-radius: 50%;
    background: rgba(0,0,0,0.3);
    transition: all 1s cubic-bezier(0.4, 0, 0.2, 1);
}
.category-card-modern:hover .cat-circle-mask::before {
    width: 200%; height: 200%;
}
```

### 3. Section Title System (Centered + Accent Underline)

**web_b2b pattern:** `<h2>` + `w-[60px] h-[2px] bg-mainColorNormal` underline.

**CSS:**
```css
.modern-section-title { text-align: center; margin-bottom: 3rem; }
.modern-section-title .title-accent {
    display: block;
    width: 60px; height: 2px;
    background: var(--accent);
    margin: 0 auto 1rem;
}
```

**HTML:**
```html
<div class="modern-section-title">
    <span class="section-badge">Section Label</span>
    <h2>SECTION TITLE</h2>
    <span class="title-accent"></span>
    <p class="section-subtitle">Description text</p>
</div>
```

### 4. Stats Section (Large Numbers + Labels)

**web_b2b pattern:** 4-column grid, large colored numbers, uppercase labels.

```html
<div class="stats-grid">
    <div class="stat-item">
        <div class="stat-number">15+</div>
        <div class="stat-label">Years Experience</div>
    </div>
    <!-- ... -->
</div>
```

### 5. Customer Testimonials (Modern Cards)

**web_b2b pattern:** Quote icon, star rating, italic quote, author avatar (initials circle), hover lift.

### 6. Certification Gallery (Lightbox)

**Pattern:** 4-column grid of cert images, click opens lightbox with prev/next nav + keyboard support (ESC/ArrowLeft/ArrowRight).

### 7. Feature Boxes (Icon Circle + Gradient Accent)

**web_b2b pattern:** Icon in circular bg that changes color on hover, top gradient border reveal.

```css
.feature-box-modern::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    background: linear-gradient(90deg, var(--primary), var(--accent));
    opacity: 0;
    transition: opacity 300ms;
}
.feature-box-modern:hover::before { opacity: 1; }
.feature-box-modern .icon-circle {
    /* On hover: bg changes from light to solid, icon color inverts */
    transition: all 300ms;
}
.feature-box-modern:hover .icon-circle {
    background: var(--primary);
    color: #fff;
    transform: scale(1.1);
}
```

## Design Token System (from web_b2b globals.css)

```css
:root {
    --primary: #1B3A5C;
    --primary-light: #E8EEF4;
    --primary-deep: #0F2640;
    --accent: #D4A843;
    --gray-50 through --gray-900;  /* 10-step neutral scale */
    --shadow-sm/md/lg/xl;          /* 4-level shadow system */
    --radius-sm/md/lg/xl/2xl/full; /* Border radius tokens */
    --transition-fast/base/slow/slower; /* Timing functions */
}
```

## Key Design Differences (web_b2b vs our PHP site)

| Aspect | web_b2b (React) | Our PHP Port |
|--------|-----------------|--------------|
| Product images | `padding-bottom: 100%` (square) | Same — CSS-only, no JS |
| Category hover | Circle mask expanding | Same — pure CSS |
| Section titles | Tailwind utility classes | Custom `.modern-section-title` class |
| Cards | React components | Static PHP + CSS |
| Lightbox | React state + hooks | Vanilla JS + CSS class toggle |
| Animations | Framer Motion | CSS transitions + IntersectionObserver |

## Integration Notes

- Created as `modern-ui-v6.css` (20KB), loaded AFTER `layout-v2.css`
- Compatible with existing Bootstrap 5 + bundle.min.css
- Uses CSS variables from `color-harmony.css`
- JS lightbox added inline in `index.php` `<script>` section
- Placeholder cert images created as SVG (replace with real scans when available)

## Files Created/Modified

| File | Action |
|------|--------|
| `assets/css/modern-ui-v6.css` | Created (20KB design system) |
| `templates/header.php` | Added CSS link after layout-v2 |
| `index.php` | Updated: category cards, product cards, feature boxes, testimonials, news cards, stats section, cert gallery, section titles |
| `assets/images/certs/*.jpg` | Created SVG placeholders (4 files) |
