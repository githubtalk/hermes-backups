# Product-Focused Homepage Pattern (B2B Agricultural Machinery)

## 首页布局顺序（产品主导）

```
1. Hero Slider（双按钮：Browse Products + Get Quote）
2. Product Category Cards（分类卡片区）
3. HP Range Showcase（马力区间展示）
4. Featured Products（推荐产品 + Tab筛选）
5. Hot Products Strip（热门产品条）
6. Why Choose Us（信任模块）
7. Trust Bar（认证徽章栏）
8. Testimonials（客户评价）
9. Latest News（新闻，3条精简）
10. Company Intro（公司简介，压缩版后移）
11. Product CTA Strip（金色渐变行动号召）
12. Contact CTA（联系方式）
```

## 数据库查询模板

```php
// 分类统计（含产品数量）
$categories = $db->query("
    SELECT c.*, COUNT(p.id) as product_count 
    FROM categories c 
    LEFT JOIN products p ON p.category_id = c.id AND p.is_active = 1 
    WHERE c.is_active = 1 
    GROUP BY c.id ORDER BY c.sort_order
")->fetchAll();

// 推荐产品（8个）
$featuredProducts = $db->query("
    SELECT p.*, c.name as category_name 
    FROM products p 
    LEFT JOIN categories c ON p.category_id = c.id 
    WHERE p.is_active = 1 AND p.is_featured = 1 
    ORDER BY p.sort_order LIMIT 8
")->fetchAll();

// 热门产品（拖拉机前6个）
$hotProducts = $db->query("
    SELECT p.*, c.name as category_name 
    FROM products p 
    LEFT JOIN categories c ON p.category_id = c.id 
    WHERE p.is_active = 1 AND p.category_id = 1
    ORDER BY p.sort_order LIMIT 6
")->fetchAll();
```

## 产品卡片徽章逻辑

```php
$badge = '';
if ($index < 2) $badge = 'hot';          // 前2个 = HOT
elseif ($index < 4) $badge = 'popular';   // 3-4 = POPULAR  
elseif ($index < 6) $badge = 'best-seller'; // 5-6 = BEST SELLER
```

## HP 区间筛选

products.php 增加 `$_GET['hp']` 参数，解析 `25-50` 格式，用 `preg_match_all('/\d+/', ...)` 提取马力数值过滤。

## ⚠️ 关键陷阱

1. **分类slug必须从数据库读取** — 硬编码 `tractors`/`implements`/`parts` 全部404
2. **products.php 每个分支必须自己 fetchAll()** — 不要在分支外无条件调用
3. **推荐产品太少首页会空** — 用 LIMIT + ORDER BY sort_order 补充
