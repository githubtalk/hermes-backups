# Comprehensive Website Testing Checklist

## Quick Test Command
```bash
# All-in-one test script
echo "=== Frontend Pages ===" && \
for url in "/" "/products" "/products?category=SLUG" "/products?hp=50-80" "/about" "/contact" "/news" "/export" "/search" "/search?q=tractor"; do
    status=$(curl -s -o /dev/null -w "%{http_code}" "https://DOMAIN${url}")
    [[ "$status" == "200" ]] && echo "  ✅ $url" || echo "  ❌ $url → $status"
done && echo "" && \
echo "=== Product Details ===" && \
php -r "\$db=new PDO('mysql:host=localhost;dbname=DB','USER','PASS');
\$stmt=\$db->query('SELECT slug FROM products WHERE is_active=1 LIMIT 10');
foreach(\$stmt->fetchAll(PDO::FETCH_COLUMN) as \$s){
    \$st=trim(shell_exec('curl -s -o /dev/null -w \"%{http_code}\" \"https://DOMAIN/product/'.\$s.'\"'));
    echo(\$st=='200'?'  ✅ ':'  ❌ ').'/product/'.\$s.PHP_EOL;
}" && echo "" && \
echo "=== Backend ===" && \
for url in "/admin/login.php" "/admin/index.php" "/admin/products.php" "/admin/settings.php"; do
    status=$(curl -s -o /dev/null -w "%{http_code}" "https://DOMAIN${url}")
    [[ "$status" == "200" || "$status" == "302" ]] && echo "  ✅ $url" || echo "  ❌ $url → $status"
done && echo "" && \
echo "=== API & Resources ===" && \
for url in "/api/products.php" "/sitemap.xml" "/robots.txt" "/assets/css/bundle-v8.min.css"; do
    status=$(curl -s -o /dev/null -w "%{http_code}" "https://DOMAIN${url}")
    [[ "$status" == "200" ]] && echo "  ✅ $url" || echo "  ❌ $url → $status"
done && echo "" && \
echo "=== Functional Tests ===" && \
echo -n "  Inquiry: " && curl -s -X POST "https://DOMAIN/api/inquiry.php" -H "Content-Type: application/json" -d '{"name":"Test","email":"t@t.com","message":"test"}' | grep -o '"success":[a-z]*' && \
echo -n "  Search: " && curl -s "https://DOMAIN/search?q=tractor" | grep -c "Found.*results" && echo " results" && \
echo -n "  Login: " && curl -s -X POST "https://DOMAIN/admin/login.php" -d "username=admin&password=PASS" -D - -o /dev/null | grep "HTTP/" | grep -o "[0-9]*"
```

## Performance Checks
```bash
# Page load times
for url in "/" "/products" "/about"; do
    curl -s -o /dev/null -w "$url: %{time_total}s\n" "https://DOMAIN${url}"
done

# Gzip compression
original=$(curl -s "https://DOMAIN/" | wc -c)
compressed=$(curl -s -H "Accept-Encoding: gzip" -o /dev/null -w "%{size_download}" "https://DOMAIN/")
echo "Gzip: $original → $compressed bytes"

# Security headers
curl -s -I "https://DOMAIN/" | grep -i "x-frame\|x-content\|strict-transport"

# Cache headers
curl -s -I "https://DOMAIN/assets/css/bundle-v8.min.css" | grep -i "cache-control\|expires"
```

## Browser Console Checks
```javascript
// Grid layouts working
['product-grid','hp-grid','feature-grid','testimonial-grid','cert-gallery'].forEach(c => {
  const el = document.querySelector('.' + c);
  console.log(c + ': ' + (el ? getComputedStyle(el).display : 'missing'));
});

// All key elements present
console.log({
  productCards: document.querySelectorAll('.product-card').length,
  sections: document.querySelectorAll('section').length,
  brokenImages: Array.from(document.querySelectorAll('img')).filter(i => !i.complete || i.naturalHeight === 0).length
});
```

## What to Check After Migration
1. All pages return 200 (not 302/404/500)
2. Each page has DIFFERENT `<title>` tag (not all showing homepage)
3. Product detail pages load with correct slug
4. Inquiry form submits successfully
5. Search returns results
6. Admin login works (302 redirect = success)
7. Gzip compression active (80%+ savings)
8. Cache headers present on static assets
9. No PHP errors in logs
10. Security headers present
