# CSS Width Widening Workflow

When user asks to "加宽" (widen) the website, all width-related selectors must be updated together.

## Required Selectors for Width Change

When changing from 980px to 1200px (or any other width), update ALL of these:

```css
#main {
    width: 1200px;  /* Primary container */
}

#translate {
    width: 1200px;  /* Translation bar */
}

#index_nav {
    width: 1200px;  /* Navigation bar */
}

#index_banner {
    width: 1200px;  /* Banner/carousel */
}

#center {
    width: 1200px;  /* Content area */
}

#index_footer {
    width: 1200px;  /* Footer */
}
```

## Column Width Adjustments

When widening, also adjust column widths proportionally:

| Component | 980px Version | 1200px Version |
|-----------|---------------|----------------|
| #index_left (sidebar) | 230px | 250px |
| #index_right (content) | 720px | 910px |
| #sidebar | 230px | 250px |
| #content | 720px | 910px |

## Product Grid

```css
#index_product li {
    width: calc(25% - 15px);  /* 4 columns at 1200px */
}

@media (max-width: 1024px) {
    #index_product li {
        width: calc(33.333% - 14px);  /* 3 columns on tablet */
    }
}

@media (max-width: 768px) {
    #index_product li {
        width: calc(50% - 10px);  /* 2 columns on mobile */
    }
}
```

## Complete Workflow

1. Create new CSS file (e.g., `style15.css`) with updated widths
2. Upload via FTP: `curl -T style15.css ftp://HOST/wwwroot/css/style15.css --user "USER:PASS"`
3. Download index.html: `curl -o index.html ftp://HOST/wwwroot/index.html --user "USER:PASS"`
4. Update CSS reference: `sed -i 's/style14\.css/style15.css/g' index.html`
5. Upload updated index.html: `curl -T index.html ftp://HOST/wwwroot/index.html --user "USER:PASS"`
6. Update ALL 60+ pages using batch update script

## Verification

```bash
# Check CSS file uploaded correctly
curl -s https://www.shengtuo-tractor.com/css/style15.css | grep "width: 1200px"

# Check index.html references new CSS
curl -s https://www.shengtuo-tractor.com | grep "style15.css"
```

## Pitfalls

1. **Missing selectors**: If any width selector is missed, layout will break
2. **Column proportions**: Sidebar/content ratio must be recalculated
3. **Mobile breakpoints**: Update @media queries for new widths
4. **Batch update**: All 60+ pages must be updated, not just index.html
