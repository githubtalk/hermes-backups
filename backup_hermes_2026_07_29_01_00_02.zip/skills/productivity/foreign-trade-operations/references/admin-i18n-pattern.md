# Admin Panel i18n (Internationalization) Pattern

## Overview

PHP admin panel language switching system — session-based, with `t()` translation function and language files as PHP arrays. Supports Chinese (zh) and English (en).

## Architecture

```
admin/
├── lang_helper.php    # Language helper (initLang, t(), getLang, langSwitchUrl)
├── lang/
│   ├── zh.php         # Chinese language pack (200+ keys)
│   └── en.php         # English language pack
└── auth.php           # Layout template (includes lang_helper, renders switcher)
```

## lang_helper.php

```php
<?php
function initLang() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (isset($_GET['lang']) && in_array($_GET['lang'], ['zh', 'en'])) {
        $_SESSION['admin_lang'] = $_GET['lang'];
        $url = strtok($_SERVER['REQUEST_URI'], '?');
        $params = $_GET;
        unset($params['lang']);
        if ($params) $url .= '?' . http_build_query($params);
        header('Location: ' . $url);
        exit;
    }
    if (!isset($_SESSION['admin_lang'])) $_SESSION['admin_lang'] = 'zh';
}

function getLang() { return $_SESSION['admin_lang'] ?? 'zh'; }

function t($key) {
    static $translations = null;
    if ($translations === null) {
        $lang = getLang();
        $file = __DIR__ . '/lang/' . $lang . '.php';
        $translations = file_exists($file) ? require $file : require __DIR__ . '/lang/zh.php';
    }
    return $translations[$key] ?? $key;
}

function langSwitchUrl($lang) {
    $params = $_GET;
    $params['lang'] = $lang;
    return strtok($_SERVER['REQUEST_URI'], '?') . '?' . http_build_query($params);
}

initLang();
```

## Language File Format (zh.php / en.php)

```php
<?php
return [
    'Dashboard' => '仪表盘',
    'Products' => '产品管理',
    'Categories' => '分类管理',
    'News' => '新闻管理',
    'Sliders' => '轮播图',
    'Messages' => '留言管理',
    'Inquiries' => '询盘管理',
    'Pages' => '页面管理',
    'Settings' => '系统设置',
    'View Website' => '访问前台',
    'Logout' => '退出登录',
    'Admin Panel' => '管理后台',
    // ... 200+ keys covering all UI text
    'Product created successfully' => '产品创建成功',
    'Invalid CSRF token' => '安全令牌无效，请重试',
    // English file: 'Dashboard' => 'Dashboard', etc.
];
```

## Auth.php Integration

```php
require_once __DIR__ . '/lang_helper.php';

// In <html> tag:
<html lang="<?= getLang() ?>">

// Sidebar navigation — wrap all text in t():
<li><a href="/admin/"><?= t('Dashboard') ?></a></li>
<li><a href="/admin/products.php"><?= t('Products') ?></a></li>

// Flash messages — translate:
<?= escape(t($flashMsg)) ?>

// Page title — translate:
<h5><?= escape(t($pageTitle ?? 'Admin')) ?></h5>

// Language switcher at sidebar bottom:
<div class="lang-switch">
    <a href="<?= langSwitchUrl('zh') ?>" class="btn <?= getLang()==='zh'?'active':'btn-outline-light' ?>">中文</a>
    <a href="<?= langSwitchUrl('en') ?>" class="btn <?= getLang()==='en'?'active':'btn-outline-light' ?>">EN</a>
</div>
```

## Login Page Integration

```php
require_once __DIR__ . '/lang_helper.php';

// Error messages:
$error = t('Please enter username and password');
$error = t('Invalid username or password');

// Form labels:
<label><?= t('Username') ?></label>
<label><?= t('Password') ?></label>
<button><?= t('Login') ?></button>

// Language switcher (fixed position, top-right):
<div style="position:fixed;top:20px;right:20px;z-index:9999;">
    <a href="?lang=zh" class="btn <?= getLang()==='zh'?'active':'' ?>">中文</a>
    <a href="?lang=en" class="btn <?= getLang()==='en'?'active':'' ?>">EN</a>
</div>
```

## Key Principles

1. **Default language: Chinese** — user's primary language
2. **Fallback: return key itself** — `t('Unknown Key')` returns 'Unknown Key'
3. **Session persistence** — language choice survives page navigation
4. **Flash message translation** — store English keys in PHP, translate at render time
5. **Page title translation** — set `$pageTitle = 'Products'`, auth.php calls `t($pageTitle)`

## Pitfalls

- **Don't store translated text in session** — store language code, translate at render
- **Flash messages must use translation keys** — if you store '产品创建成功' in session, t() won't find it. Store 'Product created successfully' and let t() translate.
- **Some pages have their own `<title>` tag** — must also call t() there
- **Language switch redirects** — the `?lang=` parameter triggers a redirect to remove it from URL. Handle this in initLang() before any output.
