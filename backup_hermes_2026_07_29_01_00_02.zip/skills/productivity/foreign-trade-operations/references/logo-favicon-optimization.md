# Logo & Favicon Optimization Pattern

## Favicon 生成（从Logo裁剪）

```python
from PIL import Image, ImageOps

logo = Image.open('logo-v2.png')

# 找到内容边界框（去除白色背景）
gray = logo.convert('L')
inverted = ImageOps.invert(gray)
bbox = inverted.getbbox()  # (left, top, right, bottom)

if bbox:
    pad = 5
    cropped = logo.crop((
        max(0, bbox[0] - pad),
        max(0, bbox[1] - pad),
        min(logo.width, bbox[2] + pad),
        min(logo.height, bbox[3] + pad)
    ))
    
    # Favicon 32x32
    favicon = cropped.copy()
    favicon.thumbnail((32, 32), Image.LANCZOS)
    canvas = Image.new('RGBA', (32, 32), (255, 255, 255, 255))
    offset = ((32 - favicon.width) // 2, (32 - favicon.height) // 2)
    canvas.paste(favicon, offset)
    canvas.save('favicon.png')
    
    # Apple Touch Icon 180x180
    apple = cropped.copy()
    apple.thumbnail((160, 160), Image.LANCZOS)
    canvas2 = Image.new('RGBA', (180, 180), (255, 255, 255, 255))
    offset2 = ((180 - apple.width) // 2, (180 - apple.height) // 2)
    canvas2.paste(apple, offset2)
    canvas2.save('apple-touch-icon.png')
```

## Logo CSS 增强

```css
.navbar-brand {
    padding: 0;
    margin-right: 2rem;
    display: flex;
    align-items: center;
}
.navbar-brand img.logo {
    max-height: 52px;
    width: auto;
    border-radius: 6px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    filter: drop-shadow(0 2px 4px rgba(0,0,0,0.06));
}
.navbar-brand:hover img.logo {
    transform: scale(1.04);
    filter: drop-shadow(0 4px 12px rgba(15,43,91,0.12));
}
```

## Logo HTML（移除硬编码宽高）

```html
<!-- ❌ 错误：硬编码宽高会导致变形 -->
<img src="/assets/images/logo-v2.png" alt="Shengtuo Tractor" class="logo" width="400" height="120">

<!-- ✅ 正确：让CSS控制尺寸 -->
<img src="/assets/images/logo-v2.png" alt="Shengtuo Tractor - Agricultural Machinery Manufacturer" class="logo">
```

## Nav链接渐变下划线

```css
.nav-link::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    width: 0;
    height: 2px;
    background: linear-gradient(90deg, var(--primary), var(--accent));
    transition: all 0.3s ease;
    transform: translateX(-50%);
    border-radius: 1px;
}
.nav-link:hover::after,
.nav-link.active::after {
    width: 60%;
}
```

## ⚠️ 注意事项

1. **favicon不要直接复制logo** — logo通常是宽幅(428x105)，favicon必须是正方形(32x32)
2. **alt文本包含关键词** — "Shengtuo Tractor - Agricultural Machinery Manufacturer" 比 "Shengtuo Tractor" 更利于SEO
3. **CSS specificity** — `.navbar-brand img.logo` 比 `.navbar-brand img` 优先级更高
4. **CDN缓存** — 修改CSS后必须重命名文件才能绕过Cloudflare缓存
