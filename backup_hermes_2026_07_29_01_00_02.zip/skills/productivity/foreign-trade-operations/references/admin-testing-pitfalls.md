# Admin Testing Pitfalls

Systematic testing patterns for PHP admin panels — discovered through multiple debugging sessions.

## CRUD Action Naming Inconsistency

Different modules use different action names for create operations:

| Module | Create Action | URL Pattern |
|--------|--------------|-------------|
| Products | `add` | `?action=add` |
| Categories | `add` | `?action=add` |
| News | `create` | `?action=create` |
| Pages | `create` | `?action=create` |
| Sliders | `add` | `?action=add` |

**PITFALL:** Using `?action=add` for news/pages will silently fail (no error, page just re-renders). Always check the module's code:
```bash
grep -n "in_array.*action.*\['" /path/to/admin/module.php
```

## Foreign Key Constraint with category_id=0

**PROBLEM:** HTML `<select>` with `<option value="">-- None --</option>` sends empty string. PHP `(int)($_POST['category_id'] ?? 0)` converts it to `0`. But FK constraint `REFERENCES categories(id)` doesn't allow 0 (IDs start at 1).

**SYMPTOM:** INSERT silently fails, page re-renders with no error, no data in DB.

**FIX:** Use NULL for empty values:
```php
$category_id = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
```

**APPLIES TO:** Any table with FK to categories, news_categories, or similar.

Also fix the form's default option:
```html
<option value="">-- None --</option>  <!-- Not value="0" -->
```

## Schema Mismatch Between Code and Database

When PHP code references columns that don't exist in the table, it causes silent failures or 500 errors.

**Known mismatches found (2026-05-30):**

| File | Code Uses | Table Has | Fix |
|------|----------|-----------|-----|
| `api/message.php` | `status` | `is_read`, `replied` | Remove `status` from INSERT |
| `api/message.php` | missing `company` | `company` VARCHAR | Add `$company` variable + column |
| `admin/pages.php` | `template` column | missing | `ALTER TABLE pages ADD COLUMN template varchar(50) DEFAULT 'default'` |
| `admin/news.php` | `category_id=0` | FK to news_categories | Use NULL instead of 0 |

**DIAGNOSIS:** When a form submits but no data appears in DB:
1. Check error log: `tail -20 /path/to/logs/error.log`
2. Test SQL directly: `mysql -u USER -p DB -e "DESCRIBE table_name;"`
3. Compare INSERT columns with table structure
4. Check FK constraints: `SHOW CREATE TABLE table_name\G`

## PHP Session Expiration in curl Testing

**PROBLEM:** When testing admin pages with curl, PHP sessions expire between requests. Pages return 0 bytes (redirect to login).

**DIAGNOSIS:**
```bash
# Page returns 0 bytes = session expired
curl -s -b /tmp/cookies.txt 'https://SITE/admin/page.php' | wc -c
# Returns: 0
```

**FIX:** Always get a fresh session before testing:
```bash
curl -s -c /tmp/cookies_new.txt -L -o /dev/null 'https://SITE/admin/login.php' \
  -d 'username=admin&password=PASS'
# Use /tmp/cookies_new.txt for all subsequent requests
```

## Dashboard Must Track All Modules

When adding new modules (inquiries, reviews, orders, etc.), the Dashboard must be updated to show:
1. **Stats card** — total count + new/unread count
2. **Recent items list** — last 5 entries with key fields

**CHECKLIST for new module:**
- [ ] Add COUNT query to `admin/index.php` stats section
- [ ] Add stats card to the row
- [ ] Add recent items query
- [ ] Add recent items table/list section
- [ ] Add sidebar nav link in `admin/auth.php`
- [ ] Add badge count (optional, for unread items)

## CSRF Token Extraction and Session Management

**CRITICAL:** When testing admin CRUD with curl, you MUST use the same cookie file for GET (extract CSRF) and POST (submit form). Different cookie files = different sessions = CSRF mismatch.

```bash
# WRONG - two separate sessions
curl -s -c /tmp/cookies1.txt ...  # Session A gets CSRF
curl -s -b /tmp/cookies2.txt -X POST ...  # Session B tries to use CSRF → FAILS

# CORRECT - same session throughout
curl -s -c /tmp/admin.txt -L -o /dev/null 'https://SITE/admin/login.php' \
  -d 'username=admin&password=PASS'

# GET page and extract CSRF (same cookie file!)
curl -s -b /tmp/admin.txt 'https://SITE/admin/categories.php?action=add' \
  | grep -oP 'csrf_token.*?value="\K[^"]+' | head -1

# POST with same cookie file
curl -s -b /tmp/admin.txt -X POST 'https://SITE/admin/categories.php?action=add' \
  -d "csrf_token=EXTRACTED_TOKEN&action=add&name=Test&slug=test"
```

**CSRF regex pattern:** `grep -oP 'csrf_token.*?value="\K[^"]+'` — matches the hidden input value. Always use `head -1` since some pages have multiple CSRF tokens.

## Product Delete Uses GET Parameter, Not POST

**PITFALL:** Product deletion uses `$_GET['csrf']` parameter, NOT `$_POST['csrf_token']`. This is different from all other modules!

```bash
# ❌ WRONG - POST with csrf_token body (silently fails)
curl -s -b /tmp/admin.txt -X POST 'https://SITE/admin/products.php?action=delete&id=5' \
  -d "csrf_token=TOKEN"

# ✅ CORRECT - GET with csrf query parameter
curl -s -b /tmp/admin.txt \
  "https://SITE/admin/products.php?action=delete&id=5&csrf=TOKEN"
```

**Code reference (products.php):**
```php
if ($action === 'delete' && $id > 0) {
    if (!isset($_GET['csrf']) || !verifyCSRFToken($_GET['csrf'])) {
```

## Comprehensive Admin Test Script

```bash
#!/bin/bash
SITE="https://sub.aiv.qzz.io"
COOKIE="/tmp/admin_test.txt"

# Login
curl -s -c $COOKIE -L -o /dev/null "$SITE/admin/login.php" \
  -d 'username=admin&password=shengtuo2026'

# Test all admin pages
echo "=== ADMIN PAGES ==="
for page in / /products /categories /news /sliders /messages /inquiries /pages /settings; do
  size=$(curl -s -b $COOKIE "$SITE/admin${page}.php" | wc -c)
  [ "$size" -gt 1000 ] && echo "✅ $page" || echo "❌ $page ($size bytes)"
done

# Test frontend pages
echo "=== FRONTEND PAGES ==="
for page in / /products /about /contact /news /export /search /sitemap.xml /robots.txt; do
  code=$(curl -s -o /dev/null -w '%{http_code}' "$SITE$page")
  [ "$code" = "200" ] && echo "✅ $page" || echo "❌ $page ($code)"
done

# Test API endpoints
echo "=== API ENDPOINTS ==="
curl -s -X POST "$SITE/api/inquiry.php" \
  -d 'product_id=5&product_name=Test&name=Bot&email=bot@test.com&message=Test'
curl -s -X POST "$SITE/api/message.php" \
  -d 'name=Bot&email=bot@test.com&message=Test'

# Check PHP errors
echo "=== PHP ERRORS ==="
cat /path/to/logs/error.log | tail -5
```

## SEO Linkage Testing (Domain ↔ Frontend)

After changing `site_url` in settings, verify ALL these use the new domain:

```bash
# og:url must be https
curl -s "$SITE/" | grep 'og:url'

# og:image must be absolute URL (not relative)
curl -s "$SITE/product/SLUG" | grep 'og:image'

# Sitemap must use configured domain
curl -s "$SITE/sitemap.xml" | grep '<loc>' | head -3

# Robots.txt Sitemap reference
curl -s "$SITE/robots.txt" | grep 'Sitemap'
```

**PITFALL:** Behind Cloudflare Flexible SSL, `$_SERVER['HTTPS']` is NOT set. `getCurrentUrl()` returns `http://` instead of `https://`. Fix both `templates/header.php` and `includes/functions.php`:

```php
function getCurrentUrl() {
    if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') $proto = 'https';
    elseif (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') $proto = 'https';
    else $proto = 'http';
    return $proto . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}
```

**Also fix `includes/seo.php`** for og:image absolute URLs:
```php
$image = $pageImage ?: ($this->baseUrl . '/assets/images/logo-v2.png');
if ($image && strpos($image, 'http') !== 0) $image = $this->baseUrl . $image;
```

## Database Missing Column Quick Fix

When a module references a column that doesn't exist:

```bash
# Check current structure
mysql -u USER -p DB -e "DESCRIBE table_name;"

# Add missing column
mysql -u USER -p DB -e "ALTER TABLE pages ADD COLUMN template varchar(50) DEFAULT 'default' AFTER content;"

# Make image column nullable
mysql -u USER -p DB -e "ALTER TABLE sliders MODIFY image varchar(255) DEFAULT NULL;"
```

## Bug Fix Checklist (this session 2026-05-30)

| # | Bug | File | Root Cause |
|---|-----|------|------------|
| 1 | `$_GET` typo `$GET` | inquiries.php:54 | Silent PHP variable error |
| 2 | Dashboard missing inquiry stats | admin/index.php | New module not added to dashboard |
| 3 | news INSERT fails silently | news.php:59 | FK constraint: 0 vs NULL |
| 4 | messages API uses wrong column | api/message.php | `status` column doesn't exist (is_read/replied) |
| 5 | messages API missing company | api/message.php | $company variable not extracted |
| 6 | pages INSERT fails | admin/pages.php | `template` column missing from DB |
| 7 | og:url uses http:// | header.php + functions.php | Cloudflare Flexible SSL: HTTPS not detected |
| 8 | og:image relative path | includes/seo.php | No absolute URL conversion |
