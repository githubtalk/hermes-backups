# shengtuo-tractor.com 维护指南

## FTP 账号信息

| 项目 | 值 |
|------|-----|
| FTP 账号 | shanweituo |
| FTP 密码 | C2r3h2q7K3 |
| FTP 服务器 | shanweituo.gotoftp4.com |
| 网站根目录 | /wwwroot/ |

**下载文件：**
```bash
curl -s -u "shanweituo:C2r3h2q7K3" ftp://shanweituo.gotoftp4.com/wwwroot/index.html -o /tmp/shengtuo-index.html
```

**上传文件：**
```bash
curl -T /tmp/shengtuo-index.html -u "shanweituo:C2r3h2q7K3" ftp://shanweituo.gotoftp4.com/wwwroot/index.html
```

## 网站结构

```
/wwwroot/
├── index.html              # 首页
├── css/
│   ├── style.css           # 主样式文件
│   ├── style5.css          # 2026-05 新美化版本（当前使用）
│   ├── 3css.css            # 产品页附加样式
│   └── main.css            # 备用样式
├── js/
│   └── jquery-1.4.3.min.js
├── template/               # ASP 模板文件（动态页面生成源）
│   ├── index.htm
│   ├── about.htm
│   ├── download.htm
│   ├── showcases.htm
│   ├── ShowNews.htm
│   ├── showshop.htm
│   └── webtitu.htm
├── about/                  # 关于我们页面
├── products/               # 产品页面（37个HTML文件 + index.asp）
├── News/                   # 新闻页面（index.asp + 13个HTML文件）
├── cases/                  # 案例展示页面（index.asp + 13个HTML文件）
├── download/               # 下载页面（index.asp + 3个HTML文件）
├── Inquiry/                # 询盘页面（index.asp）
├── message/                # 留言页面（index.asp）
├── images/                 # 图片目录
└── uploadfile/             # 上传文件目录
```

## 页面类型分类

### 静态 HTML 页面（直接 FTP 修改）
- `index.html` - 首页
- `about/*.html` - 关于我们（2.html, 3.html, 6.html, 7.html, 8.html）
- `products/*.html` - 产品详情页（37个文件，如 58.html, 61.html, 62.html 等）
- `News/*.html` - 新闻详情页（13个文件，如 66.html, 67.html 等）
- `cases/*.html` - 案例详情页（13个文件，如 31.html, 32.html 等）
- `download/*.html` - 下载详情页（3个文件，如 4.html, 5.html, 13.html）

### ASP 动态索引页面（FTP 修改 index.asp）
- `products/index.asp` - 产品分类列表
- `News/index.asp` - 新闻列表
- `cases/index.asp` - 案例列表
- `download/index.asp` - 下载列表
- `Inquiry/index.asp` - 询盘表单
- `message/index.asp` - 留言板

**⚠️ 关键区别：** sitemap.html 只包含静态 HTML 链接，不包含 ASP 索引文件。
批量更新 CSS 时必须额外处理这 6 个 ASP 文件。

## 完整站点 CSS 更新流程（5步）

### 第1步：上传新 CSS 文件
```bash
# 使用新文件名绕过 Cloudflare 缓存（必须！版本参数不够可靠）
curl -T /tmp/style-beautified.css -u "shanweituo:C2r3h2q7K3" \
  ftp://shanweituo.gotoftp4.com/wwwroot/css/style5.css
```

### 第2步：更新首页
```bash
# 下载 → 修改 CSS 引用 → 上传
curl -s -u "shanweituo:C2r3h2q7K3" ftp://shanweituo.gotoftp4.com/wwwroot/index.html -o /tmp/index.html
sed -i 's|css/style.css|css/style5.css|g' /tmp/index.html
curl -T /tmp/index.html -u "shanweituo:C2r3h2q7K3" ftp://shanweituo.gotoftp4.com/wwwroot/index.html
```

### 第3步：批量更新静态 HTML（从 sitemap）
```python
import subprocess, re

# 从 sitemap 提取所有 URL
result = subprocess.run(['curl', '-s', 'https://www.shengtuo-tractor.com/sitemap.html'],
                       capture_output=True, text=True)
urls = re.findall(r'href="https://www\.shengtuo-tractor\.com([^"]*)"', result.stdout)

for url in set(urls):
    if not (url.endswith('/') or url.endswith('.html')):
        continue
    ftp_path = url + 'index.html' if url.endswith('/') else url
    
    dl = subprocess.run(['curl', '-s', '-u', 'shanweituo:C2r3h2q7K3',
                        f'ftp://shanweituo.gotoftp4.com/wwwroot{ftp_path}'],
                       capture_output=True, text=True)
    if dl.returncode != 0 or not dl.stdout:
        continue
    
    content = dl.stdout
    new_content = content.replace('../css/style.css', '../css/style5.css')
    new_content = new_content.replace('css/style.css', 'css/style5.css')
    
    local = ftp_path.replace('/', '_')
    with open(f'/tmp/{local}', 'w') as f:
        f.write(new_content)
    
    subprocess.run(['curl', '-s', '-T', f'/tmp/{local}',
                   '-u', 'shanweituo:C2r3h2q7K3',
                   f'ftp://shanweituo.gotoftp4.com/wwwroot{ftp_path}'],
                  capture_output=True, text=True)
```

### 第4步：更新 ASP 索引文件（6个）
```python
asp_files = [
    'products/index.asp',
    'News/index.asp',
    'cases/index.asp',
    'download/index.asp',
    'Inquiry/index.asp',
    'message/index.asp',
]

for asp_file in asp_files:
    dl = subprocess.run(['curl', '-s', '-u', 'shanweituo:C2r3h2q7K3',
                        f'ftp://shanweituo.gotoftp4.com/wwwroot/{asp_file}'],
                       capture_output=True, text=True)
    if dl.returncode != 0 or not dl.stdout:
        continue
    
    new_content = dl.stdout.replace('../css/style.css', '../css/style5.css')
    local = asp_file.replace('/', '_')
    with open(f'/tmp/{local}', 'w') as f:
        f.write(new_content)
    
    subprocess.run(['curl', '-s', '-T', f'/tmp/{local}',
                   '-u', 'shanweituo:C2r3h2q7K3',
                   f'ftp://shanweituo.gotoftp4.com/wwwroot/{asp_file}'],
                  capture_output=True, text=True)
```

### 第5步：更新模板文件（7个）
```bash
for tpl in index.htm about.htm download.htm showcases.htm ShowNews.htm showshop.htm webtitu.htm; do
    curl -s -u "shanweituo:C2r3h2q7K3" \
      "ftp://shanweituo.gotoftp4.com/wwwroot/template/$tpl" -o "/tmp/tpl_$tpl"
    sed -i 's|../css/style.css|../css/style5.css|g' "/tmp/tpl_$tpl"
    curl -T "/tmp/tpl_$tpl" -u "shanweituo:C2r3h2q7K3" \
      "ftp://shanweituo.gotoftp4.com/wwwroot/template/$tpl"
done
```

### 验证
```bash
for page in "/" "/products/" "/products/58.html" "/about/2.html" \
            "/News/" "/cases/" "/download/" "/Inquiry/" "/message/"; do
    echo -n "$page: "
    curl -s "https://www.shengtuo-tractor.com$page" | grep -o "style5.css" || echo "❌ 未更新"
done
```

## 失效链接清单（2026-05 修复）

以下链接已从首页删除（已废弃）：
- translatecompany.com（翻译占位链接）
- msnim:chat（MSN 已废弃）
- taobao.com/webww（旧阿里旺旺）
- alicdn.com（阿里旺旺旧链接）

## WhatsApp 按钮

**号码：** +86 138 0646 1474

**Inline SVG 代码：**
```html
<a href="https://wa.me/8613806461474" target="_blank" style="position:fixed;bottom:30px;right:30px;width:60px;height:60px;background:#25D366;color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:28px;box-shadow:0 4px 15px rgba(37,211,102,0.4);z-index:1000;text-decoration:none;">
  <svg viewBox="0 0 24 24" width="32" height="32" fill="white">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
  </svg>
</a>
```

## 后台管理面板

**URL：** https://www.shengtuo-tractor.com/admin_v19/

后台使用教程文档位于：`/wwwroot/网站后台使用教程.doc`

## 常见陷阱

1. **read_file 行号污染**：read_file 输出带行号前缀（`1|内容`），直接写入文件会损坏 CSS/HTML
2. **Cloudflare 缓存**：必须用新文件名（如 style5.css），版本参数 `?v=xxx` 不够可靠
3. **ASP vs HTML**：sitemap 只含 HTML 链接，ASP 索引文件需单独处理
4. **相对路径**：子页面用 `../css/style.css`，首页用 `css/style.css`
5. **模板 ≠ 页面**：修改 template/*.htm 后，已生成的页面不会自动更新
