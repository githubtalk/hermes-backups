# Nginx Clean URL Configuration for PHP Sites

## Problem
When migrating a PHP site from Apache to Nginx, `.htaccess` rewrite rules don't work. All requests fall through to `index.php`, causing every page to show the homepage content.

## Solution
Each clean URL needs an explicit `location` block in the Nginx config:

```nginx
# Main fallback (catches unknown routes)
location / {
    try_files $uri $uri/ /index.php?$query_string =404;
}

# PHP processing
location ~ \.php$ {
    include snippets/fastcgi-php.conf;
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    include fastcgi_params;
    fastcgi_buffer_size 128k;
    fastcgi_buffers 4 256k;
    fastcgi_busy_buffers_size 256k;
}

# === EXPLICIT CLEAN URL ROUTES (required!) ===

# Exact match routes
location = /products {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/products.php;
    include fastcgi_params;
}

location = /about {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/about.php;
    include fastcgi_params;
}

location = /contact {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/contact.php;
    include fastcgi_params;
}

location = /news {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/news.php;
    include fastcgi_params;
}

# Prefix match routes (with slug)
location /product/ {
    try_files $uri $uri/ /product.php?slug=$uri;
}

location /news/ {
    try_files $uri $uri/ /news_detail.php?slug=$uri;
}

# Query string passthrough routes
location = /export {
    try_files $uri /export.php?$query_string;
}

location = /search {
    try_files $uri /search.php?$query_string;
}

# API endpoints
location /api/ {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    include fastcgi_params;
}

# Sitemap and robots
location = /sitemap.xml {
    try_files /sitemap.xml /sitemap.php;
}

location = /robots.txt {
    try_files /robots.txt =404;
}
```

## Key Points
1. `location = /exact` for exact matches (faster than prefix)
2. `location /prefix/` for slug-based routes
3. `try_files $uri /script.php?$query_string` for simple rewrites
4. Always include `fastcgi_params` for PHP locations
5. API routes use prefix match to handle all endpoints

## Verification
```bash
# Test each clean URL returns different content
curl -s http://site/products | grep "<title>" | head -1
curl -s http://site/about | grep "<title>" | head -1
# Titles should be DIFFERENT for each page
```
