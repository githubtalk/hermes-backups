# Image Asset Sourcing from Reference Sites

## When to Use
User asks to find/scrape images from a reference website for use on the current site.

## Workflow
1. **Discover images**: `curl -sL URL | grep -oP 'src="([^"]*\.(jpg|png|gif|webp))"'`
2. **Download candidates**: `curl -sL -o local/path "http://site/path/to/image"`
3. **Check dimensions**: Use Python `struct` module (no PIL needed)
4. **Catalog by quality**: Green (≥800×600), Yellow (≥400×300), Red (<400×300)
5. **Send to user for review**: Use `send_message` with `MEDIA:` prefix

## Dimension Checking (no PIL)
```python
import struct, os

def get_jpg_size(filepath):
    with open(filepath, 'rb') as f:
        f.read(2)  # SOI
        while True:
            marker = f.read(2)
            if len(marker) < 2 or marker[0] != 0xFF: break
            if marker[1] in (0xC0, 0xC1, 0xC2):
                f.read(3)
                h = struct.unpack('>H', f.read(2))[0]
                w = struct.unpack('>H', f.read(2))[0]
                return w, h
            else:
                length = struct.unpack('>H', f.read(2))[0]
                f.read(length - 2)
    return 0, 0

def get_png_size(filepath):
    with open(filepath, 'rb') as f:
        f.read(8)  # signature
        f.read(4)  # IHDR length
        f.read(4)  # IHDR type
        w = struct.unpack('>I', f.read(4))[0]
        h = struct.unpack('>I', f.read(4))[0]
        return w, h
```

## Quality Tiers
- 🟢 **Good** (≥800×600): Use directly on website
- 🟡 **Medium** (≥400×300): Use for thumbnails/small displays
- 🔴 **Small** (<400×300): Don't use, too low quality

## Common Image Locations on Chinese Sites
- `/upload/` — CMS uploads
- `/upload/img/` — Image gallery uploads
- `/image/` — Static site images
- Banner/slider images are usually the largest (1920×700 typical)

## Sending Images to User
```python
send_message(target="telegram", message="MEDIA:/absolute/path/to/image.jpg")
```
Send banners first, then products, then others. Label each with dimensions.
