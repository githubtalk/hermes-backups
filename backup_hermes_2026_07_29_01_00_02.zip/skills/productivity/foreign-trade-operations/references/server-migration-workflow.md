# Website Server Migration Workflow

## Overview
Complete workflow for migrating a PHP+MySQL website to a new server via SSH.

## Prerequisites
- SSH key for target server (save to `~/.ssh/KEYNAME.pem`, chmod 600)
- Target server: Ubuntu with sudo access (no password)

## Step 1: Create Backup Package

```bash
# Export database
mysqldump -uDB_USER -pDB_PASS DB_NAME > /tmp/database.sql

# Package website files
tar -czf /tmp/website-backup-$(date +%Y%m%d_%H%M%S).tar.gz \
  --exclude='website/logs/*.log' \
  --exclude='website/node_modules' \
  -C /PARENT_DIR website
```

## Step 2: Transfer to New Server

```bash
scp -i ~/.ssh/KEY.pem /tmp/backup.tar.gz user@NEW_IP:/tmp/
scp -i ~/.ssh/KEY.pem /tmp/database.sql user@NEW_IP:/tmp/
```

## Step 3: Remote Installation

```bash
ssh -i ~/.ssh/KEY.pem user@NEW_IP "
# 1. Install LEMP stack
sudo apt-get update -qq
sudo apt-get install -y nginx mysql-server php-fpm php-mysql php-curl php-gd php-mbstring php-xml php-zip

# 2. Start services
sudo systemctl start nginx mysql php*-fpm

# 3. Create database
sudo mysql -e \"CREATE DATABASE DB_NAME CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\"
sudo mysql -e \"CREATE USER 'DB_USER'@'localhost' IDENTIFIED BY 'DB_PASS';\"
sudo mysql -e \"GRANT ALL PRIVILEGES ON DB_NAME.* TO 'DB_USER'@'localhost';\"

# 4. Extract and deploy
cd /tmp && tar -xzf backup.tar.gz
sudo mkdir -p /var/www/site
sudo cp -r website/* /var/www/site/
mysql -uDB_USER -pDB_PASS DB_NAME < database.sql

# 5. Set permissions
sudo chown -R www-data:www-data /var/www/site
sudo chmod -R 755 /var/www/site
sudo chmod -R 775 /var/www/site/logs /var/www/site/uploads

# 6. Configure Nginx (use template from references/)
# Copy nginx-php-cleanurls.conf template, replace DOMAIN/ROOT_DIR/PHP_SOCK
sudo nginx -t && sudo systemctl reload nginx
"
```

## Step 4: Verify

```bash
# Test all pages return 200
for url in "/" "/products" "/about" "/contact"; do
    curl -s -o /dev/null -w "%{http_code}" "http://NEW_IP${url}"
done

# Verify pages have DIFFERENT content (not all returning homepage)
for url in "/" "/products" "/about"; do
    curl -s "http://NEW_IP${url}" | grep -o "<title>[^<]*" | head -1
done
```

## Pitfalls
1. **Nginx clean URLs**: Must add explicit location blocks for each clean URL (see references/nginx-migration-clean-urls.md)
2. **PHP-FPM socket path**: Check with `ls /var/run/php/php*-fpm.sock`
3. **MySQL on small instances**: Don't set `innodb_flush_method=O_DIRECT` on t3.micro — causes crash
4. **tar exclude order**: `--exclude` flags must come BEFORE the source paths
5. **logs directory**: Must exist with www-data ownership before PHP can write to it
