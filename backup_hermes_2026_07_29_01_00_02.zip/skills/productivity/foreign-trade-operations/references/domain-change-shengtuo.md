# shengtuo.cc.cd 域名更换

## 会话背景
- 时间: 2025-05-31
- 旧域名: `https://sub.aiv.qzz.io`
- 新域名: `https://shengtuo.cc.cd`

## 需要更新的文件清单

### 1. nginx 配置
- 路径: `/etc/nginx/sites-enabled/sub-aiv`
- 修改: `server_name sub.aiv.qzz.io;` → `server_name shengtuo.cc.cd sub.aiv.qzz.io;`
- 注意: `sites-available/sub-aiv` 也需同步，否则 `nginx -t` 报 conflict warning
- 清理: 删除 `sub-aiv.bak` 避免冲突（之前就有个备份文件在那里）
- 验证: `sudo nginx -t && sudo nginx -s reload`

### 2. 网站配置文件
- 路径: `/home/ubuntu/shengtuo-website/config/database.php`
- 修改: 默认 `SITE_URL` 常量从 `https://sub.aiv.qzz.io` → `https://shengtuo.cc.cd`
- 实际读取优先级: 数据库 settings 表 > php 常量默认值

### 3. SEO 相关静态文件
- `sitemap.xml` — 48条 `<loc>` URL 全部替换
- `robots.txt` — `Sitemap:` 引用行更新

### 4. 数据库设置（通常后台已更新，可忽略）
- 表: `shengtuo_website.settings`
- 字段: `site_url`
- 连接: `mysql -u shengtuo -pShengTuo2026!`

## 快速批量替换命令
```bash
# sitemap + robots
sed -i 's|https://sub\.aiv\.qzz\.io|https://shengtuo.cc.cd|g' /home/ubuntu/shengtuo-website/sitemap.xml
sed -i 's|https://sub\.aiv\.qzz\.io|https://shengtuo.cc.cd|g' /home/ubuntu/shengtuo-website/robots.txt

# database.php (需 patch)
patch: old_string → new_string (用 patch 工具而非 sed)
```

## 验证步骤
1. `grep -c "shengtuo.cc.cd" /home/ubuntu/shengtuo-website/sitemap.xml` → 应返回 48
2. `grep "loc" /home/ubuntu/shengtuo-website/sitemap.xml | head -3` → 应含新域名
3. `curl -I https://shengtuo.cc.cd` → 应返回 200
4. nginx: `sudo nginx -t && sudo nginx -s reload`

## 常见问题
- **nginx conflicting server name warning**: 说明 sites-available 和 sites-enabled 不同步，删掉 .bak 文件即可
- **数据库 site_url 已是新域名**: 说明用户在后台先改过了，任务变简单只需更新 nginx + 静态文件
- **新域名 SSL 未配置**: 如需 HTTPS，需先 `certbot --nginx -d shengtuo.cc.cd`