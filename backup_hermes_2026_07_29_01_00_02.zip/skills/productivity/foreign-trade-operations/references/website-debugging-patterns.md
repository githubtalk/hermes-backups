# Website Debugging Patterns — sub.aiv.qzz.io

## Page Loader Stuck (Spinner Never Disappears)

**Root Cause**: `window.addEventListener('load', ...)` waits for ALL external resources (Google Fonts, Font Awesome, Bootstrap CDN). In China, these CDNs can be slow or blocked, causing the `load` event to never fire.

**Fix in bundle-v2.min.js**:
```javascript
// BAD — waits for all external resources
window.addEventListener('load', function() {
    const loader = document.querySelector('.page-loader');
    if (loader) {
        setTimeout(() => loader.classList.add('loaded'), 300);
        setTimeout(() => loader.remove(), 800);
    }
});

// GOOD — hide ASAP with multiple fallbacks
function hideLoader() {
    const loader = document.querySelector('.page-loader');
    if (loader) {
        loader.classList.add('loaded');
        setTimeout(() => loader.remove(), 500);
    }
}
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(hideLoader, 200);
});
setTimeout(hideLoader, 3000);  // 3s fallback
window.addEventListener('load', hideLoader);
```

**CSS fallback** (in bundle-v8.min.css):
```css
@keyframes autoHideLoader {
    0%, 85% { opacity: 1; visibility: visible; }
    100% { opacity: 0; visibility: hidden; pointer-events: none; }
}
.page-loader {
    animation: autoHideLoader 3s ease forwards;
}
```

**IMPORTANT**: Changes to `b2b-enhance.js` do NOT take effect — the site loads `bundle-v2.min.js`. Always edit the bundle file directly.

---

## Async CSS Loading (Prevent Render Blocking)

Google Fonts and Font Awesome should load asynchronously in `templates/header.php`:

```html
<!-- BAD — blocks rendering -->
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<!-- GOOD — async loading -->
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet" media="print" onload="this.media='all'">
<noscript><link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet"></noscript>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"></noscript>
```

---

## CSS Selector Broken by Literal `\n`

**Symptom**: WhatsApp floating button not showing despite correct HTML.

**Root Cause**: CSS file has a literal `\n` (backslash+n) instead of actual newline, causing:
- `.wa-float-btn { position: fixed; ... }` to be parsed as `n .wa-float-btn { ... }`
- The selector `n .wa-float-btn` doesn't match any element

**Detection**:
```bash
# Check for literal \n in CSS
grep -c '\\n' /path/to/bundle-v8.min.css
# Or check if the browser sees the correct selector
# In browser console:
document.querySelectorAll('.wa-float-btn').length  # Should be 1
```

**Fix**:
```bash
# Replace literal \n with actual newline
sed -i 's/\\n\/\* === B2B Enhancement === \*\//\n\/\* === B2B Enhancement === *\//' bundle-v8.min.css
```

**Verification**:
```javascript
// In browser console
(() => {
    const btn = document.querySelector('.wa-float-btn');
    if (!btn) return 'NOT FOUND';
    const s = getComputedStyle(btn);
    return { position: s.position, bottom: s.bottom, right: s.right, zIndex: s.zIndex };
})()
// Should return: { position: 'fixed', bottom: '24px', right: '24px', zIndex: '9998' }
```

---

## Dark Background → Light Background Migration

When converting dark sections to light backgrounds, ALL inline white text colors must be updated:

| Original (dark bg) | New (light bg) |
|---|---|
| `color:#fff` | `color:#1a1a1a` |
| `color:rgba(255,255,255,0.8)` | `color:#444` |
| `color:rgba(255,255,255,0.7)` | `color:#666` |
| `color:rgba(255,255,255,0.65)` | `color:#555` |
| `border-color:rgba(255,255,255,0.5)` | `border-color:#aaa` |

**Recommended light backgrounds**:
- About section: `background:#f0f4f8` (light gray-blue)
- Newsletter section: `background:#e8eef5` (slightly different shade)

**Pitfall**: Using `sed` to batch-replace `color:#fff` in a line range can accidentally change accent colors (like gold `#D4A843`). Always verify after changes.

---

## Section Spacing Conventions

**Current standard** (compressed for compact layout):
- Regular sections: `padding: 3rem 0`
- Newsletter/compact sections: `padding: 2rem 0`
- Footer CTA: `padding: 2.5rem 0`

**Exception**: Hero/carousel section height is NOT padding-based — uses `height: 50vw; max-height: 600px; min-height: 300px`. Do not modify.

**Find Your Equipment** (category-showcase): `padding: 4rem 0 2rem` (kept original for visual breathing room after carousel).

---

## Browser Cache vs Server Cache

When user says "看不到" (can't see changes):

1. **Server check**: `curl -I https://sub.aiv.qzz.io/` — look for `cache-control: no-store, no-cache`
2. **CDN check**: `cf-cache-status: DYNAMIC` means Cloudflare is not caching the HTML
3. **PHP cache**: `sudo systemctl reload php8.3-fpm` to clear opcache
4. **CSS/JS cache**: Template uses `<?= time() ?>` for version suffix — auto-busts
5. **User browser**: Instruct to use incognito mode or append `?v=2` to URL

---

## Newsletter Section Pattern

Compact newsletter with limited width:
```html
<section style="padding:2rem 0;background:#e8eef5;color:#1a1a1a;">
    <div class="container" style="max-width:560px;">
        <div class="text-center reveal">
            <h3 style="color:#1a1a1a;font-weight:800;font-size:1.15rem;margin-bottom:0.35rem;">Stay Updated</h3>
            <p style="color:#555;font-size:0.82rem;margin-bottom:1rem;">Get the latest product updates and industry news.</p>
            <form style="display:flex;gap:0.4rem;" onsubmit="event.preventDefault();this.querySelector('button').textContent='Subscribed ✓';this.querySelector('input').value='';">
                <input type="email" placeholder="Enter your email" required style="flex:1;padding:0.5rem 0.8rem;border:1px solid #ccc;border-radius:6px;font-size:0.85rem;outline:none;">
                <button type="submit" style="padding:0.5rem 1.2rem;background:var(--accent,#D4A843);color:#fff;border:none;border-radius:6px;font-weight:700;font-size:0.85rem;cursor:pointer;white-space:nowrap;">Subscribe</button>
            </form>
        </div>
    </div>
</section>
```

---

## Cache Version Management

**footer.php** — JS bundle uses dynamic version:
```php
<script src="/assets/js/bundle-v2.min.js?v=<?= time() ?>"></script>
```

**header.php** — CSS bundle uses dynamic version:
```html
<link href="/assets/css/bundle-v8.min.css?v=<?= time() ?>" rel="stylesheet">
```

When making changes, ensure the `<?=` tags are intact (not escaped to `&lt;?=`).
