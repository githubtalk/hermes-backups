# Dynamic Settings & Domain Binding Pattern

## Problem
Website constants (SITE_URL, CONTACT_PHONE, etc.) were hardcoded in `config/database.php`. Changing domain or SEO settings required code edits.

## Solution: Database-Driven Settings

### Database Table
```sql
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    setting_type VARCHAR(20) DEFAULT 'text',  -- text, textarea, url, image, select
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### Settings Groups (37 items)
| Group | Keys | Count |
|-------|------|-------|
| Domain & Brand | site_url, site_name, site_title, site_description, site_keywords, site_logo, favicon, apple_touch_icon, icp_number | 9 |
| Contact | contact_address, contact_phone, contact_email, contact_whatsapp | 4 |
| Social | social_facebook, social_instagram, social_youtube | 3 |
| SEO & Verification | seo_og_image, seo_og_locale, seo_twitter_card, seo_google_analytics, seo_google_site_verification, seo_google_tag_manager, seo_bing_verification, seo_facebook_app_id, seo_schema_type, seo_schema_price_range, seo_sitemap_freq, seo_google_search_console, seo_baidu_site_verify, seo_baidu_push_token | 14 |
| Business | business_currency, business_trade_terms, business_payment_terms, business_min_order, business_delivery_time, business_port | 7 |

### config/database.php Pattern
```php
// Database credentials are still hardcoded (chicken-egg problem)
define('DB_HOST', 'localhost');
define('DB_NAME', 'shengtuo_website');
// ...

function loadSiteSettings() {
    static $loaded = false;
    if ($loaded) return;
    $loaded = true;
    
    try {
        $db = getDBConnection();
        $stmt = $db->query("SELECT setting_key, setting_value FROM settings");
        $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    } catch (Exception $e) {
        $settings = [];
    }
    
    $s = function($key, $default = '') use ($settings) {
        return isset($settings[$key]) && $settings[$key] !== '' ? $settings[$key] : $default;
    };
    
    // CRITICAL: use !defined() guard to avoid "constant already defined" errors
    if (!defined('SITE_URL')) define('SITE_URL', $s('site_url', 'https://default.com'));
    // ... all other constants
}
```

### functions.php Integration
```php
require_once __DIR__ . '/../config/database.php';
loadSiteSettings();  // MUST be called before any page logic
```

### Admin Settings Page (5 tabs)
Tabs: Domain & Brand | Contact | SEO & Meta | Verification | Business

**Whitelist pattern** (prevent injection):
```php
$allowedKeys = ['site_url', 'site_name', ...];  // explicit list
foreach ($_POST as $key => $value) {
    if (!in_array($key, $allowedKeys)) continue;
    $stmt = $db->prepare("INSERT INTO settings (...) VALUES (?, ?, NOW()) 
                          ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    $stmt->execute([$key, trim($value)]);
}
```

### header.php Using Dynamic Constants
```php
<!-- Favicon from database -->
<link rel="icon" type="image/png" href="<?= FAVICON ?>">
<link rel="apple-touch-icon" href="<?= APPLE_TOUCH_ICON ?>">

<!-- Google verification from database -->
<?php if (defined('GOOGLE_SITE_VERIFICATION') && GOOGLE_SITE_VERIFICATION): ?>
<meta name="google-site-verification" content="<?= escape(GOOGLE_SITE_VERIFICATION) ?>">
<?php endif; ?>

<!-- GA tracking from database -->
<?php if (defined('GA_TRACKING_ID') && GA_TRACKING_ID): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= GA_TRACKING_ID ?>"></script>
<?php endif; ?>
```

### Key Pitfalls
1. **DB credentials can't be dynamic** — chicken-egg: need DB connection to read settings, need credentials to connect
2. **Use `!defined()` guards** — loadSiteSettings() may be called multiple times; constants can only be defined once
3. **PRG pattern for settings save** — POST → redirect → GET prevents duplicate submissions on refresh
4. **Whitelist setting keys** — never use user input directly as array keys or column names
