# Nginx + PHP-FPM Deployment Patterns

## Overview

Deploying PHP websites to an existing Nginx server with PHP 8.3-FPM. Covers configuration, pitfalls, and verification steps.

**Verified on:** Ubuntu 24.04, Nginx, PHP 8.3-FPM (2026-05-29)

## Nginx Site Configuration Template

```nginx
server {
    listen 80;
    server_name sub.example.com;
    root /home/ubuntu/site-directory;
    index index.php index.html index.htm;  # PHP first for PHP sites!

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/json application/xml image/svg+xml;

    # Static asset caching
    location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot|webp)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Main location
    location / {
        try_files $uri $uri/ /index.php?$query_string =404;
    }

    # PHP-FPM handling
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.3-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        
        # PHP buffer optimization
        fastcgi_buffer_size 128k;
        fastcgi_buffers 4 256k;
        fastcgi_busy_buffers_size 256k;
    }

    # Deny access to hidden files
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }

    # Deny access to sensitive files
    location ~* \.(log|sql|bak|backup|old|env)$ {
        deny all;
    }

    # Deny access to config/includes/logs directories
    location ^~ /config/ { deny all; }
    location ^~ /includes/ { deny all; }
    location ^~ /logs/ { deny all; }

    # SEO-friendly URL rewrites
    location /product/ {
        try_files $uri $uri/ /product.php?slug=$uri;
    }
    location /news/ {
        try_files $uri $uri/ /news_detail.php?slug=$uri;
    }

    # Sitemap and robots
    location = /sitemap.xml {
        try_files /sitemap.xml /sitemap.php;
    }
    location = /robots.txt {
        try_files /robots.txt =404;
    }

    # Error pages
    error_page 404 /404.html;
    location = /404.html { internal; }
    error_page 500 502 503 504 /500.html;
    location = /500.html { internal; }

    # Logging
    access_log /var/log/nginx/sub-example-access.log;
    error_log /var/log/nginx/sub-example-error.log;
}
```

## Deployment Steps

```bash
# 1. Create nginx config (must use sudo for /etc/nginx/)
sudo tee /etc/nginx/sites-available/site-name > /dev/null << 'EOF'
... config here ...
EOF

# 2. Enable site (symlink)
sudo ln -sf /etc/nginx/sites-available/site-name /etc/nginx/sites-enabled/

# 3. Test config syntax
sudo nginx -t

# 4. Reload nginx
sudo systemctl reload nginx

# 5. Set file ownership
sudo chown -R www-data:www-data /home/ubuntu/site-directory
sudo chmod -R 755 /home/ubuntu/site-directory

# 6. Ensure PHP-FPM is running
sudo systemctl status php8.3-fpm
```

## Critical Pitfalls

### Pitfall #12: index.html Silently Overrides index.php
If both `index.html` and `index.php` exist in the project root, Nginx's `index` directive matches `.html` first (even if `.php` is listed first in some configs, the default order varies). Symptoms: editing `index.php` has no effect.
**Diagnosis:** `curl -sI URL | grep last-modified` — if timestamp matches `index.html`, it's the culprit.
**Fix:** `mv index.html index.html.bak && sudo systemctl reload nginx`

### Pitfall #13: Nginx try_files $uri Passes Full Path

`try_files $uri $uri/ /product.php?slug=$uri` passes the **full URI path** (e.g., `/product/tractor--404-1`) as the `slug` parameter, not just `tractor--404-1`. This causes database lookup failures.

**Also applies to news detail pages:** `try_files $uri $uri/ /news_detail.php?slug=$uri` passes `/news/agro-2026-exhibition` or even `/news/agro-2026-exhibition.html` as the slug.

**Symptom:** Product/news detail pages return 302 redirect or show homepage content instead of the article.

**Fix in product.php:**
```php
$slug = $_GET['slug'] ?? null;
if ($slug && strpos($slug, '/product/') === 0) {
    $slug = substr($slug, 9);
}
$slug = trim($slug, '/');
```

**Fix in news_detail.php (must also strip .html suffix if links use it):**
```php
$slug = $_GET['slug'] ?? '';
$slug = preg_replace('#^/news/#', '', $slug);  // Strip /news/ prefix
$slug = preg_replace('#\.html$#', '', $slug);   // Strip .html suffix
$slug = trim($slug, '/');
```

**Also set $pageTitle before including header.php (otherwise homepage title shows):**
```php
if (!$article) { http_response_code(404); include '404.html'; exit; }
$pageTitle = $article['title'] . ' - Site Name';
$pageDescription = mb_substr(strip_tags($article['content'] ?? ''), 0, 160);
$currentPage = 'news';
include 'templates/header.php';
```

**Verification:**
```bash
# Must show article title, not homepage title
curl -s "https://site/news/some-slug" | grep -oP '<title>[^<]*</title>'
# Must return 200
curl -s -o /dev/null -w "%{http_code}" "https://site/news/some-slug"
```

### Pitfall #11: PHP Function Duplicate Declaration

Nginx `index` directive processes files **in order**:
```nginx
index index.html index.htm index.php;
```

If `index.html` exists in the document root, it is served **instead of** `index.php` — no error, no warning. You update `index.php` but the site shows stale content from `index.html`.

**Symptom:** `curl -sI https://site.com` shows `last-modified` matching `index.html`, not `index.php`. All PHP features (database content, dynamic pages) are missing from the homepage.

**Diagnosis:**
```bash
# Check if both files exist
ls -la /path/index.*

# Compare timestamps
stat /path/index.html
stat /path/index.php

# Check what's actually being served
curl -sI https://site.com | grep -i last-modified
```

**Fix options (pick one):**
```bash
# Option A: Remove competing HTML file (recommended for PHP sites)
mv /path/index.html /path/index.html.bak
sudo systemctl reload nginx

# Option B: Change index order to prefer PHP
# In nginx config:
index index.php index.html index.htm;
sudo nginx -t && sudo systemctl reload nginx
```

**When this happens:**
- Migrating from static HTML to PHP — old `index.html` was never removed
- Building a new PHP site alongside an existing static site
- Restoring from backup that includes old `index.html`

**Real-world example (sub.aiv.qzz.io, 2026-05-29):** Old `index.html` (13KB static) existed alongside new `index.php` (12KB dynamic). Nginx served the static file, making all PHP template changes invisible. Fix: `mv index.html index.html.bak && sudo systemctl reload nginx`.

### 2. 404 Handling with try_files

```nginx
# ❌ WRONG - All missing files route to index.php (returns 200)
try_files $uri $uri/ /index.php?$query_string;

# ✅ CORRECT - Returns proper 404 for missing files
try_files $uri $uri/ /index.php?$query_string =404;
```

**Also need:**
```nginx
error_page 404 /404.html;
location = /404.html { internal; }
```

**Symptom:** `curl -s -o /dev/null -w "%{http_code}" https://site/nonexistent` returns 200 instead of 404.

### 3. require_once Path Resolution

PHP's `require_once` uses the path relative to the **including file's directory**, NOT the web root.

```php
// ❌ WRONG - In includes/functions.php, this looks for includes/database.php
require_once __DIR__ . '/database.php';

// ✅ CORRECT - Go up one level to find config/database.php
require_once __DIR__ . '/../config/database.php';
```

**Symptom:** `Fatal error: Failed opening required '/path/includes/database.php'`

### 4. File Ownership for PHP-FPM

```bash
# ❌ WRONG - Root owns files, PHP-FPM (www-data) can't write
sudo chown -R root:root /home/ubuntu/site-directory

# ✅ CORRECT - www-data owns files for PHP-FPM access
sudo chown -R www-data:www-data /home/ubuntu/site-directory
```

### 5. Writing Nginx Configs

```bash
# ❌ WRONG - write_file tool refuses to write to /etc/nginx/
# "Refusing to write to sensitive system path"

# ✅ CORRECT - Use sudo tee in terminal
sudo tee /etc/nginx/sites-available/site-name > /dev/null << 'EOF'
... config ...
EOF
```

### 6. Cloudflare Overrides robots.txt

Cloudflare Dashboard's Rules can override the source server's robots.txt.

### 7. MySQL Root Password Unknown

On Ubuntu, if `sudo mysql -e "..."`
```bash
# Use debian-sys-maint credentials
sudo cat /etc/mysql/debian.cnf | grep password | head -1
sudo mysql -u debian-sys-maint -p'FOUND_PASSWORD' -e "CREATE DATABASE ...;"
```

### 8. .html Files Containing PHP Code

When `.html` files contain PHP code, Nginx won't execute the PHP.

**Fix — Option A: Rename to .php (recommended):**
```bash
sudo mv /path/products.html /path/products.php
```

**Fix — Option B: Add fastcgi location for specific .html files:**
```nginx
location = /products.html {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/products.php;
    include fastcgi_params;
}
```

### 9. Static Files Serve Correctly But PHP Shows Errors

If `index.html` loads fine but `index.php` shows database errors:
- Wrong DB credentials in `config/database.php`
- Database not created yet
- PHP include paths pointing to wrong directory

### 10. PHP Function Redeclaration Causes Cascading 500 Errors

When adding helper functions to shared config files, check if they already exist in other included files.

**Symptom:** ALL pages return HTTP 500.
```
PHP Fatal error: Cannot redeclare escape() (previously declared in config/database.php:68) in includes/functions.php on line 47
```

**Prevention:**
1. Always check: `grep -rn 'function escape\|function getCurrentUrl' /path/to/site/`
2. Use `if (!function_exists('funcName'))` guard
3. Ensure `functions.php` is loaded in `header.php` BEFORE `seo.php`

**Fix pattern — correct include order in header.php:**
```php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';  // Has escape(), getCurrentUrl()
require_once __DIR__ . '/../includes/seo.php';        // Uses escape()
```

### 11. Adding .html → .php Routes for New Pages

When creating new PHP pages, add nginx routes so `.html` URLs work:

```nginx
location = /about.html {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/about.php;
    include fastcgi_params;
}
```

**⚠️ Check for duplicate location blocks before adding:**
```bash
sudo grep "location = /about.html" /etc/nginx/sites-enabled/site-name
```

### 13. Clean URLs Need Separate Nginx Routes

Adding `location = /about.html` does NOT make `/about` work. Each clean URL needs its own exact-match route alongside the `.html` route.

**Symptom:** `/about.html` returns 200 but `/about` returns 404.

**Fix — add exact-match clean URL routes:**
```nginx
# Clean URLs (no .html extension)
location = /products {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/products.php;
    include fastcgi_params;
}
location = /about {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/about.php;
    include fastcgi_params;
}
location = /contact {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/contact.php;
    include fastcgi_params;
}
location = /news {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/news.php;
    include fastcgi_params;
}

# .html versions (keep both)
location = /products.html { ... }
location = /about.html { ... }
```

**⚠️ Order matters:** Place clean URL routes BEFORE the `.html` routes in the config. Nginx processes `location =` blocks in order and uses the first exact match.

**Editing nginx configs:** Use `sudo sed -i` or `sudo tee` — the `write_file`/`patch` tools refuse to write to `/etc/nginx/`. Always `sudo nginx -t` before reload.

### 14. Static Asset Cache Prevents CSS/JS Updates

Nginx config `expires 30d; add_header Cache-Control "public, immutable"` + Cloudflare CDN = 30-day stale cache.

**Fix:** Create new CSS/JS filename (not just version parameter):
```bash
# New file with timestamp
cp style.css style-v$(date +%s).css
# Update header.php reference to new filename
```

### 15. Static Assets Location Missing try_files

The static assets `location` block adds caching headers but if it lacks `try_files`, nonexistent files (like `style-v123.css` after a version bump) get routed to PHP instead of returning 404.

**Symptom:** `curl -sI /assets/css/nonexistent.css` returns 200 with HTML content instead of 404.

**Fix:** Add `try_files $uri =404;` to the static assets location:
```nginx
location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot|webp)$ {
    expires 30d;
    add_header Cache-Control "public, immutable";
    access_log off;
    try_files $uri =404;  # ← 必须添加！
}
```

**Verification:**
```bash
# Should return 404
curl -sI "https://site/assets/css/nonexistent.css" | head -1
# Should return 200
curl -sI "https://site/assets/css/style.css" | head -1
```

**⚠️ Symlink 不可靠：** 用 `ln -sf style.css style-v123.css` 创建符号链接后，Cloudflare 可能仍然返回 404。用 `cp` 复制真实文件更可靠。

## Verification Checklist

```bash
# 1. Homepage returns 200
curl -s -o /dev/null -w "%{http_code}" https://site/

# 2. Homepage serves HTML (not PHP errors)
curl -s https://site/ | head -5

# 3. 404 page works
curl -s -o /dev/null -w "%{http_code}" https://site/nonexistent

# 4. Sitemap accessible
curl -s -o /dev/null -w "%{http_code}" https://site/sitemap.xml

# 5. Robots.txt accessible
curl -s -o /dev/null -w "%{http_code}" https://site/robots.txt

# 6. PHP processing works
curl -s -o /dev/null -w "%{http_code}" https://site/admin/

# 7. Response time check
curl -s -o /dev/null -w "%{time_total}" https://site/

# 8. Security headers present
curl -sI https://site/ | grep -i "x-frame\|x-content-type\|x-xss"
```

## PHP-FPM Socket Path

| Distribution | Socket Path |
|-------------|-------------|
| Ubuntu 22.04 + PHP 8.1 | /run/php/php8.1-fpm.sock |
| Ubuntu 24.04 + PHP 8.3 | /run/php/php8.3-fpm.sock |
| Custom | Check: `ls /run/php/` |
