# Nginx Link Audit & Clean URL Workflow (sub.aiv.qzz.io)

## Full Link Audit Checklist

When optimizing a PHP site's links, test ALL of these:

### Internal Page Links
```
/ (homepage)
/about and /about.html
/products and /products.html
/contact and /contact.html
/news and /news.html
/product/{slug} (each product)
/news/{slug} (each article)
/products.html?category={slug} (each category)
/products.html?hp={min}-{max} (each HP range)
/admin/login.php
```

### Static Assets
```
/assets/css/*.css (all CSS files)
/assets/js/*.js (all JS files)
/assets/images/favicon.png
/assets/images/apple-touch-icon.png
/assets/images/logo-v2.png
/assets/images/company.jpg
```

### SEO Files
```
/sitemap.xml
/robots.txt
/manifest.json
```

### Test Command Template
```bash
for url in "https://SITE/" "https://SITE/about" ...; do
  status=$(curl -s -o /dev/null -w "%{http_code}" "$url")
  [ "$status" != "200" ] && echo "❌ $status $url" || echo "✅ $url"
done
```

## Nginx Clean URL Routes

Add `location = /path` exact matches for clean URLs (without .html):

```nginx
# Clean URLs → serve PHP directly
location = /products {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/products.php;
    include fastcgi_params;
}
location = /about {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/about.php;
    include fastcgi_params;
}
location = /contact {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/contact.php;
    include fastcgi_params;
}
location = /news {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/news.php;
    include fastcgi_params;
}
```

**Pitfall:** `location =` has highest priority in nginx, but if there's a physical file/directory at that path, `try_files` in the `location /` block might match first. Verify with `curl -sI`.

**Pitfall:** nginx config at `/etc/nginx/sites-enabled/` is a system path — `patch` tool refuses it. Use `terminal` with `sudo sed` instead.

## News Detail Slug Parsing

**Problem:** Nginx `try_files $uri $uri/ /news_detail.php?slug=$uri` passes the FULL URI as slug:
- URL: `/news/agro-2026-exhibition.html`
- `$_GET['slug']` = `/news/agro-2026-exhibition.html`

**Fix in news_detail.php:**
```php
$slug = $_GET['slug'] ?? '';
$slug = preg_replace('#^/news/#', '', $slug);  // Strip /news/ prefix
$slug = preg_replace('#\.html$#', '', $slug);  // Strip .html suffix
$slug = trim($slug, '/');                       // Strip trailing slashes
```

**Same pattern applies to product.php:**
```php
if ($slug && strpos($slug, '/product/') === 0) {
    $slug = substr($slug, 9);
}
$slug = trim($slug, '/');
```

## news_detail.php Must Set Page Title

**Pitfall:** If `news_detail.php` doesn't set `$pageTitle` before `include 'templates/header.php'`, the `<title>` tag falls back to `SITE_TITLE` (homepage title).

```php
if (!$article) { http_response_code(404); include '404.html'; exit; }
$pageTitle = $article['title'] . ' - Shengtuo Tractor';
$pageDescription = mb_substr(strip_tags($article['content'] ?? ''), 0, 160);
$currentPage = 'news';
include 'templates/header.php';
```

## Common Broken Link Patterns

| Pattern | Cause | Fix |
|---------|-------|-----|
| `/about` → 404 | No nginx route | Add `location = /about` |
| `/products` → 404 | No nginx route | Add `location = /products` |
| `/cases` → 404 | No page exists | Remove from footer |
| `/privacy` → 404 | No page exists | Remove from footer |
| `/news/slug` → 404 | Slug parsing wrong | Fix regex in PHP |
| `/products?category=x` → 0 results | Wrong slug | Use DB slugs, not hardcoded |

## robots.txt Domain Fix

After cloning/migrating a site, robots.txt often has the old domain:

```bash
# Check
grep 'shengtuo-tractor.com' /home/ubuntu/shengtuo-website/robots.txt

# Fix
sed -i 's|https://www.shengtuo-tractor.com/sitemap.xml|https://sub.aiv.qzz.io/sitemap.xml|' robots.txt
```

Also update `config/database.php`:
```php
define('SITE_URL', 'https://sub.aiv.qzz.io');  // Not the old domain
```

## Missing Favicon Fix

If `/assets/images/favicon.png` returns 404:
```bash
cp /home/ubuntu/shengtuo-website/assets/images/logo-v2.png /home/ubuntu/shengtuo-website/assets/images/favicon.png
cp /home/ubuntu/shengtuo-website/assets/images/logo-v2.png /home/ubuntu/shengtuo-website/assets/images/apple-touch-icon.png
```

## PHP 8.1 Null Parameter Warning

`htmlspecialchars()` in PHP 8.1+ warns on null input. Fix `escape()`:
```php
function escape($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}
```

## Site URL Configuration

`sitemap.php` uses `SITE_URL` constant from `config/database.php`. After domain change, update:
```php
define('SITE_URL', 'https://new-domain.com');
```

Otherwise sitemap.xml URLs point to the old domain.
