# Full Site Link Audit Pattern (PHP + Nginx)

## 系统性链接检查流程

### Step 1: 提取所有内部链接
```bash
curl -s "https://site/" | grep -rhoP '(?:href|src)="[^"]*"' | sort -u | grep -v 'http' | grep -v '#' | grep -v 'data:'
```

### Step 2: HTTP状态码批量测试
```bash
for path in "/" "/about" "/products" "/contact" "/news" "/product/slug" ...; do
  status=$(curl -s -o /dev/null -w "%{http_code}" "https://site${path}")
  echo "$status $path"
done
```

### Step 3: 分类修复

**Nginx clean URL路由**（在 `location = /xxx.html` 前添加）：
```nginx
location = /about {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/about.php;
    include fastcgi_params;
}
```

**News详情页slug清理**（nginx try_files传完整URI）：
```php
$slug = $_GET['slug'] ?? '';
$slug = preg_replace('#^/news/#', '', $slug);  // 去掉 /news/ 前缀
$slug = preg_replace('#\.html$#', '', $slug);   // 去掉 .html 后缀
$slug = trim($slug, '/');
```

**导航栏分类slug**：从数据库动态读取，不要硬编码。

**Footer断链**：移除不存在的页面链接（/cases /privacy /terms）。

### Step 4: 域名一致性
- `config/database.php` 的 `SITE_URL` 必须指向当前域名
- `robots.txt` 的 `Sitemap:` 必须指向当前域名
- `sitemap.php` 使用 `SITE_URL` 常量

### Step 5: 缺失资源
- `favicon.png` (32x32) — 从logo裁剪生成
- `apple-touch-icon.png` (180x180) — 从logo裁剪生成

### Step 6: PHP兼容性
- `escape()` 函数需要 `?? ''` 处理 null 参数（PHP 8.1+）

## ⚠️ 新子站几乎必然缺失

1. `robots.txt` 的 Sitemap 指向旧域名
2. `config/database.php` 的 SITE_URL 指向旧域名
3. `favicon.png` / `apple-touch-icon.png` 缺失或尺寸不对
4. 导航栏分类硬编码（与数据库实际slug不匹配）
5. Footer链接指向不存在的页面
