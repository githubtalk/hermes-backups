# "User Can't See Changes" Debugging

## Common Causes (in order of likelihood)

### 1. Browser Cache (most common)
User's phone/browser is caching old CSS/JS/images.
- **Fix**: Tell user to open in **incognito/private mode** or add `?v=2` to URL
- **Prevention**: Use `<?= time() ?>` for cache-busting in `<link>` and `<script>` tags
- **Note**: Cloudflare CDN is set to `DYNAMIC` (no HTML caching), but static assets (CSS/JS/images) have `Cache-Control: public, immutable` with 7-30 day expiry

### 2. CSS/JS Bundle Not Updated
Changes made to source files (e.g., `b2b-enhance.js`) but not to the bundle (`bundle-v2.min.js`).
- **Fix**: Always update the bundle file directly, not source files
- **Detection**: `grep 'your-change' /path/to/bundle-v2.min.js`

### 3. Cloudflare Bot Protection
Browser gets empty page (`<html><head></head><body></body></html>`) while curl shows full content.
- **Detection**: `document.body.innerHTML.length === 0` in browser console
- **Cause**: Cloudflare JS challenge blocks automated browsers
- **Impact**: Affects testing with browser tools, but real users typically pass the challenge
- **Fix**: Use `curl` for server-side verification, browser tools for visual checks only when Cloudflare cooperates

### 4. PHP-FPM Opcache
PHP opcache serving stale files after edits.
- **Fix**: `sudo systemctl reload php8.3-fpm`

## Verification Workflow
```bash
# 1. Check server-side HTML is correct
curl -s https://sub.aiv.qzz.io/ | grep 'expected-content'

# 2. Check CSS/JS are loading
curl -s https://sub.aiv.qzz.io/ | grep 'bundle-v8.min.css\|bundle-v2.min.js'

# 3. Check image compression
ls -lh /path/to/images/

# 4. Force cache bust
# In templates: use <?= time() ?> for version strings
```

## User Communication
When user says "看不到" (can't see):
1. First check server-side HTML with curl
2. If server is correct → tell user to try incognito mode
3. If still broken → check for CSS specificity issues or bundle problems
4. Don't keep making changes hoping they'll appear — diagnose first
