# Nginx Clean URL Rewrite — Critical Migration Pitfall

## Problem
When migrating the PHP website from Apache (.htaccess) to Nginx, ALL pages return the homepage content because Nginx doesn't process `.htaccess` rewrite rules. The `try_files $uri $uri/ /index.php?$query_string` directive sends every clean URL (like `/products`, `/about`) to `index.php`.

## Solution
Each clean URL needs an explicit Nginx `location` block that maps to the correct PHP file:

```nginx
# Clean URLs — exact match
location = /products {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/products.php;
    include fastcgi_params;
}

location = /about {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/about.php;
    include fastcgi_params;
}

location = /contact {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/contact.php;
    include fastcgi_params;
}

location = /news {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/news.php;
    include fastcgi_params;
}

location = /search {
    try_files $uri /search.php?$query_string;
}

location = /export {
    try_files $uri /export.php?$query_string;
}

location = /why-us {
    try_files $uri /why-us.php?$query_string;
}

# Parameterized URLs — pattern match
location /product/ {
    try_files $uri $uri/ /product.php?slug=$uri;
}

location /news/ {
    try_files $uri $uri/ /news_detail.php?slug=$uri;
}

# API endpoints
location /api/ {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    include fastcgi_params;
}

# Static files
location = /sitemap.xml {
    try_files /sitemap.xml /sitemap.php;
}
```

## Detection
After deploying, verify each page returns DIFFERENT content:
```bash
# All pages should have different <title> tags
for url in "/" "/products" "/about" "/contact"; do
    curl -s "http://$SERVER$url" | grep -o "<title>[^<]*" | head -1
done
```

If all pages show the same title, the URL rewriting is broken.

## Full Nginx Config Template
See `templates/nginx-php-cleanurls.conf` for a complete working config.
