# Layout Optimization Pattern — 统一网站结构布局

## 问题
多文件CSS bundle合并后，各section的padding值不一致（0px, 40px, 48px, 64px, 80px混用），部分section无间距。

## 诊断方法
浏览器Console检查所有section的实际padding：
```javascript
document.querySelectorAll('section').forEach(el => {
    const cs = getComputedStyle(el);
    console.log(el.className.split(' ')[0], 'pt:', cs.paddingTop, 'pb:', cs.paddingTop, 'h:', Math.round(el.getBoundingClientRect().height));
});
```

## 标准间距值（CSS变量）
```css
:root {
    --section-py: 4rem;      /* 标准section */
    --section-py-lg: 5rem;   /* 大section（featured, testimonials） */
    --section-py-sm: 3rem;   /* 小section（trust-bar, cta） */
    --banner-py: 4rem;       /* 内页banner */
}
```

## ⚠️ 关键陷阱：CSS var() + !important 可能不生效

当覆盖bundle.min.css中的样式时，使用`var()`变量的`!important`声明可能被浏览器忽略。

**症状：** Console显示padding仍为旧值（如0px），尽管CSS文件已更新。

**修复：** 使用直接值替代CSS变量：
```css
/* ❌ 可能不生效 */
.why-choose-us { padding: var(--section-py) 0 !important; }

/* ✅ 直接值，必定生效 */
.why-choose-us { padding: 4rem 0 !important; }
```

## layout-v2.css 模板

创建独立的布局覆盖文件，放在bundle之后加载：

```css
/* 大section: 5rem */
.featured-products, .testimonials-section { padding: 5rem 0 !important; }

/* 标准section: 4rem */
.category-showcase, .hp-range-section, .hot-products-strip,
.trust-bar, .company-intro-compact, .product-cta-strip { padding: 4rem 0 !important; }

/* 修复0 padding的section */
.why-choose-us, .latest-news, .contact-cta { padding: 4rem 0 !important; }

/* 内页Banner统一 */
.page-banner { padding: 4rem 0 !important; min-height: 260px; display: flex; align-items: center; }
.page-banner h1 { color: #fff; font-size: 2.5rem; font-weight: 800; }
```

## Footer精简

Footer过长（600px+）时，用CSS Grid替代Bootstrap列：
```css
footer.bg-dark { padding-top: 2.5rem !important; padding-bottom: 1.5rem !important; }
.footer-grid { display: grid; grid-template-columns: 1.5fr 1fr 1fr 1.2fr; gap: 2rem; }
@media (max-width: 991.98px) { .footer-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 575.98px) { .footer-grid { grid-template-columns: 1fr; } }
```

## 网格系统模板

```css
/* 产品4列 */
.product-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.5rem; }
@media (max-width: 1199.98px) { .product-grid { grid-template-columns: repeat(3, 1fr); } }
@media (max-width: 767.98px) { .product-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 575.98px) { .product-grid { grid-template-columns: 1fr; } }

/* 分类3列 */
.category-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; }
@media (max-width: 767.98px) { .category-grid { grid-template-columns: 1fr; } }

/* HP Range 4列 */
.hp-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.25rem; }
@media (max-width: 991.98px) { .hp-grid { grid-template-columns: repeat(2, 1fr); } }

/* Testimonial/News 3列 */
.testimonial-grid, .news-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; }
@media (max-width: 767.98px) { .testimonial-grid, .news-grid { grid-template-columns: 1fr; } }
```

## 工作流程

1. Console诊断当前section padding值
2. 创建layout-v2.css，用直接值+!important覆盖
3. 在header.php中bundle.min.css之后加载
4. 验证所有section padding一致
5. 检查移动端响应式断点
