# Cloudflare DNS Routing Troubleshooting

## Key diagnostic commands

```bash
# Check which IP a domain resolves to
dig +short shengtuo.cc.cd

# Check SSL cert issuer/serial (different issuers = routing problem)
echo | openssl s_client -connect shengtuo.cc.cd:443 -servername shengtuo.cc.cd 2>/dev/null | openssl x509 -no_out -issuer -dates

# Check public access (uses Cloudflare)
curl -sL https://shengtuo.cc.cd -w "\nHTTP: %{http_code}\n"

# Check local server (bypasses Cloudflare)
curl -s -H "Host: shengtuo.cc.cd" http://127.0.0.1/path
```

## Problem pattern

When Cloudflare proxies two domains to different origin servers:
- sub.aiv.qzz.io → correct server ✅
- shengtuo.cc.cd → wrong server (different IP) ❌

Signs:
1. `dig +short` shows different IPs for each domain
2. SSL certs have different issuers (e.g. "CN=YE2" vs "CN=E7")
3. `curl -sL` returns different content than local Host header test

## Fix

1. Go to Cloudflare Dashboard → DNS → Records
2. Find the problematic domain's A record
3. Change Proxied→DNS Only (grey cloud) to test, or update A record to correct origin IP
4. Verify with `dig +short` and `curl -sL`

## Multi-server awareness

Before troubleshooting ANY website routing issue:
- **Always** run `dig +short` first to confirm which server the domain points to
- The current server (43.155.135.188) is NOT always the web server — shengtuo.cc.cd runs on AWS 54.168.228.5
- Local nginx config changes only affect traffic routed to THIS server