# Float Layout & Footer Positioning Debugging

## shengtuo-tractor.com 布局结构

```
<body>
  <div id="main">          ← 980px, margin: 0 auto, 居中
    <div id="header">      ← 136px 高
    <div id="nav">         ← 50px 高
    <div id="center">      ← min-height: 500px, overflow: hidden（必须！）
      <div id="left">      ← float: left, 230px 宽
      <div id="right">     ← float: right, 720px 宽
    </div>
  </div>
  <div id="footer">        ← 980px, margin: 0 auto, 居中
</body>
```

## 常见布局问题

### 问题1：Footer 出现在产品栏旁边

**原因：** `#center` 没有 `overflow: hidden`，浮动子元素不参与父容器高度计算。

**修复：** 给 `#center` 添加 `overflow: hidden`

### 问题2：Footer 不居中

**原因：** `#footer` 缺少 `margin: 0 auto`

**修复：** 给 `#footer` 添加 `margin: 0 auto`

### 问题3：Footer 和产品栏重叠

**原因：** `#center` 的 `min-height` 太小，产品列表溢出。

**修复：** 增大 `min-height` 或使用 `overflow: hidden` 让容器自动扩展。

## 诊断脚本

```javascript
// 浏览器 Console 诊断
(() => {
  const elements = ['header', 'nav', 'main', 'center', 'left', 'right', 'footer'];
  const results = {};
  
  elements.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      const rect = el.getBoundingClientRect();
      results[id] = {
        top: rect.top,
        left: rect.left,
        width: rect.width,
        height: rect.height,
        display: window.getComputedStyle(el).display,
        float: window.getComputedStyle(el).float,
        position: window.getComputedStyle(el).position
      };
    }
  });
  
  // 检查问题
  const center = document.getElementById('center');
  const right = document.getElementById('right');
  const footer = document.getElementById('footer');
  
  if (center && right && footer) {
    const cRect = center.getBoundingClientRect();
    const rRect = right.getBoundingClientRect();
    const fRect = footer.getBoundingClientRect();
    
    if (cRect.height < rRect.height) {
      console.warn('⚠️ 浮动未清除：center height < right height');
    }
    
    if (Math.abs(fRect.left - cRect.left) > 5) {
      console.warn('⚠️ Footer 未居中：footer left != center left');
    }
    
    if (fRect.top < cRect.bottom) {
      console.warn('⚠️ Footer 位置错误：footer top < center bottom');
    }
  }
  
  return JSON.stringify(results, null, 2);
})()
```

## CSS 修复模板

```css
/* 确保 #center 包含浮动子元素 */
#center {
    width: 980px;
    min-height: 500px;
    padding: 0;
    overflow: hidden;  /* 关键！ */
}

/* 确保 #footer 居中 */
#footer {
    width: 980px;
    margin: 0 auto;    /* 关键！ */
    background: #333;
    color: #fff;
    padding: 25px 30px;
    font-size: 14px;
    line-height: 1.8;
}
```

## 检查清单

修改 shengtuo-tractor.com CSS 前，检查：

- [ ] `#center` 有 `overflow: hidden`
- [ ] `#footer` 有 `margin: 0 auto`
- [ ] `#left` 是 `float: left`
- [ ] `#right` 是 `float: right`
- [ ] `#main` 有 `margin: 0 auto`
- [ ] 所有容器宽度一致（980px）

## 相关参考

- **Header 修改（搜索栏移除、LOGO 上移）：** `references/header-modification-patterns.md`
