# Header Modification Patterns

## shengtuo-tractor.com Header 结构

```html
<div id="header">        ← padding 控制整体位置
    <div id="logo">      ← float: left, 400px, max-height: 80px
    <div class="globalsearchformzone">  ← 搜索框（可选）
        <form id="globalsearchform">
            <input name="search1" type="text">
            <input name="imageField" type="image" src="images/searchr.png">
        </form>
    </div>
    <div id="nav">       ← 导航菜单 ul > li > a
</div>
```

## 已知修改

### 移除搜索栏

**触发词：** "去掉搜索栏"、"搜索框不要了"

**修改方法：** 删除 HTML 中 `.globalsearchformzone` 整个 div 块。

```python
# 用 execute_code 精确删除
old_search = '''    <div class="globalsearchformzone">
        <form id="globalsearchform" ...>
            ...
        </form>
    </div>
    '''
content = content.replace(old_search, '')
```

**影响：** 无。搜索栏是独立模块，移除不影响 logo 和导航布局。

### LOGO 上移

**触发词：** "LOGO 上移"、"logo 位置太高/太低"

**修改方法：** 调整 `#header` 的 `padding-top`。

```css
/* 原始 */
#header { padding: 20px; }

/* 上移后 */
#header { padding: 5px 20px 20px 20px; }  /* top right bottom left */
```

**影响：** padding-top 减小后，logo 和导航菜单都会上移。导航菜单与 header 底部的蓝色边框保持不变。

### LOGO 在导航栏上方（2026-05-29 实战验证）

**触发词：** "LOGO在导航栏上方"、"logo above nav"、"logo和导航分开"

**问题：** 默认布局中 logo 和 nav 都在 `#header` 内部，logo 浮动在左边，nav 在右边，视觉上是同一行。

**修改方法：** 需要同时修改 HTML 结构和 CSS。

**Step 1: 重构 HTML — 将 nav 移出 header**

```html
<!-- 原始结构 -->
<div id="header">
    <div id="logo"><img src="..."></div>
    <div id="nav"><ul>...</ul></div>
</div>

<!-- 新结构：nav 独立于 header -->
<div id="header">
    <div id="logo"><img src="..."></div>
</div>
<div id="nav">
    <ul>...</ul>
</div>
```

**Step 2: 调整 CSS**

```css
/* header 只包含 logo，高度固定 */
#header {
    height: 90px;           /* logo 80px + 5px padding */
    margin: 0;
    padding: 5px 20px 0px 20px;
    background: #fff;
    border-bottom: none;    /* 移除底部边框 */
    overflow: hidden;       /* 包含浮动的 logo */
}

/* nav 独立显示在 header 下方 */
#nav {
    width: 980px;
    height: 50px;
    background: #2563eb;
    margin: 0 auto;
}
```

**验证：** 浏览器 Console 检查 logo 在 nav 上方：
```javascript
const logo = document.getElementById('logo');
const nav = document.getElementById('nav');
const logoRect = logo.getBoundingClientRect();
const navRect = nav.getBoundingClientRect();
console.log('logo bottom:', logoRect.bottom, 'nav top:', navRect.top);
console.log('logo above nav:', logoRect.bottom <= navRect.top);
```

**⚠️ CDN 缓存陷阱：** CSS 修改后需要创建新文件名（如 `style_v6.css`）才能绕过 Cloudflare 缓存。版本参数 `?v=xxx` 不一定有效。

## CSS 修改工作流

1. 下载 `style_orig.css`（注意：HTML 引用的是 `style_orig.css` 不是 `style.css`）
2. 修改 CSS
3. 上传为新文件名（如 `style_v4.css`）绕过 CDN 缓存
4. 更新 HTML 中的 CSS 引用
5. 上传 HTML
6. 浏览器验证布局位置

**验证命令：**
```javascript
const header = document.getElementById('header');
const logo = document.getElementById('logo');
console.log('header padding-top:', window.getComputedStyle(header).paddingTop);
console.log('logo top:', logo.getBoundingClientRect().top);
```
