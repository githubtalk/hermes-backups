# PHP Website SEO Deep Optimization Patterns

## 1. Product Meta Title Batch Generation

All products had `meta_title = NULL`, causing every product page to show the generic site title. Fix with SQL CASE WHEN:

```sql
UPDATE products SET meta_title = CASE id
    WHEN 1 THEN 'ST404 35-65HP Tractor | China Manufacturer - Shengtuo'
    WHEN 2 THEN 'ST504E 50-80HP Tractor | China Factory - Shengtuo'
    ...
END WHERE id IN (1,2,...);
```

**Title formula:** `{Model} {HP}HP {Type} | {SEO Keyword} - Shengtuo`

**⚠️ Avoid duplication:** If meta_title already contains "Shengtuo", don't append " - Shengtuo Tractor":

```php
$metaTitle = $product['meta_title'] ?: $product['name'];
$pageTitle = strpos($metaTitle, 'Shengtuo') !== false ? $metaTitle : $metaTitle . ' - Shengtuo Tractor';
```

## 2. Product Meta Keywords Batch Generation

```python
# Build keywords from product attributes
kws = [name.lower()]
if model: kws.append(model.lower())
if hp_clean: kws.append(f"{hp_clean}HP tractor")
if is_tractor: kws.extend(['4WD tractor', 'farm tractor', 'tractor factory'])
else: kws.extend(['farm equipment', 'agricultural implements'])
kws.append("China, Shengtuo, tractor manufacturer, agricultural machinery")
keywords = ', '.join(kws[:12])
```

**⚠️ HP value cleaning:** Database stores "35-65HP" or "~140HP". Strip "HP"/"hp"/"~" before building keywords to avoid "35-65HPHP".

## 3. Product Schema.org Fixes

### Absolute image URLs
```php
// ❌ Wrong: relative path
'image' => $product['image'];  // "/assets/images/products/product-1.jpg"

// ✅ Correct: absolute URL
'image' => SITE_URL . '/' . ltrim($product['image'], '/');
```

### Remove price=0
Products don't have prices (on-request). Remove price field or set to empty:

```php
$productData = [
    'name' => $product['name'],
    'image' => SITE_URL . '/' . ltrim($product['image'], '/'),
    'sku' => $product['model'] ?? '',
    'url' => SITE_URL . '/product/' . $product['slug'],
    // No 'price' key → schema shows empty, not "0"
];
```

### Fix offer URL
```php
// In seo.php generateJsonLD():
'offers' => [
    'price' => $data['price'] ?? '',  // Empty, not "0"
    'url' => $data['url'] ?? $this->baseUrl,  // Product URL, not homepage
]
```

## 4. Sitemap Additions

Always include these pages in `generateSitemap()`:

```php
$sitemap .= $this->addSitemapUrl($this->baseUrl . '/products', '0.9', 'daily');
$sitemap .= $this->addSitemapUrl($this->baseUrl . '/news', '0.7', 'daily');
$sitemap .= $this->addSitemapUrl($this->baseUrl . '/export', '0.7', 'monthly');
$sitemap .= $this->addSitemapUrl($this->baseUrl . '/why-us', '0.7', 'monthly');
$sitemap .= $this->addSitemapUrl($this->baseUrl . '/contact', '0.6', 'monthly');
```

**⚠️ sitemap.xml is static:** After running `php sitemap.php`, the XML file is written to disk. nginx serves it directly without PHP. Must regenerate after any sitemap changes.

## 5. Site-Level SEO Settings

Update in database `settings` table:

| Key | Content Pattern |
|-----|----------------|
| `site_title` | `{Brand} \| China {Product} Manufacturer {HP Range}` |
| `site_description` | 160 chars max. Include: product range, certifications, export reach, trade terms |
| `site_keywords` | 10 keywords. Include: country+product, product type, trade terms |

**SEO keyword categories for tractor manufacturer:**
- Core: China tractor manufacturer, agricultural tractor factory
- Product: 4WD tractor, compact tractor, heavy duty tractor
- Trade: tractor export, OEM tractor, tractor FOB price
- Location: Shandong tractor, China tractor supplier

## 6. Page-Specific Keywords

Each page should have unique `$pageKeywords`:

| Page | Keywords Focus |
|------|---------------|
| Homepage | Brand + core products + country |
| Products | Product types + HP ranges + features |
| About | Factory + certifications + history |
| Contact | Pricing + orders + factory visits |
| Export | Trade terms + shipping + certificates |
| Why Us | Quality + reliability + after-sales |

## 7. Admin i18n Batch Translation Pitfalls

When using `perl -pi -e` to batch-translate HTML text to `<?= t('...') ?>`:

**Safe patterns (HTML text):**
```perl
# ✅ Table headers
s|<th>Name</th>|<th><?= t('Name') ?></th>|g

# ✅ Button text
s|>View All</a>|<?= t('View All') ?></a>|g

# ✅ Status text
s|>No messages yet<|<?= t('No messages yet') ?><|g
```

**DANGEROUS patterns (PHP ternary):**
```perl
# ❌ This creates NESTED PHP tags → syntax error!
s|Edit Product|<?= t('Edit Product') ?>|g
# Applied inside: <?= $action === 'edit' ? 'Edit Product' : 'Add Product' ?>
# Result: <?= $action === 'edit' ? '<?= t('Edit Product') ?>' ?>

# ✅ Correct: use patch tool for ternary expressions
# <?= $action === 'edit' ? t('Edit Product') : t('Add Product') ?>
```

**Rule:** Never use perl regex to replace text that appears inside PHP `<?php ?>` or `<?= ?>` tags. Use `patch` tool for those.

## 8. CSS Bundle Optimization

**Before:** 9 CSS files, bundle.min.css = 58KB (same styles repeated 3x)

**Deduplication:**
```bash
md5sum *.css  # Find exact duplicates
# visual-v5.css = visual-v5c.css (same md5)
# style-v2.css ≈ style-v3.css ≈ style-responsive.css (similar)

# Rebuild with unique files only
cat style-responsive.css enhance-v3.css product-focus-v4.css visual-v5c.css > bundle.min.css
```

**After:** 5 unique files, bundle.min.css = 38KB (34% reduction)

**color-harmony.css must load separately** (after bundle) to override generic variables:
```html
<link href="/assets/css/bundle.min.css" rel="stylesheet">
<link href="/assets/css/color-harmony.css" rel="stylesheet">
```

## 9. Heading Hierarchy Fix

Product cards used `<h5>` under `<h2>` sections (skipping H3/H4). Fix:

```html
<!-- ❌ Wrong: H2 → H5 (skips H3, H4) -->
<h2>Featured Tractors</h2>
<h5>ST504 Tractor</h5>

<!-- ✅ Correct: H2 → H3 (semantic) with h5 class (visual) -->
<h2>Featured Tractors</h2>
<h3 class="h5">ST504 Tractor</h3>
```

Apply to: product cards, feature boxes, contact methods, news cards, capability items.
