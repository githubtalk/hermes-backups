# Footer Consistency Pattern（Footer 一致性模式）

## 问题描述

CMS 为每个页面独立生成 HTML，子页面的 footer 内容可能与 index.html 不同。index.html 的 footer 已清理干净，但子页面（about/、cases/、products/ 等）可能仍残留：
- AddThis 分享按钮代码
- Google Analytics 脚本
- Google+ 分享按钮
- 旧浮动联系栏（rightDiv）
- 空 Fax 字段（`<li>Fax：</li>`）

## 标准 Footer 结构

所有页面必须使用一致的 footer 结构：

```html
<div id="footer">
    <div class="links">
        Links：
        <a href='https://www.instagram.com/shengtuo_tractor' target='_blank'>shengtuo-Tractor Company Video</a> | 
    </div>  
    <div class="copyright">
        <p>SHENGTUO TRACTOR,TRACTOR ,SHENGTUO,TRACTOR,CHINA AGRICULTRUAL MACHINE,CHINA TRACTOR &nbsp;ICP:0232829 &nbsp;<a href="/sitemap.html" target="_blank">Sitemap</a></p>
        <p>Add：Address: No.1008 Huaixu North Road,Changle County,Weifang city, Shandong Province, China &nbsp;Tel：+86-13806461474</p>
    </div>
    <div class="clear"></div>
</div>
```

## CSS `.links` 类

必须添加到 CSS 文件（当前版本 style_v8.css）：

```css
#footer .links {
    padding-bottom: 10px;
    border-bottom: 1px solid rgba(255,255,255,0.15);
    margin-bottom: 10px;
}

#footer .links a {
    color: #60a5fa;
}
```

## 清理步骤

使用 `patch` 工具精确替换，不要用 `write_file` 整体替换：

1. **删除 AddThis 代码块：** 从 `<!-- AddThis Button BEGIN -->` 到 `<!-- AddThis Button END -->`
2. **删除 GA 脚本：** 从 `<script>` 到 `</script>` 的 GA 代码
3. **删除 Google+ 分享：** `<div class="g-plus">` 和相关 script
4. **删除 rightDiv 浮动栏：** 整个 `<div id='rightDiv'>...</div>` 块
5. **删除空 Fax 字段：** `<li>Fax：</li>`（侧边栏和 footer 都要删）
6. **添加 Links 区域：** 如果 footer 没有 `.links` div，添加
7. **统一 footer 结构：** 替换为标准结构

## 验证清单

```bash
# 检查是否还有残留
curl -s https://www.shengtuo-tractor.com/about/2.html | grep -c "rightDiv"  # 应为 0
curl -s https://www.shengtuo-tractor.com/about/2.html | grep -c "addthis"   # 应为 0
curl -s https://www.shengtuo-tractor.com/about/2.html | grep -c "analytics" # 应为 0
curl -s https://www.shengtuo-tractor.com/about/2.html | grep -c "Fax"       # 应为 0

# 检查标准结构是否存在
curl -s https://www.shengtuo-tractor.com/about/2.html | grep -c "links"     # 应 > 0
curl -s https://www.shengtuo-tractor.com/about/2.html | grep -c "whatsapp"  # 应 > 0
```

## 批量清理脚本（50+ 页面）

当需要清理大量页面时，逐个用 `patch` 工具太慢。使用批量脚本：

```bash
#!/bin/bash
FTP="ftp://shanweituo:C2r3h2q7K3@shanweituo.gotoftp4.com/wwwroot"
UPDATED=0

# 文件 ID 清单
declare -A DIRS=(
    ["about"]="2 3 6 7 8"
    ["cases"]="31 32 33 34 35 36 37 38 39 40 41 42 43"
    ["download"]="4 5 13"
    ["News"]="66 67 68 69 70 71 72 73 74 75 76 77 78"
    ["products"]="58 61 62 64 65 66 68 137 171 172 175 183 224 225 226 227 228 229 230 231 232 233 234 235 236 237 238 239 240 241 242 243 244 245 246 247 248"
)

NEW_FOOTER='<div id="footer">
    <div class="links">
        Links：
        <a href='"'"'https://www.instagram.com/shengtuo_tractor'"'"' target='"'"'_blank'"'"'>shengtuo-Tractor Company Video</a> | 
    </div>  
    <div class="copyright">
        <p>SHENGTUO TRACTOR,TRACTOR ,SHENGTUO,TRACTOR,CHINA AGRICULTRUAL MACHINE,CHINA TRACTOR &nbsp;ICP:0232829 &nbsp;<a href="/sitemap.html" target="_blank">Sitemap</a></p>
        <p>Add：Address: No.1008 Huaixu North Road,Changle County,Weifang city, Shandong Province, China &nbsp;Tel：+86-13806461474</p>
    </div>
    <div class="clear"></div>
</div>'

for dir in "${!DIRS[@]}"; do
    for id in ${DIRS[$dir]}; do
        local_file="/home/ubuntu/website/generated/$dir/$id.html"
        mkdir -p "$(dirname "$local_file")"
        wget -q "$FTP/$dir/$id.html" -O "$local_file" 2>/dev/null || continue
        
        # Skip if already clean
        grep -q "rightDiv\|addthis\|GoogleAnalyticsObject\|g-plus\|Fax" "$local_file" 2>/dev/null || continue
        
        python3 -c "
import re
with open('$local_file', 'r', encoding='utf-8-sig') as f:
    content = f.read()
original = content
footer_match = re.search(r'<div id=\"footer\">\\\s*\\\n', content)
if footer_match:
    footer_start = footer_match.start()
    whatsapp_match = re.search(r'<!-- WhatsApp|<a href=\"https://wa\\\\.me', content[footer_start:])
    if whatsapp_match:
        clean_start = footer_start + whatsapp_match.start()
        content = content[:footer_start] + '''$NEW_FOOTER''' + '\\\n\\\n' + content[clean_start:]
content = re.sub(r\"<div id='rightDiv'[^>]*>.*?</div>\\\s*</div>\\\s*</div>\\\s*</div>\\\s*\", '', content, flags=re.DOTALL)
content = re.sub(r'<!-- Place this tag where you want.*?<script type=\"text/javascript\">\\\s*\\\\(function\\\\(\\\\).*?</script>\\\s*', '', content, flags=re.DOTALL)
content = re.sub(r'\\\s*<li>Fax：</li>\\\n?', '', content)
with open('$local_file', 'w', encoding='utf-8') as f:
    f.write(content)
print('CHANGED' if content != original else 'NOCHANGE')
"
        
        curl -s -T "$local_file" "$FTP/$dir/$id.html" --ftp-create-dirs >/dev/null 2>&1
        echo "✅ $dir/$id.html"
        ((UPDATED++))
    done
done

echo "Total updated: $UPDATED"
```

**注意：** ASP 索引页面（products/index.asp 等）不能用这个脚本，需要修改 Inc/ 模板文件。

## 相关参考

- **浮动联系栏移除：** `references/floating-contact-bar-whatsapp.md`
- **Footer 定位调试：** `references/float-layout-footer-debugging.md`
- **批量更新工作流：** `references/floating-contact-bar-whatsapp.md` (Step 3)
- **ASP 模板系统：** `references/shengtuo-tractor-asp-pages.md`
