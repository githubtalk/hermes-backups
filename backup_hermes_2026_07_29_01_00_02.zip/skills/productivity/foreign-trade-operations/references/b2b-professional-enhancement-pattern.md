# B2B Professional Enhancement Pattern

## Overview
Essential elements for a professional B2B foreign trade website. Created for sub.aiv.qzz.io based on analysis of web_b2b (React+Django) reference project and industry best practices.

## Files Created
- `assets/css/b2b-enhance.css` (14KB) — All B2B component styles
- `assets/js/b2b-enhance.js` (6.5KB) — Interactive behaviors

## Components Implemented

### 1. Floating WhatsApp Button
Always visible, bottom-right, pulse animation, pre-filled message on click.

```html
<a href="https://wa.me/PHONE?text=Hi%2C%20I%27m%20interested..." 
   class="wa-float-btn" target="_blank">
    <i class="fab fa-whatsapp"></i>
    <span class="wa-float-tooltip">Chat with us!</span>
</a>
```

CSS: Fixed position, `z-index: 9998`, green (#25D366), `@keyframes waPulse` for attention. Mobile: smaller (52px), hide tooltip.

### 2. Back-to-Top Button
Appears after scrolling 400px, smooth scroll to top.

```html
<button class="back-to-top"><i class="fas fa-arrow-up"></i></button>
```

JS: `IntersectionObserver` or scroll listener toggles `.visible` class. Position above WhatsApp button (bottom: 96px).

### 3. Sticky Navbar with Scroll Shadow
Navbar gets shadow on scroll for depth perception.

```css
.navbar.scrolled {
    box-shadow: 0 2px 20px rgba(0,0,0,0.1) !important;
    backdrop-filter: blur(10px);
    background: rgba(255,255,255,0.98) !important;
}
```

Requires: `sticky-top` class on `<nav>`. Nav links get `::after` underline animation on hover/active.

### 4. Page Loading Animation
Brand spinner shown during page load, fades out after content ready.

```html
<div class="page-loader">
    <div class="loader-spinner"></div>
    <div class="loader-text">Brand Name</div>
</div>
```

JS: `window.addEventListener('load', ...)` adds `.loaded` class (opacity: 0, visibility: hidden), then removes element after transition.

### 5. Partner/Client Logos Marquee
Infinite horizontal scroll of grayscale logos, color on hover.

```html
<div class="partner-track">
    <div class="partner-item"><img src="logo1.svg" alt="Partner"></div>
    <!-- Clone items for seamless loop -->
</div>
```

CSS: `animation: marquee 30s linear infinite`, `filter: grayscale(100%)`, hover pauses animation and shows color. JS clones items for seamless loop.

### 6. Newsletter Subscription
Email capture section with gradient background.

```html
<section class="newsletter-section">
    <form class="newsletter-form">
        <input type="email" placeholder="Enter your email" required>
        <button type="submit">Subscribe</button>
    </form>
</section>
```

### 7. Product Quick Inquiry Modal
Bootstrap modal with pre-filled product info.

```html
<div class="modal fade inquiry-modal" id="inquiryModal">
    <!-- Product info display + contact form -->
</div>
```

JS: `openInquiryModal(productName, productImage)` populates modal and shows it.

### 8. Enhanced Footer
Four-column layout with trade badges, social icons (circular), and bottom bar.

Key elements:
- Company info with logo (white filter)
- Quick links with hover underline animation
- Trade badges (FOB/CIF/EXW, T/T/L/C, Port)
- Certification badges in footer bottom
- `::after` accent line on h5 headings

## Integration Checklist

1. Add CSS link in `templates/header.php` after bundle:
```php
<link href="/assets/css/b2b-enhance.css?v=<?= filemtime(...) ?>" rel="stylesheet">
```

2. Add page loader HTML right after `<body>` in header.php

3. Add floating elements before `</body>` in footer.php:
   - WhatsApp float button
   - Back-to-top button
   - Inquiry modal

4. Add JS before closing `</body>`:
```html
<script src="/assets/js/b2b-enhance.js"></script>
```

5. Make navbar sticky: add `sticky-top` class to `<nav>`

6. Add partner logos section and newsletter section to homepage

## Pitfalls

- **WhatsApp pre-fill message**: URL-encode the message text. Use `%27` for apostrophes.
- **z-index conflicts**: WhatsApp button uses 9998, back-to-top uses 9997, page loader uses 99999.
- **Mobile tooltip**: Hide `.wa-float-tooltip` on mobile (display: none) — it overlaps content.
- **Partner marquee**: Must clone items in JS for seamless loop. CSS-only approach has gap at reset point.
- **Page loader removal**: Use `setTimeout` to allow CSS transition before `remove()`. Don't remove immediately.
