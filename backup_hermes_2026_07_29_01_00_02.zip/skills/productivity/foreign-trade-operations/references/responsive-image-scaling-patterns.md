# Responsive Image Scaling Patterns

## Why Use vw Instead of vh

- `vh` (viewport height): On mobile, height is short → images get compressed
- `vw` (viewport width): Images scale proportionally with screen width → consistent aspect ratio
- Combined with `object-fit: cover` + `object-position: center center` → subject always centered

## Carousel/Hero Slider Pattern

```css
/* Base: desktop */
.carousel-item {
    height: 50vw;
    max-height: 600px;
    min-height: 300px;
}
.carousel-item img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
}

/* Tablet */
@media (max-width: 991.98px) {
    .carousel-item { height: 45vw; max-height: 500px; }
}
/* Mobile */
@media (max-width: 767.98px) {
    .carousel-item { height: 55vw; max-height: 400px; }
}
/* Small mobile */
@media (max-width: 575.98px) {
    .carousel-item { height: 60vw; max-height: 300px; }
}
```

## Product Card Image — height: vw Pattern

Use when source images have **consistent** aspect ratios:

```css
/* Base: desktop (4-column grid, ~25% width each) */
.product-image {
    position: relative;
    overflow: hidden;
    height: 14vw;        /* ~56% of column width */
    min-height: 140px;
    max-height: 220px;
}
.product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
    transition: transform 0.3s ease;
}

/* Tablet (2-column) */
@media (max-width: 991.98px) {
    .product-image { height: 18vw; min-height: 130px; max-height: 200px; }
}
/* Mobile (1-column) */
@media (max-width: 767.98px) {
    .product-image { height: 50vw; min-height: 160px; max-height: 280px; }
}
```

## Product Card Image — aspect-ratio Pattern

Use when source images have **inconsistent** aspect ratios (e.g., 302x227 to 887x885):

```css
.product-image {
    position: relative;
    overflow: hidden;
    aspect-ratio: 4/3;   /* Force consistent ratio */
    width: 100%;
}
.product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
    transition: transform 0.3s ease;
}

/* Responsive aspect-ratio */
@media (max-width: 991.98px) { .product-image { aspect-ratio: 3/2; } }
@media (max-width: 767.98px) { .product-image { aspect-ratio: 1/1; } }
@media (max-width: 575.98px) { .product-image { aspect-ratio: 4/3; } }
```

### Responsive aspect-ratio breakpoints

| Breakpoint | Aspect Ratio | Reason |
|-----------|-------------|--------|
| Desktop (>992px) | 4:3 | Traditional product photo ratio |
| Tablet (768-992px) | 3:2 | Slightly wider for 2-column grid |
| Mobile (<768px) | 1:1 | Square for single-column visual impact |
| Small mobile (<576px) | 4:3 | Back to traditional for readability |

## Selection Guide

| Scenario | Method | Why |
|----------|--------|-----|
| Source images same ratio | `height: vw` | More flexible, adapts to content |
| Source images different ratios | `aspect-ratio` | Enforces uniform visual grid |
| Hero/banner images | `height: vw` | Full-width, ratio follows viewport |
| Product thumbnails | `aspect-ratio` | Consistent card layout |

Both methods use:
- `object-fit: cover` — Crop to fill, maintain ratio
- `object-position: center center` — Subject centered when cropped

## vw Calculation Logic

| Layout | Columns | vw Value | Rationale |
|--------|---------|----------|-----------|
| Desktop 4-col | 4 | 14vw | ~56% of 25% column width |
| Tablet 2-col | 2 | 18vw | ~36% of 50% column width |
| Mobile 1-col | 1 | 50vw | Half screen width, large and clear |

## Common Pitfalls

1. **Using fixed `px` heights** — Doesn't scale across devices
2. **Using `vh`** — Mobile height too short, images compressed
3. **Missing `object-position`** — Subject may be cropped off-center
4. **Missing `min-height`** — Images can become tiny on narrow viewports
5. **Missing `max-height`** — Images can become extremely tall on ultra-wide screens
6. **Using `height: vw` when source images have inconsistent ratios** — Use `aspect-ratio` instead
7. **Forgetting responsive breakpoints** — Single `aspect-ratio` value doesn't work well across all devices
