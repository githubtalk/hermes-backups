# Security Hardening Pattern for PHP Websites

## Login Rate Limiting

### Implementation (login.php)
```php
// At top of POST handler, before DB query
function checkLoginRateLimit($ip, $username) {
    $logFile = __DIR__ . '/../logs/login_attempts.log';
    if (!file_exists($logFile)) return true;
    
    $lines = file($logFile, FILE_IGNORE_NEW_LINES);
    $cutoff = time() - 900; // 15 minutes
    $attempts = 0;
    
    foreach ($lines as $line) {
        $parts = explode('|', $line);
        if (count($parts) >= 3 && $parts[0] === $ip && $parts[1] === $username && (int)$parts[2] > $cutoff) {
            $attempts++;
        }
    }
    return $attempts < 5;
}

// Log failed attempt
file_put_contents($logFile, "$ip|$username|" . time() . "\n", FILE_APPEND | LOCK_EX);

// On success, clear attempts for this IP+username
// On failure, show "Too many login attempts. Please try again in 15 minutes."
```

## Nginx Security Headers

### Add in server block (before location blocks)
```nginx
# Security headers
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
```

## Upload Directory Protection

### Nginx rule (in server block)
```nginx
# Deny PHP execution in uploads
location ~* /uploads/.*\.php$ {
    deny all;
    return 403;
}
```

### .htaccess fallback (Apache)
```apache
<FilesMatch "\.php$">
    Order Deny,Allow
    Deny from all
</FilesMatch>
```

## Production File Cleanup

**Files to delete before going live:**
- `test.php` — PHP info/test pages
- `db-test.php` — Database connection test
- `*.bak` — Backup files
- `*.corrupted` — Damaged files
- `phpinfo.php` — Server info exposure
- `.git/` — Source code exposure

## Security Checklist
- [ ] Login rate limiting (5 attempts / 15 min)
- [ ] CSRF tokens on all forms
- [ ] XSS protection (escape() on all output)
- [ ] SQL injection protection (prepared statements)
- [ ] Upload directory: no PHP execution
- [ ] Security headers configured
- [ ] Test/debug files removed
- [ ] Error display OFF (log only)
- [ ] Admin session timeout (1 hour)
- [ ] HTTPS enforced
