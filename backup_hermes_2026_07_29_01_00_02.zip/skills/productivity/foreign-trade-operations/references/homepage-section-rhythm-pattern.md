# Homepage Section Rhythm Pattern — 首页Section交替节奏优化

## 问题：背景节奏混乱

15个section堆叠时，容易出现同色背景相邻（3个白色连排、2个灰色连排），视觉上融为一体，失去section间的区分感。

## 诊断脚本（浏览器Console）

```javascript
const sections = document.querySelectorAll('main > section');
sections.forEach((s, i) => {
    const style = window.getComputedStyle(s);
    const h = s.querySelector('h2,h1');
    const title = h ? h.textContent.trim().substring(0, 40) : '(no heading)';
    console.log(`${i+1}. ${title} | bg: ${style.backgroundColor} | h: ${Math.round(s.getBoundingClientRect().height)}px`);
});
```

输出示例（问题版本）：
```
1. Hero           | bg: transparent | h: 600px
2. Category       | bg: rgb(232,238,244) | h: 698px  ← 浅蓝
3. HP Range       | bg: transparent  | h: 461px
4. Featured Prod  | bg: rgb(255,255,255) | h: 2008px ← 白
5. Hot Products   | bg: transparent  | h: 1731px   ← 透明（无区分）
6. Why Choose Us  | bg: rgb(255,255,255) | h: 591px  ← 白（同④）
7. Stats          | bg: rgb(255,255,255) | h: 206px  ← 白（3个白连排！）
8. Trust Bar      | bg: rgb(249,250,251) | h: 245px
9. Testimonials   | bg: rgb(255,255,255) | h: 742px  ← 白（又是白）
10. Certs         | bg: rgb(232,238,244) | h: 698px
11. News          | bg: rgb(249,250,251) | h: 629px
12. Company Intro | bg: rgb(249,250,251) | h: 358px  ← 灰（同⑪连排）
13. CTA Strip     | bg: transparent  | h: 272px
14. Contact CTA   | bg: rgb(249,250,251) | h: 310px
```

## 交替背景节奏规则

```
透明（Hero）        — 轮播图，无背景
浅蓝 ████           — 分类/认证等"介绍性"内容
白色 ░░░░           — 产品/特性等"核心"内容
灰50 ▒▒▒▒           — HP范围/新闻等"辅助"内容
白色 ░░░░           — 交替回来
浅蓝 ████           — 评价/信任等"社交证明"
白色 ░░░░           — 证书展示
灰50 ▒▒▒▒           — 新闻
深蓝渐变 ▓▓▓▓       — 关于/CTA等"转化"内容
黑色 ▓▓▓▓           — 最终CTA
```

**核心规则：相邻section背景色不能相同。**

## Section合并策略

当section数量>12时，用户滚动疲劳。合并规则：

| 合并前（碎片） | 合并后（紧凑） | 理由 |
|---|---|---|
| Featured Products + Hot Products | 统一Featured Products | 都是产品卡片，重复展示 |
| Why Choose Us + Stats (独立) | Why Choose Us底部加分隔线+Stats | Stats太小不值得独立section |
| Testimonials + Trust Bar (独立) | Testimonials底部加分隔线+Trust | Trust Bar太小不值得独立section |
| Company Intro + CTA Strip | 深蓝渐变背景合并 | 两者都是"转化"内容 |

**合并方法：** 在同一个`<section>`内用`border-top`或`padding-top`分隔子区块，而不是用独立section。

**合并后HTML模式：**
```html
<!-- 合并: Why Choose Us + Stats -->
<section style="padding:4.5rem 0;background:#fff;">
    <div class="container">
        <!-- Why Choose Us内容 -->
        <div class="row g-4 mb-5">
            <div class="col-lg-3 col-md-6"><div class="feature-box-modern">...</div></div>
            <!-- ... 4个feature cards ... -->
        </div>
        <!-- Stats用border-top分隔 -->
        <div class="stats-grid reveal" style="border-top:1px solid var(--gray-200);padding-top:3rem;">
            <div class="stat-item"><div class="stat-number">15+</div><div class="stat-label">Years</div></div>
            <!-- ... -->
        </div>
    </div>
</section>

<!-- 合并: Testimonials + Trust Bar -->
<section style="padding:4.5rem 0;background:var(--primary-light);">
    <div class="container">
        <!-- Testimonials -->
        <div class="row g-4 mb-5">...</div>
        <!-- Trust badges用border-top分隔 -->
        <div class="row reveal" style="border-top:1px solid rgba(255,255,255,0.3);padding-top:2.5rem;">
            <div class="col-6 col-md-3"><div class="trust-item">...</div></div>
            <!-- ... -->
        </div>
    </div>
</section>
```

## 统一Padding标准

所有section使用统一padding `4.5rem 0`（72px）。用inline style直接设置，避免CSS变量覆盖问题：

```html
<section style="padding:4.5rem 0;background:var(--primary-light);">
```

**不要用CSS变量：** `padding: var(--section-py) 0` 可能被bundle.min.css的`:root`覆盖导致失效。

## 10-Section首页模板（优化后）

```
① Hero        — 透明（轮播图）
② Category    — 浅蓝 var(--primary-light)（分类卡片）
③ Products    — 白色 #fff（推荐产品+Load More+Tab筛选）
④ HP Range    — 灰50 var(--gray-50)（马力区间卡片）
⑤ Why Us      — 白色 #fff（特性卡片 + 统计数字，border-top分隔）
⑥ Testimonials— 浅蓝 var(--primary-light)（评价 + 信任徽章，border-top分隔）
⑦ Certs       — 白色 #fff（证书画廊+lightbox）
⑧ News        — 灰50 var(--gray-50)（新闻卡片）
⑨ About+CTA   — 深蓝渐变 linear-gradient(135deg, var(--primary), var(--primary-deep))
⑩ Contact CTA — 黑色 var(--gray-900)（最终转化按钮）
```

## About + CTA 合并模式

将公司简介和CTA合并到一个深蓝渐变section中，左侧文字+右侧统计数据：

```html
<section style="padding:4.5rem 0;background:linear-gradient(135deg,var(--primary) 0%,var(--primary-deep) 100%);color:#fff;">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <span class="section-badge" style="color:var(--accent);">About Shengtuo</span>
                <h2 style="font-weight:800;color:#fff;">Company Name</h2>
                <p style="color:rgba(255,255,255,0.8);">Description...</p>
                <div style="display:flex;gap:1rem;">
                    <a href="/about" class="btn-modern-accent">Learn More</a>
                    <a href="/contact" class="btn-modern-outline" style="border-color:rgba(255,255,255,0.5);color:#fff;">Contact Us</a>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="stats-grid">
                    <div class="stat-item"><div class="stat-number" style="color:var(--accent);">100M</div><div class="stat-label" style="color:rgba(255,255,255,0.7);">RMB Capital</div></div>
                    <!-- ... -->
                </div>
            </div>
        </div>
    </div>
</section>
```

## Contact CTA 模式

黑底+金色按钮+3按钮布局（Products/WhatsApp/Email）：

```html
<section style="padding:4rem 0;background:var(--gray-900);color:#fff;text-align:center;">
    <div class="container reveal">
        <h2 style="font-weight:800;color:#fff;">Ready to Find Your Perfect Tractor?</h2>
        <p style="color:var(--gray-400);margin-bottom:2rem;">Subtitle text...</p>
        <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;">
            <a href="/products" class="btn-modern-primary" style="background:var(--accent);">
                <i class="fas fa-tractor me-2"></i>View All Products
            </a>
            <a href="https://wa.me/..." class="btn-modern-outline" style="border-color:rgba(255,255,255,0.4);color:#fff;" target="_blank">
                <i class="fab fa-whatsapp me-2"></i>WhatsApp Us
            </a>
            <a href="/contact" class="btn-modern-outline" style="border-color:rgba(255,255,255,0.4);color:#fff;">
                <i class="fas fa-envelope me-2"></i>Email Us
            </a>
        </div>
    </div>
</section>
```

## 验证清单

- [ ] 浏览器Console诊断：无相邻section同色背景
- [ ] Section数量 ≤ 10
- [ ] 所有section padding统一（4.5rem）
- [ ] 合并的section内有border-top分隔线
- [ ] About区域使用深蓝渐变背景
- [ ] Contact CTA使用黑色背景+金色按钮
- [ ] 移动端各section高度合理（不过长）
