# Page Loader Pitfalls & Fix

## Problem
Page-loader (`.page-loader` with `position: fixed; inset: 0; z-index: 99999; background: #fff`) covers entire page. Uses `window.addEventListener('load', ...)` to hide, but `load` event requires ALL external resources (Google Fonts, Font Awesome, Bootstrap CDN) to finish loading.

**In China**, Google CDN (fonts.googleapis.com, fonts.gstatic.com) is often slow or blocked → `load` event never fires → white overlay + spinner stays forever → user sees blank page.

## Failed Fixes (don't repeat)
1. DOMContentLoaded + 3s timeout + CSS animation fallback — still unreliable
2. CSS `@keyframes autoHideLoader` animation — CSS specificity issues with bundle files

## Working Solution
**Remove the page-loader entirely.** Delete the HTML element from `templates/header.php`:
```html
<!-- DELETE THIS -->
<div class="page-loader">
    <div class="loader-spinner"></div>
    <div class="loader-text">Shengtuo Tractor</div>
</div>
```

## Async CDN Loading Pattern (still use this)
```html
<link href="https://fonts.googleapis.com/css2?family=..." rel="stylesheet" media="print" onload="this.media='all'">
<noscript><link href="https://fonts.googleapis.com/css2?family=..." rel="stylesheet"></noscript>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"></noscript>
```

## Debugging: "User sees blank page"
1. `curl -s URL | grep 'page-loader'` — check if loader exists
2. Check CDN accessibility: `curl -o /dev/null -s -w "%{time_total}s" "https://fonts.googleapis.com/..."` 
3. If page works via curl but browser shows blank → Cloudflare JS challenge (separate issue)
