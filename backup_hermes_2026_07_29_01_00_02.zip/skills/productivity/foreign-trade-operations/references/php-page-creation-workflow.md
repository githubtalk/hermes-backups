# PHP Page Creation & Admin Backend Connection

## Overview

Creating new database-driven PHP pages (About, Contact, News) for the sub.aiv.qzz.io website system, connected to the admin backend.

**Verified on:** Ubuntu 24.04, Nginx, PHP 8.3-FPM, MySQL (2026-05-29)

## Complete Workflow

### 1. Create the PHP Page File

```php
<?php
require_once 'config/database.php';
$db = getDBConnection();
$page = $db->query("SELECT * FROM pages WHERE slug='about' AND is_active=1")->fetch();
include 'templates/header.php';
?>
<div class="container py-5">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item active">About Us</li>
        </ol>
    </nav>
    <h1>About Us</h1>
    <?php if ($page && !empty($page['content'])): ?>
        <?= $page['content'] ?>
    <?php else: ?>
        <p>Default fallback content...</p>
    <?php endif; ?>
</div>
<?php include 'templates/footer.php'; ?>
```

### 2. Add Nginx Route (CRITICAL — Without This You Get 404)

```nginx
# Add to /etc/nginx/sites-enabled/sub-aiv BEFORE the location /news/ block
location = /about.html {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/about.php;
    include fastcgi_params;
}
```

**Insert via sed (before existing block):**
```bash
sudo sed -i '/location \/news\/ {/i\    location = /about.html {\n        fastcgi_pass unix:/run/php/php8.3-fpm.sock;\n        fastcgi_param SCRIPT_FILENAME $document_root/about.php;\n        include fastcgi_params;\n    }\n' /etc/nginx/sites-enabled/sub-aiv
```

**Test and reload:**
```bash
sudo nginx -t && sudo systemctl reload nginx
```

### 3. Verify

```bash
curl -s -o /dev/null -w "%{http_code}" "https://sub.aiv.qzz.io/about.html"
# Must return 200
```

## PHP Template Dependencies (Common 500 Errors)

### header.php Requires These Functions

| Function | Error if Missing |
|----------|-----------------|
| `escape()` | `Call to undefined function escape()` |
| `getCurrentUrl()` | `Call to undefined function getCurrentUrl()` |
| `$pdo` variable | `Undefined variable $pdo` |

### Fix: Append to config/database.php

```php
// HTML escape function
if (!function_exists('escape')) {
    function escape($str) {
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    }
}

// Get current URL
if (!function_exists('getCurrentUrl')) {
    function getCurrentUrl() {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost';
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        return $protocol . '://' . $host . $uri;
    }
}
```

### Fix: header.php $pdo → getDBConnection()

```php
// ❌ WRONG (line 12 of header.php)
$seo = new SEO($pdo, SITE_URL);

// ✅ CORRECT
$db = getDBConnection();
$seo = new SEO($db, SITE_URL);
```

### Diagnosis

```bash
# Test PHP directly (outside nginx)
php /home/ubuntu/shengtuo-website/about.php 2>&1 | head -5
# Look for "Fatal error" or "Warning" messages
```

## Admin Backend Connection Patterns

### Contact Form → Messages Table

```php
// api/message.php
$stmt = $db->prepare("INSERT INTO messages (name, email, phone, subject, message, status, created_at) VALUES (?, ?, ?, ?, ?, 'new', NOW())");
$stmt->execute([$name, $email, $phone, $subject, $message]);
header('Location: /contact.html?sent=1');
```

Admin views messages at `/admin/messages.php`.

### News Page → News Table

```php
// news.php - List all news
$news = $db->query("SELECT * FROM news WHERE is_active=1 ORDER BY published_at DESC, id DESC")->fetchAll();

// news_detail.php - Single article by slug
$slug = $_GET['slug'] ?? '';
$stmt = $db->prepare("SELECT * FROM news WHERE slug = ? AND is_active=1");
$stmt->execute([$slug]);
$article = $stmt->fetch();
if (!$article) { http_response_code(404); include '404.html'; exit; }
```

Admin manages news at `/admin/news.php`.

### About/Contact Pages → Pages Table

Pages content stored in `pages` table with `slug` field:
- `slug='about'` → about.html
- `slug='contact'` → contact.html

Admin edits pages at `/admin/pages.php`.

## File Permission Issues

```bash
# Files owned by root = PHP can't write
sudo chown -R ubuntu:ubuntu /home/ubuntu/shengtuo-website/

# After creating files, restore www-data for PHP-FPM
sudo chown www-data:www-data /home/ubuntu/shengtuo-website/assets/images/*.jpg
```

**write_file tool fails with Permission denied** → Run `sudo chown ubuntu:ubuntu /path/` first.

## Complete Page Creation Checklist

- [ ] PHP file created (about.php, contact.php, news.php)
- [ ] Nginx location block added for .html → .php routing
- [ ] `sudo nginx -t` passes
- [ ] `sudo systemctl reload nginx` done
- [ ] `escape()` and `getCurrentUrl()` functions exist in database.php
- [ ] header.php uses `getDBConnection()` not `$pdo`
- [ ] `curl -s -o /dev/null -w "%{http_code}" URL` returns 200
- [ ] Contact form POST endpoint exists (api/message.php)
- [ ] Admin backend pages exist and are accessible
