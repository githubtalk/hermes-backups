# CSS Business Professional Design — shengtuo-tractor.com

## Design Principles (User-Confirmed)

### 1. Size Constraints (HARD RULES)
- `#header` height: `min-height: 136px` (original)
- `.flash` banner height: `height: 373px` (original)
- Product columns: 4 columns (original)
- User says "不变" = NEVER change these values

### 2. Layout Preferences
- Compact layout (no large gaps between sections)
- `.index_about { margin-bottom: 0; }`
- `.index_product { margin-top: 0; }`
- `#center { padding: 0; }`
- Left-aligned content (not centered with padding)

### 3. Color Preferences
- Light color scheme (not too dark)
- Blue-based professional palette
- Current production colors (style14.css):
  - Primary: `#3b82f6` (lighter blue)
  - Primary dark: `#2563eb`
  - Nav background: `#3b82f6` → `#60a5fa` gradient
  - Text primary: `#334155` (softer than #1e293b)
  - Text secondary: `#64748b`
  - Background: white with subtle gradient

### 4. Typography
- Font: Inter (Google Fonts) + Microsoft YaHei fallback
- Body font-size: 14px
- Line-height: 1.4 (compact)

## CSS Variable Template

```css
:root {
    --primary: #3b82f6;
    --primary-dark: #2563eb;
    --primary-light: #60a5fa;
    --secondary: #1e293b;
    --accent: #f59e0b;
    --text-primary: #334155;
    --text-secondary: #64748b;
    --text-light: #b0bec5;
    --bg-white: #ffffff;
    --bg-light: #f8fafc;
    --bg-gray: #f1f5f9;
    --border: #e2e8f0;
    --radius: 8px;
    --radius-lg: 12px;
    --transition: all 0.3s ease;
}
```

## Component Patterns

### Navigation Bar
```css
#nav {
    float: left;
    width: 1200px;
    height: 42px;
    background: linear-gradient(135deg, #3b82f6 0%, #60a5fa 100%);
    box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
}
#nav a {
    font: 500 13px/42px 'Inter', 'Microsoft YaHei', Arial;
    letter-spacing: 0.5px;
    text-transform: uppercase;
    width: 140px;
}
#nav a:hover {
    background: rgba(255, 255, 255, 0.15);
}
```

### Product Cards (4-column grid)
```css
.products_list {
    list-style: none;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
    padding: 8px 0;
}
.products_list li {
    text-align: center;
    background: var(--bg-white);
    border-radius: var(--radius-lg);
    padding: 10px;
    border: 1px solid var(--border);
    transition: var(--transition);
}
.products_list li:hover {
    transform: translateY(-8px);
    box-shadow: var(--shadow-lg);
    border-color: var(--primary);
}
.products_list li img {
    width: 140px;
    height: 110px;
    object-fit: cover;
}
```

### Category Sidebar
```css
.category_title {
    height: 38px;
    border-bottom: 3px solid var(--primary);
    font: 600 14px/38px 'Inter', Arial, Verdana;
    position: relative;
    padding-left: 15px;
}
.category_title::before {
    content: '';
    position: absolute;
    left: 0;
    bottom: -3px;
    width: 40px;
    height: 3px;
    background: var(--accent);
}
```

## Width Variants

| Variant | #main width | #nav width | .flash width | Product columns |
|---------|-------------|------------|--------------|-----------------|
| 980px (original) | 980px | 980px | 968px | 4 columns |
| 1200px (current) | 1200px | 1200px | 1188px | 4 columns (5 possible) |

## Batch Update Workflow

When changing CSS version (e.g., style13.css → style14.css):

1. Upload new CSS: `curl -T /tmp/style14.css -u "USER:PASS" ftp://HOST/wwwroot/css/style14.css`
2. Update index.html: Replace `style13.css` with `style14.css`
3. Update all HTML pages from sitemap (~56 files)
4. Update 6 ASP index files (products, News, cases, download, Inquiry, message)
5. Update template files (6 files in /template/)
6. Verify key pages: `/`, `/products/`, `/News/`, `/cases/`, `/download/`, `/Inquiry/`, `/message/`

**Time estimate:** ~4-5 minutes for 60+ files

## Verification Commands

```bash
# Check current CSS version
curl -s "https://www.shengtuo-tractor.com/" | grep -o "style[0-9]*\.css"

# Check header height
curl -s "https://www.shengtuo-tractor.com/css/style14.css" | grep -A3 "#header {"

# Check banner height
curl -s "https://www.shengtuo-tractor.com/css/style14.css" | grep -A5 ".flash {"

# Check product columns
curl -s "https://www.shengtuo-tractor.com/css/style14.css" | grep "grid-template-columns"

# Verify all pages use same CSS
for page in / /products/ /News/ /cases/ /download/ /Inquiry/ /message/; do
    echo -n "$page: "
    curl -s "https://www.shengtuo-tractor.com$page" | grep -o "style[0-9]*\.css"
done
```
