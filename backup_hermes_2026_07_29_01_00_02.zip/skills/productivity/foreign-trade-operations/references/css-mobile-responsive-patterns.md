# CSS Mobile Handling for shengtuo-tractor.com

## ⚠️ 用户移动端偏好（注意：可能变化！）

**不同会话中用户表达过不同偏好：**

1. **会话A**（自动缩放）："手机浏览网站效果比例要自动缩放"、"手机观看和电脑一样显示效果"
   → 删除所有 @media，viewport 自动缩放 980px 页面

2. **会话B**（响应式2列）："手机端产品是两列"
   → 添加 @media 查询，手机端产品显示2列，桌面端4列

**正确做法：先问用户手机端想怎么显示，不要假设。** 如果用户说"和电脑一样"，用自动缩放。如果用户说"两列"或"适配手机"，用响应式。

## 正确方案A：Viewport 自动缩放（和电脑显示一样）

手机浏览器会自动缩放 980px 固定宽度页面，效果和电脑一致。

### 必须条件

1. **HTML 必须有 viewport 标签：**
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
```

2. **CSS 不要有 @media 查询：**
```bash
# 检查并删除所有 @media 块
curl -s https://www.shengtuo-tractor.com/css/style.css | grep -c "@media"
# 应该返回 0

# 如果有，删除：
sed -i '/@media/,/^}/d' /tmp/style.css
```

### 添加 viewport 标签

```bash
# 检查是否已有
curl -s https://www.shengtuo-tractor.com | grep -i "viewport"

# 如果没有，添加：
sed -i 's/<head>/<head>\n<meta name="viewport" content="width=device-width, initial-scale=1.0" \/>/' /tmp/index.html
```

## 正确方案B：响应式布局（手机端2列产品）

当用户要求手机端产品显示2列时：

```css
@media (max-width: 980px) {
    #main, #translate, #nav, .flash, #center, #footer {
        width: 100% !important;
    }
    #main { border-radius: 0; }
    #left { float: none; width: 100%; }
    #right { float: none; width: 100%; }
    .products_list {
        grid-template-columns: repeat(2, 1fr);  /* ⚠️ 必须用 grid-template-columns */
        gap: 10px;
    }
}
```

### ⚠️ CSS Grid 响应式陷阱（2026-05-28 实战发现）

桌面端用 `display: grid; grid-template-columns: repeat(4, 1fr);` 时：

- ❌ **错误**：设置 `li { width: calc(50% - 5px); }` — CSS Grid 中 width 不控制列数
- ✅ **正确**：设置 `.products_list { grid-template-columns: repeat(2, 1fr); }` — 覆盖列数定义

**症状：** 设置了 width 但产品仍然4列，只是每个卡片变窄了。
**诊断：** 检查桌面端是否用了 `display: grid`，如果是，必须用 `grid-template-columns` 覆盖。

## 错误方案（已验证失败）

**不要在未确认用户偏好的情况下假设！** 不同用户/不同时期偏好不同。

```css
/* ❌ 错误：不要这样做 */
@media (max-width: 768px) {
    #left { width: 100%; float: none; }
    #right { width: 100%; float: none; }
    .products_list { grid-template-columns: repeat(2, 1fr); }
}
```

## 重影问题的正确解决方案

如果手机上出现"重影"（元素重叠），原因是固定宽度元素溢出。

**正确方案：** viewport 自动缩放（见上方）
**错误方案：** @media 响应式查询（用户不要）

## 验证

```bash
# 1. 检查 viewport 标签
curl -s https://www.shengtuo-tractor.com | grep -i "viewport"
# 应该有：<meta name="viewport" content="width=device-width, initial-scale=1.0" />

# 2. 检查没有 @media 查询
curl -s https://www.shengtuo-tractor.com/css/style.css | grep -c "@media"
# 应该返回 0

# 3. 用 Playwright 测试手机截图
cd /home/ubuntu/.hermes/hermes-agent && timeout 20 node -e "
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  await page.goto('https://www.shengtuo-tractor.com', { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(2000);
  await page.screenshot({ path: '/tmp/mobile_test.png', fullPage: false });
  await browser.close();
  console.log('done');
})();
"
```

## 发截图给用户的注意事项

- 电脑截图和手机截图**不一样**（手机会缩放），不要说"效果一样"
- 分别发电脑和手机截图，让用户自己判断
- 不要替用户说"已经修好了"，让用户确认
