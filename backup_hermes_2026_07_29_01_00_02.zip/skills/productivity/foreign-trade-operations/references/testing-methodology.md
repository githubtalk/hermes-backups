# Website Testing Methodology

## Comprehensive Testing Checklist

### 1. Frontend Pages (curl)
```bash
cd /home/ubuntu/shengtuo-website
for url in "/" "/products" "/products?category=shengtuo-tractor" "/products?hp=50-80" "/about" "/contact" "/news" "/export" "/search" "/search?q=tractor"; do
    status=$(curl -s -o /dev/null -w "%{http_code}" "https://sub.aiv.qzz.io${url}")
    echo "$url → $status"
done
```

### 2. Product Detail Pages (sample)
```bash
php -r "
\$db = new PDO('mysql:host=localhost;dbname=shengtuo_website', 'shengtuo', 'ShengTuo2026!');
\$stmt = \$db->query('SELECT slug FROM products WHERE is_active = 1 LIMIT 5');
\$products = \$stmt->fetchAll(PDO::FETCH_COLUMN);
foreach (\$products as \$slug) {
    \$status = trim(shell_exec('curl -s -o /dev/null -w \"%{http_code}\" \"https://sub.aiv.qzz.io/product/' . \$slug . '\"'));
    echo '/product/' . \$slug . ' → ' . \$status . PHP_EOL;
}
"
```

### 3. News Detail Pages (sample)
```bash
php -r "
\$db = new PDO('mysql:host=localhost;dbname=shengtuo_website', 'shengtuo', 'ShengTuo2026!');
\$stmt = \$db->query('SELECT slug FROM news WHERE is_active = 1 LIMIT 5');
\$news = \$stmt->fetchAll(PDO::FETCH_COLUMN);
foreach (\$news as \$slug) {
    \$status = trim(shell_exec('curl -s -o /dev/null -w \"%{http_code}\" \"https://sub.aiv.qzz.io/news/' . \$slug . '\"'));
    echo '/news/' . \$slug . ' → ' . \$status . PHP_EOL;
}
"
```

### 4. Backend Admin Pages
```bash
for url in "/admin/" "/admin/login.php" "/admin/index.php" "/admin/products.php" "/admin/categories.php" "/admin/news.php" "/admin/inquiries.php" "/admin/settings.php" "/admin/sliders.php" "/admin/messages.php" "/admin/pages.php" "/admin/profile.php" "/admin/seo-checker.php"; do
    status=$(curl -s -o /dev/null -w "%{http_code}" "https://sub.aiv.qzz.io${url}")
    echo "$url → $status"
done
```
**Note**: 302 = redirect to login (expected for protected pages), 200 = login page or public tool

### 5. API Endpoints
```bash
for url in "/api/products.php" "/api/products.php?page=1&limit=8" "/sitemap.xml" "/robots.txt"; do
    status=$(curl -s -o /dev/null -w "%{http_code}" "https://sub.aiv.qzz.io${url}")
    echo "$url → $status"
done
```

### 6. CSS/JS Resources
```bash
for url in "/assets/css/bundle-v8.min.css" "/assets/css/layout-optimize.css" "/assets/js/enhance-v3.js" "/assets/images/logo-v2.png"; do
    status=$(curl -s -o /dev/null -w "%{http_code}" "https://sub.aiv.qzz.io${url}")
    echo "$url → $status"
done
```

### 7. Form Validation
```bash
# Empty submission
curl -s -X POST "https://sub.aiv.qzz.io/api/inquiry.php" \
  -H "Content-Type: application/json" \
  -d '{"name":"","email":"","message":""}'

# Invalid email
curl -s -X POST "https://sub.aiv.qzz.io/api/inquiry.php" \
  -H "Content-Type: application/json" \
  -d '{"name":"Test","email":"invalid","message":"test"}'

# Valid submission
curl -s -X POST "https://sub.aiv.qzz.io/api/inquiry.php" \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","message":"Test inquiry"}'
```

### 8. Performance Metrics
```bash
# Page load times
for url in "/" "/products" "/about" "/contact"; do
    time=$(curl -s -o /dev/null -w "%{time_total}" "https://sub.aiv.qzz.io${url}")
    size=$(curl -s "https://sub.aiv.qzz.io${url}" | wc -c)
    echo "$url → ${time}s, ${size} bytes"
done

# Gzip compression
original=$(curl -s "https://sub.aiv.qzz.io/" | wc -c)
compressed=$(curl -s -H "Accept-Encoding: gzip" -o /dev/null -w "%{size_download}" "https://sub.aiv.qzz.io/")
echo "Original: ${original} bytes → Compressed: ${compressed} bytes"
```

### 9. Security Headers
```bash
curl -s -I "https://sub.aiv.qzz.io/" | grep -i "x-frame-options\|x-content-type\|strict-transport"
```

### 10. Database Statistics
```bash
php -r "
\$db = new PDO('mysql:host=localhost;dbname=shengtuo_website', 'shengtuo', 'ShengTuo2026!');
\$tables = ['products', 'categories', 'news', 'inquiries', 'admins'];
foreach (\$tables as \$t) {
    \$stmt = \$db->query('SELECT COUNT(*) FROM ' . \$t);
    echo \$t . ': ' . \$stmt->fetchColumn() . ' records' . PHP_EOL;
}
"
```

### 11. Error Logs
```bash
# PHP errors
tail -20 /var/log/php*error*.log 2>/dev/null | grep -i "error\|warning\|fatal"

# Nginx errors
tail -20 /var/log/nginx/error.log 2>/dev/null | grep -i "error\|crit\|alert"
```

### 12. Structured Data (JSON-LD)
```bash
# Check homepage
curl -s "https://sub.aiv.qzz.io/" | grep -A5 "application/ld+json" | head -20

# Check product page
curl -s "https://sub.aiv.qzz.io/product/st504e-tractor" | grep -o '"@type":"[^"]*"' | sort | uniq
```

## Browser Testing (Interactive)

### Grid Layout Verification
```javascript
// Check all grid layouts
const grids = {
  categoryGrid: document.querySelector('.category-grid'),
  productGrid: document.querySelector('.product-grid'),
  hpGrid: document.querySelector('.hp-grid'),
  featureGrid: document.querySelector('.feature-grid'),
  statsGrid: document.querySelector('.stats-grid'),
  testimonialGrid: document.querySelector('.testimonial-grid'),
  trustGrid: document.querySelector('.trust-grid'),
  certGallery: document.querySelector('.cert-gallery')
};

for (const [name, el] of Object.entries(grids)) {
  if (el) {
    const style = window.getComputedStyle(el);
    console.log(`${name}: display=${style.display}, columns=${style.gridTemplateColumns}`);
  }
}
```

### Product Tab Filtering
```javascript
// Click a tab and verify filtering
const tabs = document.querySelectorAll('.product-tab');
tabs[1].click(); // Click second tab

const items = document.querySelectorAll('.product-item');
const visible = Array.from(items).filter(item => item.style.display !== 'none');
console.log(`Visible: ${visible.length} / ${items.length}`);
```

### Reveal Animations
```javascript
// Check reveal animations after scrolling
const reveals = document.querySelectorAll('.reveal');
const revealed = document.querySelectorAll('.reveal.revealed');
console.log(`Revealed: ${revealed.length} / ${reveals.length}`);
```

## Expected Results

| Test Category | Expected |
|---------------|----------|
| Frontend pages | All 200 |
| Product details | All 200 |
| News details | All 200 |
| Admin pages | 200 or 302 (redirect to login) |
| API endpoints | 200 (except inquiry POST = 405) |
| CSS/JS resources | All 200 |
| Page load time | < 0.2s |
| Gzip compression | ~80% reduction |
| Security headers | x-frame-options, x-content-type |

## Common Issues & Fixes

### 404 on favicon.ico
- Favicon is at `/assets/images/favicon.png`
- Add nginx rule: `location = /favicon.ico { return 301 /assets/images/favicon.png; }`

### 302 on admin pages
- Expected behavior - redirects to login when not authenticated
- Login with: admin / shengtuo2026

### Empty JSON-LD scripts
- Check `includes/seo.php` - generateJsonLD() may return empty for missing data
- Verify database has required fields
