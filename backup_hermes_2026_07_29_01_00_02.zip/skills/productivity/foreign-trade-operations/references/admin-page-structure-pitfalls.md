# Admin Duplicate HTML Structure Bug

## Problem
When admin pages `require_once auth.php` AND then output their own `<!DOCTYPE html>`, `<head>`, `<body>`, and `include sidebar.php`, the page gets:
- Two `<html>` tags (nested or parallel)
- Sidebar rendered twice
- CSS/JS loaded twice
- Nginx error: `Failed to open stream: No such file or directory (includes/sidebar.php)`

## Diagnosis
```bash
for f in /path/admin/*.php; do
    name=$(basename $f)
    [ "$name" = "auth.php" ] || [ "$name" = "login.php" ] || [ "$name" = "logout.php" ] && continue
    has_doctype=$(grep -c "<!DOCTYPE" "$f")
    has_sidebar=$(grep -c "includes/sidebar.php" "$f")
    [ "$has_doctype" -gt 0 ] && echo "ISSUE: $name DOCTYPE:$has_doctype sidebar:$has_sidebar"
done
```

## Fix Pattern
auth.php outputs:
1. `<!DOCTYPE html>` + `<head>` (CSS, meta)
2. Sidebar HTML (`<div class="sidebar">`)
3. Admin header
4. Opens `<div class="content-area">`
5. Shows flash messages
6. Does NOT close any divs or `</body></html>`

So each admin page must:
1. `require_once __DIR__ . '/auth.php';` (outputs everything above)
2. Output page-specific `<style>` tags (if needed)
3. Output content HTML
4. Close with `</div></div><script>...</script></body></html>`

**Remove from broken pages:**
- `<!DOCTYPE html>` through `<body>` (lines 189-204 in products.php example)
- `include __DIR__ . '/includes/sidebar.php';` or `/partials/sidebar.php`
- Duplicate `</head>` tags

**Keep:**
- Page-specific `<style>` blocks
- Flash message display (auth.php already does this, but pages may have their own)
- `</div></div>` to close content-area and main-content
- `</body></html>` to close the page

## Affected Pages (2026-05-30)
- `products.php` — had DOCTYPE + sidebar include
- `news.php` — had DOCTYPE + partials/sidebar.php include
- `product-edit.php` — had DOCTYPE
- `seo-checker.php` — had DOCTYPE

## Null Array Access in Create/Edit Forms

When a PHP form handles both create and edit modes, `$news['field']` throws:
```
PHP Warning: Trying to access array offset on null
```

**Fix:** Use null coalescing for all field accesses:
```php
// ❌ Crashes in create mode
value="<?= escape($news['title']) ?>"

// ✅ Safe for both modes
value="<?= escape($news['title'] ?? $_POST['title'] ?? '') ?>"
```

For date fields:
```php
// ❌ Crashes in create mode
<?= $news['published_at'] ? date('Y-m-d\TH:i', strtotime($news['published_at'])) : '' ?>

// ✅ Safe
<?= isset($news['published_at']) && $news['published_at'] ? date('Y-m-d\TH:i', strtotime($news['published_at'])) : '' ?>
```

## Logs Directory Permission

`file_put_contents(logs/)` fails with "Permission denied" when web server user can't write.

```bash
chmod 777 /path/to/logs/  # or
chown www-data:www-data /path/to/logs/
```
