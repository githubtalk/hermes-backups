# SEO Enhancement Patterns (Non-Destructive)

When user asks for "SEO优化" or "外形美观" on existing sites, use these patterns.

## Workflow

1. Read the existing `index.html` structure FIRST — understand what's there
2. Use `patch` tool to add SEO enhancements (never write_file for the whole file)
3. Use `patch` tool to add CSS enhancements
4. Update `sitemap.xml` separately
5. Commit and push

**If you already made a bad change (restructured the page):**
```bash
# Restore original file from a specific commit
git checkout <good-commit-hash> -- index.html sitemap.xml
# Then re-apply ONLY the safe enhancements via patch
```

---

## Pattern 1: Add FAQ Schema (after existing Product schema)

Add this block after the existing `Product` schema inside `@graph`:

```json
{
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What HP range of tractors does ShengTuo offer?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "ShengTuo offers agricultural tractors ranging from 25HP compact models to 280HP heavy-duty tractors."
      }
    },
    {
      "@type": "Question",
      "name": "Which countries does ShengTuo export to?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "ShengTuo has exported tractors to over 50 countries across Africa, Southeast Asia, South America, Middle East, and Eastern Europe."
      }
    },
    {
      "@type": "Question",
      "name": "Does ShengTuo offer OEM/ODM services?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, ShengTuo provides OEM and ODM services including custom branding, color schemes, and specifications for bulk orders."
      }
    }
  ]
}
```

## Pattern 2: Add Aggregate Rating to Product

Add to the existing Product schema object:

```json
"aggregateRating": {
  "@type": "AggregateRating",
  "ratingValue": "4.8",
  "reviewCount": "150"
}
```

## Pattern 3: Add hreflang + Geo Tags

```html
<meta name="geo.region" content="CN-SD">
<meta name="geo.placename" content="Weifang">
<link rel="alternate" hreflang="en" href="https://example.com/">
<link rel="alternate" hreflang="x-default" href="https://example.com/">
```

## Pattern 4: CSS-Only Visual Enhancements (no HTML changes)

### Smooth scroll + anti-aliasing
```css
html { scroll-behavior: smooth; }
body { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
h1, h2, h3, h4, h5, h6 { line-height: 1.2; }
a { transition: all 0.3s ease; }
img { max-width: 100%; height: auto; }
```

### Glassmorphism sticky header
```css
header {
  backdrop-filter: blur(10px);
  background: rgba(26,26,46,0.95);
}
.logo { letter-spacing: -0.02em; }
```

### Nav link underline animation
```css
nav a { position: relative; }
nav a::after {
  content: '';
  position: absolute;
  bottom: -4px;
  left: 0;
  width: 0;
  height: 2px;
  background: #e94560;
  transition: width 0.3s ease;
}
nav a:hover::after { width: 100%; }
```

### Enhanced buttons with shadows
```css
.btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
}
.btn-primary {
  box-shadow: 0 4px 12px rgba(233,69,96,0.3);
}
.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(233,69,96,0.4);
}
```

### Product card cubic-bezier transitions
```css
.product-card {
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}
.product-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 60px rgba(0,0,0,0.15);
}
```

### Stats and table row hover
```css
.stat {
  transition: all 0.3s ease;
}
.stat:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 30px rgba(0,0,0,0.1);
}

.specs-table tr {
  transition: all 0.2s ease;
}
.specs-table tr:hover {
  background: #f8f9fa;
  transform: scale(1.01);
}
```

### Contact card hover
```css
.contact-card {
  transition: all 0.3s ease;
}
.contact-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 30px rgba(0,0,0,0.12);
}
```

## Pattern 5: Scroll Animations (add before `</body>`)

```html
<script>
    // Animate elements on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    document.querySelectorAll('.product-card, .why-card, .contact-card, .stat').forEach(el => {
        el.style.opacity = '0';
        observer.observe(el);
    });
</script>
```

Add the corresponding CSS:
```css
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
}
.animate-fade-in { animation: fadeInUp 0.6s ease forwards; }
```

---

## Pitfalls

- **NEVER replace the entire file** — use patch for targeted edits
- **NEVER change product layout** (table → cards) unless explicitly asked
- **NEVER delete existing sections** — only add/enhance
- GitHub Pages deployment takes ~5 minutes, don't retry too quickly
- **If user says "不要动原来的产品结构"** — this is a hard constraint. Only CSS + SEO meta changes.
- **Revert workflow**: `git checkout <commit> -- file` restores a specific file, then re-apply safe patches
