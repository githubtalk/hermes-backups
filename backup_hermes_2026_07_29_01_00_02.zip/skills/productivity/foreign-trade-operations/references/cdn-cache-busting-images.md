# CDN Cache Busting for Image Updates

## Problem

When replacing product images on a site behind Cloudflare CDN, simply overwriting files on disk is NOT enough. Cloudflare caches images with `max-age=2592000` (30 days) and `cf-cache-status: HIT`. The old images continue to be served even after the local files are updated.

## Diagnosis

```bash
# Compare CDN-served content vs local file
curl -s "https://SITE/assets/images/products/product-22.jpg" | md5sum
echo "CDN"
md5sum /path/to/local/product-22.jpg
echo "Local"
# If MD5s differ, CDN is serving stale content
```

## Solution: Rename Files to Bust Cache

The most reliable method is to rename all image files with a version suffix:

```bash
DEST=/path/to/assets/images/products
TS=$(date +%s)

# 1. Rename files with version suffix
for i in $(seq 1 37); do
    sudo mv "$DEST/product-${i}.jpg" "$DEST/product-${i}-v${TS}.jpg"
done

# 2. Update database references
for i in $(seq 1 37); do
    mysql -uUSER -pPASS DB_NAME -e "
    UPDATE products SET image = '/assets/images/products/product-${i}-v${TS}.jpg' WHERE id = ${i}"
done

# 3. Fix file ownership
sudo chown www-data:www-data $DEST/*.jpg
```

## Why Version Parameters (?v=xxx) Are Not Enough

- For CSS files: `?v=timestamp` usually works
- For images: Cloudflare may ignore query strings for image cache keys
- **File rename is the only 100% reliable method**

## Why Symlinks Don't Work

```bash
# ❌ Symlink — Cloudflare may still return 404
ln -sf style.css style-v123.css

# ✅ Real copy — always works
cp style.css style-v123.css
```

Cloudflare follows symlinks inconsistently. Always use `cp` to create real files.

## Verification

```bash
# After renaming, verify CDN serves new content
curl -s "https://SITE/assets/images/products/product-22-v${TS}.jpg" | md5sum
md5sum /path/to/local/product-22-v${TS}.jpg
# MD5s should match now
```

## Logo Image Cache Busting

Same technique applies to logo images. When `logo.png` returns 404 from CDN cache:

```bash
# Copy with new name
sudo cp /path/to/original-logo.png /path/to/assets/images/logo-v2.png
sudo chown www-data:www-data /path/to/assets/images/logo-v2.png

# Update header.php reference
sudo sed -i 's|/assets/images/logo.png|/assets/images/logo-v2.png|' /path/to/templates/header.php
```

## Key Pitfalls

1. **File ownership**: Images uploaded as root need `sudo chown www-data:www-data`
2. **Permission denied on mv**: Files owned by www-data need `sudo mv`
3. **Database must be updated**: Old image paths will return 404 after rename
4. **Browser console verification**: Check `img.naturalWidth` to confirm images loaded correctly
5. **Logo also cached**: CDN caches 404 responses too — if logo.png was missing, adding it back won't help. Rename to logo-v2.png

## Browser Verification

```javascript
// Check if images loaded with correct dimensions
document.querySelectorAll('img[src*="product"]').forEach(img => {
    console.log(img.alt, img.src.split('/').pop(), img.naturalWidth + 'x' + img.naturalHeight);
});
// All images should have DIFFERENT dimensions if they're truly unique
```
