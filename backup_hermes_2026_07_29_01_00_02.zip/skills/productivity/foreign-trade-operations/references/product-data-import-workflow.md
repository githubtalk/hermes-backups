# Product Data Import Workflow

## Overview

When migrating from an existing website (especially ASP-based LankeCMS sites) to the new PHP system, use this workflow to extract and import product data.

**Verified on:** shengtuo-tractor.com → shengtuo-website (2026-05-29)

## Step 1: Scrape Product Data from Source Site

Use `delegate_task` with web tools to scrape the source site in parallel:

```python
# Parallel tasks:
# Task 1: Scrape product listings + detail pages
# Task 2: Scrape company info (About Us, Contact)

delegate_task(tasks=[
    {
        "goal": "Scrape all product info from SOURCE_SITE including name, model, HP, description, specs",
        "context": "Visit product listing pages (e.g., /products/?id=71, /products/?id=90) to get all product URLs, then visit each detail page for specifications.",
        "toolsets": ["web", "terminal"]
    },
    {
        "goal": "Scrape company info from SOURCE_SITE including About Us, Contact details",
        "context": "Visit /about/2.html for company intro, /about/3.html for contact info.",
        "toolsets": ["web", "terminal"]
    }
])
```

### Source Site Structure (shengtuo-tractor.com)

| Page | URL Pattern | Content |
|------|-------------|---------|
| Product Categories | `/products/?id=71` (Tractors), `/products/?id=90` (Equipment) | Category listing with product links |
| Product Detail | `/products/58.html`, `/products/171.html` | Full specs, images, description |
| About Us | `/about/2.html` | Company intro, factory info |
| Contact | `/about/3.html` | Phone, email, address |

### Output Format (JSON)

Save to `/home/ubuntu/shengtuo_products.json`:

```json
{
  "company": "SHENGTUO TRACTOR",
  "website": "https://www.shengtuo-tractor.com",
  "contact": {
    "tel": "+86-13806461474",
    "email": "sdtractor@outlook.com",
    "person": "Henry"
  },
  "products": {
    "tractors": [
      {
        "name": "ST404 (35-65HP) Tractor",
        "model": "ST404",
        "hp_range": "35-65HP",
        "engine_power_kw": 29.4,
        "drive_type": "4x4 4WD",
        "dimensions": {"length_mm": 2820, "width_mm": 1230, "height_mm": 1110},
        "shifts": "8+2",
        "pto_rpm": "540/720",
        "description": "Chinese highly cost-efficient in-line diesel engines..."
      }
    ],
    "farm_equipment": [
      {"name": "SHENGTUO Front Loader and Backhoe", "url": "..."}
    ]
  }
}
```

## Step 2: Import Products to Database

### Tractor Import Script

```php
<?php
// /home/ubuntu/import_products.php
$db = new PDO('mysql:host=localhost;dbname=shengtuo_website;charset=utf8mb4', 'shengtuo', 'ShengTuo2026!');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$json = file_get_contents('/home/ubuntu/shengtuo_products.json');
$data = json_decode($json, true);

// Clear existing products
$db->exec("DELETE FROM products");
$db->exec("ALTER TABLE products AUTO_INCREMENT = 1");

// Get category IDs
$stmt = $db->query("SELECT id, name FROM categories");
$categories = [];
while ($row = $stmt->fetch()) {
    $categories[$row['name']] = $row['id'];
}

$tractorCatId = $categories['SHENGTUO TRACTOR'] ?? 1;
$equipmentCatId = $categories['SHENGTUO FARM EQUIPMENT'] ?? 2;

$stmt = $db->prepare("INSERT INTO products (category_id, name, slug, model, horsepower, description, features, specifications, is_featured, is_active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$sortOrder = 1;
foreach ($data['products']['tractors'] as $tractor) {
    $name = $tractor['name'];
    // ⚠️ Use product name for slug, NOT model (model can be duplicated!)
    $slug = 'tractor-' . strtolower(preg_replace('/[^a-z0-9]+/', '-', $tractor['model'])) . '-' . $sortOrder;
    
    // Build features string
    $features = [];
    if (isset($tractor['drive_type'])) $features[] = "Drive Type: {$tractor['drive_type']}";
    if (isset($tractor['shifts'])) $features[] = "Transmission: {$tractor['shifts']}";
    if (isset($tractor['pto_rpm'])) $features[] = "PTO: {$tractor['pto_rpm']}";
    
    // Build specs string
    $specs = [];
    if (isset($tractor['engine_power_kw'])) $specs[] = "Engine Power: {$tractor['engine_power_kw']}kW";
    if (isset($tractor['dimensions'])) {
        $d = $tractor['dimensions'];
        $specs[] = "Dimensions: {$d['length_mm']}x{$d['width_mm']}x{$d['height_mm']}mm";
    }
    
    $stmt->execute([
        $tractorCatId, $name, $slug, $tractor['model'], $tractor['hp_range'],
        $tractor['description'] ?? '', implode("\n", $features), implode("\n", $specs),
        ($sortOrder <= 5) ? 1 : 0, 1, $sortOrder
    ]);
    echo "✅ Imported: $name\n";
    $sortOrder++;
}
```

### Equipment Import Script

```php
<?php
// /home/ubuntu/import_equipment.php
$db = new PDO('mysql:host=localhost;dbname=shengtuo_website;charset=utf8mb4', 'shengtuo', 'ShengTuo2026!');
$json = file_get_contents('/home/ubuntu/shengtuo_products.json');
$data = json_decode($json, true);

$equipmentCatId = 2;
$stmt = $db->prepare("INSERT INTO products (category_id, name, slug, model, horsepower, description, is_featured, is_active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

$sortOrder = 1;
foreach ($data['products']['farm_equipment'] as $equip) {
    $name = $equip['name'];
    $slug = 'equipment-' . strtolower(preg_replace('/[^a-z0-9]+/', '-', $name)) . '-' . $sortOrder;
    
    $stmt->execute([$equipmentCatId, $name, $slug, '', 'N/A', '', 0, 1, $sortOrder]);
    echo "✅ Imported: $name\n";
    $sortOrder++;
}
```

## Step 3: Import Company Info

```php
<?php
// Update pages table with company info
$db->exec("DELETE FROM pages WHERE slug = 'about'");
$stmt = $db->prepare("INSERT INTO pages (title, slug, content, meta_title, meta_description) VALUES (?, ?, ?, ?, ?)");

$aboutContent = '<h2>About Shengtuo Tractor</h2>
<p>Shandong Shengtuo Heavy Industry Co., Ltd. is a large-scale industry equipment manufacturer...</p>
<h3>Company Overview</h3>
<ul>
<li><strong>Investment:</strong> 100 Million RMB</li>
<li><strong>Factory Area:</strong> 25,000 Square Meters</li>
<li><strong>Annual Production:</strong> 15,000 Sets of Agricultural Machinery</li>
</ul>';

$stmt->execute(['About Us', 'about', $aboutContent, 'About Shengtuo Tractor', 'Learn about Shengtuo Tractor...']);
```

## ⚠️ Key Pitfalls

### 1. Duplicate Slug Entries

**Symptom:** `SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry`

**Cause:** Multiple products have the same model name (e.g., ST504 appears multiple times).

**Fix:** Append sort order to slug:
```php
$slug = 'tractor-' . strtolower(preg_replace('/[^a-z0-9]+/', '-', $tractor['model'])) . '-' . $sortOrder;
```

### 2. Equipment Data May Be Sparse

The equipment listing page often only has name + URL, no detailed specs. Import with minimal fields:
```php
$stmt->execute([$equipmentCatId, $name, $slug, '', 'N/A', '', 0, 1, $sortOrder]);
```

### 3. ASP Product IDs Don't Map to MySQL IDs

Source site uses numeric IDs (58, 171, 172...) which don't match the new auto-increment IDs. Don't try to preserve them — use slugs for URL mapping instead.

### 4. Run Import Scripts with System PHP

```bash
# ❌ WRONG - Hermes venv doesn't have PDO
python3 import_products.php

# ✅ CORRECT - Use php directly
php /home/ubuntu/import_products.php
```

## Verification

```bash
# Count imported products
sudo mysql -u shengtuo -p'ShengTuo2026!' -e \
  "USE shengtuo_website; SELECT c.name, COUNT(p.id) FROM products p LEFT JOIN categories c ON p.category_id = c.id GROUP BY c.name;"

# Check admin panel
curl -s -b /tmp/cookies.txt https://site/admin/products.php | grep -c "Tractor"

# Check database test page
curl -s https://site/db-test.php | grep "产品数量"
```
