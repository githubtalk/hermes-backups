# CSS Bundling Pattern

## Problem
Multiple CSS files (5-7) loaded individually = 5-7 HTTP requests, slower page load.

## Solution: Merge + Minify into Single Bundle

### Build Script (`scripts/build-css.sh`)
```bash
#!/bin/bash
cd "$(dirname "$0")/.."
php includes/minify-css.php
echo "✅ bundle.min.css generated ($(wc -c < assets/css/bundle.min.css) bytes)"
```

### PHP Minifier (`includes/minify-css.php`)
```php
<?php
$cssDir = __DIR__ . '/../assets/css/';
$order = ['style-v3.css', 'enhance-v3.css', 'product-focus-v4.css', 
          'visual-v5c.css', 'style-responsive.css', 'style-v2.css', 'color-harmony.css'];

$combined = '';
foreach ($order as $file) {
    $path = $cssDir . $file;
    if (file_exists($path)) {
        $combined .= "/* === $file === */\n" . file_get_contents($path) . "\n";
    }
}

// Basic minification
$combined = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $combined); // remove comments
$combined = preg_replace('/\s+/', ' ', $combined);  // collapse whitespace
$combined = str_replace([' {', '{ ', ' }', '} ', '; ', ': '], ['{','{','}','}',';',':'], $combined);
$combined = trim($combined);

$outputPath = $cssDir . 'bundle.min.css';
file_put_contents($outputPath, $combined);
echo "Generated: $outputPath (" . strlen($combined) . " bytes)\n";
```

### header.php Integration
```php
<!-- Before: 7 individual CSS files -->
<link href="/assets/css/style-v3.css" rel="stylesheet">
<link href="/assets/css/enhance-v3.css" rel="stylesheet">
<!-- ... 5 more ... -->

<!-- After: 1 bundled file with version hash -->
<link href="/assets/css/bundle.min.css?v=<?= filemtime(__DIR__ . '/../assets/css/bundle.min.css') ?>" rel="stylesheet">
```

## Version Hash Strategy
Use `filemtime()` (file modification time) as version parameter. Automatically changes when CSS is rebuilt, forcing browser/CDN to fetch new version.

```php
// In header.php
$bundlePath = __DIR__ . '/../assets/css/bundle.min.css';
$version = file_exists($bundlePath) ? filemtime($bundlePath) : time();
?>
<link href="/assets/css/bundle.min.css?v=<?= $version ?>" rel="stylesheet">
```

## CSS Load Order Matters
Later files override earlier ones. The order should be:
1. `style-v3.css` — Base design system + CSS variables
2. `enhance-v3.css` — Scroll animations, testimonials, trust bar
3. `product-focus-v4.css` — Category cards, HP range, product badges
4. `visual-v5c.css` — Global polish (shadows, borders)
5. `style-responsive.css` — Responsive image scaling
6. `style-v2.css` — Product image aspect ratios
7. `color-harmony.css` — Unified color variables (LAST, highest priority)

## Rebuild Workflow
```bash
# After editing any source CSS file:
bash scripts/build-css.sh
# Browser auto-picks up new version via filemtime()
```

## Pitfalls
1. **Keep source CSS files** — don't delete them after bundling; they're the source of truth
2. **Rebuild after ANY CSS change** — editing source CSS without rebuilding = stale bundle
3. **Bootstrap CSS stays separate** — it's loaded from CDN, not bundled
4. **Don't use `!important` in source CSS** — rely on load order for specificity
