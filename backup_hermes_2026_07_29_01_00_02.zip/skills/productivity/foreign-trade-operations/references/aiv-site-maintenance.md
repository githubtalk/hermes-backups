# AIV Site (aiv.qzz.io) Maintenance Notes

## 主机环境澄清

AIV 站由 nginx 直接服务，源码在 `/home/ubuntu/wwwroot/`，**无需 FTP 上传**：
```bash
# 修改后直接生效
vim /home/ubuntu/wwwroot/index.html
# 刷新 https://aiv.qzz.io 即可验证
```

## 常见问题修复

### Flash 轮播替换（2026-05-28）

**症状**：浏览器显示 "Adobe Flash Player 已不再受支持"

**原因**：`index.html` 中使用 `<object>` 和 `<embed>` 标签加载 `.swf` 文件

**修复方案**：替换为 HTML/CSS/JS 轮播（保留原图片和链接）

```html
<!-- 替换前：Flash 标签 + document.write() -->
<div class="flash">
  <script>document.write('<object ...><embed src="/images/focus.swf" ...></object>')</script>
</div>

<!-- 替换后：纯 HTML 轮播 -->
<style>
.slider-container {position:relative;width:968px;height:373px;margin:0 auto;overflow:hidden;}
.slider-wrapper {position:relative;width:100%;height:100%;}
.slider-slide {position:absolute;top:0;left:0;width:100%;height:100%;opacity:0;transition:opacity 0.8s ease-in-out;pointer-events:none;}
.slider-slide.active {opacity:1;pointer-events:auto;}
.slider-slide img {width:100%;height:100%;object-fit:cover;display:block;}
.slider-dots {position:absolute;bottom:15px;left:50%;transform:translateX(-50%);display:flex;gap:10px;z-index:10;}
.slider-dot {width:12px;height:12px;border-radius:50%;background:rgba(255,255,255,0.5);cursor:pointer;transition:all 0.3s;border:none;}
.slider-dot.active {background:#eb6100;transform:scale(1.2);}
.slider-arrow {position:absolute;top:50%;transform:translateY(-50%);background:rgba(0,0,0,0.4);color:#fff;border:none;padding:15px 12px;cursor:pointer;font-size:20px;z-index:10;}
.slider-arrow.prev {left:10px;border-radius:0 4px 4px 0;}
.slider-arrow.next {right:10px;border-radius:4px 0 0 4px;}
</style>
<div class="flash">
<div class="slider-container">
<div class="slider-wrapper">
<div class="slider-slide active"><a href="/products"><img src="/uploadfile/xxx.jpg" alt="Product"></a></div>
</div>
<div class="slider-dots"><button class="slider-dot active" onclick="goSlide(0)"></button></div>
<button class="slider-arrow prev" onclick="prevSlide()">&#10094;</button>
<button class="slider-arrow next" onclick="nextSlide()">&#10095;</button>
</div>
<script>
(function(){var i=0,s=document.querySelectorAll('.slider-slide'),d=document.querySelectorAll('.slider-dot');function goSlide(n){s[i].classList.remove('active');d[i].classList.remove('active');i=n;s[i].classList.add('active');d[i].classList.add('active')}function nextSlide(){goSlide((i+1)%s.length)}function prevSlide(){goSlide((i-1+s.length)%s.length)}window.goSlide=goSlide;window.nextSlide=nextSlide;window.prevSlide=prevSlide;setInterval(nextSlide,5000)})();
</script>
</div>
```

### 废弃链接清理（2026-05-28）

**常见问题**：老旧中文 B2B 网站常包含已失效的外部链接

**需删除/替换的典型链接**：

| 类型 | 示例 | 说明 |
|------|------|------|
| 翻译插件 | `translatecompany.com`, `translateth.is` | 已停用 |
| MSN | `msnim:chat?contact=...` | 已废弃 |
| 阿里旺旺 | `taobao.com/webww`, `alicdn.com/msg.aw` | 旧版阿里旺旺 |
| HTTP 外链 | `http://wpa.qq.com` | 应升级 HTTPS |
| 重复站链 | `shengtuo-tractor.com` | 旧的，应指向站内 |

**处理方式**：
1. 翻译插件整个 `<div id="translate">` 区块删除
2. 阿里旺旺/MSN 等 IM 图标删除
3. QQ 链接：`http://` → `https://`
4. 外部产品链接：改为站内 `/products` 或删除第二张幻灯片

### 图片处理

轮播图尺寸：968×373px，优先居中裁剪：
```python
from PIL import Image
img = Image.open("source.jpg")
target_w, target_h = 968, 373
# 居中裁剪 + resize
img_cropped = img.crop(((img.width - target_w)//2, 0, (img.width + target_w)//2, img.height))
img_resized = img_cropped.resize((target_w, target_h), Image.LANCZOS)
img_resized.save("/home/ubuntu/wwwroot/uploadfile/xxx.jpg", quality=90)
```