# Product Image Scraping & Import Workflow

## Overview

Scrape product images from an existing source website and import them into the PHP website system. This workflow covers finding image URLs, downloading images, and updating the database.

**Verified on:** shengtuo-tractor.com → sub.aiv.qzz.io (2026-05-29)

## Step 0: Check for Local FTP Backup FIRST (Preferred)

Before downloading from the web, check if the original site has a local FTP backup on the server. This is **faster, more reliable, and avoids CDN caching issues**.

```bash
# Check common backup locations
ls /home/ubuntu/wwwroot/uploadfile/ 2>/dev/null
ls /root/wwwroot/uploadfile/ 2>/dev/null
find / -name "wwwroot" -type d 2>/dev/null | head -5
```

**Why prefer local files:**
- No network latency or rate limiting
- No Cloudflare CDN caching stale images
- File sizes are exact (no partial downloads)
- Can verify file integrity with `stat` before copying

**shengtuo-tractor.com local backup:** `/home/ubuntu/wwwroot/`
Contains 647+ images in `uploadfile/` and all product HTML pages in `products/`.

### Using Local Files Instead of curl Downloads

```bash
SRC=/home/ubuntu/wwwroot
DEST=/home/ubuntu/shengtuo-website/assets/images/products

# Copy directly from local backup
sudo cp "$SRC/uploadfile/2025226853232798.jpg" "$DEST/product-1.jpg"
sudo chown www-data:www-data "$DEST/product-1.jpg"
```

## Step 1: Find All Product Page URLs

### Method A: From Local HTML Files (Preferred)

```bash
# List all product HTML files in local backup
ls /home/ubuntu/wwwroot/products/*.html | while read f; do
    pid=$(basename "$f" .html)
    title=$(grep -oP '<title>[^<]+' "$f" | sed 's/<title>//')
    echo "$pid: $title"
done
```

### Method B: From Sitemap XML

```bash
curl -s 'https://SOURCE_SITE/sitemap.xml' | grep -oP 'products/\d+\.html' | grep -oP '\d+' | sort -n
```

**⚠️ Pitfall: Sitemap may be incomplete!** The sitemap had 22 product URLs, but the actual site had 38 product HTML files. Always cross-check with local files or direct listing.

**Complete product ID list for shengtuo-tractor.com:**
`58, 61, 62, 64, 65, 66, 68, 137, 171, 172, 175, 183, 224-248`

## Step 2: Extract Image URLs from Product Pages

### From Local HTML Files (Preferred)

```bash
SRC=/home/ubuntu/wwwroot
for pid in 58 61 62 64 65 66 68 137 171 172 175 183 224 225 226 227 228 229 230 231 232 233 238; do
    f="$SRC/products/${pid}.html"
    [ -f "$f" ] || continue
    title=$(grep -oP '<title>[^<]+' "$f" | sed 's/<title>//' | sed 's/\s*$//')
    img=$(grep -oP 'uploadfile/\d+[^"]+\.(jpg|png)' "$f" | grep -v '202522115' | grep -v '202522514' | head -1)
    [ -n "$img" ] && img_size=$(stat -c%s "$SRC/$img" 2>/dev/null) && echo "PID $pid: $title -> $img (${img_size}B)"
done
```

### From Remote Site (Fallback)

```bash
for pid in $(curl -s 'https://SOURCE_SITE/sitemap.xml' | grep -oP 'products/\d+\.html' | grep -oP '\d+'); do
    img=$(curl -s "https://SOURCE_SITE/products/$pid.html" | \
          grep -oP 'uploadfile/\d+[^"]+\.(jpg|png)' | \
          grep -v '202522115' | \
          grep -v '202522514' | \
          head -1)
    [ -n "$img" ] && echo "$pid|https://SOURCE_SITE/$img"
done
```

### Image URL Patterns by CMS

| CMS Type | Image URL Pattern | Notes |
|----------|-------------------|-------|
| LankeCMS ASP | `uploadfile/YYYYMMDDHHMMSS.jpg` | Filter out logo/banner by known filenames |
| WordPress | `wp-content/uploads/YYYY/MM/name.jpg` | Full URL needed |
| Static HTML | `images/products/XXX.jpg` | Direct path |

## Step 3: Create Product-to-Image Mapping

**This is the most critical step.** Getting the mapping wrong means images won't match descriptions.

### Complete Mapping for shengtuo-tractor.com

| DB ID | DB Product Name | Orig Site PID | Image File |
|-------|----------------|---------------|------------|
| 1 | ST404 (35-65HP) | 58 | 2025226853232798.jpg |
| 2 | ST504E | 171 | 20252269022442.jpg |
| 3 | ST504 (30-50hp) | 172 | 202522685248314.jpg |
| 4 | ST604 Garden | 231 | 202522687293417.jpg |
| 5 | ST704 (40-70hp) | 175 | 2025226836565037.jpg |
| 6 | ST804 (55-80hp) | 183 | 2025226850147150.jpg |
| 7 | ST804 (60-80hp) Garden | 137 | 2025226834184905.jpg |
| 8 | ST1154 (80-120hp) | 61 | 202522683152783.jpg |
| 9 | ST1354 (100-140hp) | 62 | 2025226829479411.jpg |
| 10 | ST1404 | 64 | 202522682641265.jpg |
| 11 | ST1604 (150-160hp) | 65 | 2025226823229802.jpg |
| 12 | ST1654 (145-165hp) | 66 | 2025226817568743.jpg |
| 13 | ST1854/ST2204 | 68 | 202522681071030.jpg |
| 14 | ST2204 New Hood | 232 | 2025226813427362.jpg |
| 15 | ST2404 Front PTO | 230 | 202522696126099.jpg |
| 16 | ST504 Cabin | 233 | 202522684342389.jpg |
| 17 | Front Loader | 227 | 2025228818317577.jpg |
| 18 | Plow | 225 | 201745155085167.jpg |
| 19 | Disc Harrow | 226 | 2017451450474178.jpg |
| 20 | Hay Baler | 228 | 202522886294924.jpg |
| 21 | Hydraulic Plough | 229 | 2017451616517641.jpg |
| 22 | Flail Mower | 234 | 20252271141492268.jpg |
| 23 | Slasher Mower | 235 | 2025227115285978.jpg |
| 24 | Post Hole Digger | 236 | 20252271156459132.jpg |
| 25 | Pipe Laying Machine | 237 | 202522712167156.jpg |
| 26 | Rotary Tiller | 238 | 2025227145137471.jpg |
| 27 | 1GLN Rotary Tiller | 239 | 20252271410187669.jpg |
| 28 | Disc Plough | 241 | 20252271426345841.jpg |
| 29 | Farm Trailer | 240 | 20252271422525440.jpg |
| 30 | Cultivator | 242 | 2025227143061710.jpg |
| 31 | Ridge Machine | 243 | 20252271432542418.jpg |
| 32 | Subsoiler | 244 | 20252271435484436.jpg |
| 33 | Box Grader | 245 | 20252271440265379.jpg |
| 34 | Corn Seeder | 246 | 20252271449495374.jpg |
| 35 | Spreader | 247 | 20252271453356703.jpg |
| 36 | Potato Harvester | 248 | 20252271459346406.jpg |
| 37 | Engine Parts | 224 | 202522881421327.jpg |

### Products Without Direct Match

Some products in the new DB may not exist on the source site. Strategy:

| Situation | Solution |
|-----------|----------|
| Same product category exists on source | Use the closest match image |
| No similar product on source | Use category-appropriate placeholder (front loader for equipment) |
| Engine/parts category | Use engine parts image |

**⚠️ Critical: Never use placeholder images without verifying!** If all images are the same file (same MD5 hash), they're all placeholders.

## Step 4: Download Images

### From Local Backup (Preferred)

```bash
SRC=/home/ubuntu/wwwroot
DEST=/home/ubuntu/shengtuo-website/assets/images/products

# Remove old files first
sudo rm -f "$DEST"/*.png "$DEST"/*.jpg

# Copy each image
sudo cp "$SRC/uploadfile/2025226853232798.jpg" "$DEST/product-1.jpg"
sudo cp "$SRC/uploadfile/20252269022442.jpg" "$DEST/product-2.jpg"
# ... for all products

sudo chown www-data:www-data "$DEST"/*.jpg
```

### From Remote Site (Fallback)

```bash
IMG_DIR="/home/ubuntu/shengtuo-website/assets/images/products"
cd "$IMG_DIR"
sudo rm -f *.png *.jpg

# Use individual curl commands (NOT associative arrays - they fail in terminal tool)
sudo curl -s -o product-1.jpg 'https://SOURCE_SITE/uploadfile/XXXXX.jpg'
sudo curl -s -o product-2.jpg 'https://SOURCE_SITE/uploadfile/YYYYY.jpg'

sudo chown www-data:www-data *.jpg
```

**⚠️ Pitfall: Bash associative arrays (`declare -A`) are unreliable in the terminal tool.** Use individual commands instead.

**⚠️ Pitfall: File permissions.** Website directories are often owned by `www-data`. Use `sudo` for rm/curl/chown operations.

## Step 5: Update Database Image Paths

```bash
mysql -uUSER -pPASS DBNAME -e "
UPDATE products SET image = '/assets/images/products/product-1.jpg' WHERE id = 1;
UPDATE products SET image = '/assets/images/products/product-2.jpg' WHERE id = 2;
"
```

**⚠️ Pitfall: Image format mismatch.** Source site may use `.jpg` while old placeholders were `.png`. Always update DB paths to match actual file extensions.

## Step 6: Extract and Update Product Descriptions

Product descriptions are often stored in `<meta name="description">` tags on the original site.

### PHP-Based Extraction (Handles Special Characters)

```php
<?php
// /tmp/update_desc.php
$pdo = new PDO('mysql:host=localhost;dbname=DBNAME;charset=utf8mb4', 'USER', 'PASS');
$stmt = $pdo->prepare("UPDATE products SET description = ? WHERE id = ?");

$map = [58=>1, 171=>2, 172=>3, /* ... */];

foreach ($map as $origPid => $dbId) {
    $file = "/home/ubuntu/wwwroot/products/{$origPid}.html";
    if (!file_exists($file)) continue;
    $html = file_get_contents($file);
    if (preg_match('/meta name="description" content="(.*?)"/s', $html, $m)) {
        $desc = mb_substr(trim($m[1]), 0, 800);
        if (!empty($desc)) $stmt->execute([$desc, $dbId]);
    }
}
```

```bash
php /tmp/update_desc.php
```

**⚠️ Why PHP not bash?** Bash `grep -oP` fails with special characters (parentheses, Chinese chars) in product descriptions. PHP's `preg_match` with `file_get_contents` handles encoding properly.

## Step 7: Fix Model Field Mismatches

**⚠️ Common data issue:** The `model` field in the database may not match the product name. Always verify:

```bash
mysql -uUSER -pPASS DBNAME -e "SELECT id, name, model FROM products WHERE is_active=1 ORDER BY id"
```

Known mismatches found:
| DB ID | Product Name | Wrong Model | Correct Model |
|-------|-------------|-------------|---------------|
| 5 | ST704 (40-70hp) | ST500-E | ST704 |
| 6 | ST804 (55-80hp) | ST704 | ST804 |
| 14 | ST2204 New Hood | ST1854 | ST2204 |

```bash
mysql -uUSER -pPASS DBNAME -e "
UPDATE products SET model = 'ST704' WHERE id = 5 AND model = 'ST500-E';
UPDATE products SET model = 'ST804' WHERE id = 6 AND model = 'ST704';
"
```

## Step 8: Verify Everything

### Image Verification

```bash
# Check images are accessible via web server
curl -s -o /dev/null -w "%{http_code}" "https://SITE/assets/images/products/product-1.jpg"
# Should return 200

# Verify unique images (not all placeholders)
md5sum /path/to/products/*.jpg | awk '{print $1}' | sort -u | wc -l
# Should equal total file count for real images

# Check file sizes vary
ls -la *.jpg | awk '{print $5, $9}' | sort -n
```

### Image-to-Product Verification

```bash
# Compare file sizes between local copy and original
for db_id in 1 5 10 15 17 20 26 37; do
    local_size=$(stat -c%s "$DEST/product-${db_id}.jpg")
    echo "product-${db_id}.jpg: ${local_size}B"
done
```

### Frontend Verification

Visit the products page and check:
1. Each product card shows the correct image
2. Product detail page shows the same image
3. Image alt text matches product name
4. No broken image icons

## Troubleshooting

| Problem | Solution |
|---------|----------|
| `Permission denied` on rm/curl | Use `sudo` |
| All images same size | Check md5sum, replace placeholders |
| Images not showing on frontend | Check DB paths match actual file extensions |
| JS pagination doesn't work | Use sitemap XML or local files |
| bash `declare -A` fails | Use individual commands |
| Source site 404 on product pages | Check local FTP backup first |
| Descriptions have garbled characters | Use PHP extraction, not bash grep |
| Model field doesn't match product name | Cross-check with `SELECT id, name, model` |
| Image appears correct file size but shows wrong product | Verify mapping by checking original HTML page title |
| Original site has more products than sitemap lists | List local HTML files directly: `ls /path/products/*.html` |
| Images updated locally but frontend shows old/duplicate images | **CDN cache issue!** Rename files with version suffix. See `references/cdn-cache-busting-images.md` |

### Browser Console Image Verification (Detect CDN Cached Duplicates)

When images appear "the same" on the frontend but local files are different, use the browser console to check actual rendered dimensions:

```javascript
(function() {
    const imgs = [];
    document.querySelectorAll('img[src*="product"]').forEach(img => {
        imgs.push({
            alt: img.alt,
            src: img.src.split('/').pop(),
            w: img.naturalWidth,
            h: img.naturalHeight
        });
    });
    // Check for duplicate naturalWidth x naturalHeight combinations
    const sizeCount = {};
    imgs.forEach(i => {
        const key = i.w + 'x' + i.h;
        sizeCount[key] = (sizeCount[key] || 0) + 1;
    });
    const dupes = Object.entries(sizeCount).filter(([k,v]) => v > 3);
    return JSON.stringify({total: imgs.length, suspiciousDupes: dupes});
})();
```

If many images share the exact same dimensions (e.g., all 407x269), CDN is likely serving cached placeholders. Compare MD5 of CDN-served vs local file:

```bash
curl -s "https://SITE/assets/images/products/product-22.jpg" | md5sum  # CDN
md5sum /path/to/products/product-22.jpg                                 # Local
# Different MD5 = CDN serving stale content
```

## Placeholder Image Detection

**Symptom:** All images show the same file size in `ls -la` (e.g., 22304 bytes).

**Diagnosis:**
```bash
md5sum *.png
# If all hashes are identical, they're all the same placeholder
```

**Root cause:** Previous import script created placeholder files instead of downloading real images.

**Fix:** Replace with real images from original site (local backup preferred).
