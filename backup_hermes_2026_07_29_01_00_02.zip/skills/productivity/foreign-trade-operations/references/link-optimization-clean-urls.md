# Link Optimization & Clean URL Management for sub.aiv.qzz.io

## Overview

Complete guide for auditing, fixing, and managing all internal links on the sub.aiv.qzz.io PHP website. Covers clean URL routing, slug parsing, footer/navbar link patterns, domain consistency, and full-site clean URL migration.

**Verified on:** 2026-05-30, Nginx + PHP 8.3-FPM + MySQL + Cloudflare

## Full-Site Clean URL Migration (Remove .html Extensions)

When standardizing all URLs to clean format (no `.html` suffix), update these files in order:

### Step 1: Header & Footer Navigation
```bash
# Header (templates/header.php)
sed -i 's|href="/products.html"|href="/products"|g' templates/header.php
sed -i 's|href="/about.html"|href="/about"|g' templates/header.php
sed -i 's|href="/news.html"|href="/news"|g' templates/header.php
sed -i 's|href="/contact.html"|href="/contact"|g' templates/header.php

# Footer (templates/footer.php)
sed -i 's|href="/products.html"|href="/products"|g' templates/footer.php
sed -i 's|href="/about.html"|href="/about"|g' templates/footer.php
sed -i 's|href="/news.html"|href="/news"|g' templates/footer.php
sed -i 's|href="/contact.html"|href="/contact"|g' templates/footer.php
```

### Step 2: All PHP Pages (batch)
```bash
for file in *.php templates/*.php; do
    [ -f "$file" ] || continue
    sed -i 's|/products.html|/products|g' "$file"
    sed -i 's|/about.html|/about|g' "$file"
    sed -i 's|/contact.html|/contact|g' "$file"
    sed -i 's|/news.html|/news|g' "$file"
done
```

### Step 3: SEO Class (includes/seo.php)
```bash
sed -i 's|/about.html|/about|g' includes/seo.php
sed -i 's|/contact.html|/contact|g' includes/seo.php
```

### Step 4: Sitemap Generator (sitemap.php)
- Fix `$pdo` variable: add `$pdo = getDBConnection();` after require statements
- Fix DB column: `WHERE status = 1` → `WHERE is_active = 1` (products and news tables)
- Delete old sitemap.xml and regenerate: `rm sitemap.xml && curl -s /sitemap.php > sitemap.xml`

### Step 5: Verification
```bash
# Check no .html links remain (except 404.html and comments)
grep -rn "\.html" *.php templates/*.php | grep -v "404.html\|\.html$\|#\|html_entity\|htmlspecialchars"

# Verify all clean URLs work
for page in / /products /about /contact /news; do
    status=$(curl -s -o /dev/null -w "%{http_code}" "https://sub.aiv.qzz.io$page")
    echo "$page: $status"
done
```

## Product Slug SEO Optimization

Auto-generated slugs like `tractor--404-1` or `equipment-1-eavy-uty-otary-iller-10` hurt SEO. Rewrite to semantic format:

### Slug Naming Convention
```
st404-tractor, st504e-tractor, st604-tractor, st1354-tractor...
front-loader-backhoe, disc-plough, rotary-tiller, post-hole-digger...
```

### Bulk Update Script
```sql
-- Tractors: model + "tractor"
UPDATE products SET slug = 'st404-tractor' WHERE id = 1;
UPDATE products SET slug = 'st504e-tractor' WHERE id = 2;
-- ... (one per product)

-- Equipment: descriptive name
UPDATE products SET slug = 'front-loader-backhoe' WHERE id = 17;
UPDATE products SET slug = 'disc-plough' WHERE id = 18;
-- ... (one per product)
```

**⚠️ After slug update:** All product links using `$product['slug']` automatically use new slugs. No PHP code changes needed.

## Sitemap Generation Fixes

### Common Issues
1. **`$pdo` undefined** — `sitemap.php` must call `getDBConnection()`:
   ```php
   require_once __DIR__ . '/config/database.php';
   require_once __DIR__ . '/includes/seo.php';
   $pdo = getDBConnection();  // Required!
   ```

2. **Wrong column name** — Products/news use `is_active`, not `status`:
   ```php
   // ❌ Wrong
   $stmt = $this->pdo->query("SELECT slug FROM products WHERE status = 1");
   // ✅ Correct
   $stmt = $this->pdo->query("SELECT slug FROM products WHERE is_active = 1");
   ```

3. **Static sitemap.xml cached** — Delete and regenerate after changes:
   ```bash
   rm -f sitemap.xml
   curl -s "https://sub.aiv.qzz.io/sitemap.php" > sitemap.xml
   ```

## Link Inventory

### Working URL Patterns

| Pattern | Nginx Route Type | Example |
|---------|-----------------|---------|
| `/` | default try_files | Homepage |
| `/about` | exact match `=` | Clean URL |
| `/products` | exact match `=` | Clean URL |
| `/products?category=slug` | query string | Category filter |
| `/products?hp=25-50` | query string | HP range filter |
| `/contact` | exact match `=` | Clean URL |
| `/news` | exact match `=` | Clean URL |
| `/product/slug` | try_files → product.php | Product detail |
| `/news/slug` | try_files → news_detail.php | News detail |
| `/sitemap.xml` | try_files /sitemap.xml | Static/dynamic |
| `/robots.txt` | try_files /robots.txt | Static only |

### Category Slugs (from DB, NOT hardcoded)

```
shengtuo-tractor       → 16 products (SHENGTUO TRACTOR category)
shengtuo-farm-equipment → 21 products (SHENGTUO FARM EQUIPMENT category)
```

**⚠️ Never hardcode category slugs in navbar/footer.** Always query from DB:
```php
$navCategories = $db->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order")->fetchAll();
foreach ($navCategories as $cat):
?>
<a href="/products?category=<?= escape($cat['slug']) ?>"><?= escape($cat['name']) ?></a>
<?php endforeach; ?>
```

## Clean URL Nginx Configuration

Both `.html` and clean URL versions must have separate exact-match routes:

```nginx
# Clean URLs (no .html) — place BEFORE .html routes
location = /products {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/products.php;
    include fastcgi_params;
}
location = /about {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/about.php;
    include fastcgi_params;
}
location = /contact {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/contact.php;
    include fastcgi_params;
}
location = /news {
    fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root/news.php;
    include fastcgi_params;
}
```

**Editing nginx:** Use `sudo sed -i` or `sudo tee` — `patch`/`write_file` refuse `/etc/nginx/`.

## Link Audit Script

```bash
#!/bin/bash
# Full link audit for sub.aiv.qzz.io
DOMAIN="https://sub.aiv.qzz.io"
total=0; pass=0; fail=0

for url in \
  "$DOMAIN/" \
  "$DOMAIN/about" \
  "$DOMAIN/products" \
  "$DOMAIN/contact" \
  "$DOMAIN/news" \
  "$DOMAIN/product/st2404-tractor" \
  "$DOMAIN/news/agro-2026-exhibition" \
  "$DOMAIN/products?category=shengtuo-tractor" \
  "$DOMAIN/products?hp=25-50" \
  "$DOMAIN/sitemap.xml" \
  "$DOMAIN/robots.txt" \
  "$DOMAIN/assets/css/style-v2.css" \
  "$DOMAIN/assets/images/favicon.png" \
  "$DOMAIN/admin/login.php"; do
  total=$((total+1))
  status=$(curl -s -o /dev/null -w "%{http_code}" "$url")
  if [ "$status" = "200" ]; then pass=$((pass+1))
  else fail=$((fail+1)); echo "❌ $status ${url#$DOMAIN}"; fi
done
echo "✅ $pass/$total passed | ❌ $fail failed"
```

## Footer Link Pattern

Footer links should use clean URLs (no `.html` suffix):

```php
<!-- Quick Links -->
<li><a href="/">Home</a></li>
<li><a href="/products">Products</a></li>
<li><a href="/about">About Us</a></li>
<li><a href="/news">News</a></li>
<li><a href="/contact">Contact</a></li>

<!-- Category Links (dynamic from DB) -->
<?php foreach ($footerCategories as $category): ?>
<li><a href="/products?category=<?= escape($category['slug']) ?>"><?= escape($category['name']) ?></a></li>
<?php endforeach; ?>
```

## News Detail Link Pattern

News links should use `/news/slug` (no `.html` suffix):

```php
// In index.php / news.php
<a href="/news/<?= escape($news['slug']) ?>"><?= escape($news['title']) ?></a>
```

## Domain Consistency Checklist

When deploying to a new domain (e.g., sub.aiv.qzz.io instead of shengtuo-tractor.com):

- [ ] `config/database.php` → `define('SITE_URL', 'https://sub.aiv.qzz.io');`
- [ ] `robots.txt` → `Sitemap: https://sub.aiv.qzz.io/sitemap.xml`
- [ ] `sitemap.php` → uses `SITE_URL` constant (auto-updated if config is correct)
- [ ] `header.php` → canonical/OG tags use `SITE_URL` or `getCurrentUrl()`
- [ ] Cloudflare DNS → A/CNAME record points to server

## PHP 8.1+ Null Parameter Fix

`htmlspecialchars()` in PHP 8.1+ throws deprecation warning when passed `null`.

```php
// ❌ Triggers: Passing null to parameter #1 ($string) of type string
function escape($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// ✅ Fixed
function escape($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}
```

## HP Range Filter (products.php)

Products page supports `?hp=25-50` style filtering:

```php
$hpRange = $_GET['hp'] ?? null;
if ($hpRange) {
    $parts = explode('-', $hpRange);
    if (count($parts) == 2) {
        $minHp = (int)$parts[0];
        $maxHp = (int)$parts[1];
        // Fetch all tractors, then filter by extracted HP number
        $allProds = $stmt->fetchAll();
        $products = array_filter($allProds, function($p) use ($minHp, $maxHp) {
            if (empty($p['horsepower']) || $p['horsepower'] === 'N/A') return false;
            preg_match_all('/\d+/', $p['horsepower'], $matches);
            if (empty($matches[0])) return false;
            $hp = (int)$matches[0][0];
            return $hp >= $minHp && $hp <= $maxHp;
        });
        $products = array_values($products);
    }
}
```

**⚠️ Pitfall:** If the `$products = $stmt->fetchAll()` line is OUTSIDE the if/elseif/else block, it overwrites the filtered results. Each branch must set `$products` internally.
