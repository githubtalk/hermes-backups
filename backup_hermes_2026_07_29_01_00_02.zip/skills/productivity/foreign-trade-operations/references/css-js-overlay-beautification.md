# CSS/JS Overlay Beautification Pattern

When the user requests visual beautification **without touching the backend, product structure, or system**, use this overlay approach.

## Core Principle

**Add new files, don't replace existing ones.** Only modify `<head>` to reference the new CSS/JS.

## Files to Create

| File | Purpose |
|------|---------|
| `css/custom.css` | Modern styling overrides (CSS variables, gradients, animations) |
| `js/custom.js` | Scroll animations, hover effects, lazy loading |

## Step-by-Step Workflow (FTP-based sites)

```bash
# 1. Download current index.html
curl -s -u "USER:PASS" ftp://HOST/wwwroot/index.html -o /tmp/index.html

# 2. Create custom.css and custom.js locally

# 3. Upload CSS
curl -T /tmp/custom.css -u "USER:PASS" ftp://HOST/wwwroot/css/custom.css

# 4. Upload JS
curl -T /tmp/custom.js -u "USER:PASS" ftp://HOST/wwwroot/js/custom.js

# 5. Add references in <head> (after existing CSS, before </head>)
# Use patch tool, NOT write_file (to preserve structure)
```

## HTML Head Modification

Only add these two lines after the existing CSS link:

```html
<link href="css/style.css" type="text/css" rel="stylesheet" />  <!-- existing -->
<link href="css/custom.css" type="text/css" rel="stylesheet" />  <!-- ADD THIS -->
<script type="text/javascript" src="js/jquery-1.4.3.min.js"></script>  <!-- existing -->
<script type="text/javascript" src="js/custom.js"></script>  <!-- ADD THIS -->
```

## CSS Custom.css Structure

```css
/* CSS Variables for consistent theming */
:root {
    --primary-color: #1a56db;
    --accent-color: #f59e0b;
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    --radius-md: 10px;
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

/* Override body background */
body {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    background-attachment: fixed !important;
}

/* Modern container */
#main {
    max-width: 1200px !important;
    background: white !important;
    border-radius: var(--radius-md) !important;
    box-shadow: var(--shadow-md) !important;
}

/* Sticky navigation */
#nav {
    position: sticky !important;
    top: 0 !important;
    z-index: 1000 !important;
}

/* Product card grid (override list layout) */
.productlist {
    display: grid !important;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)) !important;
    gap: 20px !important;
}

/* Card hover effects */
.productlist li {
    transition: var(--transition) !important;
    border-radius: var(--radius-md) !important;
    box-shadow: var(--shadow-md) !important;
}

.productlist li:hover {
    transform: translateY(-8px) !important;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1) !important;
}
```

## JS Custom.js Structure

```javascript
(function($) {
    $(document).ready(function() {
        // 1. Scroll animations - fade in elements on scroll
        // 2. Smooth scroll for anchor links
        // 3. Enhanced hover effects
        // 4. Back-to-top button
        // 5. Sticky nav shadow on scroll
    });
})(jQuery);
```

## What NOT to Touch

- ❌ Existing HTML structure (product lists, tables, content blocks)
- ❌ Backend/admin panels
- ❌ Database or CMS settings
- ❌ Product data or listings
- ❌ Navigation menu items
- ❌ Original CSS file (only override via specificity)

## Verification

After upload:
1. Check CSS loads: `getComputedStyle(document.body).background` includes gradient
2. Check JS loads: `typeof jQuery !== 'undefined'`
3. Visual inspection via browser screenshot

## shengtuo-tractor.com Specific

- FTP: `shanweituo.gotoftp4.com`
- CSS path: `/wwwroot/css/custom.css`
- JS path: `/wwwroot/js/custom.js`
- jQuery version: 1.4.3 (old, but works)
- Backend admin: `https://www.shengtuo-tractor.com/admin_v19` (do NOT touch)

## ⚠️ Restore Workflow (When User Requests Revert)

If the user says "恢复原来的配置" or is not satisfied with the beautification:

```bash
# 1. Re-download current index.html
curl -s -u "USER:PASS" ftp://HOST/wwwroot/index.html -o /tmp/index.html

# 2. Remove custom CSS/JS references (use patch tool)
# Remove: <link href="css/custom.css" ...>
# Remove: <script ... custom.js></script>

# 3. If original style.css was modified, restore it:
curl -s -u "USER:PASS" ftp://HOST/wwwroot/css/style.css -o /tmp/style.css
# Patch back: body { background-color: #FFFFFF; }
# Patch back: #main { background-color: transparent; box-shadow: none; }
curl -T /tmp/style.css -u "USER:PASS" ftp://HOST/wwwroot/css/style.css

# 4. Remove CSS version cache-buster if added
# Restore: <link href="css/style.css" ...> (remove ?v=...)

# 5. Upload restored index.html
curl -T /tmp/index.html -u "USER:PASS" ftp://HOST/wwwroot/index.html
```

**Key insight:** The custom.css and custom.js files can stay on the server — they won't affect the page once the HTML references are removed. No need to delete them.

## Inline SVG Icons (No Image Upload Needed)

When adding contact buttons (WhatsApp, QQ, etc.), use inline SVG instead of image files:

```html
<!-- WhatsApp inline SVG (green, no image upload needed) -->
<a target="_blank" href="https://wa.me/86XXXXXXXXXXX">
<svg width="20" height="20" viewBox="0 0 24 24" fill="#25D366" style="vertical-align:middle;margin-right:4px;">
<path d="M17.472 14.382c-.297-.149-1.758-.867..."/>
</svg>
<span style="color:#25D366;font-weight:bold;">WhatsApp</span>
</a>
```

**Benefits:**
- No image file upload needed
- Always renders (no broken images)
- Scales perfectly at any size
- Color easily changed via `fill` attribute

**Sizing:** Default 20x20 is small. For larger buttons, use 36x36 and increase font-size to 16px.
