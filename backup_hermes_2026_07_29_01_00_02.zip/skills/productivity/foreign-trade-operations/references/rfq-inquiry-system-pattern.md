# RFQ/Inquiry System Pattern for International Trade Websites

## Architecture

```
Product Detail Page → JavaScript fetch() → api/inquiry.php → inquiries table → admin/inquiries.php
```

## Database Table

```sql
CREATE TABLE inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT DEFAULT NULL,
    product_name VARCHAR(200) DEFAULT '',
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(50) DEFAULT '',
    company VARCHAR(100) DEFAULT '',
    country VARCHAR(80) DEFAULT '',
    quantity VARCHAR(50) DEFAULT '',
    message TEXT NOT NULL,
    status ENUM('new','replied','quoted','closed') DEFAULT 'new',
    admin_notes TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_product (product_id),
    INDEX idx_created (created_at)
);
```

## API Endpoint (api/inquiry.php)

- POST only (405 for GET)
- Accept JSON or form-data
- Required: name, email, message
- Validate email with filter_var()
- Sanitize all inputs
- Return JSON: `{success: true/false, message: "..."}`
- Log errors, don't expose them

## Product Page Form Fields

| Field | Type | Required | Notes |
|-------|------|----------|-------|
| name | text | ✅ | Full name |
| email | email | ✅ | |
| phone | text | | International format |
| company | text | | |
| country | select | | 26+ export countries dropdown |
| quantity | text | | Placeholder: "e.g. 1-5 units" |
| message | textarea | ✅ | Pre-filled: "I am interested in [product]. Please send me a quotation..." |
| product_id | hidden | | From product page |
| product_name | hidden | | From product page |

## JavaScript Submission Pattern

```javascript
fetch('/api/inquiry.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
}).then(r => r.json()).then(result => {
    if (result.success) {
        // Show success alert + WhatsApp quick link
    } else {
        // Show error alert
    }
});
```

## Admin Page Features

- Stats cards: Total, New, Replied, Quoted
- Status filter tabs + search
- List table with colored status badges
- New inquiries highlighted (yellow bg)
- Detail view: all fields, status dropdown, admin notes
- Reply button (mailto: link)
- CSRF + flash messages

## Country Dropdown (Common Export Markets)

Nigeria, Argentina, Vietnam, Brazil, Russia, Egypt, Thailand, Indonesia, India, Pakistan, Mexico, Colombia, Myanmar, Ethiopia, Tanzania, South Africa, Kenya, Ghana, Philippines, Peru, Chile, Ukraine, Turkey, Iran, Sudan, Others

## ⚠️ Known Bug: `$_GET` Typo in inquiries.php

Line 54 of `admin/inquiries.php` had `($GET['action'] ?? '')` instead of `($_GET['action'] ?? '')`. This caused the detail view (`?action=view&id=X`) to silently fail — the page loaded but showed the list view with "No inquiries found" instead of the inquiry details.

**Fix:** Replace `$GET` with `$_GET` on the condition line. This is a common PHP superglobal typo that doesn't trigger a PHP error (just an "Undefined variable" notice in logs).

## ⚠️ Dashboard Integration Required

After creating the inquiries module, `admin/index.php` must be updated with:
- Inquiry count stats (total + new)
- Recent inquiries table (last 5, showing name/country/product/status/date)

Without this, the Dashboard has no visibility into incoming inquiries.
