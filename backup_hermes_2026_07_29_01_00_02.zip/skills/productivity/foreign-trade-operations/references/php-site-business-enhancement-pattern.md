# PHP Site Business Enhancement Pattern

## Overview
Proven pattern for enhancing B2B websites with professional animations, trust signals, and UX improvements. Works with Bootstrap 5 + custom CSS.

## Files to Create
- `assets/css/enhance-v3.css` — All enhancement styles
- `assets/js/enhance-v3.js` — Scroll reveal engine, typing effect, counter animation, image zoom, lazy loading

## CSS Additions

### Scroll Reveal Animations
```css
.reveal { opacity:0; transform:translateY(40px); transition:opacity 0.8s, transform 0.8s; }
.reveal.revealed { opacity:1; transform:translateY(0); }
.reveal-left { opacity:0; transform:translateX(-60px); transition:opacity 0.8s, transform 0.8s; }
.reveal-left.revealed { opacity:1; transform:translateX(0); }
.reveal-right { opacity:0; transform:translateX(60px); transition:opacity 0.8s, transform 0.8s; }
.reveal-right.revealed { opacity:1; transform:translateX(0); }
.reveal-scale { opacity:0; transform:scale(0.85); transition:opacity 0.8s, transform 0.8s; }
.reveal-scale.revealed { opacity:1; transform:scale(1); }
.delay-1 { transition-delay:0.1s; } /* ... up to delay-6 */
```

### Testimonial Cards
```css
.testimonial-card { background:#fff; border-radius:16px; padding:2.5rem; box-shadow:0 4px 24px rgba(0,0,0,0.06); position:relative; }
.testimonial-card::before { content:''; position:absolute; top:0; left:0; right:0; height:4px; background:linear-gradient(90deg,var(--primary),var(--accent)); border-radius:16px 16px 0 0; }
.testimonial-stars { color:var(--accent); font-size:0.9rem; letter-spacing:2px; }
.testimonial-text { font-style:italic; line-height:1.8; }
.testimonial-avatar { width:52px; height:52px; border-radius:50%; background:linear-gradient(135deg,var(--primary),var(--accent)); display:flex; align-items:center; justify-content:center; color:#fff; font-weight:700; }
```

### Trust Badges
```css
.trust-bar { background:var(--gray-100); padding:2.5rem 0; }
.trust-item { text-align:center; transition:all 0.3s; }
.trust-item:hover { transform:translateY(-4px); }
.trust-icon { width:56px; height:56px; border-radius:50%; background:linear-gradient(135deg,var(--primary),var(--primary-light)); display:flex; align-items:center; justify-content:center; margin:0 auto 0.75rem; }
.trust-item:hover .trust-icon { background:linear-gradient(135deg,var(--accent),var(--accent-hover)); transform:scale(1.1); }
```

### Product Image Zoom (Hover)
```css
.product-detail-image { position:relative; overflow:hidden; cursor:crosshair; border-radius:16px; }
.product-detail-image img { transition:transform 0.3s ease; }
.product-detail-image:hover img { transform:scale(1.5); }
.zoom-hint { position:absolute; bottom:12px; right:12px; background:rgba(0,0,0,0.6); color:#fff; padding:0.3rem 0.8rem; border-radius:20px; font-size:0.75rem; }
.product-detail-image:hover .zoom-hint { opacity:0; }
```

### Sticky Product CTA (Mobile)
```css
.sticky-cta { position:fixed; bottom:0; left:0; right:0; background:rgba(255,255,255,0.95); backdrop-filter:blur(12px); border-top:1px solid rgba(0,0,0,0.08); padding:0.75rem 0; z-index:1040; transform:translateY(100%); transition:transform 0.4s; }
.sticky-cta.visible { transform:translateY(0); }
```

### Section Divider
```css
.section-divider { height:4px; background:linear-gradient(90deg,transparent,var(--accent),transparent); margin:0 auto 2rem; width:80px; border-radius:2px; }
```

## JS Modules

### Scroll Reveal Engine (IntersectionObserver)
```js
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
            observer.unobserve(entry.target);
        }
    });
}, { threshold: 0.15, rootMargin: '0px 0px -50px 0px' });
document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale').forEach(el => observer.observe(el));
```

### Typing Effect
- Element with class `.typing-text` and `data-strings='["text1","text2"]'`
- Types forward, pauses 2s, deletes, moves to next string
- Blinking caret animation via CSS `@keyframes blink-caret`

### Counter Animation
- Elements with `data-target`, `data-suffix`, `data-prefix` attributes
- Triggers on scroll into view (IntersectionObserver)
- Easing: ease-out cubic over 2 seconds
- Supports comma-formatted numbers

### Image Zoom (mousemove)
- Container with class `.product-detail-image`
- Sets `transformOrigin` based on mouse position for magnified view on hover

### Sticky CTA Trigger
- Uses IntersectionObserver on `.product-cta-trigger` element
- When trigger leaves viewport, adds `.visible` class to `.sticky-cta`

## HTML Patterns

### Hero Typing Effect
```html
<h2><span class="typing-text" data-strings='["Line 1","Line 2","Line 3"]'>Line 1</span></h2>
<div class="hero-trust">
    <span class="hero-trust-item"><i class="fas fa-check-circle"></i> ISO9001</span>
    <span class="hero-trust-item"><i class="fas fa-check-circle"></i> 50+ Countries</span>
</div>
```

### Trust Bar
```html
<section class="trust-bar reveal">
    <div class="container">
        <div class="row">
            <div class="col-6 col-md-3">
                <div class="trust-item">
                    <div class="trust-icon"><i class="fas fa-certificate"></i></div>
                    <div class="trust-label">ISO9001</div>
                </div>
            </div>
            <!-- repeat for CE, EPA, Global Export -->
        </div>
    </div>
</section>
```

### Testimonials
```html
<section class="testimonials-section">
    <div class="container">
        <div class="text-center mb-5 reveal">
            <span class="section-badge">Client Feedback</span>
            <h2 class="section-title">What Our Clients Say</h2>
            <div class="section-divider"></div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-6 mb-4 reveal delay-1">
                <div class="testimonial-card">
                    <div class="testimonial-stars">★★★★★</div>
                    <p class="testimonial-text">"Quote text..."</p>
                    <div class="testimonial-author">
                        <div class="testimonial-avatar">AB</div>
                        <div class="testimonial-info">
                            <h6>Name</h6>
                            <span>City, Country · Role</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
```

### Product Image Zoom
```html
<div class="product-detail-image" style="max-height:450px;display:inline-block;">
    <img src="..." alt="..." style="max-width:100%;max-height:450px;object-fit:contain;border-radius:12px;">
    <span class="zoom-hint"><i class="fas fa-search-plus"></i> Hover to zoom</span>
</div>
```

### Counter Stats
```html
<div class="stat-number" data-target="25,000" data-suffix="">0</div>
```

## Integration Checklist
- [ ] Add `reveal` class to section headers
- [ ] Add `reveal-left` / `reveal-right` to side-by-side content
- [ ] Add `reveal delay-N` to grid cards (stagger by index)
- [ ] Add `section-divider` after section titles
- [ ] Add `loading="lazy"` to all below-fold images
- [ ] Add `data-target` attributes to stat numbers
- [ ] Create trust bar with 4 certification badges
- [ ] Create 3 testimonial cards with international clients
- [ ] Add typing effect to first hero slide only
- [ ] Add hero trust badges below hero CTA
- [ ] Add sticky CTA on product detail pages (d-lg-none)

## Pitfalls
- **Stagger delay limit**: Don't exceed delay-6; longer delays feel sluggish
- **Typing on all slides**: Only add typing-text to the FIRST carousel item
- **Zoom on mobile**: Touch events need separate handling; CSS hover zoom works on desktop only
- **Sticky CTA z-index**: Must be below navbar (1050) but above content (1040)
- **Reduced motion**: Always include `@media (prefers-reduced-motion: reduce)` to disable animations
