# Nginx Proxy Manager PUT 400 陷阱

## 现象
`PUT /api/nginx/proxy-hosts/{id}` 返回：
```json
{"error":{"code":400,"message":"data must NOT have additional properties"}}
```
真正原因是 **PUT 载荷里多一个 schema 不认识的字段，整个请求就会被拒绝**，不是只校验被改的字段。

## 模式
1. `GET /api/nginx/proxy-hosts/{id}` 取得当前完整对象。
2. 只保留后端 schema 明确支持的字段，**删掉任何额外字段**（meta、owner、certificate、custom 等）。
3. `PUT` 回去，或用一个已验证的最小字段集提交。

## 最小可用字段集（实测通过）
```json
{
  "domain_names": [],
  "forward_scheme": "http",
  "forward_host": "",
  "forward_port": 0,
  "access_list_id": 0,
  "certificate_id": 0,
  "ssl_forced": false,
  "caching_enabled": false,
  "block_exploits": false,
  "allow_websocket_upgrade": true,
  "http2_support": false,
  "trust_forwarded_proto": false,
  "enabled": true,
  "hsts_enabled": false,
  "hsts_subdomains": false,
  "locations": [],
  "advanced_config": ""
}
```

## 注意
- NPM 不同版本 schema 差异较大。先 `GET` 原样 `PUT` 能过，是最稳的跨版本写法。
- 新增用 `POST /api/nginx/proxy-hosts`，更新用 `PUT /api/nginx/proxy-hosts/{id}`。
