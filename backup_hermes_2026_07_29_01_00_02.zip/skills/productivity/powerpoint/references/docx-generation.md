# docx Generation

Create .docx Word documents programmatically with python-docx.

## Quick Setup

```bash
/usr/bin/pip3 install python-docx --break-system-packages
```

## Execution Path

```bash
# Always use /usr/bin/python3 for docx operations
/usr/bin/python3 /tmp/make_docx.py
```

**Why this matters**: The sandbox Python (3.11) and Hermes venv Python (3.11) are separate from system Python (3.12). Modules installed system-wide via `/usr/bin/pip3` go to Python 3.12's site-packages, not the venv.

## Common Workflows

### Basic Document Creation

```python
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()
section = doc.sections[0]
section.page_width = Inches(8.27)
section.page_height = Inches(11.69)
section.left_margin = Inches(1.18)
section.right_margin = Inches(1.18)

# Title
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run("Document Title")
run.font.size = Pt(22)
run.font.bold = True

# Body paragraph
p = doc.add_paragraph()
p.paragraph_format.first_line_indent = Pt(24)
p.add_run("Body text goes here.")

# Heading
p = doc.add_paragraph()
run = p.add_run("Section Heading")
run.font.size = Pt(13)
run.font.bold = True
run.font.color.rgb = RGBColor(0x0a, 0x2c, 0x5e)

# Bullet list
p = doc.add_paragraph(style='List Bullet')
p.add_run("List item")

# Bold inline
p = doc.add_paragraph()
p.paragraph_format.first_line_indent = Pt(24)
rb = p.add_run("Bold text: ")
rb.font.bold = True; rb.font.size = Pt(12)
rn = p.add_run("Normal continues here.")
rn.font.size = Pt(12)

doc.save('/tmp/output.docx')
```

### Chinese Text with python-docx

Chinese characters work natively in python-docx (UTF-8). Be careful with:
- **Smart quotes** (U+FF0C, U+2019, etc.) in Python source → SyntaxError. Use regular ASCII quotes inside strings.
- **Chinese text in terminal heredocs** → safe, bash handles UTF-8
- **python-docx API** → fully supports Chinese characters

## Encoding Pitfall: Avoid Here-Doc to Python

❌ **DON'T do this** — smart quotes in the Chinese text cause Python SyntaxError:
```bash
python3 << 'PYEOF'
p = doc.add_paragraph("中文内容"）  # syntax error
PYEOF
```

✅ **SAFE APPROACH**: Write script to file first, then execute:
```bash
cat > /tmp/script.py << 'ENDOFFILE'
# Chinese content here, safe in heredoc
p = doc.add_paragraph("中文内容")
doc.save('/tmp/out.docx')
ENDOFFILE
/usr/bin/python3 /tmp/script.py
```

## PPT + docx Decision Tree

| Output format | Best tool | Command |
|---------------|-----------|---------|
| Slides/presentations | python-pptx | `/usr/bin/python3 /tmp/script.py` |
| Word documents | python-docx | `/usr/bin/python3 /tmp/script.py` |
| Both | Write script to `/tmp/`, execute from terminal | `terminal` tool |

## Key Functions Reference

```python
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn  # for East Asian font

# Set font for Chinese text
run.font.name = 'Microsoft YaHei'
r = run._element
r.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')

# Paragraph spacing
p.paragraph_format.line_spacing = Pt(24)
p.paragraph_format.space_before = Pt(12)
p.paragraph_format.space_after = Pt(6)

# Page borders (requires lxml)
from docx.oxml.ns import nsmap
```

## Send to User

```python
# After generating, send via Telegram
# File path: /tmp/output.docx
# Send with: send_message(target='telegram', message="MEDIA:/tmp/output.docx")
```