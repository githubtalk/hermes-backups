# PDF Appearance Modifier: Debugging Log

## Session: 2026-07-17 — Change red font to black in 5 PDFs

### Error 1: PyMuPDF `span["color"] = ...` silently fails

**Symptom**: Assigned `(0,0,0)` or `0x000000` to `span["color"]`, saved PDF, but `fitz.open()` still showed old color `15366264`.

**Root cause**: PyMuPDF exposes span dicts as read-only views. Assignments are silently ignored.

**Fix**: Do NOT mutate spans. Use `pikepdf` for stream-level surgery.

### Error 2: `pikepdf.Stream(pdf, ...)` TypeError

**Symptom**: `TypeError: (): incompatible function arguments` when calling `pikepdf.Stream(pdf, ...)`.

**Root cause**: Passing `pdf` as first positional argument conflicts with `__init__` signature. Must use named or positional args correctly.

**Fix**: `pikepdf.Stream(pdf, data)` works in newer versions. In some cases must instantiate without args and set content differently.

### Error 3: PyMuPDF `insert_text()` corrupts PDF with ICC colorspace errors

**Symptom**: After `page.insert_text()`, saving produced many `MuPDF error: format error: object is not a stream` and `syntax error: invalid ICC colorspace` errors.

**Root cause**: PyMuPDF sanitizes/recreates resources when inserting new content, breaking embedded ICC profiles in existing documents.

**Fix**: Use `pikepdf` stream replacement instead of PyMuPDF content insertion.

### Error 4: `page.Contents` type varies (Array vs single Stream)

**Symptom**: `AttributeError: 'str' object has no attribute 'read_bytes'` when iterating `page.Contents`.

**Root cause**: `page.Contents` can be a `pikepdf.Array` of streams, or a single `pikepdf.Stream` object. Must check type before iterating.

**Fix**:
```python
if isinstance(contents, pikepdf.Array):
    for stream in contents:
        ...
elif hasattr(contents, 'read_bytes'):
    stream = contents
```

### Error 5: Content stream is FlateDecode-compressed

**Symptom**: `pikepdf.Stream.read_bytes()` returns bytes that look like binary/garbage when decoded as latin-1.

**Root cause**: Stream is compressed. Must decompress with zlib or use pikepdf's built-in decompression.

**Fix**: In many cases `read_bytes()` already returns decompressed data. If not, use `zlib.decompress(data)`. Always decode with `latin-1` to preserve all byte values.

### Error 6: Regex fails when color values have extra decimals

**Symptom**: Regex for `0.91764706 0.47058824 0.47058824 scn` found 0 matches in some files.

**Root cause**: Same color may appear with slightly different precision, e.g. `0.918 0.471 0.471 scn` vs `0.91764706 0.47058824 0.47058824 scn`.

**Fix**: Use flexible regex `r'(\d+\.\d+)\s+(\d+\.\d+)\s+(\d+\.\d+)\s+scn'` with tolerance-based replacement logic.

## Color Detection Logic

Red-ish detection threshold (empirically derived):
```python
def is_red(r, g, b):
    return r > 0.7 and r > g + 0.1 and r > b + 0.1
```

Target red in this session: `(0.918, 0.471, 0.471)` in sRGB colorspace.
Replacement: `(0, 0, 0)` — pure black.

## Verification Recipe

After batch processing:
```python
import fitz
doc = fitz.open("output.pdf")
red_count = 0
for page in doc:
    for span in page.get_text("dict")["blocks"]:
        c = span.get("color")
        if c and c > 0:
            r = (c >> 16) & 0xFF
            g = (c >> 8) & 0xFF
            b = c & 0xFF
            if r == 234 and g == 120 and b == 120:
                red_count += 1
```

Red count should be 0 for successful conversion.

## Tools Used

- `pikepdf` 10.10.0 — stream-level PDF editing
- `pymupdf` 1.27.2.3 — verification/reading only
- `re` — regex for color operator matching
- `zlib` — stream decompression (when needed)
