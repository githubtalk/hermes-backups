---
name: productivity
description: Skills for document creation, presentations, spreadsheets, and other productivity workflows.
version: 1.0.0
metadata:
  hermes:
    tags: [productivity]
    related_skills: ['public-api-tools', 'notion', 'nano-pdf', 'google-workspace', 'ocr-and-documents', 'powerpoint', 'maps', 'linear']
---

# Productivity

## Overview

Skills for document creation, presentations, spreadsheets, and other productivity workflows.

## Sub-skills

- **airtable**: Airtable REST API via curl
- **cli-utilities**: Practical CLI tools for HTTP requests, JSON processing, date calculations, and file conversions
- **foreign-trade-operations**: Tractor/farm-machinery export operations management
- **google-workspace**: Gmail, Calendar, Drive, Docs, Sheets via gws CLI or Python
- **linear**: Linear issue/project management via GraphQL + curl
- **maps**: Geocoding, POIs, routes, and timezones via OpenStreetMap/OSRM
- **nano-pdf**: Edit PDF text/typos/titles via nano-pdf CLI
- **notion**: Notion API via curl for pages, databases, and blocks
- **ocr-and-documents**: Extract text from PDFs/scans (pymupdf, marker-pdf)
- **pdf-appearance-modifier**: Change font colors, remove highlights, and adjust visual styling in PDFs without altering content or layout (pikepdf stream surgery).
- **powerpoint**: Create, read, and edit .pptx decks and slides
- **public-api-tools**: Free public API tools from the public-apis project

> **Note:** Obsidian knowledge management has moved to the `note-taking` umbrella skill. See `note-taking/obsidian` for vault reading, searching, and note creation.

## Usage

Load individual skills from this category using:
```
skill_view(name="productivity/{sub_skill}")
```
