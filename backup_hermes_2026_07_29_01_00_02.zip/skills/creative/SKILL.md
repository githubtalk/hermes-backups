---
name: creative
description: Creative content generation — ASCII art, hand-drawn style diagrams, and visual design tools.
version: 1.0.0
metadata:
  hermes:
    tags: [creative]
    related_skills: ['songwriting-and-ai-music', 'ascii-art', 'popular-web-designs', 'excalidraw', 'manim-video', 'creative-ideation', 'p5js', 'ascii-video', 'pixel-art', 'architecture-diagram', 'baoyu-infographic', 'baoyu-article-illustrator', 'baoyu-comic', 'claude-design', 'comfyui', 'design-md', 'humanizer', 'pretext', 'sketch', 'touchdesigner-mcp']
---

# Creative

## Overview

Creative content generation — ASCII art, hand-drawn style diagrams, and visual design tools.

## Diagramming

Visual diagram creation — architecture diagrams, flowcharts, sequence diagrams, and illustrations. For Excalidraw hand-drawn JSON diagrams, see the `excalidraw` sub-skill. For dark-themed SVG architecture/cloud/infra diagrams as HTML, see `architecture-diagram`.

## Image Generation

AI image generation and video workflows. For Stable Diffusion, Flux, SDXL, and video models via ComfyUI, see `comfyui`.

## Article & Comic Illustration

For article illustrations and knowledge comics, see:
- `baoyu-article-illustrator`: Article illustrations with consistent type × style × palette
- `baoyu-comic`: Educational and biography knowledge comics

## Design

- `claude-design`: Design one-off HTML artifacts (landing, deck, prototype) via CLI/API agents
- `design-md`: Author/validate/export Google's DESIGN.md token spec files
- `humanizer`: Humanize text — strip AI-isms and add real voice
- `pretext`: Creative browser demos with @chenglou/pretext
- `sketch`: Throwaway HTML mockups — 2-3 design variants to compare
- `touchdesigner-mcp`: TouchDesigner integration via twozero MCP

## Sub-skills

- **architecture-diagram**: Dark-themed SVG architecture/cloud/infra diagrams as HTML
- **ascii-art**
- **ascii-video**
- **baoyu-article-illustrator**: Article illustrations with consistent type × style × palette
- **baoyu-comic**: Knowledge comics (educational, biography, tutorial)
- **baoyu-infographic**
- **claude-design**: Design one-off HTML artifacts (landing, deck, prototype)
- **comfyui**: ComfyUI image/video/audio generation and workflow automation
- **creative-ideation**
- **design-md**: Author/validate/export Google DESIGN.md token spec files
- **excalidraw**: Hand-drawn Excalidraw JSON diagrams (arch, flow, seq)
- **humanizer**: Humanize text — strip AI-isms and add real voice
- **manim-video**
- **p5js**
- **pixel-art**
- **popular-web-designs**
- **pretext**: Creative browser demos with @chenglou/pretext
- **sketch**: Throwaway HTML mockups — 2-3 design variants to compare
- **songwriting-and-ai-music**
- **touchdesigner-mcp**: TouchDesigner integration via twozero MCP

## Usage

Load individual skills from this category using:
```
skill_view(name="creative/{sub_skill}")
```
