# Cloudflare Workers + Tanstack Start SSR 调试

## 核心诊断流程

当网站 `curl` 返回 200 且 HTML 正确，但浏览器显示 "Something went wrong"：

### Step 1: 确认服务端正常
```bash
# 用 --compressed 避免 binary data 问题
curl -sL --compressed -H "Accept: text/html" "https://your-site.com/"
```
- 检查 HTML 中是否有 `<title>正确标题</title>`
- 检查 `matches` 数组里是否有正确的 loader data
- 如果有 → 服务器正常，问题在浏览器端 hydration
- 如果是 404 页面 → 服务端路由问题

### Step 2: 区分问题类型
- **服务器 404**：`curl` 返回 "The page you are looking for does not exist" → 路由配置问题
- **客户端错误**：`curl` HTML 正确但浏览器报错 → JavaScript hydration/rendering 问题

### Step 3: 浏览器端排查
1. **硬刷新**：Ctrl+Shift+R（不只是 Ctrl+R）
2. **隐私/无痕窗口**：排除浏览器缓存
3. **检查浏览器控制台**：F12 → Console → 看 JS 报错
4. **截图**：让用户截图错误页面

## 常见根因

### 1. 浏览器缓存了旧的 JS bundle
- 部署了新版本但浏览器加载旧版 JS
- **解决**：硬刷新或清除缓存

### 2. Hydration mismatch（SSR vs Client 不匹配）
- 服务端渲染的 HTML 和客户端期望的结构不一致
- Tanstack Start 中常见于 loader 数据结构变化后未重建

### 3. 依赖清理不完整
Fumadocs 移除时常见：
- `sitemap.ts` 残留 `import { source } from "#/lib/source"`
- `vite.config.ts` 残留 `mdx() from "fumadocs-mdx/vite"`
- `demo.tsx` 残留 `getDocsUrl` 调用

**排查**：在代码库中 grep 残留引用
```bash
grep -r "docs-i18n\|getDocsUrl\|source.*import" src/ --include="*.ts" --include="*.tsx"
```

### 4. 构建产物残留
- 删了源码但 dist/ 里还有旧 bundle
- **解决**：`rm -rf dist && pnpm build`

## 部署验证标准

所有关键路由必须返回 200：
```bash
for path in "/" "/blog" "/about" "/rss.xml" "/sitemap.xml"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "https://blog.atobt.com$path")
  echo "$path → $code"
done
```

## Tanstack Start + Cloudflare Workers 部署命令

```bash
cd apps/web
rm -rf dist
pnpm build  # 或 npx vp run web#build
wrangler deploy --config dist/server/wrangler.json
```

## 相关文件位置参考（my-blog 示例）

| 文件 | 用途 |
|------|------|
| `apps/web/vite.config.ts` | MDX 插件配置 |
| `apps/web/src/lib/source.ts` | Fumadocs source 配置（已删除） |
| `apps/web/src/lib/sitemap.ts` | sitemap 生成，移除 source 引用 |
| `apps/web/src/routes/demo.tsx` | Docs i18n 引用清理 |
| `apps/web/src/components/site-shell.tsx` | 导航栏 Docs 链接移除 |