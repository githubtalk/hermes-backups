# Cloudflare Workers + D1 + KV + R2 部署模式参考

## 快速部署流程

```bash
# 1. 克隆并安装依赖
git clone <repo> && cd <repo> && npm install

# 2. 创建 Cloudflare 资源（D1 + KV + R2）
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/<ACCOUNT_ID>/d1/database" \
  -H "Authorization: Bearer <API_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"name": "<db_name>"}'

curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/<ACCOUNT_ID>/r2/buckets" \
  -H "Authorization: Bearer <API_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"name": "<bucket_name>"}'

curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/<ACCOUNT_ID>/storage/kv/nv/namespaces" \
  -H "Authorization: Bearer <API_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"title": "<kv_name>"}'

# 3. 初始化数据库（schema.sql）
CLOUDFLARE_API_TOKEN="<token>" CLOUDFLARE_ACCOUNT_ID="<id>" \
npx wrangler d1 execute <db_name> --file=schema/schema.sql --remote

# 4. 更新 wrangler.toml（绑定 D1/KV/R2）
# 5. 部署
CLOUDFLARE_API_TOKEN="<token>" CLOUDFLARE_ACCOUNT_ID="<id>" npx wrangler deploy
```

## wrangler.toml 典型配置

```toml
name = "project-name"
main = "src/index.js"
compatibility_date = "2025-01-01"

[[d1_databases]]
binding = "DB"
database_name = "<db_name>"
database_id = "<uuid>"

[[kv_namespaces]]
binding = "STATIC_ASSETS"
id = "<kv_id>"

[[r2_buckets]]
binding = "ASSETS"
bucket_name = "<bucket_name>"
```

## D1 数据库操作

```bash
# 执行 SQL（远程）
npx wrangler d1 execute <db_name> --command "SELECT * FROM table" --remote

# 执行 SQL 文件
npx wrangler d1 execute <db_name> --file=schema/schema.sql --remote

# 导出数据
npx wrangler d1 export <db_name> --remote -o dump.sql
```

## KV 操作

```javascript
// 写入
await env.NAMESPACE.put('key', JSON.stringify(data));

// 读取
const data = JSON.parse(await env.NAMESPACE.get('key'));

// 删除
await env.NAMESPACE.delete('key');
```

## 常见权限问题

### 问题：API 返回 "Unauthorized. Super admin access required."
**原因**：用户角色不是 `super_admin`

**解决**：
```sql
-- 查看管理员角色
SELECT id, username, role FROM admins;

-- 升级为 super_admin
UPDATE admins SET role = 'super_admin' WHERE username = 'admin123';
```

### 问题：POST /api/xxx 返回 401 但登录成功
**原因**：JWT 中 role 字段值与 requireSuperAdmin 检查不一致

**解决**：检查 `admin.role !== 'super_admin'` 判断，确保数据库中 role 字段精确为 `'super_admin'`

## 通过 API 动态更新数据（绕过权限问题）

当管理后台 API 需要 super_admin 但数据库中用户是 `admin` 角色时：
1. 直接用 D1 SQL 更新：`UPDATE admins SET role = 'super_admin' WHERE username = 'xxx'`
2. 或者修改源码中角色检查逻辑

## 通过 API 批量写入数据

```javascript
// 登录获取 token
const loginRes = await fetch(`${API_BASE}/api/admin/login`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ username, password })
});
const token = await loginRes.json().data.token;

// 带 token 请求
await fetch(`${API_BASE}/api/settings`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify(settings)
});
```

## 产品图片 URL 处理

产品图片存放在外部源（如 shengtuo.cc.cd），通过完整 URL 引用：
```
https://shengtuo.cc.cd/assets/images/products/product-N-v1780048106.jpg
```

更新产品图片：
```sql
UPDATE products SET image_url = '<url>' WHERE name = '<product_name>';
```

## 验证部署状态

```bash
curl -sI "https://<worker>.<account>.workers.dev/" | head -3
curl -s "https://<worker>.<account>.workers.dev/api/products" | python3 -c "..."
```

## 典型错误处理

### D1 SQL CASE WHEN 批量更新
```sql
UPDATE products SET image_url = CASE name
  WHEN 'X' THEN 'url1'
  WHEN 'Y' THEN 'url2'
END
WHERE name IN ('X', 'Y')
```
- `CASE WHEN` 必须有 `END`
- `WHERE name IN (...)` 限制更新范围

### 删除重复数据
```sql
-- 保留 ID 1-29，删除 > 29 的重复项
DELETE FROM products WHERE id > 29;
```

## 环境变量（部署时需要）

| 变量 | 说明 |
|------|------|
| CLOUDFLARE_API_TOKEN | API Token（cfut_ 开头） |
| CLOUDFLARE_ACCOUNT_ID | Account ID（32位字母数字） |