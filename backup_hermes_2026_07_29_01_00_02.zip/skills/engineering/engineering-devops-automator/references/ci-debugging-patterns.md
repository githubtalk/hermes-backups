# CI Debugging Patterns

## Pattern: First Step Failure Skips Everything
**Symptom**: GitHub Actions workflow shows `failure`, and every subsequent job step is `skipped`.  
**Root cause pattern**: The failure happens in an early step, commonly `actions/checkout@v4`. When checkout fails, downstream steps are skipped automatically.  
**What to inspect first**:
- Job-level conclusion: `failure`
- Steps array: the first failed step is usually checkout
- HTML logs may appear empty if the failure is pre-run auth-related

## Pattern: actions/checkout Failure with secrets
**Symptom**: `Run actions/checkout@v4` fails immediately.  
**Common causes**:
- Secret referenced in workflow is missing or revoked
- Secret is not visible to the workflow run context
- Token lacks repo read permissions

**Verification**:
```bash
# List jobs
gh run view <run_id> --repo <owner>/<repo> --json jobs --jq '.jobs[]'

# List steps with failures highlighted
gh run view <run_id> --repo <owner>/<repo> --json jobs --jq \
  '.jobs[].steps[] | select(.conclusion=="failure") | {name, conclusion}'
```

**Fix order**:
1. Verify secret exists under repo Settings → Secrets
2. Verify token has not expired
3. Verify workflow has read access to the secret
4. Verify the branch reference in `ref:` is accessible with the token

## Pattern: Empty Log Output from `gh run view --log-failed`
**Observation**: `gh run view <run_id> --log-failed` may return empty output when the failure occurs before step scripts execute.  
**Fallback**: Read the jobs API directly.
```bash
curl -sL -o /tmp/ci_run.json \
  "https://api.github.com/repos/<owner>/<repo>/actions/runs/<run_id>/jobs"
python3 -c "import json; d=json.load(open('/tmp/ci_run.json')); print(json.dumps(d, indent=2))"
```
