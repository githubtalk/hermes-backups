# 远程服务器连接参考

## domcloud.co 平台限制

domcloud.co 是一个托管 VPS 平台，有以下关键限制：

### sudo 限制
```
Sorry! You can't have root access!
Read more: https://domcloud.co/docs/intro/security#no-sudo

imclaw is not in the sudoers file.
This incident will be reported.
```

**影响**：
- 用户不在 sudoers 文件中，无法执行 `sudo systemctl`
- 无法安装软件包
- 无法启动 Docker 等系统服务
- 无法修改系统级配置

**验证方法**：
```python
# 检查用户权限
stdin, stdout, stderr = client.exec_command("id", timeout=10)
stdin, stdout, stderr = client.exec_command("groups", timeout=10)
stdin, stdout, stderr = client.exec_command("sudo -l 2>/dev/null", timeout=10)
```

### 适用场景
domcloud.co 适合：
- 托管静态网站
- 轻量级 Web 应用（PHP、Node.js）
- 数据库服务（已有 MariaDB、PostgreSQL）
- **不适合**：需要 Docker 或 root 权限的应用

## SSH 连接技术

### paramiko 连接模式

**基本连接**：
```python
import paramiko

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(
    hostname='host',
    username='user',
    password='password',
    timeout=20,
    banner_timeout=20
)

# 执行命令
stdin, stdout, stderr = client.exec_command("command", timeout=15)
print(stdout.read().decode('utf-8', errors='ignore'))
```

**交互式 Shell（用于 sudo 命令）**：
```python
import paramiko
import time

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(hostname='host', username='user', password='password', timeout=20)

shell = client.invoke_shell()
time.sleep(1)

# 发送 sudo 命令
shell.send('sudo systemctl enable --now docker\n')
time.sleep(1)
shell.send('password\n')
time.sleep(3)

output = shell.recv(65535).decode('utf-8', errors='ignore')
print(output)

shell.close()
client.close()
```

### 连接问题排查

**超时处理**：
- 首次连接可能不稳定，多次重试
- 使用 `banner_timeout` 和 `timeout` 分开设置
- 保持连接：`transport.set_keepalive(10)`

**错误处理**：
```python
try:
    client.connect(hostname='host', username='user', password='pass', timeout=20)
except EOFError:
    # 重试连接
    time.sleep(2)
    client.connect(hostname='host', username='user', password='pass', timeout=20)
except TimeoutError:
    # 检查网络
    pass
```

## 服务器诊断命令

### 系统状态
```bash
uptime                                    # 运行时间 + 负载
free -h                                   # 内存使用
df -h                                     # 磁盘使用
top -bn1 | head -15                       # CPU/进程
ps aux --sort=-%cpu | head -15            # Top CPU 进程
```

### 服务状态
```bash
systemctl list-units --type=service --state=running  # 运行中的服务
docker ps 2>/dev/null || echo 'Docker not running'  # Docker 状态
ss -tuln | head -15                         # 网络监听端口
```

### 服务管理命令（需要 sudo）
```bash
# 启用并启动服务
sudo systemctl enable --now <service>

# 查看服务状态
sudo systemctl status <service>

# 重启服务
sudo systemctl restart <service>
```

## 已知平台限制

| 平台 | sudo | Docker | 备注 |
|------|------|--------|------|
| domcloud.co | ❌ | ❌ | 托管平台，限制 root |
| 标准 VPS | ✅ | ✅ | 需手动安装 Docker |
| GCP 实例 | ✅ | ✅ | 通过 GCP Console 配置 |