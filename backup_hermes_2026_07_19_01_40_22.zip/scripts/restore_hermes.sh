#!/usr/bin/env bash
# =============================================================================
# Hermes Agent Restore - 备份恢复脚本
# =============================================================================
# 用法: bash ~/.hermes/scripts/restore_hermes.sh [日期]
#   日期可选，默认恢复最新版本
# =============================================================================

set -euo pipefail

AGENT_NAME="hermes"
BACKUP_LOCAL="$HOME/hermes_backups"
REMOTE_REPO="git@github.com:clowlove/hermes-backups.git"
RESTORE_TEMP="$HOME/restore_temp"
LATEST_LINK="$BACKUP_LOCAL/backup_${AGENT_NAME}_latest.zip"

echo "═══════════════════════════════════════════════"
echo "Hermes 备份恢复"
echo "═══════════════════════════════════════════════"

# 停止 Hermes（重要！）
echo "⚠️  准备恢复，请确保 Hermes 已停止"
echo "如果有正在运行的 Hermes 进程，请先停止："
echo "  pkill -f hermes 或 systemctl stop hermes"
echo ""
read -p "按 Enter 继续..." -t 10

# 同步远程仓库
echo "1. 同步备份仓库..."
mkdir -p "$BACKUP_LOCAL"
cd "$BACKUP_LOCAL"

if [ ! -d ".git" ]; then
    git clone "$REMOTE_REPO" "$BACKUP_LOCAL"
else
    git pull origin main
fi

# 选择要恢复的备份
if [ -n "${1:-}" ]; then
    TARGET="$BACKUP_LOCAL/backup_${AGENT_NAME}_${1}"*.zip
else
    TARGET="$LATEST_LINK"
fi

if [ ! -f "$TARGET" ]; then
    echo "❌ 找不到备份文件: $TARGET"
    echo ""
    echo "可用备份："
    ls -lh "$BACKUP_LOCAL"/backup_${AGENT_NAME}_*.zip 2>/dev/null || echo "  无备份文件"
    exit 1
fi

echo "2. 使用备份: $(basename $TARGET)"

# 解压到临时目录
echo "3. 解压备份..."
rm -rf "$RESTORE_TEMP"
unzip "$TARGET" -d "$RESTORE_TEMP"

# 列出备份内容
echo "4. 备份内容："
find "$RESTORE_TEMP/.hermes" -maxdepth 1 -type f -o -type d | grep -v "^$RESTORE_TEMP/.hermes$" | head -10

# 恢复到 Hermes 目录
echo "5. 恢复到 ~/.hermes/ ..."
if [ -d "$RESTORE_TEMP/.hermes" ]; then
    # 先备份当前状态
    if [ -d "$HOME/.hermes" ]; then
        BACKUP_OLD="$HOME/.hermes_backup_$(date +%Y%m%d_%H%M%S)"
        echo "   备份当前配置到: $BACKUP_OLD"
        mv "$HOME/.hermes" "$BACKUP_OLD"
    fi
    
    mv "$RESTORE_TEMP/.hermes" "$HOME/.hermes"
    echo "✅ 恢复完成！"
else
    echo "❌ 恢复失败：备份格式不正确"
    exit 1
fi

# 清理
rm -rf "$RESTORE_TEMP"

echo ""
echo "═══════════════════════════════════════════════"
echo "✅ 恢复完成！"
echo ""
echo "请重启 Hermes："
echo "  hermes gateway run &"
echo "═══════════════════════════════════════════════"
