---
name: social-media-daily
description: Multi-source content monitoring and automated daily report generation and Telegram push — covers GitHub AI agent trends and RSS feeds.
version: 1.0.0
metadata:
  hermes:
    tags: [social-media, monitoring, telegram, automation, daily-report]
    related_skills: [feeds, github]
---

# Social Media Daily — Automated Monitoring & Telegram Reports

## Overview

Automated daily report generation and Telegram push from multiple content sources: GitHub trending, and RSS feeds. The shared pattern is:

1. **Pull** data from a source on a schedule
2. **Curate & categorize** content (often 5-category × 10-item format)
3. **Format** for the target channel (Telegram, Discord, etc.)
4. **Push** via the messaging platform's API

## Sub-skills / Labeled Sections

### GitHub AI Agent Trend Daily

Automated GitHub AI agent trend scanning with Xiaohongshu-style daily report generation. See `references/github-trend-daily-workflow.md` under the `github` skill.

### Autonomous Learning — Evolution Log

Scheduled GitHub discovery + evolution log update workflow. See `references/autonomous-learning-workflow.md`.

### RSS Feed Monitoring

RSS-based content monitoring with scheduled aggregation. See `references/rss-monitoring.md`.

## Common Report Format

**5分类×10条** format (common across GitHub daily reports):

```
📊 财经·科技（第1条/共5条）| YYYY-MM-DD

1️⃣ 新闻标题1
2️⃣ 新闻标题2
...
🔟 新闻标题10

━━━━━━━━━━━━━━━
🏛 政治·社会（第2条/共5条）

━━━━━━━━━━━━━━━
[... 5 categories total ...]

━━━━━━━━━━━━━━━
📈 今日汇总（YYYY-MM-DD）
• 🆕 本次爬取：N条（M平台）
• 📰 已推送：50条（分5类）
• ⏰ 爬取时间：HH:MM
```

### RSS Feed Monitoring

RSS-based content monitoring and aggregation. See `references/rss-monitoring.md` for MCP tools and cron setup.

## Cron Schedule Examples

```bash
# 每天 09:00（GitHub Profile README update）
0 9 * * *
```

## Telegram Push Guidelines

- Split messages if > 4096 characters
- Use `send_message` tool with `MEDIA:<path>` for images
- For Telegram topics/threads: `target="telegram:CHAT_ID:THREAD_ID"`
- Rate limit: ~1 message per second for bulk sends

## Automation with Hermes Cron

```python
cronjob(
    action="create",
    name="Daily Social Media Report",
    prompt="""执行 RSS/社交媒体每日热点推送任务：
1) 触发数据源更新
2) 生成日报
3) 按5分类×10条推送到 Telegram""",
    schedule="0 9 * * *",
    skills=["social-media-daily"],
)
```
