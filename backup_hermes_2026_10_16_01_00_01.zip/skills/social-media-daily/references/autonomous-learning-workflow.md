# Autonomous Learning — Evolution Log 更新工作流

> `~/.hermes/scripts/autonomous_learning.py` — 定时探索 GitHub 社区，发现有价值的 AI Agent 项目并记录到 evolution log

## 脚本设计

```
1. 搜索 GitHub（3 个查询，TOP 5 结果/查询，过滤 >100⭐）
2. 去重（按 full_name）
3. 更新 evolution log（追加到 /tmp/hermes-house-sync/docs/evolution/log-2026-05.md）
4. 内嵌 CI 状态检查（GitHub Actions API via urllib，不依赖 curl）
```

## 输出文件

| 文件 | 位置 |
|------|------|
| Evolution log | `/tmp/hermes-house-sync/docs/evolution/log-2026-05.md` |
| 日志目录 | `~/.hermes/logs/evolution/evolution-YYYY-MM-DD.md` |
| 根目录汇总 | `~/.hermes/evolution_log.md` |

## CI 状态检查

脚本内嵌了 GitHub Actions API 调用（通过 `urllib.request`，非 curl），因此：
- ✅ 脚本自己报告 CI 状态
- ❌ 单独的 `curl | python3` 命令会被安全扫描拦截

如果需要单独检查 CI 状态，使用 Python urllib 或 gh CLI：
```bash
gh run list --repo clowlove/Harmes-House --limit 1 --json name,conclusion,status --jq '.[0] | "\(.conclusion // .status) | \(.name)"'
```

## 更新 Evolution Log 的逻辑

脚本在 `log-2026-05.md` 中查找 `*日志自动生成，最后更新:` 标记，将新发现插入到该标记之前。

**关键代码片段**（来自 `update_evolution_log()`）：
```python
content = open(log_path).read()
content = content.replace(
    "\n---\n\n*日志自动生成，最后更新:",
    f"\n{entry}\n---\n\n*日志自动生成，最后更新:"
)
open(log_path, "w").write(content)
```

这意味着 log 文件必须包含 `\n---\n\n*日志自动生成，最后更新:` 字符串，否则脚本会静默失败（只打印 "Log file not found"）。

## 运行

```bash
python3 ~/.hermes/scripts/autonomous_learning.py
```

典型输出：
```
[22:36] Starting autonomous learning...
Found 8 interesting projects
Updated evolution log with 8 findings
[22:36] Learning complete
CI Status: success | Validate Skills
```