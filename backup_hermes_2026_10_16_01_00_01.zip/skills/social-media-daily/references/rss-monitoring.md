# RSS Feed Monitoring

> Skills for monitoring, aggregating, and processing RSS feeds, blogs, and web content sources.

## MCP Tools

- `rss_get_latest` — 获取最新 RSS 订阅数据（支持多日查询）
- `rss_search` — 搜索 RSS 数据
- `rss_get_feeds_status` — 查看 RSS 源状态信息
- `rss_aggregate_news` — 跨平台新闻聚合去重合并

## 获取 RSS 数据

```python
# 获取最近 N 天的 RSS 数据
rss_get_latest(days=7, feeds=['hacker-news', '36kr'], limit=50)

# 搜索包含关键词的 RSS 条目
rss_search(keyword='AI', feeds=['hacker-news'], days=14)

# 查看所有 RSS 源状态
rss_get_feeds_status()
```

## RSS 源

常用 RSS 源包括：
- `hacker-news` — Hacker News
- `36kr` — 36氪
- 自定义 RSS URL

## 自动化定时任务

```bash
# 每6小时抓取一次 RSS
0 */6 * * *
```

## Related

- `social-media-daily` — 父级 umbrella，包含每日报告生成和 Telegram 推送
