---
name: .hub
description: Internal skill hub metadata directory. Holds indexing and audit artifacts, not a standalone skill.
---

# Skill hub

This directory stores hub metadata, caches, lockfiles, and quarantine data used by the local skill system.
