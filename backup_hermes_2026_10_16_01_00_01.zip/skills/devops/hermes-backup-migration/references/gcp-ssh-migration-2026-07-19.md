# GCP 双机迁移记录 — 2026-07-19

## 机器信息
- 旧机器：43.155.135.188 (aws54)
- 新机器：35.212.209.223 (GCP instance-20260718-115004, Debian 13, root)
- GitHub PAT: `githubtalk` 账号
- 新仓库: `githubtalk/hermes-backups` (公开)

## 问题与解决
1. **SSH 被 GCP 防火墙拦** — 用户操作开防火墙后无效，实际是 Fail2Ban 已封旧机器 IP (43.155.135.188)
2. **解封后仍连不上** — 外部端口扫描全关，GCP 防火墙未真正开放
3. **用户浏览器 SSH 可用** — 改用浏览器终端完成迁移
4. **git clone 失败** — `clowlove/hermes-backups` 不存在，PAT 属于 `githubtalk` 账号
5. **创建仓库后 clone 成功** — 用 HTTPS + PAT 方式

## 命令记录
```bash
# 新机器解封 IP
fail2ban-client set sshd unbanip 43.155.135.188
systemctl stop fail2ban
systemctl disable fail2ban

# 创建仓库
curl -s -H "Authorization: token ***" https://api.github.com/user/repos \
  -d '{"name":"hermes-backups","private":false}'

# 克隆（浅克隆）
git clone --depth 3 --branch main https://***@github.com/githubtalk/hermes-backups.git ~/hermes_backups
```

## 数据
- 新机器首次备份: 2.3MB (仅 .env + scripts，config.yaml 等被 zip 排除)
- 备份脚本 REMOTE_REPO 已改为 HTTPS 方式
