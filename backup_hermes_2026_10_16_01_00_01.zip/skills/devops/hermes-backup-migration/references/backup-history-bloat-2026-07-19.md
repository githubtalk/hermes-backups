# Session Reference: Backup History Bloat & Migration

## Observed state (2026-07-19)

| Metric | Value |
|---|---|
| Backup repo path | `~/hermes_backups` |
| Zip file count | 9 files (2026-07-11 to 2026-07-19) |
| Individual zip size | 190–204MB each |
| Total zip size | ~406MB |
| `.git` directory size | ~8.3GB |
| Total repo size | ~8.7GB |
| Migration package size | 3.2KB (scripts + cron + README) |

## Shallow clone command for migration

```bash
git clone --depth 3 --branch main git@github.com:clowlove/hermes-backups.git ~/hermes_backups
```

Adjust `--depth` to desired retention. This avoids downloading the full ~10GB history.

## GCP firewall pitfall

When migrating to a new GCP instance, `ssh` may return `Permission denied (publickey,password)` even with correct credentials. This is caused by the GCP firewall blocking port 22, not bad credentials.

**Diagnosis sequence:**
1. `ping <ip>` — confirms host is online
2. Port scan on 22, 2222, 80, 443 — identifies which ports are open
3. SSH attempt — only after confirming port 22 is open

**Fix:** GCP Console → VPC network → Firewall → Create rule allowing `tcp:22` from your IP.

## git gc timeout pitfall

`git gc --prune=now --aggressive` and `git repack` timed out repeatedly (60s, 180s, 300s) on this repo. Do not use interactive gc for large backup repos. Use shallow clone or accept existing history size instead.

## Retention change recommendation

In `backup_hermes.sh`:
```bash
RETENTION_DAYS=3  # was 7
```

This keeps future `.git` growth bounded.

## Remote repo conflict note

If multiple machines push to the same `hermes-backups` remote, they may overwrite each other's commits. Prefer separate remotes per machine, or coordinate pushes.
