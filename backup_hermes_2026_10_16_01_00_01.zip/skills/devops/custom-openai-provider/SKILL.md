---
name: custom-openai-provider
description: Configure any OpenAI-compatible API as a Hermes model provider — NVIDIA NIM, Together AI, Fireworks, Groq, local vLLM/Ollama, or any custom endpoint. Covers the critical provider-clearing pitfall.
version: 1.0.0
metadata:
  hermes:
    tags: [models, providers, nvidia-nim, custom-endpoint, openai-compatible]
---

# Custom OpenAI-Compatible Provider Setup

Configure Hermes to use any OpenAI-compatible API endpoint as its model provider.

## When to Use

- NVIDIA NIM (https://integrate.api.nvidia.com/v1)
- Together AI, Fireworks AI, Groq
- Local vLLM, Ollama, LM Studio
- Any self-hosted OpenAI-compatible server

## Key Steps

### 1. Add API Key

Use `hermes config env-path` to find the .env location. Add your key there (use terminal + sed for the protected file).

### 2. Configure Model Settings

```bash
hermes config set model.default "provider/model-name"
hermes config set model.base_url "https://api.example.com/v1"
hermes config set model.api_key "env:YOUR_ENV_VAR_NAME"
```

### 3. CRITICAL: Clear Provider

**PITFALL**: If `model.provider` is set to a previous provider (e.g., "xiaomi", "openrouter"), Hermes routes requests incorrectly. MUST clear it:

```bash
hermes config set model.provider ""
```

This is the #1 mistake when switching from a named provider to a custom endpoint.

### 4. Restart

Exit CLI and restart hermes. For gateway: `hermes gateway restart`.

## Switching Between Named Providers (e.g., → mimo)

When the target provider is already defined in `config.yaml` under `providers`, **do NOT set `model.base_url` or `model.api_key`** — clear them so Hermes inherits from the provider block. Set `model.provider` to the provider name:

```yaml
model:
  api_mode: chat_completions
  provider: mimo       # provider name from config.yaml providers section
  api_key: ''          # MUST be empty — inherits from providers.mimo.api_key
  base_url: ''         # MUST be empty — inherits from providers.mimo.base_url
  default: mimo-v2.5-pro
```

Then update fallback:
```yaml
fallback_providers:
- mimo
- xiaomi_mimo
- openrouter
```

**Pitfall**: Some API keys need a provider-specific prefix (e.g., mimo uses `tp-`). Test with curl first:
```bash
curl -s -X POST "https://token-plan-sgp.xiaomimimo.com/v1/chat/completions" \
  -H "Authorization: Bearer tp-YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"mimo-v2.5-pro","messages":[{"role":"user","content":"Hi"}],"max_tokens":10}'
```
If 401 "Invalid API Key" — try adding the provider's required prefix.

**Mimo Provider Details:**
| Item | Value |
|------|-------|
| Base URL | `https://api.xiaomimimo.com/v1` |
| API Key Format | `tp-` prefix required (e.g., `tp-sbcomkklr...`) |
| Models | `mimo-v2.5-pro`, `mimo-v2.5`, `mimo-v2-pro`, `mimo-v2-omni`, `mimo-v2-flash`, `mimo-v2.5-pro-ultraspeed` |
| Config in | `providers.mimo` in config.yaml |

## MiMo Endpoint Verifier

Use this when a 401 occurs after confirming the key has the required prefix.

Repeat verification across both documented base URLs. If both return `401 Invalid API Key`, stop retrying — the key is invalid or not yet approved. The correct active endpoint for new keys is `https://api.xiaomimimo.com/v1`; legacy endpoints may not accept new keys.

Example probe:
```bash
curl -s -o /tmp/mimo_call.json -w "%{http_code}" \
  -X POST "https://api.xiaomimimo.com/v1/chat/completions" \
  -H "Authorization: Bearer tp-YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"mimo-v2.5-pro-ultraspeed","messages":[{"role":"user","content":"ping"}]}'
```

## NVIDIA NIM

- Base URL: `https://integrate.api.nvidia.com/v1`
- Get key: https://build.nvidia.com
- Models: `deepseek-ai/deepseek-v4-pro`, `meta/llama-3.1-405b-instruct`, etc.

### List Available Models
```bash
curl -s https://integrate.api.nvidia.com/v1/models \
  -H "Authorization: Bearer nvapi-YOUR_KEY" | jq -r '.data[].id'
```

### Test Model Availability
```bash
curl -s https://integrate.api.nvidia.com/v1/chat/completions \
  -H "Authorization: Bearer nvapi-YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model": "MODEL_NAME", "messages": [{"role": "user", "content": "Hi"}], "max_tokens": 5}'
```

### Diagnose 403 Errors
If `/v1/models` works (returns model list) but `/v1/chat/completions` returns 403:
1. **Check account credits** - https://build.nvidia.com → Billing/Credits
2. **Free tier exhausted** - New accounts have limited free credits
3. **Key permissions** - May need to regenerate key with inference permissions
4. **Model not enabled** - Some models require manual activation in console

### Test Multiple Models
When unsure which models are available/working, batch test:
```bash
for model in model1 model2 model3; do
  echo -n "$model: "
  curl -s "https://integrate.api.nvidia.com/v1/chat/completions" \
    -H "Authorization: Bearer nvapi-YOUR_KEY" \
    -H "Content-Type: application/json" \
    -d "{\"model\": \"$model\", \"messages\": [{\"role\": \"user\", \"content\": \"Hi\"}], \"max_tokens\": 10}" \
    | grep -q '"choices"' && echo "✅" || echo "❌"
done
```

### Reasoning Models
Some models (e.g., `minimaxai/minimax-m2.7`, `minimaxai/minimax-m3`) return `reasoning_content` field instead of `content` when `max_tokens` is too low. Use `max_tokens: 100+` to get actual responses. Note: responses may include `"reasoning_content": null` even when not using reasoning — this is harmless noise from the endpoint, not an error condition.

### NVIDIA NIM Multi-Provider Config
If multiple NVIDIA keys exist (`custom_nvidia`, `custom_nvidia-1`, `custom_nvidia-2`), changing to a new model requires updating **all** of them under `providers.*.models`, `model`, `model_display_name`, and `available_models_json`. Otherwise stale model lists still expose the old model names.

### NVIDIA NIM Header Routing Quirk
For `https://integrate.api.nvidia.com/v1/chat/completions`, if a request returns:
```
Missing request extension: Extension of type `headers::common::authorization::Authorization<headers::common::authorization::Bearer>` was not found
```
This is a gateway-level 500, not an auth failure. Retry with **non-empty prompt content** — empty-string `messages[].content` appears to trigger the faulty handler. A valid request body should have substantive `content` in each user message (even `"Hi"`).

### MiniMax M3
- Model ID: `minimaxai/minimax-m3`
- Multimodal capable (image/video via `content` list of parts)
- Tested working Jun 2026 with: `temperature=1, top_p=0.95, max_completion_tokens=8192`
- Expected response shape: `choices[].message.content` for normal output; `reasoning_content` may be `null`

### Switching From a Named Provider (updated pitfall)
When switching **from** a named provider such as `nous` to a nested provider like `custom_nvidia`:
1. Set `model.provider` to the provider name (e.g., `custom_nvidia`).
2. Set `model.default` to the new model ID.
3. Set `model.base_url` to the endpoint base (e.g., `https://integrate.api.nvidia.com/v1`).
4. Ensure `model.api_key` is empty so Hermes inherits from `providers.<name>.api_key`.
5. Update all matching `providers.*` blocks for the new model, not just one.
6. Restart the CLI.

## MiMo Free-AI Flow (verified Jun 2026)

The free-ai path does **not** use the `tp-` token-plan keys. Actual working flow:

1. Bootstrap: `POST https://api.xiaomimimo.com/api/free-ai/bootstrap` with `{"client":"<name>"}`
   - Returns `{"jwt":"..."}` in `exp` short TTL.
2. Chat: `POST https://api.xiaomimimo.com/api/free-ai/openai/chat`
   - Headers: `Authorization: Bearer <jwt>` + `X-Mimo-Source: mimocode-cli-free`
   - Body: standard OpenAI `model`, `messages`, etc.
3. Response is OpenAI `chat.completion` with optional `reasoning_content`.

Confirm by using the factory `xiaomi-mimo` skill (role: encoder/verifier for the free-ai API), available via the new `custom-openai-provider` factory method.

### Do not do this
- Do not pass `tp-` token-plan keys to `/api/free-ai/openai/chat` (returns 401).
- Do not hardcode the bootstrap JWT/TTL.

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Requests go to wrong provider | `hermes config set model.provider ""` |
| 401 Unauthorized (token-plan key) | The free-ai endpoint requires JWT via bootstrap; `tp-` keys do not work here. Use the `xiaomi-mipo` skill factory workflow or switch to the token-plan endpoint at `token-plan-sgp.xiaomimimo.com/v1/chat/completions` if you hold an approved `tp-` key. |
| 401 Unauthorized | Verify key with curl test |
| 403 Forbidden (can list models) | Account has no credits or free tier exhausted |
| 403 Forbidden (cannot list models) | Invalid key or key format wrong |
| Model not found | List models via /v1/models endpoint |
| Changes not生效 | Restart CLI session |
| Nous OAuth key stored as `eyJhbG...ny2w` | Truncation happens when token is written from truncated terminal output. Re-authenticate, capture the full JWT from the JSON response, and save it directly to `auth.json` / `config.yaml`. Validate with a curl request using the full token. |
