# Cloudflare Workers Blog Deployment (blog.atobt.com)

## Stack Overview

- **Framework**: 01MVP/blog-starter (TanStack Start + Cloudflare Workers)
- **Backend**: D1 (SQLite) + KV (cache) + R2 (assets)
- **Auth**: better-auth (cookie-based sessions)
- **Repo**: githubtalk/my-blog

## Resource Creation (one-time)

```bash
# D1 database
wrangler d1 create my-blog-cms
# → ID: b34004e3-27fc-431a-a094-de4bfa3a01b3

# KV namespace
wrangler kv:namespace create CMS_CACHE
# → ID: 57ca77d9ed72462a98f6f62f0f4e4718

# R2 bucket
wrangler r2 bucket create my-blog-assets
```

## wrangler.jsonc Bindings

```jsonc
{
  "kv_namespaces": [{ "binding": "CMS_CACHE", "id": "57ca77d9..." }],
  "r2_buckets": [{ "binding": "CMS_STORAGE", "bucket_name": "my-blog-assets" }],
  "d1_databases": [{
    "binding": "CMS_DB",
    "database_name": "my-blog-cms",
    "database_id": "b34004e3-...",
    "migrations_dir": "../../packages/db/migrations"
  }]
}
```

## Critical Secret Management

**The BETTER_AUTH_SECRET Problem**

Local `.dev.vars` file is NOT uploaded to Cloudflare automatically. Without `BETTER_AUTH_SECRET`, the Worker returns HTTP 500 on ALL routes because better-auth initialization fails silently.

**Fix — use wrangler secret put:**
```bash
wrangler secret put BETTER_AUTH_SECRET --config apps/web/dist/server/wrangler.json
# Enter secret value at prompt (or pipe it)
echo "your-secret-value" | wrangler secret put BETTER_AUTH_SECRET --config apps/web/dist/server/wrangler.json
```

This uploads the secret to Cloudflare Workers environment variables — it does NOT write to wrangler.jsonc.

**Rule**: Any env var that is a secret (API keys, auth tokens, database connection strings with passwords) must be uploaded via `wrangler secret put`. Only non-sensitive tunables (URLs, feature flags, email addresses) belong in wrangler.jsonc `vars`.

## Deployment Sequence

```bash
# 1. Install deps
pnpm install

# 2. Run local migrations (optional — remote migrations via step 4)
pnpm db:migrate

# 3. Build
pnpm build:web

# 4. Deploy (uses generated dist/server/wrangler.json)
CLOUDFLARE_API_TOKEN="cfut_..." \
CLOUDFLARE_ACCOUNT_ID="a0e4e66e..." \
wrangler deploy --config apps/web/dist/server/wrangler.json
```

**Important**: Do NOT use the source wrangler.jsonc path for deploy — use the generated `dist/server/wrangler.json` which has resolved the bindings.

## Custom Domain Setup

1. Add domain to Cloudflare (already configured by user at blog.atobt.com)
2. Add route in Cloudflare Dashboard → Workers → my-blog → Triggers → Custom Domains
3. Update wrangler.jsonc `vars`:
   ```jsonc
   "VITE_BASE_URL": "https://blog.atobt.com",
   "CMS_PUBLIC_SITE_URL": "https://blog.atobt.com",
   ```
4. Rebuild and redeploy
5. Verify with curl

## Database Operations (Remote)

```bash
# Execute SQL on remote D1
cd apps/web
wrangler d1 execute my-blog-cms --remote --config dist/server/wrangler.json \
  --command "SQL_QUERY"

# Example: upgrade user to admin
wrangler d1 execute my-blog-cms --remote --config dist/server/wrangler.json \
  --command "UPDATE user SET role = 'admin' WHERE email = 'imtalk@proton.me'"
```

**Table names** from the blog-starter schema: `account`, `user` (for auth users), `posts`, `tags`, `site_settings`, `session`, `verification` — not `users`.

## Removing a Route (e.g. /docs)

This blog-starter uses a content-based doc system. Two locations must be cleaned:

1. **Route files** — delete from `apps/web/src/routes/`:
   ```
   apps/web/src/routes/docs/$.tsx
   apps/web/src/routes/docs/$.lazy.tsx
   apps/web/src/routes/zh/docs/$.tsx
   apps/web/src/routes/zh/docs/$.lazy.tsx
   ```
2. **Content source files** — delete from `apps/web/content/docs/`:
   ```
   apps/web/content/docs/*.md
   apps/web/content/docs/meta.json
   ```
3. **Navigation links** — edit `apps/web/src/components/site-shell.tsx` to remove nav items referencing `/docs`
4. **Sitemap** — edit `apps/web/src/lib/sitemap.ts` to remove `/docs` from pagePaths
5. Rebuild and redeploy

## Admin Account Setup

```bash
# 1. Sign up via API (from a browser or with Origin header)
curl -X POST "https://blog.atobt.com/api/account/signup" \
  -H "Content-Type: application/json" \
  -H "Origin: https://blog.atobt.com" \
  -d '{"email":"imtalk@proton.me","name":"githubtalk","password":"B1gStr0ng!"}'

# 2. Upgrade to admin via D1
wrangler d1 execute my-blog-cms --remote --config dist/server/wrangler.json \
  --command "UPDATE user SET role = 'admin' WHERE email = 'imtalk@proton.me'"
```

## Verification Commands

```bash
curl -s -o /dev/null -w "%{http_code}" "https://blog.atobt.com/"      # 200
curl -s -o /dev/null -w "%{http_code}" "https://blog.atobt.com/rss.xml"  # 200
curl -s -o /dev/null -w "%{http_code}" "https://blog.atobt.com/sitemap.xml" # 200
curl -s -o /dev/null -w "%{http_code}" "https://blog.atobt.com/docs"   # 404 (after removal)
curl -s -o /dev/null -w "%{http_code}" "https://blog.atobt.com/zh/docs" # 404 (after removal)
```

## Error Patterns

| Error | Cause | Fix |
|-------|-------|-----|
| HTTP 500 on all routes | BETTER_AUTH_SECRET missing in Cloudflare | `wrangler secret put BETTER_AUTH_SECRET` |
| Deploy fails "No such KV namespace" | Wrangler JSON path issue | Use `dist/server/wrangler.json` not source wrangler.jsonc |
| CORS error on signup | Origin header needed for server-side API calls | Add `-H "Origin: https://blog.atobt.com"` |
| "Something went wrong!" on client | Undefined function imported from deleted module | Use `browser_console expression "document.body.innerText"` or `window.__ERROR_STACK__` to find the actual error. curl returning 200 does NOT mean client-side JS is fine. |
| HTTP 200 but blank/error page | Client-side JS runtime error despite server working | Diagnose via browser console, not curl — server HTML being 200 means nothing about client hydration |
| Docs still 200 after deletion | Only deleted route files, forgot `content/docs/` markdown source | Also delete `apps/web/content/docs/` |
| nav has empty item after removal | Trailing comma left after deleting array element | Clean up array syntax after removal |
| RSS feed disabled | `rssEnabled: false` in site settings D1 | Update D1: `UPDATE site_settings SET rss_enabled = 1` |

## GitHub Deployment (CI)

After local changes:
```bash
git add -A && git commit -m "message" && git push origin main
```
Worker deployment is manual via wrangler (no GitHub Actions configured yet for this repo).