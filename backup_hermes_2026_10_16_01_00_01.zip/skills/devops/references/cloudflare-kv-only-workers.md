# Card-Tab 类纯 KV Workers 项目部署

适用于只有 KV 存储、无 D1/R2 的 Workers 项目（如书签管理、简单键值存储类工具）。

---

## 部署流程

**1. 克隆并分析项目结构**
```bash
git clone <repo>
mkdir -p /tmp/cf-<project> && cp -r <repo>/* /tmp/cf-<project>/
cd /tmp/cf-<project>
```

**2. 创建并配置 wrangler.toml**
```toml
name = "<worker-name>"
main = "src/index.js"          # 或 workers.js/index.js
compatibility_date = "2024-01-01"

[[kv_namespaces]]
id = "<namespace-id>"
binding = "CARD_ORDER"         # 与代码中 env.XXX 一致

[vars]
ADMIN_PASSWORD = "<password>"  # 视项目而定

routes = [
  { pattern = "sub.domain.com", zone_name = "domain.com", custom_domain = true }
]
preview_urls = false
```

**3. 部署**
```bash
CLOUDFLARE_API_TOKEN="<token>" \
CLOUDFLARE_ACCOUNT_ID="<account_id>" \
npx wrangler deploy --name <worker-name>
```

---

## 关键调试：ES 模块格式问题

**症状：** API 上传时报 `Unexpected token 'export'` 或 `Unexpected token ','`

**原因：** 项目使用 `export default { fetch, ... }` 导出，但 Cloudflare Workers 在 `has_modules:true` 模式下要求正确的模块格式。`wrangler deploy` 会自动处理，但 REST API 直接上传不会。

**解决：** 使用 `wrangler deploy` 而非 REST API 上传。wrangler 会自动转换 `export default` 格式。

---

## 查找 Worker 真实名称

如果部署后 `tab.xiaoai.tech` 能访问但不知道 Worker 真实名称：
```bash
curl -s "https://api.cloudflare.com/client/v4/accounts/<ACCOUNT_ID>/workers/scripts" \
  -H "Authorization: Bearer <API_TOKEN>"
```
返回的 `id` 字段才是 Worker 的真实名称（如 `cardtab` 而非 `tab`）。

---

## KV 数据管理

**列出所有 keys：**
```bash
curl -s "https://api.cloudflare.com/client/v4/accounts/<ACCOUNT_ID>/storage/kv/namespaces/<NS_ID>/keys" \
  -H "Authorization: Bearer <API_TOKEN>"
```

**读取单个值：**
```bash
curl -s "https://api.cloudflare.com/client/v4/accounts/<ACCOUNT_ID>/storage/kv/namespaces/<NS_ID>/values/<key>" \
  -H "Authorization: Bearer <API_TOKEN>"
```

**写入数据：**
```bash
curl -s -X PUT "https://api.cloudflare.com/client/v4/accounts/<ACCOUNT_ID>/storage/kv/namespaces/<NS_ID>/values/<key>" \
  -H "Authorization: Bearer <API_TOKEN>" \
  -H "Content-Type: application/json" \
  --data-binary '{"links":[],"categories":{}}'
```

---

## 书签导入示例（Card-Tab）

数据结构：`{"links": [...], "categories": {...}}`，KV key 为 `testUser`。

分类规则：
- 社交媒体: facebook, whatsapp, instagram, telegram, linkedin
- AI工具: chatgpt, claude, gemini, kimi, deepseek, bard, openai
- 外贸平台: fobshanghai, made-in-china, alibaba, globalsources
- 技术开发: github, stackoverflow, npm, pypi, docker
- 云服务: aws, azure, gcp, cloudflare, digitalocean
- 学习资源: coursera, udemy, youtube, bilibili
- 加密货币: coinmarketcap, coingecko, binance, tradingview
- 金融支付: paypal, stripe, wise, twilio
- 其他: 其余未匹配项

API 上传示例：
```python
import requests
url = f"https://api.cloudflare.com/client/v4/accounts/{account_id}/storage/kv/namespaces/{ns_id}/values/testUser"
requests.put(url, data=json.dumps(data), headers={
    "Authorization": f"Bearer {api_token}",
    "Content-Type": "application/json"
})
```