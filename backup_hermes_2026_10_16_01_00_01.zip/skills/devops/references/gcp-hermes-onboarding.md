# GCP -> Hermes 弟子上线备忘

## 基本信息
- GCP VM：`35.208.156.131`，角色：root
- 操作口令：已配置，由主神保管；传习前永远优先走 SSH pubkey，不传口令
- 目标：让新实例成为已经带技能库的 Hermes 弟子

## 前置要求（子机）
1. GCP Console：Compute Engine > 目标 VM
2. Edit > Networking：
   - 确保防火墙和 VPC 允许入站 SSH `tcp:22`
   - 保留 80/443 若需要后续外网
3. 在 GCP 网页 SSH 里进入实例执行：`useradd -m -s /bin/bash hermes`，给密码账本；或者直接用 root（主神-owned实例）
4. 安装 `openssh-server` 并确保服务启用：
   - `apt-get update -y && apt-get install -y openssh-server`
   - `systemctl enable sshd && systemctl start sshd || service ssh start`
   - `echo "PasswordAuthentication yes" >> /etc/ssh/sshd_config && echo "PermitRootLogin yes" >> /etc/ssh/sshd_config && systemctl restart sshd`

## 主神侧打包
- 技能打包：`~/.hermes/skills/`
- 记忆打包：`～/.hermes/memories/`
- 可复制操作：`scp -r`，并入库到 `/tmp/hermes-sync/YYYYMMDD` 便于回滚

## 子机侧回灌
- `rsync -avz --delete /tmp/hermes-sync/ /hermes/`
- 需要 hermues 服务以软链或 dotenv 指向新目录方式运行，避免 pid/mutex 冲突。

## 已知 fail-path
- 先不行再 paw：22 端口眼直连未开。主神当时在线 cmd/Q 时直直是 `ssh: connect to host ...: Connection refused`。
- 重连 Kali/superaldo 慢：GCP 无开关直连，用 Console 直直 WebSSH
- 若 bot 日晚后重车载入前：)`grep ssh /var/log/auth.log` 看 **FAILED PAM 3 times** 判断是否密码输错/被锁定

## 回执验证
- `ssh root@35.208.156.131 "hostname && ls -la /etc/ssh/sshd_config"`
- `ssh root@35.208.156.131 "systemctl is-enabled sshd || true; systemctl is-active sshd || true" `
- 请在 Console 显示 Act 后再下传技能。
