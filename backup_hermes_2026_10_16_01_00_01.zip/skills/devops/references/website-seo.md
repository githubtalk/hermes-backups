# Website SEO & Administration

> Domain binding, SSL setup, Cloudflare DNS, search engine submission, sitemap management, and Windows shared hosting FTP workflows

## Domain Binding (GitHub Pages → Custom Domain)

### GitHub Settings
1. Repository → Settings → Pages → Custom domain: `www.example.com`
2. Do NOT check "Enforce HTTPS" until after DNS verification completes

### Cloudflare DNS
| Type | Name | Target | Proxy |
|------|------|--------|-------|
| CNAME | www | `githubtalk.github.io` | DNS only (gray) during verification |

**Critical**: Keep DNS-only (gray cloud) while GitHub validates domain ownership. After GitHub issues HTTPS cert, re-enable proxy (orange cloud).

### Why Enforce HTTPS Is Optional with Cloudflare
Cloudflare Flexible/Full SSL already handles HTTP→HTTPS redirect at CDN level. GitHub's "Enforce HTTPS" does the same.

## Cloudflare SSL 525 Error

**Symptom**: `HTTP 525 - SSL handshake failed`

**Root cause**: Origin server has no valid SSL certificate for the domain

**Quick fix**:
- Cloudflare → SSL/TLS → Mode: **Flexible**
- Visitor → Cloudflare: HTTPS ✅
- Cloudflare → Origin: HTTP (no cert needed) ✅

**Permanent fix**: Install Let's Encrypt on origin server.

## Cloudflare Proxy → Origin Server Setup

When origin is a VPS/root server (not GitHub Pages):

### Step 1: Start web server on origin FIRST
```bash
sudo systemctl start nginx
sudo systemctl enable nginx
sudo ss -tlnp | grep -E ':80|:443'  # verify listening
```

### Step 2: Check PHP-FPM if 502 Bad Gateway
```bash
sudo systemctl status php8.3-fpm | grep "Active:"
# If permission denied:
sudo chmod 660 /run/php/php8.3-fpm.sock
sudo usermod -a -G www-data nginx
sudo systemctl restart nginx php8.3-fpm
```

### Step 3: Cloudflare DNS record
| Type | Name | Target | Proxy |
|------|------|--------|-------|
| A | sub | `YOUR_SERVER_IP` | Proxied (☁️ orange) |

## Nginx sites-enabled Gotcha (Ubuntu)

On Ubuntu, nginx configs go in `/etc/nginx/sites-enabled/` but **nginx.conf does not include it by default**. If nginx starts but serves nothing on port 80:

1. Check: `grep sites-enabled /etc/nginx/nginx.conf`
2. If missing, add inside `http {}` block: `include /etc/nginx/sites-enabled/*;`
3. Test: `sudo nginx -t`
4. Reload: `sudo systemctl reload nginx`

Note: The `include` line must be INSIDE the `http {}` block.

## Classic ASP (VBScript) Cannot Run on Linux

**Symptom**: ASP files return as plain text download instead of executing

**Root Cause**: Classic ASP (VBScript/Jet OLEDB) is **Windows IIS only**. Mono does not support Classic ASP — only ASP.NET (C#/VB.NET).

| Original Stack | Target Stack | Classic ASP Backend |
|---------------|--------------|---------------------|
| Windows + IIS | Linux + Nginx | ❌ **Cannot migrate** |
| Windows + IIS | Windows + IIS | ✅ Works as-is |

**Migration Options**:
1. **Keep original server for admin** — Use old backend for updates, sync static to new server
2. **Rebuild backend** — Rewrite ASP admin in PHP/Laravel
3. **Use Windows VPS** — Keep IIS + Classic ASP, add Cloudflare in front

## Sitemap After Domain Change

**Problem**: sitemap.xml still has old `githubtalk.github.io/shengtuo-tractor/` URLs

**Fix**:
1. Update `sitemap.xml` with new domain URLs
2. Update `canonical`, JSON-LD `@id`/`url`, `og:url`, `og:image`, `twitter:image`
3. GitHub Pages automatically redirects `/sitemap.xml` from parked URL to custom domain

> ⚠️ **Cloudflare can override robots.txt**: Cloudflare Dashboard Rules can control robots.txt at CDN level. If changes don't appear, check Cloudflare Dashboard → Rules.

## Search Engine Submission

| Engine | Priority | Tools |
|--------|----------|-------|
| Google | Must-do | search.google.com/search-console |
| Bing | High (Yahoo shared) | bing.com/webmasters |
| Yandex | Medium (Russia) | webmaster.yandex.com |
| Baidu | If China market | zhanzhang.baidu.com |

### Verification Methods

| Method | Best For | Limitations |
|--------|----------|-------------|
| **HTML tag** | Any site | Must be able to edit `<head>` |
| **Cloudflare授权** | Cloudflare-proxied sites | Only works for Google |
| **File upload** | FTP-accessible sites | Baidu only accepts .txt/.html |
| **CNAME** | Sites with Cloudflare blocking bots | Most reliable for Baidu |

### Baidu Verification (FTP)
Baidu requires **raw text file** (no HTML wrapper):
```bash
echo -n "codeva-XXXXX" > baidu_verify_codeva-XXXXX.html
curl -u "USER:PASS" -T baidu_verify_codeva-XXXXX.html "ftp://HOST/wwwroot/"
```

### Yandex Verification
Filename must be `yandex_<code>.html` (underscore in middle):
```html
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head>
<body>Verification: 3fdba79f71c66d1b</body></html>
```

## MySQL on Ubuntu 8.0

Root password reset via debian-sys-maint:
```bash
sudo mysql -u root
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'new_password';
```

## References

Full reference files in `devops/website-seo/references/`:
- `seo-submission-checklist.md`
- `cloudflare-origin-server.md`
- `cloudflare-ssl-modes.md`
- `nginx-url-rewrite-static.md`
- `mysql-ubuntu-setup.md`
- `baidu-verify-ftp.md`
- `sitemap-template.md`
- `classic-asp-iis-migration.md`
- `github-pages-seo.md`
- `website-sync-workflow.md`