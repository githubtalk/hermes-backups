# Remote Hermes Server Operations

## Known Servers

| Host | IP | SSH Key | Role |
|------|-----|---------|------|
| AWS Tokyo | 54.168.228.5 | `~/.ssh/aws54_key` | **生产网站运行在此** + Hermes v0.15.1 gateway |
| 本机 | 43.155.135.188 | local | shengtuo-website 备用 |
| 其他 | 154.41.135.101 | ? | 未知状态 |
| GCP | ? | ? | 未知状态 |

> ⚠️ 网站实际运行在 AWS (54.168.228.5)，调试网站问题需 SSH 到该机器。

## SSH 连接

```bash
# AWS (网站+Hermes)
ssh -o ConnectTimeout=8 -o StrictHostKeyChecking=no -i ~/.ssh/aws54_key ubuntu@54.168.228.5
```

## Hermes 状态检查序列（远程）

```bash
# 1. 版本
hermes --version

# 2. 进程是否存活
ps aux | grep hermes | grep -v grep

# 3. Gateway 状态
hermes gateway status

# 4. 配置概览
cat ~/.hermes/config.yaml | head -40

# 5. Cron jobs
hermes cron list
## AWS Hermes 现状 (54.168.228.5)

- **版本**: v0.15.1 (2026.5.29) — 比本机 v0.14.0 新
- **Gateway**: Systemd service (`hermes-gateway.service`)，开机自启 ✅
- **模型**: `minimaxai/minimax-m2.7` via **custom_nvidia** (NVIDIA NIM)
- **Telegram**: 独立 Bot Token (`8641693282:AAE0...`)
- **Skills**: 27 个已安装
- **Cron Jobs**: 无
- **MCP TrendRadar**: ⚠️ 无法连接（mcp-server 在本机运行，AWS 无法访问 localhost:3333）

## 关键操作记录

### 安装 System Service
```bash
ssh -i ~/.ssh/aws54_key ubuntu@54.168.228.5
yes | sudo hermes gateway install --system
sudo hermes gateway restart --system
sudo hermes gateway status --system
```

### Telegram Bot Token 冲突（重要）
**问题**: 两个 Hermes 实例使用同一个 Bot Token → `Conflict: terminated by other getUpdates request`

**解决**: 每台机器用独立 Bot Token。本机用原 Token，AWS 用 `8641693282:AAE0Jcy9YGa2QuttL2UlAVovy5wuvRl6lYY`

```bash
# AWS 上更新 .env 中的 Telegram token
sed -i 's/TELEGRAM_BOT_TOKEN=.*/TELEGRAM_BOT_TOKEN=8641693282:AAE0Jcy9YGa2QuttL2UlAVovy5wuvRl6lYY/' ~/.hermes/.env
sudo hermes gateway restart --system
```

### 切换模型 Provider
```bash
# provider 从 mimo → custom_nvidia
sed -i 's/^  provider: mimo$/  provider: custom_nvidia/' ~/.hermes/config.yaml
sed -i 's/^\(  default:\).*/\1 minimaxai\/minimax-m2.7/' ~/.hermes/config.yaml
sudo hermes gateway restart --system
```

### 同步 .env 到远程
```bash
scp -i ~/.ssh/aws54_key ~/.hermes/.env ubuntu@54.168.228.5:~/.hermes/.env
```

### 常见问题模式

| 现象 | 原因 | 修复 |
|------|------|------|
| Gateway 未运行 | 手动进程，未设 systemd | `hermes gateway install --system` |
| Telegram polling conflict | 两台机器共用同一 Bot Token | 每台机器用独立 Token |
| MCP TrendRadar 连接失败 | mcp-server 只在本机运行 | 正常，AWS 无法访问本机服务 |
| `.env` 文件缺失 | 未同步到远程机器 | 用 scp 从本机复制 |
| 无 cron jobs | 从未配置 | 按需创建 |
| 版本落后 | 未升级 | `uv pip install --upgrade hermes-agent` |
| 内存/磁盘紧张 | 长期运行累积 | 清理 logs、cache |

## AWS Hermes 现状 (54.168.228.5)

- **版本**: v0.15.1 (2026.5.29) — 比本机 v0.14.0 新
- **Gateway**: 手动运行，PID 82855，运行 3 天 12 小时
- **模型**: minimaxai/minimax-m2.7 via NVIDIA NIM
- **Telegram**: 已配置 home channel 522296847
- **Skills**: 27 个已安装
- **Cron Jobs**: 无
- **服务模式**: 非 systemd，手动进程