---
title: AWS Server
scope: remote
created: 2026-06-06
---

# AWS — Hermes Server Facts

## Server
- **IP:** 54.168.228.5
- **User:** ubuntu
- **SSH Key:** ~/.ssh/aws54_key (only this key works)

## Hermes
- **Version:** v0.15.1
- **Python:** 3.11.15
- **Config:** ~/.hermes/config.yaml
- **Skills:** ~/.hermes/skills/

## SSH
```bash
ssh -i ~/.ssh/aws54_key ubuntu@54.168.228.5
```
其他密钥失败；root 登录被禁止。

## 同步技能到 AWS
```bash
rsync -av --progress -e "ssh -i ~/.ssh/aws54_key" \
  /home/ubuntu/.hermes/skills/ \
  ubuntu@54.168.228.5:/home/ubuntu/.hermes/skills/
```
已验证，推送后 AWS 技能集与本地一致。
