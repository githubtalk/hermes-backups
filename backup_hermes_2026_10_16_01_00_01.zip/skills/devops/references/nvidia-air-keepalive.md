# NVIDIA AIR Simulation Server Keepalive

## 服务器信息
- **SIMULATION_ID**: `18cba2c1-0c4d-4891-aa93-170d4114424c`
- **API_BASE**: `https://api.air-ngc.nvidia.com/api/v3`
- **创建时间**: 2026-05-21 14:34:33 北京时间
- **有效期**: 72小时（约 2026-05-24 14:34 到期）
- **API_KEY**: `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`

## 脚本位置
`/home/ubuntu/nvidia_air_keepalive.sh`

## 功能
向 NVIDIA AIR API 发送 PATCH 请求，将 simulation sleep_at 时间延长 71 小时（当前时间 + 71小时 = 新sleep_at）

## Cron 设置
```bash
0 */12 * * * /home/ubuntu/nvidia_air_keepalive.sh >> /home/ubuntu/nvidia_air_keepalive.log 2>&1
```

每12小时执行一次（北京时间 00:00 和 12:00）

## 测试结果
```
target_sleep_at=2026-05-24T10:07:53Z
before_sleep_at=2026-05-24T10:30:00Z
after_sleep_at=2026-05-24T10:07:53Z
ok
```

## API 端点
- GET: `{API_BASE}/simulations/{SIMULATION_ID}/` — 获取当前状态
- PATCH: `{API_BASE}/simulations/{SIMULATION_ID}/` — 更新 sleep_at

## 请求头
```
Accept: application/json
Content-Type: application/json
User-Agent: air-sdk/1.3.1
X-Air-Sdk-Version: 1.3.1
Authorization: Bearer {API_KEY}
```

## 验证逻辑
脚本会比较 after_sleep_at 与 target_sleep_at，不匹配则返回非零 exit code。