# Cloudflare Workers + D1 B2B Website

## Project Structure

```
/home/ubuntu/cf_b2b/
├── wrangler.toml          # Workers config (D1, R2, KV bindings)
├── src/
│   ├── index.js           # Router
│   ├── pages/
│   │   ├── layout.js      # Shared layout (header/footer/CSS vars)
│   │   ├── home.js
│   │   ├── products.js    # Product listing (server-side D1 query)
│   │   ├── product-detail.js
│   │   ├── about.js       # About page (Shengtuo company info)
│   │   └── contact.js     # Contact page + social links
│   └── api/
│       ├── handlers/
│       │   └── products.js  # /api/products endpoint
│       └── [...slug].js
```

## Key Commands

```bash
# Deploy
cd /home/ubuntu/cf_b2b
CLOUDFLARE_API_TOKEN="cfut_..." npx wrangler deploy

# D1 remote query (verify data)
CLOUDFLARE_API_TOKEN="cfut_..." npx wrangler d1 execute b2b_database \
  --command "SELECT name, category FROM products LIMIT 5;" --remote

# D1 execute SQL file
CLOUDFLARE_API_TOKEN="cfut_..." npx wrangler d1 execute b2b_database \
  --file=/tmp/update.sql --remote
```

## D1 SQL Sort Pattern

Cloudflare D1 remote supports `ORDER BY CASE WHEN`:

```sql
-- Tractors first, Equipment second
SELECT * FROM products
ORDER BY CASE
  WHEN category = 'SHENGTUO TRACTOR' THEN 1
  WHEN category = 'SHENGTUO FARM EQUIPMENT' THEN 2
  ELSE 3
END, name
```

**Note:** Category values depend on how data was imported. Check with:
```sql
SELECT DISTINCT category FROM products;
```

## CSS Variable Conventions

Old → New mapping used in this project:
- `--primary-color` → `var(--primary)`
- `--text-light` → `var(--gray-500)`
- `--bg-light` → `var(--gray-100)`
- `--border-color` → `#e5e7eb`
- `--text-dark` → `var(--dark)`

CSS vars defined in `layout.js`:
```css
:root {
  --primary: #1a7f37;
  --dark: #111827;
  --gray-100: #f3f4f6;
  --gray-500: #6b7280;
  --radius: 0.5rem;
  --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.1);
}
```

## Common Failures

### about.js nested template literal
**Problem:** sed replacing backticks breaks JS template literal nesting (`const scripts = \`...\`` containing `${}` and another backtick inside).

**Fix:** Replace the entire scripts block with a single-line string or remove inline JS entirely:
```js
const scripts = '<script>document.head.appendChild(Object.assign(document.createElement("style"),{textContent:".card-description{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}"}));</script>';
```

### Two independent sort paths
Products page sort is controlled by BOTH:
1. `src/pages/products.js` — direct D1 query in page handler (server-side)
2. `src/api/handlers/products.js` — `/api/products` endpoint

Both must be updated independently. API is used by JS-driven features.

## Site URLs

- Production: `https://cf-b2b-website.sdtractor.workers.dev`
- API: `https://cf-b2b-website.sdtractor.workers.dev/api/products`

## D1 Database

- Name: `b2b_database` (remote)
- Bind name in wrangler.toml: `DB`
- Products table: 42 products, categories `SHENGTUO TRACTOR` (18) and `SHENGTUO FARM EQUIPMENT` (24)
- Image URL pattern: `https://shengtuo.cc.cd/assets/images/products/*.jpg`
- Image verification: All 42 image URLs return HTTP 200

## KV Namespace

- Name: `STATIC_ASSETS`
- Used for: `website_settings` (JSON with site_name, company_name, email, phone, address, social links)