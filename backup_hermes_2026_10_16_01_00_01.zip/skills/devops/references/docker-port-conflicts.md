# Docker 容器端口冲突调试

## 典型场景

容器显示 "Up" 但端口未监听。

## 调试序列

```bash
# 1. 容器状态
docker compose ps

# 2. 容器日志（第一时间看 fatal/error）
docker compose logs --tail=30

# 3. 主机端口占用
ss -tlnp | grep -E ':80|:81|:443'

# 4. 定位占用进程
ss -tlnp | grep ':80 '  # 看 users 栏的进程名
```

## 常见冲突

### Apache2 占端口（Nginx Proxy Manager）

Apache2 默认监听 80/443，与 NPM 冲突。

**特征：**
```
Error response from daemon: failed to bind host port 0.0.0.0:80/tcp: address already in use
ss -tlnp | grep ':80 ' → apache2
```

**修复：**
```bash
systemctl stop apache2 && systemctl disable apache2
cd /etc/docker/npm && docker compose restart
```

**验证：**
```bash
ss -tlnp | grep -E ':80|:81|:443'  # 三个端口都应该有 npm 监听
```

### 另一个容器实例占端口

同一 compose 项目多个实例或残留容器。

```bash
docker ps -a | grep npm
docker compose down && docker compose up -d
```

## 关键区分

| 状态 | 含义 |
|------|------|
| container "Up" | 进程在跑 |
| 端口监听 | 容器已绑定到主机端口 |

NPM 的 backend 在容器内监听 3000，但对外暴露 80/81/443。容器 Up 不代表端口映射成功。

## NPM 安装注意

slobys/npm 脚本存放位置：
- 脚本克隆到：`~/npm/`
- compose 文件在：`/etc/docker/npm/`
- 运行脚本前先 `mkdir -p /etc/docker/npm`