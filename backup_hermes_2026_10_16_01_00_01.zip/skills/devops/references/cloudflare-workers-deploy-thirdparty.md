# Cloudflare Workers 第三方仓库部署

从 GitHub 克隆并部署第三方 Cloudflare Workers 项目到自有 Cloudflare 账号的标准工作流。

---

## 完整流程

### 1. 克隆仓库并检查结构

```bash
git clone <repo-url>
cd <repo>
cat wrangler.toml
cat package.json
cat schema/*.sql
```

重点关注 `wrangler.toml` 中的：
- `[[d1_databases]]` — 需要创建的 D1 数据库
- `[[r2_buckets]]` — 需要创建的 R2 Bucket
- `[[kv_namespaces]]` — 需要创建的 KV Namespace
- `[vars]` — 环境变量

### 2. 创建云端资源

**D1 数据库：**
```bash
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/<ACCOUNT_ID>/d1/database" \
  -H "Authorization: Bearer <API_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"name": "<database_name>"}'
```

**R2 Bucket：**
```bash
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/<ACCOUNT_ID>/r2/buckets" \
  -H "Authorization: Bearer <API_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"name": "<bucket_name>"}'
```

**KV Namespace：**
```bash
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/<ACCOUNT_ID>/storage/kv/namespaces" \
  -H "Authorization: Bearer <API_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"title": "<namespace_title>"}'
```

### 3. 更新 wrangler.toml

用新创建的资源 ID 替换 `wrangler.toml` 中的占位符：

```toml
name = "<worker-name>"
main = "src/index.js"
compatibility_date = "2025-01-01"

[[d1_databases]]
binding = "DB"
database_name = "<database_name>"
database_id = "<新创建的 database_id>"

[[r2_buckets]]
binding = "<binding_name>"
bucket_name = "<bucket_name>"

[[kv_namespaces]]
binding = "<binding_name>"
id = "<新创建的 kv_id>"
```

### 4. 安装依赖

```bash
npm install
```

### 5. 初始化数据库（远程）

```bash
CLOUDFLARE_API_TOKEN="<token>" \
CLOUDFLARE_ACCOUNT_ID="<account_id>" \
npx wrangler d1 execute <database_name> --file=schema/schema.sql --remote
```

### 6. 部署

```bash
CLOUDFLARE_API_TOKEN="<token>" \
CLOUDFLARE_ACCOUNT_ID="<account_id>" \
npx wrangler deploy
```

---

## 常见坑

### wrangler 非交互环境必须设置环境变量

`wrangler dev` 和 `wrangler deploy` 在非交互（CI/CD）环境下**必须**显式设置：
```bash
CLOUDFLARE_API_TOKEN="<token>" \
CLOUDFLARE_ACCOUNT_ID="<account_id>" \
npx wrangler deploy
```
否则报错：`Please go to https://developers.cloudflare.com/fundamentals/api/get-started/create-token/`

### 删除 Cloudflare Worker

```bash
curl -s -X DELETE \
  "https://api.cloudflare.com/client/v4/accounts/<ACCOUNT_ID>/workers/scripts/<script-name>" \
  -H "Authorization: Bearer <API_TOKEN>"
```

### 默认账号角色不够导致 API 写入失败

**症状：** 登录成功，但 POST `/api/settings` 和 POST `/api/products` 返回 `Unauthorized. Super admin access required.`

**原因：** 很多 cf_b2b 类项目使用 `requireSuperAdmin()` 检查 `role === 'super_admin'`，但初始化脚本创建的默认账号是 `admin` 角色，不是 `super_admin`。

**修复（直接操作 D1）：**
```bash
# 1. 确认账号角色
npx wrangler d1 execute <database_name> --command "SELECT id, username, role FROM admins" --remote

# 2. 升级为 super_admin
npx wrangler d1 execute <database_name> --command "UPDATE admins SET role = 'super_admin' WHERE username = 'admin123'" --remote
```

### KV settings 需登录后通过 API 写入

前端 JS 调用 `GET /api/settings` 时，如果 KV 中没有 `website_settings` key，会返回默认示例数据（GlobalMart）。需要以 super_admin 身份 POST 写入真实数据后，前端才能显示正确的公司信息。

### 通过 API 批量填充内容

当管理员账号权限问题解决后，用 Node.js 脚本通过 API 批量写入产品数据：

```javascript
const API_BASE = 'https://your-worker.workers.dev';

async function login() {
  const res = await fetch(`${API_BASE}/api/admin/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin123', password: 'admin123' })
  });
  return (await res.json()).data.token;
}

async function addProduct(token, product) {
  return fetch(`${API_BASE}/api/products`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(product)
  }).then(r => r.json());
}

const token = await login();
for (const p of products) await addProduct(token, p);
```

### HTTP 状态码与实际内容不符

Cloudflare Workers 有时返回 5xx 状态码但仍返回 HTML 内容（fallback 错误页面）。以 `-w "%{http_code}"` 的响应码为准，内容是否正确需配合 size_download 判断。

---

## API 资源端点速查

| 资源 | 端点 |
|------|------|
| D1 数据库 | `POST /accounts/{account_id}/d1/database` |
| R2 Bucket | `POST /accounts/{account_id}/r2/buckets` |
| KV Namespace | `POST /accounts/{account_id}/storage/kv/namespaces` |
| 删除 Worker | `DELETE /accounts/{account_id}/workers/scripts/{script_name}` |

认证：所有请求加 `-H "Authorization: Bearer <API_TOKEN>"`