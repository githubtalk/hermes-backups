<?php
/**
 * Plugin Name: Force zh_CN Locale
 * Description: Force WordPress site language to Simplified Chinese.
 * Author: Site Admin
 */

add_filter( 'locale', function() { return 'zh_CN'; } );
add_filter( 'determine_locale', function() { return 'zh_CN'; } );
