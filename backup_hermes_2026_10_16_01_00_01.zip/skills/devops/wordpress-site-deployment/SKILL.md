---
name: wordpress-site-deployment
description: Deploy, configure, and manage WordPress sites on Debian/Nginx/PHP-FPM. Use when setting up a new WordPress site, installing plugins/themes, configuring HTTPS, switching admin language, or preparing for AdSense.
---

# WordPress 站点部署与管理

适用于 Debian/Nginx/PHP-FPM 环境下的 WordPress 部署、配置和日常管理。

## 触发条件

用户要求建站、部署 WordPress、配置后台、安装插件、切换语言、申请 AdSense 等。

## 部署流程

### 1. 环境检查
```bash
hostname && uname -a
nginx -v 2>&1
php -v 2>&1 | head -1
mysql -V 2>&1
```

### 2. 安装 LEMP
```bash
# 先确认可用 PHP 版本
apt-cache search php | grep "^php[0-9]" | head -5

DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  nginx mariadb-server php-fpm php-mysql php-xml php-mbstring \
  php-curl php-gd php-zip php-intl php-bcmath
```

### 3. 创建数据库
```bash
mysql -u root -e "CREATE DATABASE wordpress_ai CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'wpuser'@'localhost' IDENTIFIED BY '<strong-password>';
GRANT ALL PRIVILEGES ON wordpress_ai.* TO 'wpuser'@'localhost';
FLUSH PRIVILEGES;"
```

### 4. 部署 WordPress
```bash
mkdir -p /var/www/<site-dir> && cd /var/www/<site-dir>
curl -sL https://wordpress.org/latest.tar.gz | tar -xz --strip-components=1
cp wp-config-sample.php wp-config.php
# 编辑 wp-config.php：数据库名、用户、密码
# 替换 salts：curl https://api.wordpress.org/secret-key/1.1/salt/
chown -R www-data:www-data /var/www/<site-dir>
```

### 5. Nginx 配置
```bash
cat > /etc/nginx/sites-available/<site> << 'EOF'
server {
    listen 80;
    server_name <domain> www.<domain>;
    root /var/www/<site-dir>;
    index index.php index.html;
    client_max_body_size 64M;
    location / { try_files $uri $uri/ /index.php?$args; }
    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/php-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_read_timeout 120;
    }
    location ~ /\. { deny all; }
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 7d; add_header Cache-Control "public, immutable";
    }
}
EOF
ln -sf /etc/nginx/sites-available/<site> /etc/nginx/sites-enabled/<site>
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
```

### 6. HTTPS（Let's Encrypt）
```bash
apt-get install -y certbot python3-certbot-nginx
certbot --nginx -d <domain> -d www.<domain> \
  --non-interactive --agree-tos -m <email>
```

### 7. WP-CLI 安装
```bash
curl -sL https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar \
  -o /usr/local/bin/wp && chmod +x /usr/local/bin/wp
```

### 8. WordPress 初始化
```bash
cd /var/www/<site-dir>
wp --allow-root core install \
  --url="https://<domain>" \
  --title="<站点标题>" \
  --admin_user="admin" \
  --admin_password="<password>" \
  --admin_email="<email>" \
  --skip-email
```

## 后台语言切换为中文

### 关键步骤（必须全部执行，缺一不可）

1. 安装中文语言包：
```bash
cd /var/www/<site-dir>
wp --allow-root language core install zh_CN
```

2. 设置站点语言：
```bash
wp --allow-root option update language zh_CN
```

3. 设置用户语言（必须指定 user_id）：
```bash
wp --allow-root user meta update 1 locale zh_CN
```

4. **必须告知用户手动确认**：
- 登录后台 → 用户 → 个人资料 → 语言 → 选择 **简体中文**
- 保存后刷新页面

### 强制前台/后台中文显示（determine_locale 不生效时的兜底）

当 `wp --allow-root eval "echo get_locale();"` 返回 `en_US` 且 `language` option 已设为 `zh_CN` 仍不生效时，说明有插件/缓存干扰 locale 检测。

**正确做法**：使用 `templates/force-locale-mu-plugin.php` 作为模板，部署到 `wp-content/mu-plugins/`。详见 `references/wordpress-seo-sitemap-optimization.md` 中的 "Language/Locale Mismatch Troubleshooting" 章节。

```bash
cp templates/force-locale-mu-plugin.php /var/www/<site-dir>/wp-content/mu-plugins/force-locale.php
chown www-data:www-data /var/www/<site-dir>/wp-content/mu-plugins/force-locale.php
```

验证：
```bash
wp --allow-root eval "var_dump(get_locale()); var_dump(determine_locale());"
# 都应返回 string(5) "zh_CN"
```

### 常见错误
- 只改 `language` option 不改 user meta，admin 用户仍看到英文
- 语言包未安装就切换，会回退到英文
- 浏览器缓存导致切换后仍显示旧语言
- 在 `wp-config.php` 里调用 `add_filter()`：此时 WordPress 核心尚未加载，会 fatal error

## 插件安装清单

### robots.txt Nginx 配置模板

```nginx
location = /robots.txt {
    allow all;
    log_not_found off;
    access_log off;
}
location ~ /\. {
    deny all;
}
```

### 推荐插件（AdSense 站点）
| 插件 | 用途 | 注意 |
|-----|------|------|
| wordpress-seo | SEO | 必须 |
| ad-inserter | 广告位管理 | 必须 |
| autoptimize | CSS/JS 压缩 | Nginx 兼容 |
| akismet | 反垃圾评论 | 必须 |
| contact-form-7 | 联系表单 | 必须 |
| google-site-kit | Google 服务接入 | 必须 |

### 不推荐在 Nginx 使用的插件
- **LiteSpeed Cache**：仅 LiteSpeed Web Server 可用，Nginx 下无效
- 替代方案：WP Super Cache 或 W3 Total Cache

## 主题选择

- **GeneratePress**：轻量、速度快、AdSense 友好
- 创建子主题存放自定义 CSS，避免直接修改父主题

## AdSense 申请准备清单

- [ ] 域名已解析并 HTTPS 生效
- [ ] 30+ 篇高质量原创文章
- [ ] 关于我们 / 隐私政策 / 联系我们 页面已发布
- [ ] 导航菜单配置完成
- [ ] 移动端响应式正常
- [ ] 无broken链接
- [ ] 隐私政策包含 Cookie 和第三方服务声明

## 内容批量创建

使用 WP-CLI 从文件创建文章：
```bash
cat > /tmp/postN.txt << 'EOF'
<p>文章内容...</p>
EOF
wp --allow-root post create --post_type=post --post_status=publish \
  --post_title="标题" --post_category="2" \
  --post_content="$(cat /tmp/postN.txt)"
```

## 用户偏好（来自会话经验）

- 用户授权型：给方向后自主执行，不需要每步确认
- 偏好简洁直接汇报（完成/失败/下一步）
- 做错了会被骂：必须先诊断再动手，不要盲目尝试
- 不移动原有产品结构，只改 CSS/JS/meta
- 网站风格：浅色商务风、紧凑布局、移动端友好
- 中文交流，偏好简洁直接

## 故障排查

### SSH 连接失败
- 本机操作无需 SSH，直接 terminal
- 远程服务器确认 IP 和凭据

### WP-CLI 超时
- 长文章创建可能超时，改用文件方式
- 数据库操作确保路径正确

### 语言切换不生效
- 按"后台语言切换为中文"章节完整执行
- 确认 user meta 写入成功
- 提醒用户手动在个人资料里确认语言设置
