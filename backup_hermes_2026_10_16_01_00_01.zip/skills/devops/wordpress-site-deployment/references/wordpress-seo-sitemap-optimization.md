# WordPress SEO & Sitemap Optimization Notes

## Site: aideep.uk (WordPress 7.0.4, GeneratePress AI Child, Yoast SEO 28.2)

### Sitemap Health Check
- sitemap_index.xml returns 200 with 5 sub-sitemaps: post/page/category/tag/author
- Post count: 96 published posts
- Page count: 5 published pages
- Yoast SEO sitemap is functioning correctly

### robots.txt Common Pitfalls
1. Nginx may block robots.txt: the pattern `location ~ /\. { deny all; }` blocks all dotfiles including robots.txt
2. Fix: add explicit whitelist BEFORE the deny rule
3. File permissions: robots.txt must be readable by www-data, not root-only

### robots.txt Template for Chinese Sites
- Include Sitemap directive
- Allow uploads
- Block admin, plugins, themes, cache dirs

### Duplicate Content Cleanup
- Check for duplicate pages via post_name suffix (-2, -3 etc.)
- Check for test/draft posts that should be trashed
- Always purge all caches after bulk content changes

### Empty Meta Description Issues
- Yoast SEO stores meta descriptions in wp_postmeta with key _yoast_wpseo_metadesc
- If the table shows 0 rows for this key, descriptions may be generated dynamically from post excerpts
- Verify by checking page source for meta name=description tag

### Language/Locale Mismatch Troubleshooting
- Symptom: html lang=en-US but wp_options.language = zh_CN
- Diagnosis: wp eval var_dump(get_locale()); var_dump(determine_locale());
- If both return en_US despite DB setting zh_CN, a plugin or object cache is overriding locale
- Fix hierarchy: flush caches first, then use mu-plugins force-locale.php
- Never add add_filter() calls directly in wp-config.php — causes fatal error because WP core is not loaded yet

### Yoast SEO Default Settings Checked
- enable_xml_sitemap: 1
- noindex-post: 0
- noindex-page: 0
- noindex-archive: 1 (correct for blog)
- title-home: sitename + page + sep + sitedesc
- metadesc-home: empty (should be filled)
