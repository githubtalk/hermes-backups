# aideep.uk 站点详情

## 服务器环境
- IP: 35.212.180.57
- OS: Debian 13 (6.12.95)
- Web: Nginx 1.26.3
- PHP: 8.4.24 (FPM)
- DB: MariaDB 11.8.6
- WordPress: 7.0.4

## 文件路径
- 站点根目录: /var/www/wordpress-ai
- Nginx 配置: /etc/nginx/sites-available/wordpress-ai
- 主题: generatepress-ai-child (子主题)
- 自定义 CSS: /var/www/wordpress-ai/wp-content/themes/generatepress-ai-child/style.css

## 数据库
- 数据库名: wordpress_ai
- 用户: wpuser
- 密码: TalentPro2026!

## 后台
- URL: https://aideep.uk/wp-admin
- 账号: admin
- 密码: TalentPro2026!
- 语言: zh_CN

## SSL
- Let's Encrypt 证书
- 到期: 2026-11-15
- 自动续期已配置

## 内容统计
- 文章: 79+ 篇
- 分类: 5 个 (AI写作工具, AI图像生成, AI编程辅助, AI效率工具, +1)
- 页面: 关于我们, 隐私政策, 联系我们

## 已安装插件
- wordpress-seo (28.2)
- ad-inserter (2.8.18)
- autoptimize (3.1.15.1)
- akismet (5.7)
- contact-form-7 (6.1.6)
- google-site-kit (1.185.0)
- litespeed-cache (7.9) - 注：Nginx 下无效，建议替换

## 注意事项
- LiteSpeed Cache 在 Nginx 下不生效，建议换成 WP Super Cache
- Contact Form 7 表单需在后台配置字段和邮件通知
- Google Site Kit 需在后台登录 Google 账号授权
- AdSense 尚未申请，内容已达标可直接申请
