---
name: devops
description: Skill category for devops — infrastructure, deployment, automation, cloud platforms, and AI agent configuration
version: 2.0.0
metadata:
  hermes:
    tags: [devops]
    related_skills: [custom-openai-provider, hermes-telegram-setup, webhook-subscriptions, scrapling]
---

# Devops

## Overview

Infrastructure, deployment, automation, and AI agent configuration — covers website administration, cloud platforms, Telegram integration, webhook subscriptions, web scraping, and AI CLI tools.

## MCP (Model Context Protocol) Integration

Hermes Agent has a built-in MCP client that connects to MCP servers at startup, discovers their tools, and makes them available as first-class tools. For full configuration reference, transport types, security, troubleshooting, and examples — see the `native-mcp` sub-skill under `mcp`.

### Quick Config
```yaml
mcp_servers:
  time:
    command: "uvx"
    args: ["mcp-server-time"]
```

## Sub-skills

- **custom-openai-provider**: Configure any OpenAI-compatible API as a Hermes model provider
- **hermes-telegram-setup**: Set up and troubleshoot Telegram bot integration with Hermes Agent
- **scrapling**: Scrapling - adaptive web scraping framework with anti-scraping bypass
- **webhook-subscriptions**: Webhook subscriptions for event-driven agent runs

## Labeled Sections

### AWS Server

For AWS (54.168.228.5) — server inventory, SSH access (`~/.ssh/aws54_key`, ubuntu user), Hermes v0.15.1 state, skills sync recipe, and authentication constraints — see `references/aws-server-ops.md`.

### NVIDIA Air NGC API

For NVIDIA Air (air-ngc.nvidia.com) API operations — authentication, endpoints, GPU cloud simulation instance management — see `references/nvidia-air-ngc.md`. Covers Bearer token auth, simulation CRUD, 403 business email errors, and environment connectivity.

### Website SEO & Administration

For domain binding, SSL setup, Cloudflare DNS, search engine submission, sitemap management, MySQL on Ubuntu, and Classic ASP/IIS migration guidance, see `references/website-seo.md`. Covers Cloudflare 525 errors, nginx gotchas, Baidu/Yandex verification, and GitHub Pages custom domain SEO.

### Cloudflare Workers Blog Deployment

For Cloudflare Workers blog deployment (01MVP blog-starter), D1/KV/R2 binding config, BETTER_AUTH_SECRET secret management, custom domain setup, database operations, and route removal workflow — see `references/cloudflare-workers-blog-deploy.md`.

### Cloudflare Workers 第三方仓库部署

For cloning and deploying third-party Cloudflare Workers projects from GitHub — resource creation (D1/R2/KV), wrangler.toml patching, remote D1 init, and deployment — see `references/cloudflare-workers-deploy-thirdparty.md`.

### Cloudflare Workers B2B Website

For the Shengtuo B2B product site (D1 + Workers + R2), including product listing sort fixes, CSS variable conventions, about/contact page content sourcing, and common deployment pitfalls — see `references/cloudflare-b2b-website.md`.

### Cloudflare Workers KV-only 项目

For pure KV-based Workers projects (no D1/R2), including Card-Tab bookmark management, `wrangler deploy` workflow, ES module format debugging, and KV data management via REST API — see `references/cloudflare-kv-only-workers.md`.

### Remote Hermes Operations

For SSH diagnostics, known server inventory, Hermes status checks, and cross-host operational guidance — see `references/remote-hermes-ops.md`. Covers connection patterns, version checks, gateway management, and common failure modes across remote instances.

### Debugging References

- **references/docker-port-conflicts.md** — Docker 容器端口冲突调试：apache2 与 NPM 冲突、容器 Up 但端口未监听、调试序列

## Usage

Load individual skills from this category using:
```
skill_view(name="devops/{sub_skill}")
```