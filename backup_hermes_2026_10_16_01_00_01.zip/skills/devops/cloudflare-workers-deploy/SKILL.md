---
name: cloudflare-workers-deploy
description: Deploy and manage Cloudflare Workers with D1, R2, KV, and Workers KV store
triggers:
  - deploy to cloudflare workers
  - cf_b2b type projects
  - wrangler.toml based deployment
---

# Cloudflare Workers Deployment

## Workflow

### Phase 1: Scout & Plan
1. Clone/fetch the repo, read `wrangler.toml` and `package.json`
2. Identify required Cloudflare resources (D1, R2, KV) and their bindings
3. If resources don't exist yet, create them via REST API
4. **Repo download fallback**: If `git clone` times out, use `scripts/github-downloader.py` with `raw.githubusercontent.com` instead.

### Phase 1b: GitHub Repo Deployment (new Worker project)
When deploying a third-party GitHub repo as a new Worker:
1. Clone repo: `git clone https://github.com/<owner>/<repo>.git /tmp/<repo>`
2. Read `README.md` / `README_zh.md` for deployment prerequisites
3. Read `wrangler.toml` — identify placeholder values (`YOUR_D1_DATABASE_ID`, `YOUR_KV_NAMESPACE_ID`, `YOUR_R2_BUCKET_NAME`)
4. Read `package.json` — check scripts (`deploy`, `dev`, etc.)
5. Check for `src/schema.sql` or migration files that need to run after D1 creation
6. Provision CF resources via REST API (D1, KV, R2)
7. Update `wrangler.toml` with real resource IDs/names
8. Initialize DB: `npx wrangler d1 execute <db_name> --file=src/schema.sql --remote`
9. Deploy: `CLOUDFLARE_API_TOKEN=<token> npx wrangler deploy`
10. Set secrets: `npx wrangler secret put <NAME>` for each required env var
11. Verify Worker URL and test login/health endpoint

### Phase 2: Create Cloudflare Resources
```bash
# D1 Database
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/$ACCOUNT_ID/d1/database" \
  -H "Authorization: Bearer $API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "database_name"}'

# R2 Bucket
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/$ACCOUNT_ID/r2/buckets" \
  -H "Authorization: Bearer $API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "bucket-name"}'

# KV Namespace
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/$ACCOUNT_ID/storage/kv/namespaces" \
  -H "Authorization: Bearer $API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title": "namespace-name"}'
```

### Phase 3: Configure wrangler.toml
Update `wrangler.toml` with resource IDs:
```toml
[[d1_databases]]
binding = "DB"
database_name = "database_name"
database_id = "<uuid>"

[[kv_namespaces]]
binding = "STATIC_ASSETS"
id = "<uuid>"
```

### Phase 4: Initialize Database
```bash
# Run SQL migrations (use --remote for production D1)
npx wrangler d1 execute database_name --file=schema/schema.sql --remote
```

### Phase 5: Deploy
```bash
npx wrangler deploy
```

## KV Settings Pattern (website_settings)
Many CF Workers projects store site config in KV as JSON. This pattern recurs in B2B/ecommerce templates.

**Correct way to write JSON to KV:**
```bash
# Must use --path <file>, NOT stdin/heredoc — wrangler reads value from file
echo '{"site_name":"...","email":"..."}' > /tmp/settings.json
npx wrangler kv key put "website_settings" --path /tmp/settings.json --namespace-id <uuid> --remote
```

## Pitfalls

- **git clone may timeout on large repos**: When `git clone` times out in headless environments, fall back to downloading files individually via `raw.githubusercontent.com` + a Python downloader script in `/tmp/dl.py`. See the `scripts/github-downloader.py` template. This avoids cloning the entire repo history.
- **npm install may fail on esbuild native binary**: In some environments `npm install` fails with `esbuild` SIGSEGV during postinstall. **Fix**: use `npm install --ignore-scripts`. For Workers-only deployment, wrangler bundles its own esbuild and the skipped scripts are not needed. Only use full `npm install` if the project needs native addons or postinstall build steps.
- **frontend-dist download may create nested paths**: When downloading a repo's `frontend-dist/` directory via GitHub Contents API with a Python downloader, files may land in `frontend-dist/frontend-dist/` instead of `frontend-dist/`. **Fix**: after download, if `frontend-dist/frontend-dist/` exists, move its contents up one level and remove the nested directory. Wrangler's `[assets] directory` must point to the actual build output root.
- **Browser snapshot may show "Page not found" while curl returns 200**: For Workers with `not_found_handling = "single-page-application"` but a custom JS route matcher, the browser title can read "Page not found" even though `curl -L` returns HTTP 200 with full HTML. **Fix**: verify deployment with `curl -sL -D- <worker-url> -o /dev/null | head -20` and `curl -sL <worker-url> | head -20` instead of relying on browser snapshot titles. Browser stealth/proxy layers can also affect title rendering.
- **wrangler.toml placeholders block resource creation**: Invalid placeholder values like `YOUR_R2_BUCKET_NAME` cause wrangler to reject config validation before any resource-creation command runs. **Fix**: Patch `wrangler.toml` placeholders to valid values BEFORE running `wrangler d1 create`, `wrangler kv`, or `wrangler r2` commands. R2 bucket names must be 3-63 chars, lowercase alphanumeric + hyphens.
- **wrangler.toml may be auto-generated by CI scripts**: Some repos (e.g., CloudFlare-ImgBed) include `deploy/worker/generate-toml.js` that generates `wrangler.toml` from env vars for GitHub Actions. For manual deployment, create `wrangler.toml` yourself with real resource IDs rather than relying on the generator.
- **Worker may use auto-generated route table from filesystem**: Projects like CloudFlare-ImgBed use `generate-routes.js` to scan `functions/` and build a route map. `index.js` then imports all modules. **Fix**: When deploying such projects, ensure the `functions/` directory is present locally and matches the expected structure; the route generator must be run (or its output committed) before `wrangler deploy`.
- **Database adapter may prefer D1 over KV**: Some projects use `databaseAdapter.js` to abstract D1/KV. If `env.img_d1` is bound, D1 is used; if only `env.img_url` (KV) is bound, KV is used. Configure both bindings in `wrangler.toml` to avoid fallback surprises.
- **Frontend assets need explicit directory binding**: Workers serving SPAs often declare `[assets]` in `wrangler.toml`. Verify the `directory` path points to the actual frontend build output (e.g., `../../frontend-dist`). Missing or wrong path causes 404s on `/` despite successful deploy.
- **wrangler deploy requires auth in non-interactive environments**: Set `CLOUDFLARE_API_TOKEN` env var explicitly. `--temporary` may fail with 403 proof-of-work challenge errors in headless environments.
- **D1 database may already exist**: `wrangler d1 create` returns error 7502 "already exists". Use list API to find existing DB UUID: `curl -s "https://api.cloudflare.com/client/v4/accounts/{id}/d1/database" -H "Authorization: Bearer {token}"`.
- **wrangler secret put for passwords**: Use file redirection (`echo -n 'password' > /tmp/pw.txt && wrangler secret put PASSWORD < /tmp/pw.txt`) to avoid interactive prompt issues in non-TTY.
- **Pure JS Workers deploy via wrangler, not raw API**: Cloudflare `/content` API rejects ES module `export` statements with `Unexpected token 'export'`. Wrangler CLI handles script wrapping and module conversion automatically. Always prefer `npx wrangler deploy` for pure JS Workers.
- **Worker source is NOT in local project directories**: Some deployed Workers (e.g., Card-Tab) have source code managed separately from the local project. To inspect live Worker code: `curl -sL https://api.cloudflare.com/client/v4/accounts/{account}/workers/scripts/{name} -H "Authorization: Bearer {token}"` -o /tmp/worker.js`. The downloaded file is wrapped; search for actual handler logic inside.
- **wrangler setup scripts can fail with User API Tokens**: Even when `npx wrangler whoami` succeeds, commands like `wrangler kv namespace list` may fail with `Authentication error [code: 10000]` on `/memberships`. The REST API (`/accounts/{id}/storage/kv/namespaces`) may still work. **Workaround**: bypass `npm run setup` and create KV/R2/D1 directly via `curl` + Cloudflare REST API, then patch `wrangler.toml` with real IDs before `npx wrangler deploy`.
- **wrangler.toml must include `account_id` for deployment**: Some repo templates omit `account_id`. Wrangler may still deploy, but resource-creation scripts often fail. Add `account_id = "<your-account-id>"` at the top level of `wrangler.toml` when deploying to a specific account.
- **KV-only Workers skip D1/R2 steps**: Projects like SubsTracker use only KV + static assets + cron triggers. Skip D1/R2 provisioning entirely. Bind KV with `[[kv_namespaces]]` and verify `[assets]` points to the correct static directory.
- **First-run migrations happen inside the Worker**: Some projects (e.g., SubsTracker) run KV schema migrations on first fetch/scheduled event. No manual migration step is needed; just ensure KV is bound and accessible. Check Worker logs via Cloudflare Dashboard if data doesn't appear.
- **Blank page debugging — check KV data before Worker code**: Login blank page is usually NOT the Worker filtering logic. The current online Worker may already handle string `categories` mapping. The real cause is often `categories` being empty `{}` in KV while `links` have valid categories. **Fix**: reconstruct `categories` from `links[].category` values and write back to KV. Verify with `GET /storage/kv/namespaces/{id}/values/{userId}` before assuming Worker code needs modification.

## Known Issues (cf-b2b project — Jul 2026)
- **wrangler d1 execute**: Always add `--remote` flag to target production D1, not local dev DB.
- **No build step**: Pure JS projects deploy directly without `npm run build`. Check `package.json` scripts first.
- **Admin role**: Default admin accounts may be `admin` role, not `super_admin`. Upgrade via D1: `UPDATE admins SET role='super_admin' WHERE username='admin'`
- **POST vs PUT for updates**: POST often creates duplicates — verify whether update uses POST or PUT
- **D1 SQL via API**: When `wrangler` CLI fails, fall back to Cloudflare REST API for D1 operations
- **KV settings NOT auto-propagated to pages**: Pages with hardcoded HTML template strings do NOT update when KV changes. Fix: read settings server-side in page handler (`await env.STATIC_ASSETS.get()`), inject into HTML template string, redeploy. Check home.js, about.js, contact.js when updating site content. Pages using JS `fetch('/api/settings')` client-side may fail silently — always prefer server-side injection for static content pages.
- **D1 SQL file execute does NOT support transactions**: Wrangler rejects `BEGIN;`/`COMMIT;` in SQL files with `To execute a transaction, please use the state.storage.transaction() or state.storage.transactionSync() APIs`. Workaround: execute statements one-by-one without transaction wrappers. For batch updates, just write N individual `UPDATE ... WHERE id = N;` statements in one file — D1 executes them all atomically without a transaction block.
- **D1 CASE WHEN works in ORDER BY**: `ORDER BY CASE WHEN category = 'SHENGTUO TRACTOR' THEN 1 WHEN category = 'SHENGTUO FARM EQUIPMENT' THEN 2 ELSE 3 END, name` works fine in D1. Verify with `--dry-run` before deploying.
- **CSS variable naming mismatch causes 500 errors**: `layout.css` defines `--primary`, `--dark`, `--gray-*`, `--radius`, `--shadow-*`. Many page templates incorrectly use `--primary-color`, `--text-light`, `--text-dark`, `--bg-light` which do NOT exist in layout.css and cause Worker exceptions. **Always verify all CSS variables match layout.css definitions before deploying.** Replace: `var(--primary-color)→var(--primary)`, `var(--text-light)→var(--gray-500)`, `var(--text-dark)→var(--dark)`, `var(--bg-light)→var(--gray-100)`, `var(--border-color)→#e5e7eb`.
- **Template literal `class` keyword causes "Expected ; but found class" build error**: In Cloudflare Workers (V8 engine), template literals containing `class=` attributes fail to parse, producing cryptic build errors at the `class` keyword. **Workaround**: Use string concatenation (`'<div class="card">' + ... + '</div>'`) for HTML with class attributes. Do NOT use backtick template literals for HTML card markup in page handlers.
- **Product detail pages 500 — check CSS vars first**: When a product-detail page throws 500, CSS variable mismatches are almost always the culprit, not the DB query. Use a minimal stub page to isolate, then progressively add complexity.
- **Server-side rendering preferred for product listing**: Pages fetching `/api/products` client-side via `API.get()` are fragile. Render products server-side with `env.DB.prepare().all()` and inject HTML during SSR. Client-side JS fetch is fine for dynamic content (filters, modals) but not primary content.

## Known Issues (cf-b2b project — Jul 2026)

### Product Detail Page Routing Broken
Products page "View Details →" links fail — clicks don't navigate. Direct access to `/products/13` returns "Product Not Found" even though the product exists in D1 (confirmed via `/api/products`). Root cause: product-detail route handler or route pattern mismatch. Check `src/pages/product-detail.js` route matching `event.params.id` vs actual URL pattern. This is a pre-existing bug in the geeeeeeek/cf_b2b repo.

### Category Filter Dropdown Non-Functional
Products page `/products` has combobox for filtering by category but selection doesn't filter the displayed cards. Likely JS event binding issue on the `<select>` element.

### Typo in Product Names
Some product names have "SHEGNTUO" instead of "SHENGTUO" — these are data errors in D1, not code issues.

## Verification
```bash
curl -sLo /dev/null -w "%{http_code}" "https://worker.workers.dev/"
curl -s "https://worker.workers.dev/api/settings"
```

## References
- `references/cloudflare-rest-api.md` — Cloudflare API endpoints for D1/R2/KV/Workers management
- `references/cf-b2b-project-notes.md` — Session-specific notes from deploying geeeeeeek/cf_b2b
- `references/card-tab-kv-import.md` — Card-Tab bookmark import/recategorization via CF KV API (tab.xiaoai.tech), including backup/restore, dedup, and category mapping
- `references/card-tab-visual-optimization.md` — Card-Tab CSS/color optimization (theme #10b981, gradients, 16px radius, hover effects), deploy steps
- `references/d1-database-operations.md` — D1 INSERT/UPDATE patterns, image URL batch update, validation scripts, and browser-console product extraction technique
- `references/product-sync-workflow.md` — Product comparison workflow: browser-console extraction, model-number matching, image URL validation, D1 batch UPDATE without transactions
- `references/memos-worker-deployment-2026-07-10.md` — Memos Worker GitHub repo deployment: resource provisioning, wrangler.toml patching, D1 schema init, secret setup, and known pitfalls
- `references/imgbed-worker-deployment.md` — CloudFlare-ImgBed project structure, auto-generated routes, frontend assets binding, database adapter pattern, and manual deployment steps
- **Worker source retrieval**: Card-Tab Worker source is NOT in `/home/ubuntu/Rin/` (that's a different project). To inspect live Worker code: `curl -sL https://api.cloudflare.com/client/v4/accounts/<account>/workers/scripts/<name> -H "Authorization: Bearer <token>" -o /tmp/worker.js`. The downloaded file is wrapped; search for the actual handler logic inside.