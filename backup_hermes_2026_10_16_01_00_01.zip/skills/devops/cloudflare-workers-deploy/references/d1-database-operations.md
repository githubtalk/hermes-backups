# D1 Database Operations — cf_b2b Session Notes

## Schema (b2b_database)
```sql
CREATE TABLE products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  detailed_description TEXT,
  specifications TEXT,
  image_url TEXT,
  gallery_images TEXT,  -- JSON array
  category TEXT,
  is_featured BOOLEAN DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
```

**Confirm columns before inserting** — `PRAGMA table_info(products)` — don't guess (e.g., `stock_status` doesn't exist, use `is_active`).

## Adding Missing Products (Jul 2026)
Source: shengtuo.cc.cd/products listing page — extracted 37 product names + images via browser console.

### Step 1: Extract from source site
```js
// In browser console on the products listing page
const items = document.querySelectorAll('[class*="product"], [class*="card"], .grid > *');
const results = [...items].map(el => {
  const img = el.querySelector('img');
  const h3 = el.querySelector('h3');
  return { name: h3?.textContent.trim() || '', img: img?.src || '' };
}).filter(x => x.name && x.img);
const seen = new Set();
const unique = results.filter(r => { if (seen.has(r.name)) return false; seen.add(r.name); return true; });
JSON.stringify(unique)
```

### Step 2: Generate INSERT SQL with write_file
Save to `/tmp/insert.sql` — **never heredoc** (backticks get escaped in wrangler). Use write_file or a Python script.

### Step 3: Execute
```bash
npx wrangler d1 execute b2b_database --file=/tmp/insert.sql --remote
```

## Batch Updating Image URLs
```sql
UPDATE products SET image_url='https://...' WHERE name='Product Name';
-- One per line, 39 lines for full sweep
```
Execute: `npx wrangler d1 execute b2b_database --file=/tmp/update.sql --remote`

## Image Validation
```python
import urllib.request
from collections import Counter
# Validate all product images
for p in products:
    try:
        req = urllib.request.Request(p['image_url'], headers={'User-Agent':'Mozilla/5.0'})
        resp = urllib.request.urlopen(req, timeout=8)
        ct = resp.headers.get('Content-Type','')
        print('OK' if 'image' in ct else f'NOT_IMAGE: {ct}')
    except Exception as e:
        print(f'ERROR: {e}')
# Find shared URLs
urls = [p['image_url'] for p in products]
counts = Counter(urls)
shared = [(u, c) for u, c in counts.items() if c > 1]
```