# SubsTracker Deployment Notes (2026-07-18)

## Project
- **Repo**: `wangwangit/SubsTracker`
- **Description**: Subscription expiry reminder system via Cloudflare Workers + KV + Telegram/Bark/Webhook/ntfy/email
- **Worker URL**: https://subscription-manager.sdtractor.workers.dev
- **Account**: `a0e4e66e8ea4dc776e23626f79e70bdf` (`Sdtractor@outlook.com`)

## Key Files
- `src/index.js` — fetch + scheduled entry
- `src/app.js` — Hono app
- `wrangler.toml` — CF config
- `package.json` — `subscription-manager@3.0.0`

## Deployment Steps
1. `git clone --depth=1 https://github.com/wangwangit/SubsTracker.git ~/SubsTracker`
2. `npm install`
3. Create KV via REST API: `curl -X POST /accounts/{id}/storage/kv/namespaces -d '{"title":"SUBSCRIPTIONS_KV"}'`
4. Patch `wrangler.toml` with `account_id` and `[[kv_namespaces]]` binding
5. `CLOUDFLARE_API_TOKEN=<token> npx wrangler deploy`

## Pitfalls
- `npm run setup` fails with User API Token even though `wrangler whoami` succeeds. Use REST API instead.
- Token must include Account:Edit + KV:Edit permissions.
- First-run KV schema migration runs automatically on fetch/scheduled event.

## Default Credentials
- Username: `admin`
- Password: `password`
- **Must change on first login.**
