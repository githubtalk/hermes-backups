# cf_b2b Project Notes

**Repo**: https://github.com/geeeeeeeek/cf_b2b
**Workers URL**: https://cf-b2b-website.sdtractor.workers.dev
**Status**: Deployed & populated

## Resources Created
- D1: `b2b_database` (761a885a-2ce1-43da-...)
- R2: `b2b-product-images` (for product image storage — not yet wired up)
- KV: `b2b-static-assets` / `STATIC_ASSETS` binding (d560f5c23c8d405b...)

## Schema
3 tables: `products`, `inquiries`, `admins`

## Admin Credentials
- Username: `admin123` / Password: `admin123`
- Role must be `super_admin` for settings/products write operations
- Upgraded via: `UPDATE admins SET role='super_admin' WHERE username='admin123'`

## Settings in KV (`website_settings` key)
```json
{
  "site_name": "Shengtuo Tractor",
  "company_intro": "Shandong Shengtuo Heavy Industry Co., Ltd.",
  "email": "sdtractor@outlook.com",
  "phone": "+86-13806461474",
  "whatsapp": "+86-13806461474",
  "address": "Weifang City, Shandong Province, China",
  "company_name": "Shandong Shengtuo Heavy Industry Co., Ltd.",
  "business_hours": "Monday - Saturday: 8:00 AM - 6:00 PM (CST)",
  "facebook": "https://www.facebook.com/shengtuo.tractor",
  "youtube": "https://www.youtube.com/@shengtuo.tractor",
  "instagram": "https://www.instagram.com/shengtuo_tractor"
}
```

## Key Fix Applied
**contact.js**: Was rendering hardcoded placeholder text. KV settings load succeeded but HTML template had hardcoded defaults. Fixed by reading settings server-side in `contactPage(env)` and injecting real values directly into the HTML template string (not relying on JS `loadContactInfo()`). This is the right pattern for CF Workers static-ish pages.

## Critical Issues Discovered & Fixed (Jul 2026)

### 1. CSS Variable Mismatch → 500 on products & detail pages
`layout.css` defines only: `--primary`, `--dark`, `--gray-*`, `--radius`, `--radius-sm`, `--shadow-*`, `--white`, `--black`.
Pages incorrectly used: `--primary-color`, `--text-light`, `--text-dark`, `--bg-light` — these don't exist in layout.css and cause Worker exception 1101.

**Always replace before deploying:**
- `var(--primary-color)` → `var(--primary)`
- `var(--text-light)` → `var(--gray-500)`
- `var(--text-dark)` → `var(--dark)`
- `var(--bg-light)` → `var(--gray-100)`

### 2. Template Literal `class=` Build Error
Wrangler build fails with `Expected ; but found class` at the `class=` keyword inside backtick template literals containing HTML. This is a V8/Workers build tool parsing issue.

**Fix**: Use string concatenation (`'<div class="card">' + content + '</div>'`) instead of template literals for any HTML containing `class=` attributes. See `products.js` ( rewritten to use string concat + `productCards.join('\n')` pattern with server-side D1 query).

### 3. products.js Rewritten — Server-Side Rendering
Original client-side `API.get('/products')` approach was fragile. Rewritten to fetch from D1 directly in the page handler using `await env.DB.prepare('SELECT ...').all()` and render product cards server-side. Filter/search now works via DOM manipulation (no re-fetch), matching products by toggling `card.style.display`.

### 4. product-detail.js Rewritten — CSS Var Cleanup
Original had mixed CSS var names (`--primary-color`, `--text-light`, etc.). Simplified to use only vars that exist in layout.css. Now server-side renders with proper vars, no client-side JS needed for basic display.

## Products
46 products (Jul 2026). Originally 37, added 11 missing: ST504, ST504 Cabin, Plow Plough, Slasher Mower, Pipe Laying Machine, 1GQN Heavy Duty Rotary Tiller, 1GLN Series Rotary Tiller, Disc Plough, 3Z Cultivator, Adjustable Ridge Machine, 3S Series Subsoiler. Additional products added: ST604, ST704, ST804, ST1204, ST1304, ST1404, ST1604, ST1804, ST2204, ST2404, ST2604, ST504E, ST504Y, ST504 Cabin, plus 20+ farm equipment items. Image URLs from shengtuo.cc.cd CDN (primary) and shengtuo-tractor.com (partial). All verified 200 OK. 4 images shared across products (normal — source site reuses farm implement photos).

## Wrangler Deploy Command
```bash
cd /home/ubuntu/cf_b2b
CLOUDFLARE_API_TOKEN="cfut_..." CLOUDFLARE_ACCOUNT_ID="..." npx wrangler deploy
```

## Social Media URLs
- Facebook: https://www.facebook.com/shengtuo.tractor
- YouTube: https://www.youtube.com/@shengtuo.tractor
- Instagram: https://www.instagram.com/shengtuo_tractor

## Visual Design (layout.js — Jun 2026)
Full visual overhaul.

### Color & Typography
- Primary: `#1a7f37` (agricultural green) — replaced old `#2563eb` blue
- Accent: `#f59e0b` (amber) for CTAs and stat numbers
- Dark: `#111827` for headers
- Font: Inter (Google Fonts) — imported via `<link>` in `<head>`
- Border radius: `--radius: 12px`, `--radius-sm: 8px`

### layout.js CSS Architecture
```css
/* Card image: wrap in .card-image-wrap (fixed height + overflow hidden) */
.card-image-wrap { width: 100%; height: 220px; overflow: hidden; background: var(--gray-100); position: relative; }
.card-image { width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s ease; display: block; }
.card:hover .card-image { transform: scale(1.05); }  /* zoom on hover */

/* Hero: dark gradient + SVG pattern overlay */
.hero { background: linear-gradient(135deg, #0f3d14 0%, var(--primary) 50%, #2d7a3e 100%); }

/* Stats bar: dark background, amber numbers */
.stats-bar { background: var(--dark); padding: 2.5rem; border-radius: var(--radius); }
.stat-number { font-size: 2.5rem; font-weight: 800; color: var(--accent); letter-spacing: -0.03em; }

/* Category cards: centered icon + title + description + button */
.category-card { padding: 2rem; text-align: center; transition: all 0.25s; }
.category-card:hover { border-color: var(--primary); transform: translateY(-4px); }
```

### Pages Updated (Jun 2026)
- **home.js**: Hero + stats bar + 3 category cards + "Why Choose" grid + featured products + CTA section
- **about.js**: Full rewrite with server-side KV settings injection (not JS client-side load)
- **contact.js**: Full rewrite with server-side KV settings injection (not JS client-side load)
- **layout.js**: Complete CSS overhaul — new color system, shadows, transitions, Inter font

### KV Settings Pattern (confirmed working)
Pages that inject settings server-side (read `await env.STATIC_ASSETS.get()` in page handler) work correctly. Pages that rely on JS `fetch('/api/settings')` in the browser may fail silently — always use server-side injection for contact/about/home content.
**Rule**: After updating KV settings, you STILL need to redeploy if the page handler reads from KV on each request. If content doesn't update after KV change, check whether the page uses server-side KV read vs client-side API fetch.

### Product Image Auto-Zoom
All product cards use `.card-image-wrap` wrapper. Fallback placeholder: `https://shengtuo.cc.cd/images/logo.png`. Image error handler: `onerror="this.src='https://shengtuo.cc.cd/images/logo.png';this.onerror=null;"`

## Jul 2026 Live Site Status Check

### ✅ Working (confirmed via browser Jul 10 2026)
- **Home page** — renders correctly with About section, stats bar (25,000m² factory, 15,000+ units/year, 50+ countries), featured products
- **Products listing** — 46 products displayed, category combobox + search textbox present
- **Contact page** — WhatsApp (+86-13806461474), email (sdtractor@outlook.com), address shown correctly
- **About page** — company info rendered
- **sitemap.xml** — valid XML
- **/api/products** — returns full JSON with all 46 products (confirmed via browser console)

### ⚠️ Known Issues (as of Jul 2026)
1. **Product detail links broken** — `/products` "View Details →" links don't navigate. Direct `/products/13` → "Product Not Found". Products exist in D1 (API confirms). Route handler likely has parameter mismatch — check `product-detail.js` route pattern vs `event.params.id`.
2. **Category filter dropdown** — combobox selection changes but product cards don't filter (JS event binding issue on `<select>`).
3. **Typo in product names** — "SHEGNTUO" instead of "SHENGTUO" in some product names (data error in D1, not code).

### Product Count (Jul 2026)
- **Total**: 46 products
- **SHENGTUO TRACTOR**: 19 models (ST254 through ST2604)
- **SHENGTUO FARM EQUIPMENT**: 27 implements (Disc Harrow, Rotary Tiller, Baler, etc.)

### Product Image Sources
- Primary CDN: `https://shengtuo.cc.cd/assets/images/products/` (✅ healthy, verified 200 OK)
- Backup: `https://www.shengtuo-tractor.com/uploadfile/` (⚠️ partial availability)