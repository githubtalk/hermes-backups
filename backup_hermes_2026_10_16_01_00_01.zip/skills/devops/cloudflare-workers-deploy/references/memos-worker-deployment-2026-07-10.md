# Memos Worker Deployment Notes (2026-07-10)

## Project
- Repo: `https://github.com/githubtalk/memos-worker`
- Deployed Worker: `memos-worker.sdtractor.workers.dev`

## Resources Provisioned
- D1 database: `notes-db` (uuid: `b80ab124-5364-4676-92b2-0335c5341fba`)
- KV namespace: `notes-kv` (id: `937f686ff065477faa47c0b5eb00aa32`)
- R2 bucket: `notes-files` (APAC region)

## Deployment Steps
1. `git clone https://github.com/githubtalk/memos-worker.git /tmp/memos-worker`
2. Patch `wrangler.toml` placeholders:
   - `YOUR_D1_DATABASE_ID` / `YOUR_D1_DATABASE_NAME` → real D1 values
   - `YOUR_KV_NAMESPACE_ID` → real KV id
   - `YOUR_R2_BUCKET_NAME` → `notes-files` (3-63 chars, lowercase alphanumeric + hyphens)
3. Initialize D1: `npx wrangler d1 execute notes-db --file=src/schema.sql --remote`
4. Deploy: `CLOUDFLARE_API_TOKEN=... npx wrangler deploy`
5. Set secrets: `npx wrangler secret put USERNAME` and `npx wrangler secret put PASSWORD`

## Issues Encountered
- **wrangler.toml validation error**: `YOUR_R2_BUCKET_NAME` placeholder caused wrangler to fail before resource creation. Patch placeholder first.
- **wrangler d1 create --temporary failed**: 403 proof-of-work challenge in non-interactive environment. Used REST API instead.
- **D1 already existed**: `wrangler d1 create notes-db` returned error 7502. Used list API to find existing DB.

## Related
- See `imgbed-worker-deployment.md` for CloudFlare-ImgBed deployment with auto-generated routes, `functions/` structure, and `npm install --ignore-scripts` workaround.

## Verification
- Worker URL: `https://memos-worker.sdtractor.workers.dev`
- Login page loads with MEMOS branding
- D1 schema initialized: 9 tables, 4 triggers (from schema.sql)
