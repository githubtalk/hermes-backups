# CloudFlare-ImgBed Worker Deployment Notes (Jul 2026)

## Repo Structure
```
deploy/worker/
  index.js          # Entry point; imports auto-generated routes
  generate-routes.js # Scans functions/ and builds route table
  generate-toml.js   # Generates wrangler.toml from env vars (for CI only)
  wrangler.toml      # Placeholder file; must be replaced for manual deploy

functions/           # Business logic modules, imported by index.js
  utils/
    databaseAdapter.js  # Prefers D1 (env.img_d1) over KV (env.img_url)
    sysConfig.js        # Reads settings from D1; falls back to defaults on error
  api/, dav/, file/, random/, upload/  # Route handlers

frontend-dist/       # SPA build output (css/, js/, static/, img/, index.html)
database/
  init.sql           # D1 schema
  migrations/        # Migration scripts
```

## Key Patterns

### 1. Auto-Generated Route Table
`deploy/worker/index.js` imports a pre-built route table. It scans `functions/` and builds a route map:
```js
const routes = [
  { path: '/api/manage/list', module: apiManageList, middlewares: [...] },
  { path: '/upload', module: upload_index, middlewares: [...] },
  ...
];
```
When deploying, ensure `functions/` is present locally. The worker does NOT rely on Workers runtime filesystem scanning.

### 2. Frontend Assets Binding
`wrangler.toml` must declare:
```toml
[assets]
directory = "../../frontend-dist"
binding = "ASSETS"
not_found_handling = "single-page-application"
```
Verify the `directory` path points to the actual frontend build output. Missing/wrong path causes 404s on `/`.

### 3. Database Adapter Abstraction
`functions/utils/databaseAdapter.js` checks env bindings:
- `env.img_d1` present → uses D1 (`D1Database` class)
- `env.img_url` present → uses KV (`KVAdapter` class)
- Neither → logs error, returns null

Configure both `[[d1_databases]]` and `[[kv_namespaces]]` in `wrangler.toml` to avoid fallback surprises.

### 4. Admin Auth Defaults
`functions/api/auth/adminLogin.js` behavior:
- If no admin username/password configured in security config → auto-creates admin session, no auth required
- If configured → validates username/password, then creates session
- Default admin password hash stored in D1 (`auth.admin.adminPassword`)

## Deployment Steps (Manual)
1. Download repo files via raw.githubusercontent.com + Python script (git clone may timeout)
2. Provision D1, KV, R2 via Cloudflare REST API
3. Create `wrangler.toml` manually with real resource IDs
4. Initialize D1: `npx wrangler d1 execute imgbed-db --file=database/init.sql --remote`
5. Install deps: `npm install --ignore-scripts` (esbuild native binary may SIGSEGV in some environments; Workers deploy does not need postinstall scripts)
6. Deploy: `npx wrangler deploy --config deploy/worker/wrangler.toml`
7. Set secrets if needed: `npx wrangler secret put TG_BOT_TOKEN`

## Pitfalls
- `generate-toml.js` is CI-only; do NOT run it manually for production deploy
- `generate-routes.js` output is already committed in `index.js`; no need to regenerate
- Frontend `index.html.gz` exists but wrangler serves from `directory`; do not manually decompress
- KV is "mandatory" per README for legacy compatibility, but D1 is preferred; bind both
- `git clone` may timeout in headless/container environments; use raw.githubusercontent.com fallback
- `npm install` may fail with esbuild SIGSEGV; use `npm install --ignore-scripts` for Workers-only projects
- Downloading `frontend-dist/` via GitHub Contents API can create nested `frontend-dist/frontend-dist/`. After download, move nested contents up one level and remove the extra directory.
- Browser snapshot may show "Page not found" title for Workers with `not_found_handling = "single-page-application"` even when deploy succeeded. Always verify with `curl -sL -D- <worker-url> -o /dev/null | head -20` and `curl -sL <worker-url> | head -20`.

## Successful Deploy Reference (Jul 2026)
- Worker URL: `https://cloudflare-imgbed.sdtractor.workers.dev`
- D1: `imgbed-db` (uuid: `024e42be-27c1-4861-b1dd-40159fd8034c`), init.sql executed successfully: 21 queries, 5 tables
- KV: `imgbed-kv` (id: `e447320583234f69b10108faabfd8552`)
- R2: `imgbed-r2`
- Bindings: `env.img_d1`, `env.img_url`, `env.img_r2`, `env.ASSETS`
- `[assets] directory = "../../frontend-dist"` works when path points to actual build output root
