# Product Comparison & Sync Workflow

Complete workflow for comparing a Cloudflare D1 product catalog against a source website and syncing image URLs + names.

---

## When to Run

- New product catalog sync
- After source site (shengtuo-tractor.com / shengtuo.cc.cd) content changes
- Before any major product listing page redesign

---

## Step 1: Extract Products from Source Site

### Browser Console — Classic ASP / server-rendered sites (shengtuo-tractor.com pattern)

```js
// Sites with <ul class="products_list"> markup
JSON.stringify([...document.querySelectorAll('ul.products_list li')].map(li => {
  const a = li.querySelector('a[href$=".html"]');
  const img = li.querySelector('img');
  return a ? { name: a.title || a.textContent.trim(), href: a.href, img: img ? img.src : null } : null;
}).filter(Boolean));

// For pages with pagination — iterate all pages, then deduplicate by name
```

### Browser Console — Generic product card grids

```js
JSON.stringify([...document.querySelectorAll('[class*="product"], [class*="card"]')].map(el => {
  const a = el.querySelector('a[href*="id="], a[href*=".html"]');
  const img = el.querySelector('img');
  const name = el.querySelector('h3,h2,a[title]');
  return a ? { name: name?.textContent.trim() || a.textContent.trim(), href: a.href, img: img?.src || null } : null;
}).filter(Boolean));
```

---

## Step 2: Match Products (Python)

```python
import json, urllib.request, re

def norm(s):
    return s.upper().replace(' ','').replace('（','(').replace('）',')').replace('—','-')

def extract_model(name):
    m = re.search(r'ST\d+[A-Z]*', norm(name))
    return m.group() if m else norm(name)

# Load DB products
req = urllib.request.Request('https://cf-b2b-website.sdtractor.workers.dev/api/products',
    headers={'User-Agent':'Mozilla/5.0'})
with urllib.request.urlopen(req, timeout=10) as r:
    db = json.loads(r.read())

# Build site product map by model number
site_by_model = {extract_model(p['name']): p for p in site_products}

# Compare
updates = []
for dbp in db['data']:
    db_model = extract_model(dbp['name'])
    if db_model in site_by_model:
        sp = site_by_model[db_model]
        new_img = f"https://www.shengtuo-tractor.com{sp['img']}"  # strip any double-prefix
        if dbp['image_url'] != new_img:
            updates.append((dbp['id'], dbp['name'], new_img, dbp['image_url']))
```

---

## Step 3: Validate Image URLs Before Writing

```bash
# Validate all new image URLs return 200
for url in "https://site.com/uploadfile/xxx.jpg" "https://site.com/uploadfile/yyy.jpg"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "$url")
  echo "$code $url"
done
```

---

## Step 4: Generate & Execute UPDATE SQL

- **One UPDATE per line, no BEGIN/COMMIT** — D1 file execute rejects transaction statements
- Use `WHERE id = N` (not `WHERE name = '...'`) for precision

```sql
UPDATE products SET image_url = 'https://site.com/uploadfile/xxx.jpg' WHERE id = 6;
UPDATE products SET name = 'Corrected Product Name' WHERE id = 14;
```

```bash
npx wrangler d1 execute b2b_database --file=/tmp/update.sql --remote
```

**D1 transaction error** (if you see it):
```
To execute a transaction, please use the state.storage.transaction() or state.storage.transactionSync() APIs
```
→ Remove `BEGIN;` / `COMMIT;` from your SQL file. D1 executes all statements atomically without explicit transactions.

---

## Common Image URL Patterns

| Source | Pattern |
|--------|---------|
| shengtuo-tractor.com | `https://www.shengtuo-tractor.com/uploadfile/YYYYMMDDnnnnnnn.jpg` |
| shengtuo.cc.cd | `https://shengtuo.cc.cd/assets/images/products/product-N-vNNNNN.jpg` |

**Double-prefix bug**: `https://www.shengtuo-tractor.comhttps://www.shengtuo-tractor.com/...` — always check `img.src` in browser console for sites that auto-prefix URLs. Fix with string replacement before saving.

---

## Product Name Mapping Gotcha

Site products often have different casing/spacing than DB:
- Site: `SHENGTUO ST504E TRACTOR ` (uppercase, trailing space)
- DB: `ST504E Tractor` (title case)

Use `extract_model()` (regex on ST+digits) for fuzzy matching. Don't rely on exact string equality — normalize both sides first.

---

## API vs Page Order Discrepancy

When D1 SQL returns correct order but the page renders wrong order:
1. Check if the API handler (`/api/products`) has its own separate query with different ORDER BY
2. API handler and page SSR both query DB independently — fix both queries
3. Common culprit: API uses `ORDER BY created_at DESC` while page SSR uses different sort — make them consistent