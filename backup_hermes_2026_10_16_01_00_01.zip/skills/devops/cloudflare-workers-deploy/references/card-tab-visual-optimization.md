# Card-Tab Visual Optimization (Jul 2026)

tab.xiaoai.tech runs hmhm2022/Card-Tab as a Cloudflare Worker (`cardtab`). The entire app is a single ~156KB `workers.js` with inline HTML/CSS/JS.

## Worker Details
- **Worker name**: `cardtab` (NOT `tab` — API uses worker name, not route)
- **Route**: `tab.xiaoai.tech` (custom domain on zone `xiaoai.tech`)
- **KV namespace**: `501e67fc029a497a80ca3d484ddffbd7` (binding `CARD_ORDER`)
- **Deploy command**: `wrangler deploy --name cardtab`
- **KV namespace ID for API calls**: `501e67fc029a497a80ca3d484ddffbd7`
- **Account ID**: `a0e4e66e8ea4dc776e23626f79e70bdf`

## wrangler.toml Template
```toml
name = "cardtab"
main = "src/index.js"
compatibility_date = "2024-01-01"
routes = [{ pattern = "tab.xiaoai.tech", zone_name = "xiaoai.tech", custom_domain = true }]
preview_urls = false

[vars]
ADMIN_PASSWORD = "661474ef"

[[kv_namespaces]]
id = "501e67fc029a497a80ca3d484ddffbd7"
binding = "CARD_ORDER"
```

## CSS/Visual Optimization

Target strings in `workers.js` (string-replace before deploy):

| Element | Old | New |
|---------|-----|-----|
| Theme green | `#43b883` | `#10b981` |
| Dark green | `#35a674` | `#059669` |
| Background (light) | `#f8f6f2` | `#fafafa` |
| Background (dark) | `#121418` | `#0f172a` |
| Card bg (dark) | `#2a2e38` | `#1e293b` |
| Text color | `#222` | `#1f2937` |

### Background Gradient
```css
/* Light mode */
background: linear-gradient(135deg, #fafafa 0%, #f0f4f8 100%);
/* Dark mode */
background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
```

### Card Style
```css
/* Old */
background-color: white;
border-radius: 8px;
box-shadow: 0 3px 10px rgba(0, 0, 0, 0.06);
border-left: 3px solid #43b883;

/* New */
background: linear-gradient(145deg, #ffffff, #f8fafc);
border-radius: 16px;
box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
border-left: 4px solid #10b981;
```

### Card Hover
```css
.card:hover {
    transform: translateY(-4px) scale(1.02);
    box-shadow: 0 12px 24px rgba(16, 185, 129, 0.15);
    border-left-color: #059669;
}

body.dark-theme .card:hover {
    box-shadow: 0 12px 24px rgba(16, 185, 129, 0.25);
}
```

### Font Stack
```css
font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'PingFang SC', 'Microsoft YaHei', sans-serif;
```

## Deploy Workflow
```bash
# 1. Create project structure
mkdir -p /tmp/cf-cardtab/src
cp workers.js /tmp/cf-cardtab/src/index.js

# 2. Create wrangler.toml (see template above)

# 3. Deploy
CLOUDFLARE_API_TOKEN="cfut_..." \
CLOUDFLARE_ACCOUNT_ID="a0e4e66e8ea4dc776e23626f79e70bdf" \
wrangler deploy --name cardtab
```

## Troubleshooting

### Worker name mismatch
- API says "Worker does not exist" → use `GET /accounts/{id}/workers/scripts` to list actual worker names
- tab.xiaoai.tech maps to worker `cardtab`

### CSS changes not visible after deploy
- Hard refresh: `Ctrl+Shift+R` or `Cmd+Shift+R`
- Or append `?refresh=1` to URL
- Check deployed version ID in wrangler output

### KV data missing after deploy
- Deploy does NOT touch KV data
- Verify with: `curl "https://api.cloudflare.com/client/v4/accounts/{id}/storage/kv/namespaces/{ns_id}/keys" -H "Authorization: Bearer {token}"`