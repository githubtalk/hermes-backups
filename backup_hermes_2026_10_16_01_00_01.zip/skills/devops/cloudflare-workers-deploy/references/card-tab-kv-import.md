# Card-Tab Bookmark Import via CF KV API

tab.xiaoai.tech is a Cloudflare Workers app (hmhm2022/Card-Tab) that stores bookmark data in KV namespace `CARD_ORDER`.

## KV Structure
- Namespace ID: `501e67fc029a497a80ca3d484ddffbd7`
- Key = userId (e.g. `testUser`, or derived from login)
- Value = JSON: `{"links": [...], "categories": {...}}`

## Link Object Shape
```json
{
  "name": "网站名称",
  "url": "https://example.com/",
  "description": "",
  "icon": "",
  "category": "常用网站",
  "isPrivate": false
}
```

## Categories Object Shape
```json
{
  "常用网站": "常用网站",
  "AI工具": "AI工具",
  "社交媒体": "社交媒体",
  "搜索引擎": "搜索引擎",
  "外贸商务": "外贸商务",
  "技术开发": "技术开发",
  "加密货币": "加密货币",
  "其他": "其他"
}
```

## Python Import Script
```python
import re, json, requests

# 1. Parse Chrome bookmarks HTML export
with open("bookmarks.html", "r", encoding="utf-8") as f:
    content = f.read()

links = re.findall(r'<A\s+HREF="([^"]+)"[^>]*>([^<]*)</A>', content)

# 2. Categorize
categories = {"常用网站": [], "AI工具": [], "社交媒体": [], "搜索引擎": [],
              "外贸商务": [], "技术开发": [], "加密货币": [], "其他": []}

for url, title in links:
    title = title.strip() or url.split("/")[-1][:50]
    # categorize by URL patterns...
    categories[cat].append({"name": title, "url": url, "description": "", "icon": "", "category": cat, "isPrivate": False})

# 3. Format for upload
output = {"links": [], "categories": {k: k for k in categories}}
for items in categories.values():
    output["links"].extend(items)

# 4. Upload via CF API
account_id = "a0e4e66e8ea4dc776e23626f79e70bdf"
ns_id = "501e67fc029a497a80ca3d484ddffbd7"
api_token = "cfut_..."

url = f"https://api.cloudflare.com/client/v4/accounts/{account_id}/storage/kv/namespaces/{ns_id}/values/testUser"
requests.put(url, data=json.dumps(output), headers={"Authorization": f"Bearer {api_token}", "Content-Type": "application/json"})
```

## Finding the userId
- userId comes from the frontend JS — check workers.js for `fetch('/api/getLinks?userId=XXX')`
- Default test user: `testUser`
- For custom userId, login to the site and check localStorage or network requests

## Recategorization Workflow

This is the proven recipe for bulk-updating Card-Tab categories in production KV.

### Step 1: Read current data
```bash
curl -s "https://api.cloudflare.com/client/v4/accounts/$ACCOUNT_ID/storage/kv/namespaces/$NS_ID/values/testUser" \
  -H "Authorization: Bearer $API_TOKEN" > /tmp/cardtab_current.json
```

### Step 2: Parse and categorize
Use `python3` to read the JSON, inspect `links[].category`, and map each link to a new category. For complex bookmark sets, build a keyword-based categorizer before bulk-updating.

### Step 3: Deduplicate
Before rewriting, deduplicate on `(name, url)` to avoid duplicates after merge.

```python
seen = set()
unique = []
for link in links:
    key = (link.get("name", ""), link.get("url", ""))
    if key not in seen:
        seen.add(key)
        unique.append(link)
```

### Step 4: Backup old data
Create a timestamped KV backup BEFORE overwriting.

```bash
backup_name="backup_$(date +%Y-%m-%d_%H:%M:%S)_before_recategorize"
curl -s -X PUT "https://api.cloudflare.com/client/v4/accounts/$ACCOUNT_ID/storage/kv/namespaces/$NS_ID/values/$backup_name" \
  -H "Authorization: Bearer $API_TOKEN" \
  -H "Content-Type: application/json" \
  --data-binary @/tmp/cardtab_current.json
```

### Step 5: Upload updated links
Upload only `{"links": [...]}` to `testUser`. Do NOT include `categories` unless the frontend requires it; many builds infer categories from link `category` fields.

```bash
curl -s -X PUT "https://api.cloudflare.com/client/v4/accounts/$ACCOUNT_ID/storage/kv/namespaces/$NS_ID/values/testUser" \
  -H "Authorization: Bearer $API_TOKEN" \
  -H "Content-Type: application/json" \
  --data-binary @/tmp/cardtab_updated.json
```

### Step 6: Verify counts
Re-read `testUser` and count categories to confirm the upload matches expectations.

```python
verify_links = data.get("links", [])
verify_categories = {}
for link in verify_links:
    cat = link.get("category", "其他")
    verify_categories[cat] = verify_categories.get(cat, 0) + 1
```

### Category mapping examples
Common mappings observed on tab.xiaoai.tech:
- Agriculture/tractor keywords → `农业机械`
- Crypto/mining/payment keywords → `加密货币`
- Social platform keywords → `社交媒体`
- Cloud/VPS/dashboard/panel keywords → `技术开发`
- AI platform keywords → `AI工具`
- PDF/scan/seal/tool keywords → `在线工具`
- Bank/payment/tax keywords → `金融/银行`
- eSIM/telecom keywords → `通信/ESIM`
- Email/mailbox keywords → `邮箱服务`

## Verify Import
Navigate to the site, login, and check if bookmarks appear under categorized tabs.