# Cloudflare REST API Quick Reference

Base: `https://api.cloudflare.com/client/v4/accounts/{account_id}`

## Headers
```
Authorization: Bearer {API_TOKEN}
Content-Type: application/json
```

## D1 Database
```bash
# List
curl -s "https://api.cloudflare.com/client/v4/accounts/{id}/d1/database" \
  -H "Authorization: Bearer {token}"

# Create
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/{id}/d1/database" \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{"name": "db_name"}'

# Execute SQL
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/{id}/d1/database/{db_id}/query" \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{"params":[],"queries":[{"params":[],"sql":"SELECT * FROM admins"}]}'
```

## R2 Bucket
```bash
# Create
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/{id}/r2/buckets" \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{"name": "bucket-name"}'
```

## KV Namespace
```bash
# Create
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/{id}/storage/kv/namespaces" \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{"title": "namespace-name"}'

# Write key (raw)
curl -s -X PUT "https://api.cloudflare.com/client/v4/accounts/{id}/storage/kv/namespaces/{ns_id}/values/{key}" \
  -H "Authorization: Bearer {token}" \
  --data-binary '{"foo":"bar"}'
```

## Workers
```bash
# List scripts
curl -s "https://api.cloudflare.com/client/v4/accounts/{id}/workers/scripts" \
  -H "Authorization: Bearer {token}"

# Delete script
curl -s -X DELETE "https://api.cloudflare.com/client/v4/accounts/{id}/workers/scripts/{script_name}" \
  -H "Authorization: Bearer {token}"
```

## wrangler v4 syntax (for reference)
```bash
# KV key write — MUST use --path, must add --remote
npx wrangler kv key put "key" --path /tmp/file.json --namespace-id <uuid> --remote

# D1 execute — MUST add --remote
npx wrangler d1 execute db_name --file=schema.sql --remote

# Deploy
npx wrangler deploy
```

## Current Account (from session)
- Account ID: `a0e4e66e8ea4dc776e23626f79e70bdf`
- API Token env var: `CLOUDFLARE_API_TOKEN`
- KV namespace for cf_b2b: `d560f5c23c8d405b954afa2006ccf2d4`
- D1 database for cf_b2b: `b2b_database` (id: `761a885a-2ce1-43da-...`)