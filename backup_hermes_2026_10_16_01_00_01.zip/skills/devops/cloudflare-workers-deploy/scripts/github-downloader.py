#!/usr/bin/env python3
"""Download a GitHub repo directory tree via raw.githubusercontent.com.

Usage:
  python3 scripts/github-downloader.py <owner> <repo> <branch> <local-dir> [path]

Examples:
  python3 scripts/github-downloader.py MarSeventh CloudFlare-ImgBed main /tmp/CloudFlare-ImgBed
  python3 scripts/github-downloader.py MarSeventh CloudFlare-ImgBed main /tmp/CloudFlare-ImgBed functions
"""
import urllib.request, json, os, sys

BASE = "https://api.github.com/repos/{owner}/{repo}/contents"
RAW = "https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{path}"


def fetch_json(url):
    req = urllib.request.Request(url, headers={
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "github-downloader"
    })
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read())


def dl(url, dest):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    urllib.request.urlretrieve(url, dest)


def recurse(owner, repo, branch, path, local_root):
    api = BASE.format(owner=owner, repo=repo)
    url = f"{api}/{path}?ref={branch}"
    items = fetch_json(url)
    for it in items:
        local = os.path.join(local_root, it["path"])
        if it["type"] == "file":
            raw_url = RAW.format(owner=owner, repo=repo, branch=branch, path=it["path"])
            dl(raw_url, local)
        elif it["type"] == "dir":
            recurse(owner, repo, branch, it["path"], local_root)


def main():
    if len(sys.argv) < 5:
        print(__doc__)
        sys.exit(1)
    owner, repo, branch, local_dir = sys.argv[1:5]
    start_path = sys.argv[5] if len(sys.argv) > 5 else ""
    os.makedirs(local_dir, exist_ok=True)
    recurse(owner, repo, branch, start_path, local_dir)
    print("Done.")


if __name__ == "__main__":
    main()
