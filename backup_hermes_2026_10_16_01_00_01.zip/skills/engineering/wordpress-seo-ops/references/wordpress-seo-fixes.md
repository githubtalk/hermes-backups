# WordPress SEO 常见修复速查

## robots.txt 被 Nginx 拒绝

**症状**：`curl https://example.com/robots.txt` 返回 403
**根因**：Nginx 的 `location ~ /\. { deny all; }` 规则拦截了以 `.` 开头的文件，包括 `robots.txt`
**修复**：在 Nginx conf 的对应 `server {}` 块中添加：
```nginx
location = /robots.txt {
    allow all;
    log_not_found off;
    access_log off;
}
```
注意：必须放在 `location ~ /\. { deny all; }` 之前。修改后执行 `nginx -t && systemctl reload nginx`。
同时确保 `robots.txt` 文件存在且权限为 `644`，属主为 `www-data:www-data`。

## Sitemap 索引异常

**症状**：`/sitemap_index.xml` 返回 404 或子地图数量不对
**排查**：
1. Yoast SEO 是否启用：`wp option get wpseo` 中 `enable_xml_sitemap` 应为 `b:1`
2. 固定链接是否正常：`curl https://example.com/post-sitemap.xml` 应返回 200
3. 如果 sitemap 被缓存插件截断，清缓存：`wp cache flush && wp litespeed-purge all`

## `<html lang>` 与后台语言不一致

**症状**：后台是 `zh_CN`，但前端显示 `<html lang="en-US">`
**根因**：WordPress 7.x 使用 `determine_locale()` 优先取用户 meta，可能返回 `en_US`
**修复**：创建 `wp-content/mu-plugins/force-locale.php`：
```php
<?php
add_filter( 'locale', function() { return 'zh_CN'; } );
add_filter( 'determine_locale', function() { return 'zh_CN'; } );
```
文件权限必须 `www-data:www-data 644`，目录 `wp-content/mu-plugins/` 为 `755`。
**不要**放在 `wp-config.php` 里——那里 `add_filter()` 尚未定义，会导致 500。

## Yoast meta description 前端不输出

**症状**：`_yoast_wpseo_metadesc` 在数据库里有值，但源码里没有 `<meta name="description">`
**真相**：Yoast 在某些页面类型上只输出 `og:description` 和 JSON-LD 中的 `description`，不输出 `<meta name="description">`。这是正常行为。
**验证方法**：抓源码确认实际输出，不要只看后台编辑器或数据库。

## 清理测试内容后索引不同步

**症状**：批量删除测试文章后，Yoast 后台仍显示"有未索引内容"
**修复**：重建 Yoast 索引
```bash
wp --path=/var/www/site yoast index
# 或后台：SEO > Tools > Rebuild index
```
如果 CLI 不可用，访问 `/?yoast-index=true` 或等待 cron 自动重建。

## favicon.ico 产生 404 噪音

**症状**：error log 大量 `open() "/path/to/site/favicon.ico" failed (2: No such file or directory)`
**修复**：在网站根目录放一个最小 favicon：
```bash
# 用 Python 生成 1x1 透明 ICO
python3 << 'PYEOF'
import struct
ico_header = struct.pack('<HHH', 0, 1, 1)
png = (b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89'
       b'\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\r\n-\xb4'
       b'\x00\x00\x00\x00IEND\xaeB`\x82')
with open('favicon.ico', 'wb') as f:
    f.write(ico_header + png)
PYEOF
chown www-data:www-data favicon.ico
chmod 644 favicon.ico
```

## 中文 slug 返回 404

**症状**：`curl https://example.com/关于我们/` 返回 404
**排查**：
1. 先确认页面存在：`curl "https://example.com/?p=5"` 或后台查看页面 ID
2. 如果 `?p=ID` 正常，说明是 rewrite 问题
3. 检查 Nginx `try_files $uri $uri/ /index.php?$args;` 是否存在
4. 考虑改用 `/sample-page/` 类纯英文 slug 避免编码问题

## mu-plugins 文件权限导致静默跳过

**症状**：PHP error log 出现 `include_once(.../mu-plugins/xxx.php): Permission denied`
**根因**：mu-plugin 文件属主是 `root:root`，PHP-FPM 以 `www-data` 运行，无读取权限
**修复**：
```bash
chown -R www-data:www-data wp-content/mu-plugins/
chmod 755 wp-content/mu-plugins/
chmod 644 wp-content/mu-plugins/*.php
```
