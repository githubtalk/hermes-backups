---
name: xiaomi-mimo
description: Xiaomi MiMo free-ai client. Use when calling mimo-auto or basic MiMo V2.5-style APIs that return OpenAI-compatible chat completions.
---

# Xiaomi MiMo

通过 `https://api.xiaomimimo.com` 调用免费 MiMo 接口，返回 OpenAI 兼容结果。

## Prerequisites

- `curl`
- `jq`
- Python 3 (optional)

## Bootstrap: get JWT

先获取临时 JWT：

```bash
source "$HOME/.hermes/skills/xiaomi-mimo/scripts/bootstrap.sh"
```

> `bootstrap.sh` 会暴露 `$MIMO_JWT`。

## Call Chat

流式：

```bash
source "$HOME/.hermes/skills/xiaomi-mimo/scripts/call_chat.sh" \
  -m "你好" \
  --stream
```

非流式：

```bash
source "$HOME/.hermes/skills/xiaomi-mimo/scripts/call_chat.sh" \
  -m "你好" \
  --no-stream
```

## Response shape

标准 OpenAI `chat.completions` 格式。额外可能有：

- `choices[0].message.reasoning_content`
- `choices[0].message.content`

## Caveats

- 禁止硬编码密钥/JWT。每次调用前 `source bootstrap.sh`。
- 已知 endpoint 路径：`/api/free-ai/openai/chat`。
- 必需 header：`X-Mimo-Source: mimocode-cli-free`。
- 鉴权流程：先调 `/api/free-ai/bootstrap` 拿 JWT，再用 JWT Bearer 调 chat。直接用 `sk-xxx` 或 `tp-xxx` 会返回 401。
- 响应字段：标准 OpenAI `chat.completions`，但 model 固定返回 `mimo-auto`，且可能有 `reasoning_content`。
- Hermes fallback 不可用：因 JWT 是动态的、需要自定义 header、endpoint 非标准 `/v1/chat/completions`，不能直接接入 Hermes 主模型链。
- 403 Illegal access 表示 key/JWT 已被服务端识别，但当前账号无权访问该模型或 endpoint。
