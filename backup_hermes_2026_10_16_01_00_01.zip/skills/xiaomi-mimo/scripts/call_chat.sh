#!/usr/bin/env bash
# Call MiMo chat.
# Usage:
#   source "$HOME/.hermes/skills/xiaomi-mimo/scripts/call_chat.sh" -m "你好" [--stream] [--no-stream]
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
bootstrap="$script_dir/bootstrap.sh"

if [[ ! -f "$bootstrap" ]]; then
  echo '[mimo] missing bootstrap.sh' >&2
  return 1 2>/dev/null || exit 1
fi
source "$bootstrap"

if [[ -z "${MIMO_JWT:-}" ]]; then
  echo '[mimo] MIMO_JWT not set' >&2
  return 1 2>/dev/null || exit 1
fi

if [[ $# -lt 1 ]]; then
  echo '[mimo] Usage: call_chat.sh -m "text" [--stream|--no-stream]' >&2
  return 1 2>/dev/null || exit 1
fi

model="mimo-auto"
stream="true"
args=("$@")

for i in "${!args[@]}"; do
  case "${args[i]}" in
    -m|--message)
      msg="${args[$((i+1))]}"
      ;;
    --model)
      model="${args[$((i+1))]}"
      ;;
    --stream)
      stream="true"
      ;;
    --no-stream)
      stream="false"
      ;;
  esac
done

if [[ -z "${msg:-}" ]]; then
  echo '[mimo] missing message (-m)' >&2
  return 1 2>/dev/null || exit 1
fi

api_url='https://api.xiaomimimo.com/api/free-ai/openai/chat'
if [[ "$stream" == "true" ]]; then
  cmd=(
    curl -N -s "$api_url"
    -H "Authorization: Bearer $MIMO_JWT"
    -H 'X-Mimo-Source: mimocode-cli-free'
    -H 'Content-Type: application/json'
    -d "{\"model\":\"${model}\",\"messages\":[{\"role\":\"user\",\"content\":\"${msg}\"}],\"max_tokens\":128000,\"stream\":true,\"temperature\":1.0}"
  )
  "${cmd[@]}"
else
  out=$(mktemp)
  code=$(curl -s -o "$out" -w '%{http_code}' "$api_url" \
    -H "Authorization: Bearer $MIMO_JWT" \
    -H 'X-Mimo-Source: mimocode-cli-free' \
    -H 'Content-Type: application/json' \
    -d "{\"model\":\"${model}\",\"messages\":[{\"role\":\"user\",\"content\":\"${msg}\"}],\"max_tokens\":128000,\"stream\":false,\"temperature\":1.0}" || true)
  body=$(cat "$out"); rm -f "$out"
  echo "$body"
  if [[ "$code" =~ ^[45] ]]; then
    return 1 2>/dev/null || exit 1
  fi
fi
