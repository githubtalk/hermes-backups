#!/usr/bin/env bash
# Get a fresh MiMo JWT and export it.
set -euo pipefail

resp=$(curl -s -X POST 'https://api.xiaomimimo.com/api/free-ai/bootstrap' \
  -H 'Content-Type: application/json' \
  -d '{"client":"hermes-agent"}')

export MIMO_JWT
MIMO_JWT=$(printf '%s' "$resp" | jq -r '.jwt // empty')

if [[ -z "${MIMO_JWT:-}" ]]; then
  echo '[mimo] bootstrap failed' >&2
  echo "$resp" >&2
  return 1 2>/dev/null || exit 1
fi

echo "[mimo] bootstrap ok"
