---
name: .archive
description: Archive metadata directory. Not a standalone skill; contains curated skill backups and auxiliary roles.
---

# Archived skills

This directory holds archived copies/sub-themes of skills. It is not a standalone skill module.
