---
name: communication
description: Communication and messaging workflows — email, social media, and platform interactions.
version: 1.0.0
metadata:
  hermes:
    tags: [communication, email, social, messaging]
    related_skills: [himalaya, xurl]
---

# Communication

## Overview

Communication and messaging workflows — email sending/receiving/searching, social media posting/monitoring, and platform interactions.

## Email

Skills for sending, receiving, searching, and managing email from the terminal.

### Mails.dev Email CLI

For Mails.dev email infrastructure for AI agents — send/receive emails via `imclaw@mails.dev`, inbox checking, HTML email, and confirmation code verification — see `references/mails-cli.md`. Requires `bun` runtime.

### Himalaya

For Himalaya CLI (IMAP/SMTP email from terminal) — see the `himalaya` sub-skill.

## Social Media

Skills for interacting with social platforms — posting, reading, monitoring, and account operations.

### X/Twitter (xurl)

For X/Twitter operations via xurl CLI — post, search, DM, media, v2 API — see the `xurl` sub-skill.

## Sub-skills

- **himalaya**: Himalaya CLI: IMAP/SMTP email from terminal
- **xurl**: X/Twitter via xurl CLI: post, search, DM, media, v2 API

## Usage

Load individual skills from this category using:
```
skill_view(name="communication/{sub_skill}")
```
