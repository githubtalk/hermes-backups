---
name: obsidian
description: Agent skills for Obsidian knowledge management, CLI, markdown, bases, and canvas.
version: 1.0.0
metadata:
  hermes:
    tags: [obsidian, knowledge-management]
    related_skills: ['note-taking']
---

# Obsidian Skills

Agent skills for working with Obsidian vaults, markdown, bases, and canvas files.

## Sub-skills

- **obsidian-cli**: Interact with Obsidian vaults using the Obsidian CLI to read, create, search, and manage notes, tasks, properties, and more.
- **obsidian-markdown**: Create and edit Obsidian Flavored Markdown with wikilinks, embeds, callouts, properties, and other Obsidian-specific syntax.
- **obsidian-bases**: Create and edit Obsidian Bases (.base files) with views, filters, formulas, and summaries.
- **json-canvas**: Create and edit JSON Canvas files (.canvas) with nodes, edges, groups, and connections.
- **defuddle**: Extract clean markdown content from web pages using Defuddle CLI, removing clutter and navigation to save tokens.

## Usage

Load individual skills from this category using:
```
skill_view(name="obsidian/{sub_skill}")
```

## Source

These skills are synced from [kepano/obsidian-skills](https://github.com/kepano/obsidian-skills).
