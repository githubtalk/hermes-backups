---
description: Note taking skills, to save information, assist with research, and collab on multi-session planning and information sharing.
---

# Note Taking

Skills for taking notes, saving information, assisting with research, and collaborating on multi-session planning.

## Obsidian Knowledge Management

For working with Obsidian vaults, markdown, bases, and canvas files — see the `obsidian` sub-skill.

### Obsidian Sub-skills

- **obsidian-cli**: Interact with Obsidian vaults using the Obsidian CLI to read, create, search, and manage notes, tasks, properties, and more.
- **obsidian-markdown**: Create and edit Obsidian Flavored Markdown with wikilinks, embeds, callouts, properties, and other Obsidian-specific syntax.
- **obsidian-bases**: Create and edit Obsidian Bases (.base files) with views, filters, formulas, and summaries.
- **json-canvas**: Create and edit JSON Canvas files (.canvas) with nodes, edges, groups, and connections.
- **defuddle**: Extract clean markdown content from web pages using Defuddle CLI, removing clutter and navigation to save tokens.

## Usage

Use this skill when you need to create, organize, or search notes across sessions.

Load individual skills from this category using:
```
skill_view(name="note-taking/{sub_skill}")
```