---
name: hermes-cleanup
description: Completely remove Hermes features, skills, cron jobs, and traces. Use when the user asks to uninstall, delete, cancel, or remove any Hermes integration, skill, MCP server, or scheduled job.
---

# Hermes Cleanup

Completely remove a Hermes feature and all its traces.

## When to Use

- User asks to uninstall, delete, cancel, or remove a Hermes feature
- User asks to stop a scheduled job or integration
- Cleaning up deprecated skills, MCP servers, or automations

## Workflow

### 1. Inventory All Components

A Hermes feature can live in multiple places. Check ALL of these:

- **Active skills**: `~/.hermes/skills/<feature-name>/`
- **Archived skills**: `~/.hermes/skills/.archive/*/<feature-name>/`
- **Cron jobs**: Use `cronjob action=list` and grep for the feature name
- **Memory**: `~/.hermes/memories/MEMORY.md` and other memory files
- **Scripts**: `~/.hermes/scripts/` for feature-specific scripts
- **Config**: `~/.hermes/config.*` for any references
- **State**: `~/.hermes/state/` for cached data or indexes
- **Prompt snapshots**: `~/.hermes/.skills_prompt_snapshot.json`

### 1b. Check Embedded References in Parent/Umbrella Skills

A feature may have been folded into another skill rather than living in its own directory. Check:
- **Parent skills** that list the feature under `Sub-skills` or `Labeled Sections`
- **Child skill directories** within umbrella skills that reference the feature
- **references/** files inside other skills that import the feature's MCP tools or workflows

### 2. Remove Cron Jobs

Use the `cronjob` tool with `action=remove` and the specific `job_id`. Do NOT rely on `crontab -l` alone — Hermes has its own cron system in `~/.hermes/cron/jobs.json`.

### 3. Remove Skill Files

Delete the skill directory. Check both:
- `~/.hermes/skills/<feature-name>/`
- `~/.hermes/skills/.archive/*/<feature-name>/`

### 4. Clean Memory

Remove memory entries that reference the removed feature. Use `memory` tool with `action=remove`.

### 5. Verify Complete Removal

Run a grep to confirm no active references remain:
```bash
grep -ri "<feature-name>" ~/.hermes/ --exclude-dir={node_modules,.git}
```

Exclude historical reference files that are not actively loaded (e.g., `skills/github/references/`).

## Pitfalls

- **Don't forget `.archive/`**: Old skills are often moved here, not deleted.
- **Don't forget memory**: Stale memory entries about removed features cause confusion.
- **Use `cronjob` tool, not `crontab`**: Hermes scheduled jobs are managed by Hermes, not system cron.
- **Verify after removal**: Always grep for the feature name to catch hidden references in config, state, or snapshots.
+- **Rename embedded tool references**: If a removed feature's MCP tools were referenced in another skill's `references/` files, update those tool names to generic equivalents or remove them.

## References

- `references/removal-checklist.md` — complete checklist for feature removal
