# Hermes Feature Removal Checklist

Use this checklist when removing any Hermes feature, skill, MCP server, or cron job.

## Pre-Removal Inventory

- [ ] List all cron jobs: `cronjob action=list` | grep for feature name
- [ ] Check active skills: `ls ~/.hermes/skills/` | grep feature
- [ ] Check archived skills: `ls ~/.hermes/skills/.archive/*/` | grep feature
- [ ] Check memory: `grep -ri "feature-name" ~/.hermes/memories/`
- [ ] Check scripts: `ls ~/.hermes/scripts/` | grep feature
- [ ] Check config: `grep -ri "feature-name" ~/.hermes/config.*`
- [ ] Check state: `grep -ri "feature-name" ~/.hermes/state/`
- [ ] Check prompt snapshots: `grep -ri "feature-name" ~/.hermes/.skills_prompt_snapshot.json`
+- [ ] Check embedded references in parent/umbrella skills: grep for feature name inside `~/.hermes/skills/*/SKILL.md` and `~/.hermes/skills/*/references/*.md`

## Removal Steps

### Cron Jobs
- [ ] Remove each job by ID: `cronjob action=remove job_id=<id>`

### Skills
- [ ] Delete active skill dir: `rm -rf ~/.hermes/skills/<feature-name>/`
- [ ] Delete archived skill dir: `rm -rf ~/.hermes/skills/.archive/*/<feature-name>/`

### Memory
- [ ] Remove memory entries: `memory action=remove old_text="..." target=memory`

### Scripts (if any)
- [ ] Delete feature scripts: `rm ~/.hermes/scripts/<feature-*`

### Config (if any)
- [ ] Remove feature references from config files

## Post-Removal Verification

```bash
grep -ri "<feature-name>" ~/.hermes/ --exclude-dir={node_modules,.git}
```

Expected output: No active references (only historical archives or references files in other skills are acceptable). If references remain in other skills, decide whether to update them to generic equivalents or remove them entirely.

## Common Features to Remove

| Feature | Skill Location | Cron Job Pattern |
|---------|---------------|------------------|
| TrendRadar | `trend-radar-daily`, `.archive/social-media/trendradar` | `TrendRadar` |
| GitHub Sync | Check `scripts/` for `github_sync.py`, `github_knowledge.py` | `GitHub` |
| Hermes Curator | Check `scripts/` for `hermes_curator.py` | `Curator` |
| Skills Sync | Check `scripts/` for `skills_sync.py` | `Hermes House` |
